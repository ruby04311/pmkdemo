<?php
if(!defined('BASEPATH')) exit('No direct script access allowed');
date_default_timezone_set('UTC');
class Cron extends CI_Controller {

	/**
	 * 
	 * Index Page for this controller.
	 * 
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 * 	- or -
	 * 		http://example.com/index.php/welcome/index
	 * 	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 * 
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 * 
	 */
	 
 	public function __construct() {

		parent::__construct();
		$this->load->model('case_handling_model');
		$this->load->model('cron_model');

		function array_intersecting( $output , $count ) {

			if( $count == 1 )
					return $output[0];
			else if( $count == 2 )
					return array_intersect( $output[0] ,  $output[1] );
			else if( $count == 3 )
					return array_intersect( $output[0] ,  $output[1],  $output[2] );
			else if( $count == 4 )
					return array_intersect( $output[0] ,  $output[1],  $output[2],  $output[3] );
			else if( $count == 5 )
					return array_intersect( $output[0] ,  $output[1], $output[2],  $output[3],  $output[4] );
			else if( $count == 6 )
					return array_intersect( $output[0] ,  $output[1], $output[2],  $output[3],  $output[4], $output[5] );
			else
				return array();
		}

		#file_put_contents("/code/production/b2c/html/time.txt", date('Y-m-d H:i:s') .'++++++++++++++++++++++++++'. gmdate("Y-m-d H:i:s") );
	}

	public function index() {
		$DB1 = $this->load->database( 'live', TRUE );
		#$v = $this->cron_model->email_tpl( '11' , 'pl' ); print_r($v);
		#$Q1 = $this->cron_model->emailing_airline( 'AA' ); print_r( $Q1->row() );
		#$Q1 = $this->cron_model->emailing_passenger( $DB1, 3 ); print_r( $Q1->row() );
		#$case_id = '28782'; $log = "Develoer Testing...";
		#$this->cron_model->activility( $DB1, $case_id ,  $log );
		date();
		exit('#');
	}

	private function case_status_log( $case_id ) {
		$DB1 = $this->load->database('live', TRUE);
		$sql1 = "select log_entry_ts  from case_status_log where case_id = '$case_id'";
		if( $DB1->query($sql1)->num_rows() ) {
			return $DB1->query( $sql1 )->row()->log_entry_ts;
		} else {
			return '';
		}
	}
	
	private function pivotal_project_code( $pivotal_project_id ) {
		$DB1 = $this->load->database('live', TRUE);
		$sql1 = "select project_code from pivotal_project where pivotal_project_id = '$pivotal_project_id' ";
		if( $DB1->query($sql1)->num_rows() ) {
			return $DB1->query($sql1)->row()->project_code;
		} else {
			return '';
		}
	}
	
	public function collect_cases( $single = '' ) {

		$DB1 = $this->load->database('live', TRUE);
		$res = $this->cron_model->condition_actions( $single );
		$cron_time = time();
		#echo $this->db->last_query(); exit;

		$output = array();
		if($res) {
			$case_ids = array();
			#print_r($res);

			$o_outcome_status = '';
			$o_outcome_case_substatus = '';
			$out = array();
			$result = array();
			foreach( $res as $gi => $r ) {

				$condition_id = $r->id;
				$new_status = $r->new_status;
				$set_labels = $r->set_labels;
				$remove_levels = $r->remove_levels;
				$send_email_tpl = $r->send_email_tpl;
				$receiver_code = $r->receiver_code;
				$case_log_text_id = $r->case_log_text_id;
				$actions = base64_encode( $condition_id.'|'.$new_status.'|'.$set_labels.'|'.$remove_levels.'|'.$send_email_tpl.'|'.$receiver_code.'|'.$case_log_text_id );

				##############################################################################
				$status = $r->status;
				$llc = $r->Logical_lable_condition;
				$cf_iata = $r->cf_iata;
				$pivotal = $r->pivotal;
				$DinP = $r->DinP;
				$DinS = $r->DinS;
				$excluded_cf_iata = $r->excluded_cf_iata;
				##############################################################################							

				if( $DinS ) {
					$sql_res = $this->cron_model->days_status( $DB1, $DinS );
					$out = array();
					foreach( $sql_res as $sr ) $out[] = $sr->case_id.'|'.$sr->case_reference_num.'|'.$sr->passenger_id.'|'.$sr->user_language.'|'.$sr->operating_airline_code.'|'.$sr->refund_class_id.'|'.$sr->case_received_utc .'|'. $actions ;
					if( !empty($out) ) $output[] = $out; else $output[] = array();
				}


				if( strlen($status) > 3 ) {
					$o = @explode( ',', str_replace("(","",str_replace(")","",$status)) );
					$o_outcome_status = @$o[0];
					$o_outcome_case_substatus = @$o[1];

					$sql_res = $this->cron_model->case_status( $DB1, $o_outcome_status , $o_outcome_case_substatus );
					$out = array();
					foreach( $sql_res as $sr ) $out[] = $sr->case_id.'|'.$sr->case_reference_num.'|'.$sr->passenger_id.'|'.$sr->user_language.'|'.$sr->operating_airline_code.'|'.$sr->refund_class_id.'|'.$sr->case_received_utc .'|'. $actions ;
					if( !empty($out) ) $output[] = $out; else $output[] = array();
				}

				if( $DinP ) {
					$sql_res = $this->cron_model->days_pivotal( $DB1, $o_outcome_status , $o_outcome_case_substatus, $DinP );
					$out = array();
					foreach( $sql_res as $sr ) $out[] = $sr->case_id.'|'.$sr->case_reference_num.'|'.$sr->passenger_id.'|'.$sr->user_language.'|'.$sr->operating_airline_code.'|'.$sr->refund_class_id.'|'.$sr->case_received_utc .'|'. $actions ;
					if( !empty($out) ) $output[] = $out; else $output[] = array();
				}

				if( $llc ) {

					// (L1,n) AND (L2,m)
					// (L1,n) OR (L2,m)

					$label_name = " cl.label_name != '' ";
					if( strpos($llc , 'AND') !== false && strpos($llc , 'OR') === false  && strpos($llc , '!') === false  ) {
						if( preg_match_all( '!\(([^\)]+)\)!', $llc, $match ) )  $_and = $match[1];
						if(!empty($_and))
						foreach( $_and as $_a ) {
							$v = @explode("," , $_a )[0];
							$label_name .= " OR cl.label_name = '$v' ";
						}
					}

					if( strpos($llc , 'OR') !== false && strpos($llc , 'AND') === false  && strpos($llc , '!') === false  ) {
					    if( preg_match_all( '!\(([^\)]+)\)!', $llc, $match ) )  $_or = $match[1];
					    if(!empty($_or))
						foreach( $_or as $_o ) {
							$v = @explode( "," , $_o )[0];
							$label_name .= " OR cl.label_name = '$v' ";
						}
					}

					if( $label_name == " cl.label_name != '' " ) $label_name = " cl.label_name = '$llc' ";

					$sql_res = $this->cron_model->case_label_conditions( $DB1, $o_outcome_status , $o_outcome_case_substatus , $llc , $label_name );					
					$out = array();
					foreach( $sql_res as $sr ) $out[] = $sr->case_id.'|'.$sr->case_reference_num.'|'.$sr->passenger_id.'|'.$sr->user_language.'|'.$sr->operating_airline_code.'|'.$sr->refund_class_id.'|'.$sr->case_received_utc .'|'. $actions;
					if(!empty($out)) $output[] = $out; else $output[] = array();
				}

				if( $cf_iata ) {

					$sql_res = $this->cron_model->case_cf_iata( $DB1, $o_outcome_status , $o_outcome_case_substatus , $cf_iata );
					$out = array();
					foreach( $sql_res as $sr ) $out[] = $sr->case_id.'|'.$sr->case_reference_num.'|'.$sr->passenger_id.'|'.$sr->user_language.'|'.$sr->operating_airline_code.'|'.$sr->refund_class_id.'|'.$sr->case_received_utc .'|'. $actions ;
					if(!empty($out)) $output[] = $out; else $output[] = array();
				}


				if($pivotal) {
					$sql_res = $this->cron_model->case_pivotal_conditions( $DB1, $pivotal );
					$out = array();
					foreach( $sql_res as $sr ) $out[] = $sr->case_id.'|'.$sr->case_reference_num.'|'.$sr->passenger_id.'|'.$sr->user_language.'|'. $sr->operating_airline_code.'|'.$sr->refund_class_id.'|'.$sr->case_received_utc .'|'. $actions ;
					if(!empty($out)) $output[] = $out; else $output[] = array();
				}
				
				$result = array_intersecting( $output , count( $output ) );

				if($excluded_cf_iata) {
					$sql_res = $this->cron_model->case_not_cf_iata( $DB1, $o_outcome_status , $o_outcome_case_substatus , $excluded_cf_iata );
					foreach( $sql_res as $sr ) {
						if(isset($result)) {
							foreach( $result as $k => $resultn ) {
								$exclude = @explode( "|", $resultn )[0];
								if( $sr->case_id == $exclude && isset($result[$k]) ) unset( $result[$k] );
							}
						}
					}
				}

				$output = array();
				$db = array();
				if(isset($result)) {
					$result = array_unique($result);
					foreach( $result as $resultn ) {
						if( ! $this->cron_model->check_crons($resultn) ) {
							if($single)
								$db[] = array( 'data' => $resultn, 'cron_time' => $cron_time , 'status' => 2 , 'time_stamp' => date('Y-m-d H:i:s') );
							else
								$db[] = array( 'data' => $resultn, 'cron_time' => $cron_time , 'time_stamp' => date('Y-m-d H:i:s') );
						}
					}
				}
				$result = array();
				if( isset($db) && count($db) > 0 )  $this->db->insert_batch( 'temp_cron', $db ); 
			}
			#############################################################################


		   	########### History-Log ##################################################################
			if( @$this->session->userdata('employee_id') &&  @$this->session->userdata('first_name') && @$this->session->userdata('email_address') ) {
				$group_owner = 'Emp:'. $this->session->userdata('employee_id');
				$group_owner .= 'Email:'.$this->session->userdata('first_name').'<'.$this->session->userdata('email_address').'>';
			} else {
				$group_owner = 'Admin/Cron';
			}

			
			$title = 'Auto Cron Task Handling - Cron #'  . $cron_time ;

			$case_handling_history = array( 'owner_group' => $group_owner ,
											'title' => $title ,
											'detail_in_file' => $cron_time ,
											'handling_date' => date('Y-m-d H:i:s')
										  );
			$this->case_handling_model->save_history( $case_handling_history );
			##########################################################################################

		}
	}

	public function actions_cron( $single = '' ) {
		
		$DB1 = $this->load->database('live', TRUE);
   		$arr = $this->db->query("select id, data from temp_cron where status = 0 or status = 2 order by status, id desc limit 2")->result();
   		
   		#print_r($arr);exit;
   		if(!empty($arr)) {

	   		foreach($arr as $a ) {

   		  		$record = $a->data;
   		  		$tid = $a->id;
   		  		$v = explode( "|" ,  $record );
   		  		$case_id = $v[0];
   		  		$case_ref = $v[1];
   		  		$passenger_id = $v[2];
   		  		$user_language = $v[3];
   		  		$airline_code = $v[4];
				$refund_class_id = $v[5];
				$case_received_utc = $v[6];

   		  		$actions = @base64_decode( $v[7] );
   		  		$aa = @explode( "|" , $actions );
   		  		
   		  		$condition_id = @$aa[0];
   		  		$new_status = @$aa[1];
   		  		$set_labels = @$aa[2];
   		  		$remove_levels = @$aa[3];
   		  		$email_tpl = @$aa[4];
   		  		$email_to_code = @$aa[5];
   		  		$case_log_text_id = @$aa[6];

				$n = @explode(',', str_replace("(","",str_replace(")","", $new_status )) );
				$n_outcome_status = @$n[0]; $n_outcome_case_substatus = @$n[1];


   		  		/*** ********************** ***/
   		  		$to_email = '';
   		  		$this->action_custom( $DB1 , $case_id,  $set_labels, $remove_levels,  $n_outcome_status, $n_outcome_case_substatus , $case_log_text_id );
				
				$refund_amount = $this->cron_model->refund_amount( $DB1 , $refund_class_id );

				if( $email_to_code == "A" ) {
					if($airline_code) {
						$email_logs = $this->emailing_airline( $DB1 , $airline_code, $email_tpl, $case_ref ,$case_id, $user_language , $case_received_utc, $refund_amount);
						$to_email = 'A: '. $email_logs[0];
						if( $email_logs[0] == '' ) $to_email = 'No Email';
					}else{
						$to_email = '-- No Airline Code --';
					}
				} else if( $email_to_code == "P" ) {
					$email_logs = $this->emailing_passenger( $DB1 , $passenger_id, $email_tpl, $case_ref ,$case_id, $user_language , $case_received_utc, $refund_amount );
					$to_email = 'P: '. $email_logs[0];
					if( $email_logs[0] == '' ) $to_email = 'No Email';
				} else if( strlen($email_to_code) > 3 ) {
					$email_logs = $this->emailing_custom( $DB1 , $email_to_code , $email_tpl, $case_ref ,$case_id, $user_language , $case_received_utc , $refund_amount);
					$to_email = 'Custom: '. $email_logs[0];
					if( $email_logs[0] == '' ) $to_email = 'No Email';
				}
   		  		/*** ********************** ***/

   		  		$email_log = $email_logs[1];
				if( !$email_log ) $email_log = '';
				$logs = $this->log_table( $case_id, $case_ref , $condition_id );
				$body_html = $email_log . $logs ;

				#$pipe = substr(BASEPATH, -1);
				#$dir = str_replace('system'.$pipe, '', BASEPATH).'data-file'.$pipe.'case_conditions_actions'.$pipe.$in_file;
				#file_put_contents( $dir , $body_html );
				
	   			$this->db->query("update temp_cron set `status` = 1 , `to_email` = '$to_email' where `id` = $tid ");
				$this->cron_model->activility( $DB1 , $case_id ,  $body_html );
	   		}
   		}
	}


	private function log_table( $case_id, $case_ref, $condition_id ) {

		$html = $this->cron_model->log_table( $case_id, $case_ref, $condition_id );

		return $html;
	}

	private function action_custom( $DB1 , $case_id ,  $set_labels , $remove_levels ,  $n_outcome_status , $n_outcome_case_substatus, $case_log_text_id ) {

		$this->cron_model->update_cases( $DB1 , $case_id ,  $n_outcome_status , $n_outcome_case_substatus );
		usleep(1);
		$this->cron_model->update_case_labels( $DB1 , $case_id,  $set_labels, $remove_levels );

		if($case_log_text_id) {
			$this->cron_model->save_log_legacy( $DB1 , $case_id, $case_log_text_id );
		}
	}

	private function emailing_custom( $DB1 , $custom_emails , $email_tpl,  $case_ref, $case_id, $user_language, $case_received_utc, $refund_amount) {

		$tpl = $this->cron_model->email_tpl( $email_tpl , $user_language );
		if($tpl){
			$message = $tpl->message;
			$subject = $tpl->subject;

			$message = str_replace( "{{caseReference}}", $case_ref , $message );
			$message = str_replace( "{{case_reference_number}}", $case_ref , $message );
			$message = str_replace("{{caseReceivedUTC}}", $case_received_utc , $message );
			$message = str_replace("{{refundAmount}}", $refund_amount , $message );

			$subject = str_replace( "{{caseReference}}", $case_ref , $subject );
			$subject = str_replace( "{{case_reference_number}}", $case_ref , $subject );

			$from_address = $tpl->email_from;
			$from_name = $tpl->email_from_name;

			$legacy_attachment = $tpl->case_attachment_doc;
			$attachment_url = $tpl->attachments;
		}else{
			$message = 'Content Not Exists';
			$subject = $case_ref;
			$from_address = '';
			$from_name = '';

			$legacy_attachment = '';
			$attachment_url = '';
		}

		if( $custom_emails != '' ) {
			return $this->send_email_to_user( $case_id, $custom_emails, $message , $subject, $from_address, $from_name, $legacy_attachment , $attachment_url );
		}
	}

	private function emailing_passenger( $DB1 , $passenger_id, $email_tpl, $case_ref , $case_id, $user_language, $case_received_utc , $refund_amount) {

		$passenger_email = '';
		$Q1 = $this->cron_model->emailing_passenger( $DB1 , $passenger_id );
		if( $Q1->num_rows() ) {
			$e = $Q1->row();
			$passenger_email = $e->email;

			$first_name = $e->first_name;
			$last_name = $e->last_name;
			$address = $e->address;
			$telephone = $e->telephone;
		}

		$tpl = $this->cron_model->email_tpl( $email_tpl, $user_language );
		if($tpl) {
			$message = $tpl->message;
			$subject = $tpl->subject;

			$message = str_replace("{{casePassenger.firstName}}", $first_name , $message );
			$message = str_replace("{{casePassenger.lastName}}", $last_name , $message );
			$message = str_replace("{{passenger_name}}", $first_name.' '.$last_name , $message );
			$message = str_replace("{{passenger_address}}", $address , $message );
			$message = str_replace("{{caseReference}}", $case_ref , $message );
			$message = str_replace("{{case_reference_number}}", $case_ref , $message );
			$message = str_replace("{{caseReceivedUTC}}", $case_received_utc , $message );
			$message = str_replace("{{refundAmount}}", $refund_amount , $message );
			
			$subject = str_replace( "{{caseReference}}", $case_ref , $subject );
			$subject = str_replace( "{{case_reference_number}}", $case_ref , $subject );

			$from_address = $tpl->email_from;
			$from_name = $tpl->email_from_name;
			
			$legacy_attachment = $tpl->case_attachment_doc;
			$attachment_url = $tpl->attachments;

		} else {
			$message = 'Content Not Exists';
			$subject = $case_ref;
			$from_address = '';
			$from_name = '';

			$legacy_attachment = '';
			$attachment_url = '';
		}

		if( $passenger_email != '' ) {
			return $this->send_email_to_user(  $case_id, $passenger_email, $message , $subject, $from_address, $from_name, $legacy_attachment , $attachment_url );
		}
	}

	private function emailing_airline( $DB1 , $airline_code, $email_tpl, $case_ref , $case_id, $user_language , $case_received_utc , $refund_amount) {

		$airline_email = '';
		$Q1 = $this->cron_model->emailing_airline( $airline_code );
		if( $Q1->num_rows() ) {
			$e = $Q1->row();
			$airline_email = $e->email_id;
			$airline_fax = $e->airline_fax;
			if(!$airline_email) $airline_email = ($airline_fax) ? $airline_fax.'@efaxsend.com' : '';
		}

		$tpl = $this->cron_model->email_tpl( $email_tpl , $user_language );
		if( $tpl ) {
			$message = $tpl->message;
			$subject = $tpl->subject;
			// {{refundAmount}}


			$message = str_replace( "{{caseReference}}", $case_ref , $message );
			$message = str_replace( "{{case_reference_number}}", $case_ref , $message );
                        $message = str_replace( "{{caseReceivedUTC}}", $case_received_utc , $message );
			$message = str_replace( "{{refundAmount}}", $refund_amount , $message );

			$subject = str_replace( "{{caseReference}}" , $case_ref , $subject );
			$subject = str_replace( "{{case_reference_number}}" , $case_ref , $subject );

			$from_address = $tpl->email_from;
			$from_name = $tpl->email_from_name;

			$legacy_attachment = $tpl->case_attachment_doc;
			$attachment_url = $tpl->attachments;
		} else {
			$message = 'Content Not Exists';
			$subject = $case_ref;
			$from_address = '';
			$from_name = '';

			$legacy_attachment = '';
			$attachment_url = '';
		}

		if( $airline_email != '' ) {
			 return $this->send_email_to_user( $case_id, $airline_email, $message, $subject, $from_address, $from_name, $legacy_attachment , $attachment_url );
		}
	}

	public function send_email_to_user( $case_id, $to_address, $message , $subject , $from_address, $from_name , $legacy_attachment, $attachment_url ) {
		
		/*
			$type = 'CUSTOM';
			$from_address = 'support@refund.me';
			$from_name = 'refundme';
			$to_address = 'sraban@refundme.in';
			#$email_bcc = 'joachim@refund.me';
			#$email_cc = 'joachim@refund.me';
		*/

		$type = 'CUSTOM';
		if(!$from_address) $from_address = 'support@refund.me';
		if(!$from_name) $from_name = 'refundme';
		$to_address = $to_address;
		$email_bcc = '';
		$email_cc = '';
 		

		 if($to_address!='') {
		 	 ob_start();
			 $this->load->model('email_model');

			 $eflag = $this->email_model->send_email_do_cron(
				 									    $case_id,
													    $subject ,
													    $from_address ,
													    $from_name ,
													    str_replace(" ","", $to_address) ,
													    $message ,
													    $type ,
													    $email_bcc,
													    $email_cc,
													    $legacy_attachment , 
													    $attachment_url 
													);
			 ob_end_clean();
			 if( $eflag ) 
			 {
			 	$email_log = '<b>To:</b>'.$to_address.'</br>----------------------</br><b>Subject:</b>'.$subject.'</br>----------------------</br><b>Body:</b></br>----------------------</br>'.$message.'<br><br><br>';
			 }
			 else
			 {
			 	$email_log = '';
			 }
		 }
		 else
		 {
		 	$email_log = '';
		 }

		return array( $to_address , $email_log );
	}

}
