<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Role extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
 	public function __construct(){
		parent::__construct();
		//$this->check_isvalidated();
		 
		$this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0,post-check=0, pre-check=0');
 		$this->output->set_header('Pragma: no-cache');
		
 		$this->load->model('role_model');
	  	$this->validate_admin_login();	

	}
	private function validate_admin_login(){
		 
		 if($this->session->userdata('admin_logged_in'))
		{
			 $this->emp_sign='';
			$this->user_logged_in = true;
			$this->user_type = 'ADMIN';
			$this->user_id = 1;
			$this->user_pic = $this->session->userdata('profile_pic');
			$this->user_name = $this->session->userdata('first_name');
			$this->user_email = $this->session->userdata('user_email');
		}
		 
		else
		{
				redirect(WEB_URL.'/login');
		}
		 
    }
	 
	function add_privileges($param='')
	{
		$data='';
		if($param!='')
		{
			$data['page_data'] = json_decode(base64_decode($param));
 		} 
		  $data['modules'] = $this->role_model->get_modules_all();
   		$this->load->view('employee/add_privileges',$data);
	}
	 
	function add_privileges_do()
	{
			 
			 
		$this->load->library('form_validation');
		$this->form_validation->set_rules('modules', 'Modules', 'trim|required');
		$this->form_validation->set_rules('p_name', 'Privileges Name', 'trim|required');
		$this->form_validation->set_rules('c_name', 'Controller Name', 'trim|required');
		$this->form_validation->set_rules('m_name', 'Method Name', 'trim|required');
		$this->form_validation->set_rules('p_icon', 'Privileges Icon', 'trim|required');
		$this->form_validation->set_rules('visi', 'Visibility', 'trim|required|in_list[show,hide]');
		  
 		if ( $this->form_validation->run() != false ) 
		{
				 if($this->role_model->add_privileges_do($this->input->post('modules'),$this->input->post('p_name'),$this->input->post('c_name')
				 ,$this->input->post('m_name'),$this->input->post('p_icon'),$this->input->post('visi')))
				 {
					 $data_['msg_type'] = 'success';
						$data_['msg'] = 'Added Successfully.';
						$page_encrpt_data = base64_encode(json_encode($data_));
						redirect(WEB_URL.'/role/manage_privileges/'.$page_encrpt_data,'refresh');
				 }
				 else
				 {
					 $data_['msg_type'] = 'error';
						$data_['msg'] = 'Failed.';
						$page_encrpt_data = base64_encode(json_encode($data_));
						redirect(WEB_URL.'/role/add_privileges/'.$page_encrpt_data,'refresh');
				 }
		}
		else
		{ 
			$data_['msg_type'] = 'error';
			$data_['msg'] = trim(preg_replace( "/\r|\n/", "",validation_errors()));
			$page_encrpt_data = base64_encode(json_encode($data_));
			redirect(WEB_URL.'/role/add_privileges/'.$page_encrpt_data,'refresh');
		}
	}
	  
	function change_privileges_status_active($data)
	{
		 
		$data_v = (base64_decode($data));
			 
		 $status='ACTIVE';
			if($this->role_model->change_privileges_status($data_v,$status))
			{
				return true;
			}
			else
			{
				return false;
			}
		 
	}
	function change_privileges_status_inactive($data)
	{
$data_v = (base64_decode($data));
 		  $status='INACTIVE';		
			if($this->role_model->change_privileges_status($data_v,$status))
			{
				return true;
			}
			else
			{
				return false;
			}
		 
	}
 
	function allot_privileges($param='')
	{
		if($param!='')
		{
			$data['page_data'] = json_decode(base64_decode($param));
 		}
		 $data['result'] = $this->role_model->get_employee_all();
		  $data['module'] = $this->role_model->get_module_all();
		   
		 $this->load->view('employee/allot_privileges',$data);
		 
	}  
	function get_privileges_based($id='')
	{
		if($id!='')
		{
		 $data['module'] = $this->role_model->get_module_all();
		  $privileges_active = $this->role_model->get_privileges_action_all($id);
		  $privileges_active_v=array();
		  if($privileges_active)
		  {
			  for($i=0;$i<count($privileges_active);$i++)
			  {
				  $privileges_active_v[] = $privileges_active[$i]->privileges_id;
			  }
		  }
		$data['privileges_active']= $privileges_active_v;
		$this->load->view('employee/get_privileges_based',$data);
		}
	 
	}
	function allot_privileges_do()
	{
		 
		$this->load->library('form_validation');
		$this->form_validation->set_rules('role_id', 'Employee', 'trim|required'); 
	 
 		if ( $this->form_validation->run() != false ) 
		{
				 if($this->role_model->allot_privileges_do($this->input->post('role_id'),$this->input->post('privileges')))
				 {
					$data_['msg_type'] = 'success';
					$data_['msg'] = 'Updated Successfully.';
					$page_encrpt_data = base64_encode(json_encode($data_));
					redirect(WEB_URL.'/role/allot_privileges/'.$page_encrpt_data,'refresh');
				 }
				 else
				 {
					$data_['msg_type'] = 'error';
					$data_['msg'] = 'Failed.';
					$page_encrpt_data = base64_encode(json_encode($data_));
					redirect(WEB_URL.'/role/allot_privileges/'.$page_encrpt_data,'refresh');
				 }
		}
		else
		{ 
			$data_['msg_type'] = 'error';
			$data_['msg'] = trim(preg_replace( "/\r|\n/", "",validation_errors()));
			$page_encrpt_data = base64_encode(json_encode($data_));
			redirect(WEB_URL.'/role/allot_privileges/'.$page_encrpt_data,'refresh');
		}
	
	}
	function add_privileges_module_do()
	{
		 
		$this->load->library('form_validation');
		$this->form_validation->set_rules('g_name', 'Group Name', 'trim|required'); 
		$this->form_validation->set_rules('m_name', 'Module Name', 'trim|required|is_unique[privileges_module.module_name]'); 
		$this->form_validation->set_rules('m_icon', 'Module Icon', 'trim|required'); 
		$this->form_validation->set_rules('m_pos', 'Position', 'trim|required|integer'); 
	 
 		if ( $this->form_validation->run() != false ) 
		{
				 if($this->role_model->add_privileges_module_do($this->input->post('g_name'),$this->input->post('m_name'),$this->input->post('m_icon')
				 ,$this->input->post('m_pos')))
				 {
					$data_['msg_type'] = 'success';
					$data_['msg'] = 'Updated Successfully.';
					$page_encrpt_data = base64_encode(json_encode($data_));
					redirect(WEB_URL.'/role/privileges_module/'.$page_encrpt_data,'refresh');
				 }
				 else
				 {
					$data_['msg_type'] = 'error';
					$data_['msg'] = 'Failed.';
					$page_encrpt_data = base64_encode(json_encode($data_));
					redirect(WEB_URL.'/role/add_privileges_module/'.$page_encrpt_data,'refresh');
				 }
		}
		else
		{ 
			$data_['msg_type'] = 'error';
			$data_['msg'] = trim(preg_replace( "/\r|\n/", "",validation_errors()));
			$page_encrpt_data = base64_encode(json_encode($data_));
			redirect(WEB_URL.'/role/add_privileges_module/'.$page_encrpt_data,'refresh');
		}
	
	}
		function delete_role($data='')
	{
		$data_v = (base64_decode($data));
		 if($this->role_model->delete_role($data_v))
				 {
					 $data_['msg_type'] = 'success';
						$data_['msg'] = 'Deleted Successfully.';
						$page_encrpt_data = base64_encode(json_encode($data_));
						redirect(WEB_URL.'/role/list_all/'.$page_encrpt_data,'refresh');
				 }
				 else
				 {
					 $data_['msg_type'] = 'error';
						$data_['msg'] = 'Failed.';
						$page_encrpt_data = base64_encode(json_encode($data_));
						redirect(WEB_URL.'/role/list_all/'.$page_encrpt_data,'refresh');
				 }
	}
	function add_privileges_module($param='')
	{
		$data='';
		if($param!='')
		{
			$data['page_data'] = json_decode(base64_decode($param));
 		} 
    		 $this->load->view('employee/add_privileges_module',$data);
	}
	function manage_privileges($param='')
	{
		if($param!='')
		{
			$data['page_data'] = json_decode(base64_decode($param));
 		}
		 $data['result'] = $this->role_model->get_privileges_all();
		  
		 $this->load->view('employee/manage_privileges',$data);
		 
	}  
	function privileges_module($param='')
	{
		if($param!='')
		{
			$data['page_data'] = json_decode(base64_decode($param));
 		}
		 $data['result'] = $this->role_model->get_privileges_module_all();
		  
		 $this->load->view('employee/manage_privileges_moudle',$data);
		 
	}  
	function view_privileges_module($id)
	{
		$id = base64_decode($id);
		$data['result'] = $this->role_model->get_privileges_id_with_status($id);
		  
		 $this->load->view('employee/view_privileges_module_view',$data);
	}
	 function edit_privileges_module($id,$param='')
	{
		if($param!='')
		{
			$data['page_data'] = json_decode(base64_decode($param));
 		}
		$data_v = (base64_decode($id));
	 
		$data['result'] = $this->role_model->get_module_all_id($data_v);
	   		$this->load->view('employee/edit_privileges_module',$data);
	}
	function update_privileges_module_do($privileges_module_id)
	{
		 
		$this->load->library('form_validation');
		$this->form_validation->set_rules('g_name', 'Group Name', 'trim|required'); 
		$this->form_validation->set_rules('m_name', 'Module Name', 'trim|required'); 
		$this->form_validation->set_rules('m_icon', 'Module Icon', 'trim|required'); 
		$this->form_validation->set_rules('m_pos', 'Position', 'trim|required|integer'); 
	 
 		if ( $this->form_validation->run() != false ) 
		{
			$privileges_module_id_v = base64_decode($privileges_module_id);
				 if($this->role_model->update_privileges_module_do($privileges_module_id_v,$this->input->post('g_name'),$this->input->post('m_name'),$this->input->post('m_icon')
				 ,$this->input->post('m_pos')))
				 {
					$data_['msg_type'] = 'success';
					$data_['msg'] = 'Updated Successfully.';
					$page_encrpt_data = base64_encode(json_encode($data_));
					redirect(WEB_URL.'/role/privileges_module/'.$page_encrpt_data,'refresh');
				 }
				 else
				 {
					$data_['msg_type'] = 'error';
					$data_['msg'] = 'Failed.';
					$page_encrpt_data = base64_encode(json_encode($data_));
					redirect(WEB_URL.'/role/privileges_module/'.$page_encrpt_data,'refresh');
				 }
		}
		else
		{ 
			$data_['msg_type'] = 'error';
			$data_['msg'] = trim(preg_replace( "/\r|\n/", "",validation_errors()));
			$page_encrpt_data = base64_encode(json_encode($data_));
			redirect(WEB_URL.'/role/privileges_module/'.$page_encrpt_data,'refresh');
		}
	
	}
}
