<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Help_Do extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
 	public function __construct(){
		parent::__construct();
		//$this->check_isvalidated();
		 
		$this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0,post-check=0, pre-check=0');
 		$this->output->set_header('Pragma: no-cache');
  		$this->load->model('help_model');
	  	$this->validate_admin_login();	

	}
	private function validate_admin_login(){
		 
		  $result_v='';
		if(isset($_GET['emp_sign']))
		{
				$result_v = json_decode(base64_decode($_GET['emp_sign']));
		}
		
		if(isset($result_v->employee_id) && isset($result_v->email_address) && isset($result_v->first_name))
		{
				$controller_name = $this->router->fetch_class();
				$function_name = $this->router->fetch_method();

				 $this->load->model('security_model');
				$employee_id = $result_v->employee_id;
			   /*if(!$this->security_model->get_privileges_by_employee_id($employee_id,$controller_name,$function_name))
			   {			
					access_denied('error');
				}*/
				$this->emp_sign="?emp_sign=".$_GET['emp_sign'];
				$this->user_logged_in = true;
				$this->user_type = 'EMPLOYEE';
				$this->user_id = $result_v->employee_id;
				$this->user_pic = $result_v->profile_pic;
				$this->user_name = $result_v->first_name;
				$this->user_email = $result_v->email_address;
				
			 
		 	
 		}
		elseif($this->session->userdata('admin_logged_in'))
		{
			 $this->emp_sign='';
			$this->user_logged_in = true;
			$this->user_type = 'ADMIN';
			$this->user_id = 1;
			$this->user_pic = $this->session->userdata('profile_pic');
			$this->user_name = $this->session->userdata('first_name');
			$this->user_email = $this->session->userdata('user_email');
		}
		elseif($this->session->userdata('employee_logged_in'))
		{
			$this->emp_sign='';
		 	$controller_name = $this->router->fetch_class();
			 $function_name = $this->router->fetch_method();
			 
             $this->load->model('security_model');
            $employee_id = $this->session->userdata('employee_id');
          /* if(!$this->security_model->get_privileges_by_employee_id($employee_id,$controller_name,$function_name))
		   {			
    	 	  	access_denied('error');
			}*/
			
       	 
			$this->user_logged_in = true;
			$this->user_type = 'EMPLOYEE';
			$this->user_id = $this->session->userdata('employee_id');
			$this->user_pic = $this->session->userdata('profile_pic');
			$this->user_name = $this->session->userdata('first_name');
			$this->user_email = $this->session->userdata('email_address');
		}
		else
		{
				redirect(WEB_URL.'/login');
		}
		 $this->overlay_employee_details = $this->security_model->get_employee_id_name($this->user_id,$this->user_type);
    }
	function update_help($id)
	{
			$data_v = (base64_decode($id));
			
		$this->load->library('form_validation');
		$this->form_validation->set_rules('question', 'Question', 'trim|required');
		$this->form_validation->set_rules('answer', 'Answer', 'trim|required'); 
	 
 		if ( $this->form_validation->run() != false ) 
		{
				 if($this->help_model->update_help($data_v,$this->input->post('question'),
				 $this->input->post('answer')))
				 {
					 $data_['msg_type'] = 'success';
						$data_['msg'] = 'Updated Successfully.';
						$page_encrpt_data = base64_encode(json_encode($data_));
						redirect(WEB_URL.'/help/edit_help/'.$id.'/'.$page_encrpt_data,'refresh');
				 }
				 else
				 {
					 $data_['msg_type'] = 'error';
						$data_['msg'] = 'Failed.';
						$page_encrpt_data = base64_encode(json_encode($data_));
						redirect(WEB_URL.'/help/edit_help/'.$id.'/'.$page_encrpt_data,'refresh');
				 }
		}
		else
		{
			
			$data_['msg_type'] = 'error';
			$data_['msg'] = 'Failed.';
			$page_encrpt_data = base64_encode(json_encode($data_));
			redirect(WEB_URL.'/help/edit_help/'.$id.'/'.$page_encrpt_data,'refresh');
		}
	
	}
	function change_help_status_active($data)
	{
		 
		$data_v = (base64_decode($data));
			 
		 $status='ACTIVE';
			if($this->help_model->change_help_status($data_v,$status))
			{
				return true;
			}
			else
			{
				return false;
			}
		 
	}
	
	function change_help_status_inactive($data)
	{
$data_v = (base64_decode($data));
 		  $status='INACTIVE';		
			if($this->help_model->change_help_status($data_v,$status))
			{
				return true;
			}
			else
			{
				return false;
			}
		 
	}
 	function add_help()
	{
			 
		$this->load->library('form_validation');
		$this->form_validation->set_rules('question', 'Question', 'trim|required');
		$this->form_validation->set_rules('answer', 'Answer', 'trim|required'); 
	 
 		if ( $this->form_validation->run() != false ) 
		{
			$insert_id = $this->help_model->add_help($this->input->post('question'),$this->input->post('answer'));
				 if($insert_id)
				 {
					 $data_['msg_type'] = 'success';
						$data_['msg'] = 'Added Successfully.';
							 
						$page_encrpt_data = base64_encode(json_encode($data_));
						
						///////////////////////NOTIFICATION////////////////////////////
						 $message= 'Added new help question and answer.';
						 $url=WEB_URL.'/help/view_help/'.base64_encode($insert_id);
						 $to_user_type='ALL';
						 $to_user_id='';
						$title='Help';
						$icon='icon-info';
						$num_rows = $this->notification_model->store_notification($this->user_type,$this->user_id,$this->user_name,$this->user_pic,$message,$url,$to_user_type,$to_user_id,$title,$icon);
						$this->session->set_flashdata('notification','active');
						$this->session->set_flashdata('ntfy_count',$num_rows['me']);
						$this->session->set_flashdata('ntfy_count_other',$num_rows['other']);
						$this->session->set_flashdata('ntfy_url',$url);
						$this->session->set_flashdata('ntfy_pic',$this->user_pic);
						$this->session->set_flashdata('ntfy_title',$this->user_name);
						$this->session->set_flashdata('ntfy_time','Now');
						$this->session->set_flashdata('ntfy_msg',$message);
						$this->session->set_flashdata('ntfy_from_user',$this->user_id);
 						$this->session->set_flashdata('ntfy_user',$to_user_id);
						///////////////////////NOTIFICATION////////////////////////////
						
 						redirect(WEB_URL.'/help/list_all/'.$page_encrpt_data,'refresh');
				 }
				 else
				 {
					 $data_['msg_type'] = 'error';
						$data_['msg'] = 'Failed.';
						$page_encrpt_data = base64_encode(json_encode($data_));
						redirect(WEB_URL.'/help/add_help/'.$page_encrpt_data,'refresh');
				 }
		}
		else
		{ 
			$data_['msg_type'] = 'error';
			$data_['msg'] = trim(preg_replace( "/\r|\n/", "",validation_errors()));
			$page_encrpt_data = base64_encode(json_encode($data_));
			redirect(WEB_URL.'/help/add_help/'.$page_encrpt_data,'refresh');
		}
	}
	
}
