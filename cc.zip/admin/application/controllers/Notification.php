<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Notification extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
 	public function __construct(){
		parent::__construct();
		//$this->check_isvalidated();
		 
		$this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0,post-check=0, pre-check=0');
 		$this->output->set_header('Pragma: no-cache');
		$this->load->model('email_model');
 	 
	  	$this->validate_admin_login();	
	}
	private function validate_admin_login(){
		 
		 $result_v='';
		if(isset($_GET['emp_sign']))
		{
				$result_v = json_decode(base64_decode($_GET['emp_sign']));
		}
		
		if(isset($result_v->employee_id) && isset($result_v->email_address) && isset($result_v->first_name))
		{
				$controller_name = $this->router->fetch_class();
				$function_name = $this->router->fetch_method();

				 $this->load->model('security_model');
				$employee_id = $result_v->employee_id;
			 /*  if(!$this->security_model->get_privileges_by_employee_id($employee_id,$controller_name,$function_name))
			   {			
					access_denied('error');
				}*/

$this->emp_sign="?emp_sign=".$_GET['emp_sign'];
				$this->user_logged_in = true;
				$this->user_type = 'EMPLOYEE';
				$this->user_id = $result_v->employee_id;
				$this->user_pic = $result_v->profile_pic;
				$this->user_name = $result_v->first_name;
				$this->user_email = $result_v->email_address;
				
			 
		 	
 		}
		elseif($this->session->userdata('admin_logged_in'))
		{
			 $this->emp_sign='';
			$this->user_logged_in = true;
			$this->user_type = 'ADMIN';
			$this->user_id = 1;
			$this->user_pic = $this->session->userdata('profile_pic');
			$this->user_name = $this->session->userdata('first_name');
			$this->user_email = $this->session->userdata('user_email');
		}
		elseif($this->session->userdata('employee_logged_in'))
		{
			$this->emp_sign='';
		 	$controller_name = $this->router->fetch_class();
			 $function_name = $this->router->fetch_method();
			 
             $this->load->model('security_model');
            $employee_id = $this->session->userdata('employee_id');
        /*   if(!$this->security_model->get_privileges_by_employee_id($employee_id,$controller_name,$function_name))
		   {			
    	 	  	access_denied('error');
			}*/
			
       	 
			$this->user_logged_in = true;
			$this->user_type = 'EMPLOYEE';
			$this->user_id = $this->session->userdata('employee_id');
			$this->user_pic = $this->session->userdata('profile_pic');
			$this->user_name = $this->session->userdata('first_name');
			$this->user_email = $this->session->userdata('email_address');
		}
		else
		{
				redirect(WEB_URL.'/login');
		}
		 $this->overlay_employee_details = $this->security_model->get_employee_id_name($this->user_id,$this->user_type);
    }
	  
	function index($param='')
	{
		if($param!='')
		{
			$data['page_data'] = json_decode(base64_decode($param));
 		}
		
 		 $data['result'] = $this->notification_model->get_notification_all($this->user_type,$this->user_id); 
  		 $this->load->view('notification/view',$data);
	}
	  
	function view($ids)
	{
 			$id = base64_decode($ids);
		 
 		 $data['result'] = $this->notification_model->get_notification_id($id); 
  		 $this->load->view('notification/view_msg',$data);
	}
	function change_status_none()
	{
		$this->notification_model->change_status_none($this->user_type,$this->user_id); 
		 
	}
 	function get_notification_page($page_count='0')
	{
		sleep(2);
		$page_count = $page_count+10;
		 $data['result'] = $this->notification_model->get_notification_all($this->user_type,$this->user_id,$page_count); 
  		 $result = $this->load->view('notification/view_ajax',$data,true);
		$over='no';
		 if(!$data['result'])
		 {
			$over='yes';
		 }
		 echo json_encode(array('result'=>$result,'page_count'=>$page_count,'over'=>$over));
		 
	}
	function send_message()
	{
		 
		if(isset($_POST['overlay_employee']) && $_POST['overlay_employee']!='' && isset($_POST['overlay_message']) && $_POST['overlay_message']!=''  && isset($_POST['overlay_subject']) && $_POST['overlay_subject']!='')
		{
			$notification_message_code =  date("dmHis").rand('11111','99999');
			$profile_pic='';
			if (isset($_FILES["file"]["tmp_name"]) && $_FILES["file"]["tmp_name"] != "") 
			{
						$config['upload_path'] = "data-file/attachment/";
 						$config['max_size']	= '10048'; 
							$config['allowed_types'] = 'gif|jpg|png|jpeg|JPG|JPEG|DOC|pdf|PDF|ZIP|zip|docs|excel';
						$config['file_name'] = $notification_message_code.date('ymdHis').time();
						$this->load->library('upload', $config);
				if ($this->upload->do_upload('file'))
                {
                     			$upload_data = $this->upload->data();
 								$profile_pic = FILE_PATH."attachment/".$this->upload->file_name;
				}
				else {
							  $error = array('error' => $this->upload->display_errors()); 
							
					 echo '<pre/>';print_r($error);exit;
						}
  			 
			}
	//	for($i=0;$i<25;$i++)
		//{	  
			$notification_alert_v = $this->notification_model->store_overlay_message($notification_message_code,$this->user_type,$this->user_id,$this->user_name,$this->user_pic,$_POST['overlay_employee'],$_POST['overlay_message'],$_POST['overlay_subject'],$profile_pic); 
		//}
						
		}
		
		echo json_encode(array('result'=>'','notification'=>$notification_alert_v));
		 
	}
	function get_notification_record()
	{
		  
		$result_v2 = $this->notification_model->get_notification_list($this->user_type,$this->user_id,$_POST['order'],$_POST['start'], $_POST['length']);
		
		$result['draw']= $_POST['draw'];
		$result['recordsTotal']=  $this->notification_model->get_notification_list_all($this->user_type,$this->user_id);
		$result['recordsFiltered']= $result['recordsTotal'];
		
		 $result['data']=array();
		if($result_v2)
		{
		 for($i=0;$i<count($result_v2);$i++)
		 {
			  
 			 $result['data'][]= array( 
			 							' <div style="margin:15px 0"><i style="text-align:center" class="'.$result_v2[$i]->faicon.'"></i></div>',
										'<img src="'.$result_v2[$i]->picture.'" width="50"/> &nbsp;'.$result_v2[$i]->name,
										$result_v2[$i]->title,
										$result_v2[$i]->message,
										$result_v2[$i]->created_timestamp,
										 '
                                                    <div class="btn-group btn-group-sm btn-group-solid">   <a href="'.$result_v2[$i]->url.'" target="_blank" class="btn btn-xs   blue">
                                                                            <i class="fa fa-link"></i>
                                                                        </a>
                                                                     	  </a></div> ',
										'DT_RowId'=>'row_'.$result_v2[$i]->notification_id);
			 
			 }
		}
			echo json_encode($result); 
			 
			
		 
	}
}
