<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Flight_Notification extends CI_Controller {

 	public function __construct(){
		parent::__construct();
		$this->load->model('flight_notification_model');
		
		$this->validate_admin_login();
	}
	
	private function validate_admin_login(){
		
		$result_v='';
		if(isset($_GET['emp_sign']))
		{
			$result_v = json_decode(base64_decode($_GET['emp_sign']));
		}
		
		if(isset($result_v->employee_id) && isset($result_v->email_address) && isset($result_v->first_name))
		{
			$controller_name = $this->router->fetch_class();
			$function_name = $this->router->fetch_method();

			$this->load->model('security_model');
			$employee_id = $result_v->employee_id;
			if(!$this->security_model->get_privileges_by_employee_id($employee_id,$controller_name,$function_name))
			{			
				access_denied('error');
			}

			$this->emp_sign="?emp_sign=".$_GET['emp_sign'];
			$this->user_logged_in = true;
			$this->user_type = 'EMPLOYEE';
			$this->user_id = $result_v->employee_id;
			$this->user_pic = $result_v->profile_pic;
			$this->user_name = $result_v->first_name;
			$this->user_email = $result_v->email_address;
		}
		elseif($this->session->userdata('admin_logged_in'))
		{
			$this->emp_sign='';
			$this->user_logged_in = true;
			$this->user_type = 'ADMIN';
			$this->user_id = 1;
			$this->user_pic = $this->session->userdata('profile_pic');
			$this->user_name = $this->session->userdata('first_name');
			$this->user_email = $this->session->userdata('user_email');
		}
		elseif($this->session->userdata('employee_logged_in'))
		{
			$this->emp_sign='';
		 	$controller_name = $this->router->fetch_class();
			$function_name = $this->router->fetch_method();
			 
            $this->load->model('security_model');
            $employee_id = $this->session->userdata('employee_id');
			if(!$this->security_model->get_privileges_by_employee_id($employee_id,$controller_name,$function_name))
			{			
    	 	  	access_denied('error');
			}
      	 
			$this->user_logged_in = true;
			$this->user_type = 'EMPLOYEE';
			$this->user_id = $this->session->userdata('employee_id');
			$this->user_pic = $this->session->userdata('profile_pic');
			$this->user_name = $this->session->userdata('first_name');
			$this->user_email = $this->session->userdata('email_address');
		}
		else
		{
			redirect(WEB_URL.'/login');
		}
		$this->overlay_employee_details = $this->security_model->get_employee_id_name($this->user_id,$this->user_type); 
    }
	
	public function all_notification(){
		$data['allNotification']	=	$this->flight_notification_model->get_all_notification();
	
		$this->load->view('flight_registration/list_registration', $data);
	}
	
	public function all_notification_ajax(){
		$itinerary_id		=	!empty( $this->input->get('itinerary_id') ) ? $this->input->get('itinerary_id') : '';
		$flight_change		=	!empty( $this->input->get('flight_change') ) ? $this->input->get('flight_change') : '';
		$flight_id			=	!empty( $this->input->get('flight_id') ) ? $this->input->get('flight_id') : '';
		$flight_number		=	!empty( $this->input->get('flight_number') ) ? $this->input->get('flight_number') : '';
		$flight_name		=	!empty( $this->input->get('flight_name') ) ? $this->input->get('flight_name') : '';
		$origin_iata		=	!empty( $this->input->get('origin_iata') ) ? $this->input->get('origin_iata') : '';
		$destination_iata	=	!empty( $this->input->get('destination_iata') ) ? $this->input->get('destination_iata') : '';
		$delay_index		=	!empty( $this->input->get('delay_index') ) ? $this->input->get('delay_index') : '';
		$delay_risk			=	!empty( $this->input->get('delay_risk') ) ? $this->input->get('delay_risk') : '';
		$delay_causes		=	!empty( $this->input->get('delay_causes') ) ? $this->input->get('delay_causes') : '';
		$flight_status		=	!empty( $this->input->get('flight_status') ) ? $this->input->get('flight_status') : '';
		$created_date_from	=	!empty( $this->input->get('created_date_from') ) ? $this->input->get('created_date_from') : '';
		$created_date_to	=	!empty( $this->input->get('created_date_to') ) ? $this->input->get('created_date_to') : '';
		$departure_date_from=	!empty( $this->input->get('departure_date_from') ) ? $this->input->get('departure_date_from') : '';
		$departure_date_to	=	!empty( $this->input->get('departure_date_to') ) ? $this->input->get('departure_date_to') : '';
		$arrival_date_from	=	!empty( $this->input->get('arrival_date_from') ) ? $this->input->get('arrival_date_from') : '';
		$arrival_date_to	=	!empty( $this->input->get('arrival_date_to') ) ? $this->input->get('arrival_date_to') : '';
		
		$start				=	!empty( $this->input->get('start') ) ? $this->input->get('start') : 0;
		$length				=	!empty( $this->input->get('length') ) ? $this->input->get('length') : 10;
		
		$created_date_from	=	!empty($created_date_from) ? date('Y-m-d', strtotime($created_date_from)) : '';
		$created_date_to	=	!empty($created_date_to) ? date('Y-m-d', strtotime($created_date_to)) : '';
		$departure_date_from=	!empty($departure_date_from) ? date('Y-m-d', strtotime($departure_date_from)) : '';
		$departure_date_to	=	!empty($departure_date_to) ? date('Y-m-d', strtotime($departure_date_to)) : '';
		$arrival_date_from	=	!empty($arrival_date_from) ? date('Y-m-d', strtotime($arrival_date_from)) : '';
		$arrival_date_to	=	!empty($arrival_date_to) ? date('Y-m-d', strtotime($arrival_date_to)) : '';
		
		$result_all	=	$this->flight_notification_model->get_all_notification($start, $length, $itinerary_id, $flight_change, $flight_number, $origin_iata, $destination_iata, $delay_risk, $delay_causes, $flight_status, $flight_id, $flight_name, $delay_index, $created_date_from, $created_date_to, $departure_date_from, $departure_date_to, $arrival_date_from, $arrival_date_to);
		
		$recordsTotal	=	$this->flight_notification_model->get_all_notification_count($itinerary_id, $flight_change, $flight_number, $origin_iata, $destination_iata, $delay_risk, $delay_causes, $flight_status, $flight_id, $flight_name, $delay_index, $created_date_from, $created_date_to, $departure_date_from, $departure_date_to, $arrival_date_from, $arrival_date_to);
		$result['recordsTotal'] 	= $recordsTotal;
		$result['recordsFiltered']	= $recordsTotal;
		
		for($i=0; $i < count($result_all); $i++){
			$flight_notification_id = base64_encode( $result_all[$i]->flight_notification_id );
			$result['data'][]	=	array(
											$result_all[$i]->flight_notification_id,
											$result_all[$i]->itinerary_id,
											$result_all[$i]->flight_change,
											$result_all[$i]->flight_number,
											$result_all[$i]->origin_iata,
											$result_all[$i]->destination_iata,
											$result_all[$i]->delay_risk,
											$result_all[$i]->delay_causes,
											$result_all[$i]->flight_status,
											$result_all[$i]->created_timestamp,
											'<a class="ajax-demo" data-url="'.WEB_URL.'/flight_notification/notification_details/'.$flight_notification_id.'" data-toggle="modal"><button class="btn blue-dark  ">Details</button></a>'
										);
		}
		
		echo json_encode( $result );
	}
	
	public function notification_details($flight_notification_id=''){
		$flight_notification_id = base64_decode( $flight_notification_id );
		
		$result['details']	=	$this->flight_notification_model->get_notification_details_by_id($flight_notification_id);
		$this->load->view('flight_registration/notification_details', $result);
	}
	
	###############################
	### Auto Complete Functions ###
	###############################
	
	function flight_id_autocomp(){
		$flight_id	=	!empty(trim($this->input->get('term'))) ? trim($this->input->get('term')) : '';
		
		$result['flight_id']	=	$this->flight_notification_model->get_flight_id_autocomp( $flight_id );
		
		echo json_encode( $result['flight_id'] );
	}
	
	function flight_number_autocomp(){
		$flight_number	=	!empty(trim($this->input->get('term'))) ? trim($this->input->get('term')) : '';
		
		$result['flight_number']	=	$this->flight_notification_model->get_flight_number_autocomp( $flight_number );
		
		echo json_encode( $result['flight_number'] );
	}
	
	function flight_name_autocomp(){
		$flight_name	=	!empty(trim($this->input->get('term'))) ? trim($this->input->get('term')) : '';
		
		$result['flight_name']	=	$this->flight_notification_model->get_flight_name_autocomp( $flight_name );
		
		echo json_encode( $result['flight_name'] );
	}
	
	function destination_iata_autocomp(){
		$destination_iata	=	!empty(trim($this->input->get('term'))) ? trim($this->input->get('term')) : '';
		
		$result['destination_iata']	=	$this->flight_notification_model->get_destination_iata_autocomp( $destination_iata );
		
		echo json_encode( $result['destination_iata'] );
	}
	
	function delay_index_autocomp(){
		$delay_index	=	!empty(trim($this->input->get('term'))) ? trim($this->input->get('term')) : '';
		
		$result['delay_index']	=	$this->flight_notification_model->get_delay_index_autocomp( $delay_index );
		
		echo json_encode( $result['delay_index'] );
	}
	
	function itinerary_id_autocomp(){
		$itinerary_id	=	!empty(trim($this->input->get('term'))) ? trim($this->input->get('term')) : '';
		
		$result['itinerary_id']	=	$this->flight_notification_model->get_itinerary_id_autocomp( $itinerary_id );
		
		echo json_encode( $result['itinerary_id'] );
	}
}