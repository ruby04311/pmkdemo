<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
 class Employee_Do extends CI_Controller {
 
 	public function __construct(){
		parent::__construct();
		//$this->check_isvalidated();
		 
		$this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0,post-check=0, pre-check=0');
 		$this->output->set_header('Pragma: no-cache');
		$this->load->model('email_model');
 		$this->load->model('employee_model');
	  	$this->validate_admin_login();	

	}
	private function validate_admin_login(){
		
		  $result_v='';
		if(isset($_GET['emp_sign']))
		{
				$result_v = json_decode(base64_decode($_GET['emp_sign']));
		}
		
		if(isset($result_v->employee_id) && isset($result_v->email_address) && isset($result_v->first_name))
		{
				$controller_name = $this->router->fetch_class();
				$function_name = $this->router->fetch_method();

				 $this->load->model('security_model');
				$employee_id = $result_v->employee_id;
 
			   /*if(!$this->security_model->get_privileges_by_employee_id($employee_id,$controller_name,$function_name))
			   {			
					access_denied('error');
				}
*/
				$this->emp_sign="?emp_sign=".$_GET['emp_sign'];
				$this->user_logged_in = true;
				$this->user_type = 'EMPLOYEE';
				$this->user_id = $result_v->employee_id;
				$this->user_pic = $result_v->profile_pic;
				$this->user_name = $result_v->first_name;
				$this->user_email = $result_v->email_address;
				
			 
		 	
 		}
		elseif($this->session->userdata('admin_logged_in'))
		{
			 $this->emp_sign='';
			$this->user_logged_in = true;
			$this->user_type = 'ADMIN';
			$this->user_id = 1;
			$this->user_pic = $this->session->userdata('profile_pic');
			$this->user_name = $this->session->userdata('first_name');
			$this->user_email = $this->session->userdata('user_email');
		}
		elseif($this->session->userdata('employee_logged_in'))
		{
			$this->emp_sign='';
		 	 
			 
			
			$this->user_logged_in = true;
			$this->user_type = 'EMPLOYEE';
			$this->user_id = $this->session->userdata('employee_id');
			$this->user_pic =$this->session->userdata('profile_pic');
			$this->user_name = $this->session->userdata('first_name');
			$this->user_email = $this->session->userdata('user_email');
		}
		else
		{
				redirect(WEB_URL.'/login');
		}
		 $this->overlay_employee_details = $this->security_model->get_employee_id_name($this->user_id,$this->user_type); 
    }
	public function index()
	{	
		//$this->load->model('mi_model');
		// $data['invoice_range'] = $this->mi_model->get_invoice_range();
		 $user_id = $this->user_id;
		
		 $data['last_login'] = $this->employee_model->get_last_login_record($user_id);
  		$this->load->view('employee/employee_dashboard',$data);
 	} 
	 	public function update_profile()
	{
		 
		$this->load->library('form_validation');
		$this->form_validation->set_rules('firstname', 'First Name', 'trim|required');
		$this->form_validation->set_rules('lastname', 'Last Name', 'trim|required'); 
		 
 		if ( $this->form_validation->run() != false ) 
		{
  			 
			 
			$firstname = $this->input->post('firstname');
			$lastname = $this->input->post('lastname');
			$skype_id = $this->input->post('skype_id');
			$phno = $this->input->post('phno');
			$note_info = $this->input->post('note_info');
			 
 			if($this->employee_model->update_employee_data($this->user_id,$firstname,$lastname,$skype_id,$phno,$note_info))
				{
					$data_['module'] = 'account';
					$data_['sub_module'] = 'personal_info';
					$data_['msg_type'] = 'success';
					$data_['msg'] = 'Your profile information updated successfully';
					$page_encrpt_data = base64_encode(json_encode($data_));
					redirect(WEB_URL.'/employee/my_profile/'.$page_encrpt_data,'refresh');
					
				}
				else
				{
					$data_['module'] = 'account';
					$data_['sub_module'] = 'personal_info';
					$data_['msg_type'] = 'error';
					$data_['msg'] = 'Failed';
					$page_encrpt_data = base64_encode(json_encode($data_));
					redirect(WEB_URL.'/employee/my_profile/'.$page_encrpt_data,'refresh');
				}
				
			}	
			else
			{
					 
					$data_['module'] = 'account';
					$data_['sub_module'] = 'personal_info';
					$data_['msg_type'] = 'error';
					$data_['msg'] = 'Failed';
					$page_encrpt_data = base64_encode(json_encode($data_));
					redirect(WEB_URL.'/employee/my_profile/'.$page_encrpt_data,'refresh');
					
			}
			
	        
	}
	 public function change_logo()
	{
		 
		 
			if ($_FILES["avatar_file"]["tmp_name"] != "") 
			{
				$config['upload_path'] = "data-file/employee/";
				$config['allowed_types'] = 'gif|jpg|png';
				$config['max_size']	= '2048';
				$config['max_width'] = '1024';
				$config['max_height'] = '768';
				$config['file_name'] = 'profile_pic_'.$_FILES["avatar_file"]["tmp_name"][0].date('ymdHis').time();
				$this->load->library('upload', $config);
				  if ( ! $this->upload->do_upload('avatar_file'))
                {
                       echo $this->upload->display_errors();
				}
				$upload_data = $this->upload->data();
				
				//echo $this->upload->display_errors();
				//echo "<pre>"; var_dump($upload_data);
				$admin_profile_pic = "employee/".$this->upload->file_name;
			
				if($this->employee_model->update_employee_logo($this->user_id,$admin_profile_pic))
				{
					$data_['module'] = 'account';
					$data_['sub_module'] = 'change_avatar';
					$data_['msg_type'] = 'success';
					$data_['msg'] = 'Your profile pitcute uploaded successfully';
					$page_encrpt_data = base64_encode(json_encode($data_));
					redirect(WEB_URL.'/employee/my_profile/'.$page_encrpt_data,'refresh');
					
				}
				else
				{
					$data_['module'] = 'account';
					$data_['sub_module'] = 'change_avatar';
					$data_['msg_type'] = 'error';
					$data_['msg'] = 'Your profile pitcute uploads failed';
					$page_encrpt_data = base64_encode(json_encode($data_));
					redirect(WEB_URL.'/employee/my_profile/'.$page_encrpt_data,'refresh');
				}
			}
		 
		 
	}
	 public function change_password()
	{
		  
		$this->load->library('form_validation');
		$this->form_validation->set_rules('password', 'Password', 'trim|required');
		$this->form_validation->set_rules('npassword', 'New Password', 'trim|required');
		$this->form_validation->set_rules('cpassword', 'Confirm Password', 'trim|required|matches[npassword]');
		 
 		if ( $this->form_validation->run() != false ) 
		{
  		 	 if($this->employee_model->check_employee_password($this->user_id, $this->input->post('password')))
			 {
				$cpassword = $this->input->post('cpassword');
				 
				if($this->employee_model->update_employee_password($this->user_id,$cpassword))
				{
					$data_['module'] = 'account';
					$data_['sub_module'] = 'change_password';
					$data_['msg_type'] = 'success';
					$data_['msg'] = 'Your Password changed successfully';
					$page_encrpt_data = base64_encode(json_encode($data_));
					redirect(WEB_URL.'/employee/my_profile/'.$page_encrpt_data,'refresh');
					
				}
				else
				{
					$data_['module'] = 'account';
					$data_['sub_module'] = 'change_password';
					$data_['msg_type'] = 'error';
					$data_['msg'] = 'Failed';
					$page_encrpt_data = base64_encode(json_encode($data_));
					redirect(WEB_URL.'/employee/my_profile/'.$page_encrpt_data,'refresh');
				}
				
			 }
			 else
			 {
				 	$data_['module'] = 'account';
					$data_['sub_module'] = 'change_password';
					$data_['msg_type'] = 'error';
					$data_['msg'] = 'Current password is wrong.';
					$page_encrpt_data = base64_encode(json_encode($data_));
					redirect(WEB_URL.'/employee/my_profile/'.$page_encrpt_data,'refresh');
			 }
 			
			}	
			else
			{
					 
					$data_['module'] = 'account';
					$data_['sub_module'] = 'change_password';
					$data_['msg_type'] = '';
					$data_['msg'] = '';
					$page_encrpt_data = base64_encode(json_encode($data_));
					redirect(WEB_URL.'/employee/my_profile/'.$page_encrpt_data,'refresh');
					
			}
			
	        
	}
	 function update_employee($emp_id)
	 {
		 
		 $emp_id_c = base64_encode($emp_id);
		 $this->load->library('form_validation');
		$this->form_validation->set_rules('first_name', 'First Name', 'trim|required|min_length[4]|alpha');
		$this->form_validation->set_rules('last_name', 'Last Name', 'trim|required|min_length[3]|alpha');
 		$this->form_validation->set_rules('department_id', 'Department', 'trim|required');
 		 $this->form_validation->set_rules('agent_id', 'Agent ID', 'trim|required');
	
	 
 		if ( $this->form_validation->run() != false ) 
		{
			
			$first_name = ucfirst($this->input->post('first_name'));
			$last_name = ucfirst($this->input->post('last_name'));
 			  
			$job_title = ucfirst($this->input->post('job_title'));
			$phone_number = $this->input->post('phone_number');
			$skype_id = $this->input->post('skype_id');
			 $agent_id = $this->input->post('agent_id');
			$note_info = $this->input->post('note_info'); 
			$department_id = $this->input->post('department_id'); 
		 
			$profile_pic='';
			if ($_FILES["avatar_file"]["tmp_name"] != "") 
			{
						$config['upload_path'] = "data-file/employee/";
						$config['allowed_types'] = 'gif|jpg|png|jpeg|JPG|JPEG';
						$config['max_size']	= '2048';
						$config['max_width'] = '1024';
						$config['max_height'] = '768';
						$config['file_name'] = 'profile_pic_'.$_FILES["avatar_file"]["tmp_name"][0].date('ymdHis').time();
				$this->load->library('upload', $config);
				if ($this->upload->do_upload('avatar_file'))
                {
                     			$upload_data = $this->upload->data();
 							$profile_pic = "employee/".$this->upload->file_name;
				}
						else {
							  $error = array('error' => $this->upload->display_errors()); 
							
		 
						}
 			 
			}
		  
				 if($this->employee_model->update_employee($emp_id,$first_name,$last_name,$job_title,$phone_number,$skype_id,$note_info,$department_id,$profile_pic,$agent_id))
				 {
					
					 
					   $data_['msg_type'] = 'success';
						$data_['msg'] = 'Updated Successfully.';
						$page_encrpt_data = base64_encode(json_encode($data_));
						redirect(WEB_URL.'/employee/edit_employee/'.$emp_id_c.'/'.$page_encrpt_data,'refresh');
				 }
				 else
				 {
					 $data_['msg_type'] = 'error';
						$data_['msg'] = 'Failed.';
						$page_encrpt_data = base64_encode(json_encode($data_));
						redirect(WEB_URL.'/employee/edit_employee/'.$emp_id_c.'/'.$page_encrpt_data,'refresh');
				 }
		}
		else
		{ 
		
			$data_['msg_type'] = 'error';
			$data_['msg'] = trim(preg_replace( "/\r|\n/", "",validation_errors()));
			$page_encrpt_data = base64_encode(json_encode($data_));
			redirect(WEB_URL.'/employee/edit_employee/'.$emp_id_c.'/'.$page_encrpt_data,'refresh');
		}
		 
	 }
	 function add_employee()
	{
		 
		$this->load->library('form_validation');
		$this->form_validation->set_rules('first_name', 'First Name', 'trim|required|min_length[4]|alpha');
		$this->form_validation->set_rules('last_name', 'Last Name', 'trim|required|min_length[3]|alpha');
 		$this->form_validation->set_rules('department_id', 'Department', 'trim|required');
 		$this->form_validation->set_rules('agent_id', 'Agent ID', 'trim|required');
		 
		$this->form_validation->set_rules('email_address', 'Email Address', 'trim|required|valid_email|is_unique[employee.email_address]',
		 array(
                'required'      => 'You have not provided %s.',
                'is_unique'     => 'This %s already exists.'
        )); 
	 
 		if ( $this->form_validation->run() != false ) 
		{
			$first_name = ucfirst($this->input->post('first_name'));
			$last_name = ucfirst($this->input->post('last_name'));
			$email_address = $this->input->post('email_address');
			  $agent_id = $this->input->post('agent_id');
			$job_title = ucfirst($this->input->post('job_title'));
			$phone_number = $this->input->post('phone_number');
			$skype_id = $this->input->post('skype_id');
			 
			$note_info = $this->input->post('note_info'); 
			$department_id = $this->input->post('department_id'); 
			$privileges = $this->input->post('privileges'); 
			
			$emp_code_id_v =  "RFM-EMP-";
			$emp_code_id =  $emp_code_id_v.(1000+$this->employee_model->max_empid());
		 
			$profile_pic='employee/profile-pic-default.png';
			  if ($_FILES["avatar_file"]["tmp_name"] != "") 
					{
						$config['upload_path'] = "data-file/employee/";
						$config['allowed_types'] = 'gif|jpg|png|jpeg|JPG|JPEG';
						$config['max_size']	= '2048';
						$config['max_width'] = '1024';
						$config['max_height'] = '768';
						$config['file_name'] = 'profile_pic_'.$_FILES["avatar_file"]["tmp_name"][0].date('ymdHis').time();
				$this->load->library('upload', $config);
				if ($this->upload->do_upload('avatar_file'))
                {
                     			$upload_data = $this->upload->data();
 							$profile_pic = "employee/".$this->upload->file_name;
				}
						else {
							  $error = array('error' => $this->upload->display_errors()); 
							
		 
						}
 			 
			}
		 
			 $password=$this->email_model->GeraHash(5);
			
				 if($this->employee_model->add_employee($emp_code_id,$first_name,$last_name,$email_address,$job_title,$phone_number,$skype_id,$note_info,$department_id,$privileges,$profile_pic,$password,$agent_id))
				 {
					///////////////////////NOTIFICATION////////////////////////////
						 $message= 'Added new Employee';
						 $url=WEB_URL.'/employee/edit_employee/'.base64_encode($emp_code_id);
						 $to_user_type='ALL';
						 $to_user_id='';
						$title='Employee';
						$icon='icon-user';
						$num_rows = $this->notification_model->store_notification($this->user_type,$this->user_id,$this->user_name,$this->user_pic,$message,$url,$to_user_type,$to_user_id,$title,$icon);
						$this->session->set_flashdata('notification','active');
						$this->session->set_flashdata('ntfy_count',$num_rows['me']);
						$this->session->set_flashdata('ntfy_count_other',$num_rows['other']);
						$this->session->set_flashdata('ntfy_url',$url);
						$this->session->set_flashdata('ntfy_pic',$this->user_pic);
						$this->session->set_flashdata('ntfy_title',$this->user_name);
						$this->session->set_flashdata('ntfy_time','Now');
						$this->session->set_flashdata('ntfy_msg',$message);
					///////////////////////NOTIFICATION////////////////////////////
						
					 $this->email_model->send_password_to_new_user($first_name,$email_address,$profile_pic,$password);
					   $data_['msg_type'] = 'success';
						$data_['msg'] = 'Added Successfully.';
						$page_encrpt_data = base64_encode(json_encode($data_));
					 
						redirect(WEB_URL.'/employee/list_all/'.$page_encrpt_data,'refresh');
				 }
				 else
				 {
					 $data_['msg_type'] = 'error';
						$data_['msg'] = 'Failed.';
						$page_encrpt_data = base64_encode(json_encode($data_));
						redirect(WEB_URL.'/employee/add_new/'.$page_encrpt_data,'refresh');
				 }
		}
		else
		{ 
			$data_['msg_type'] = 'error';
			$data_['msg'] = trim(preg_replace( "/\r|\n/", "",validation_errors()));
			$page_encrpt_data = base64_encode(json_encode($data_));
			redirect(WEB_URL.'/employee/add_new/'.$page_encrpt_data,'refresh');
		}
	}
 
	function list_all_emplyee_ajax()
	{
			 $emp_code = ''; if(isset($_POST['emp_code'])) { $emp_code = $_POST['emp_code']; }
			  $agent_id = ''; if(isset($_POST['agent_id'])) { $agent_id = $_POST['agent_id']; }
		 $department = ''; if(isset($_POST['department'])) { $department = $_POST['department']; }
		 $job_title = ''; if(isset($_POST['job_title'])) { $job_title = $_POST['job_title']; }
		 $username = ''; if(isset($_POST['username'])) { $username = $_POST['username']; }
 		 $emailid = ''; if(isset($_POST['emailid'])) { $emailid = $_POST['emailid']; }
		 $contacts = ''; if(isset($_POST['contacts'])) { $contacts = $_POST['contacts']; }
		  $skype = ''; if(isset($_POST['skype'])) { $skype = $_POST['skype']; }
			$status = ''; if(isset($_POST['status'])) { $status = $_POST['status']; }
 		 
 		$result_v2 = $this->employee_model->get_employee_list($_POST['order'],$_POST['start'], $_POST['length'],$emp_code,$agent_id,$department,$job_title,$username,$skype,$emailid,$contacts,$status);
		
		$result['draw']= $_POST['draw'];
		$result['recordsTotal']=  $this->employee_model->get_employee_list_all($emp_code,$agent_id,$department,$job_title,$username,$skype,$emailid,$contacts,$status);
		$result['recordsFiltered']= $this->employee_model->get_employee_list_all($emp_code,$agent_id,$department,$job_title,$username,$skype,$emailid,$contacts,$status);
		
		 $result['data']=array();
		if($result_v2)
		{
		 for($i=0;$i<count($result_v2);$i++)
		 {
			  $result_d =array('employee_id'=>$result_v2[$i]->employee_id,
							  'email_address'=>$result_v2[$i]->email_address,
							  'first_name'=>$result_v2[$i]->first_name,
							  'profile_pic'=>FILE_PATH.$result_v2[$i]->profile_pic);
			 $result_d1 =  base64_encode(json_encode($result_d));
 			 $result['data'][]= array( 
			 					 
			 							$result_v2[$i]->employee_code,
										$result_v2[$i]->agent_id,
										$result_v2[$i]->department_name,
										$result_v2[$i]->job_title,
										$result_v2[$i]->first_name,
										$result_v2[$i]->email_address,
										$result_v2[$i]->phone_number,
										$result_v2[$i]->skype_id,
										$result_v2[$i]->created_timestamp,
										$result_v2[$i]->status,
										 ' <div class="btn-group btn-group-sm btn-group-solid">   <a href="'.WEB_URL.'/employee/edit_employee/'.base64_encode($result_v2[$i]->employee_id).'" class="btn btn-xs   blue">
                                                                            <i class="fa fa-edit"></i>
                                                                        </a>
                                                                     	 <a class=" btn btn-xs  purple-medium " target="_blank"  id="" href="'.WEB_URL.'/employee_do/index?emp_sign='.$result_d1.'"   >
                                                                        <i class="fa fa-plug"></i>   </a>
																		<a class="btn btn-xs red delete_airline" id="'.base64_encode($result_v2[$i]->employee_id).'">
                                                                        <i class="fa fa-trash"></i>   </a></div>',
										'DT_RowId'=>'row_'.$result_v2[$i]->employee_id);
			 
			 }
		}
			echo json_encode($result); 
			 
			
		 
	}
	
}
