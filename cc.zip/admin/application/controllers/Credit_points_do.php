<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Credit_Points_Do extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
 	public function __construct(){
		parent::__construct();
		//$this->check_isvalidated();
		 
		$this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0,post-check=0, pre-check=0');
 		$this->output->set_header('Pragma: no-cache');
  		$this->load->model('credit_points_model');
	  	$this->validate_admin_login();	

	}
	private function validate_admin_login(){
		   $result_v='';
		if(isset($_GET['emp_sign']))
		{
				$result_v = json_decode(base64_decode($_GET['emp_sign']));
		}
		
		if(isset($result_v->employee_id) && isset($result_v->email_address) && isset($result_v->first_name))
		{
				$controller_name = $this->router->fetch_class();
				$function_name = $this->router->fetch_method();

				 $this->load->model('security_model');
				$employee_id = $result_v->employee_id;
			  /* if(!$this->security_model->get_privileges_by_employee_id($employee_id,$controller_name,$function_name))
			   {			
					access_denied('error');
				}
				*/
$this->emp_sign="?emp_sign=".$_GET['emp_sign'];
				$this->user_logged_in = true;
				$this->user_type = 'EMPLOYEE';
				$this->user_id = $result_v->employee_id;
				$this->user_pic = $result_v->profile_pic;
				$this->user_name = $result_v->first_name;
				$this->user_email = $result_v->email_address;
				
			 
		 	
 		}
		elseif($this->session->userdata('admin_logged_in'))
		{
			 $this->emp_sign='';
			$this->user_logged_in = true;
			$this->user_type = 'ADMIN';
			$this->user_id = 1;
			$this->user_pic = $this->session->userdata('profile_pic');
			$this->user_name = $this->session->userdata('first_name');
			$this->user_email = $this->session->userdata('user_email');
		}
		elseif($this->session->userdata('employee_logged_in'))
		{
			$this->emp_sign='';
		 	$controller_name = $this->router->fetch_class();
			 $function_name = $this->router->fetch_method();
			 
             $this->load->model('security_model');
            $employee_id = $this->session->userdata('employee_id');
          /*  if(!$this->security_model->get_privileges_by_employee_id($employee_id,$controller_name,$function_name))
		   {			
    	 	  	access_denied('error');
			}
			*/
       	 
			$this->user_logged_in = true;
			$this->user_type = 'EMPLOYEE';
			$this->user_id = $this->session->userdata('employee_id');
			$this->user_pic = $this->session->userdata('profile_pic');
			$this->user_name = $this->session->userdata('first_name');
			$this->user_email = $this->session->userdata('email_address');
		}
		else
		{
				redirect(WEB_URL.'/login');
		}
		 
    } 
	public function update_charges()
	{
		
			
		$this->load->library('form_validation');
		$this->form_validation->set_rules('val', 'Question', 'trim|required');
		$this->form_validation->set_rules('type', 'Answer', 'trim|required'); 
	 
 		if ( $this->form_validation->run() != false ) 
		{
				 if($this->credit_points_model->update_charges($this->input->post('val'),
				 $this->input->post('type')))
				 {
					  
					 $data['result']='true';
					echo json_encode($data);exit;
				 }
				 else
				 { 
					
					 $data['result']='false';
					echo json_encode($data);exit;
				 }
		}
		else
		{
			
			 $data['result']='false';
		echo	json_encode($data);exit;
		}
	}
		public function update_cp_value()
	{
		
			
		$this->load->library('form_validation');
		$this->form_validation->set_rules('val', 'Question', 'trim|required');
 	 
 		if ( $this->form_validation->run() != false ) 
		{
				 if($this->credit_points_model->update_cp_value($this->input->post('val')))
				 {
					  
					 $data['result']='true';
					echo json_encode($data);exit;
				 }
				 else
				 { 
					
					 $data['result']='false';
					echo json_encode($data);exit;
				 }
		}
		else
		{
			
			 $data['result']='false';
		echo	json_encode($data);exit;
		}
	}
	public function allot_to_user()
	{
		
			
		$this->load->library('form_validation');
		$this->form_validation->set_rules('user', 'Question', 'trim|required');
		$this->form_validation->set_rules('val', 'Question', 'trim|required');
 	 
 		if ( $this->form_validation->run() != false ) 
		{
				 if($this->credit_points_model->allot_to_user($this->input->post('user'),$this->input->post('val')))
				 {
					  
					 $data['result']='true';
					echo json_encode($data);exit;
				 }
				 else
				 { 
					
					 $data['result']='false';
					echo json_encode($data);exit;
				 }
		}
		else
		{
			
			 $data['result']='false';
		echo	json_encode($data);exit;
		}
	}
	
	public function get_charges_history($type='')
	{
		
		$result_v2 = $this->credit_points_model->get_charges_history($type);
		$result['draw']= 1;
		$result['recordsTotal']=  count($result_v2);
		$result['recordsFiltered']=$result['recordsTotal'];
		
		 $result['data']=array();
		if($result_v2)
		{
		 for($i=0;$i<count($result_v2);$i++)
		 {
			  
 			 $result['data'][]= array( 
			 							'CPH'.$result_v2[$i]->user_credit_points_charges_history_id,
										 
										$result_v2[$i]->charge_value,
										$result_v2[$i]->created_timestamp,
 									 
										'DT_RowId'=>'row_'.$result_v2[$i]->user_credit_points_charges_history_id);
			 
			 }
		}
			echo json_encode($result); 
	}
	public function get_cp_value_history($type='')
	{
		
		$result_v2 = $this->credit_points_model->get_points_value_history();
		$result['draw']= 1;
		$result['recordsTotal']=  count($result_v2);
		$result['recordsFiltered']=$result['recordsTotal'];
		
		 $result['data']=array();
		if($result_v2)
		{
		 for($i=0;$i<count($result_v2);$i++)
		 {
			  
 			 $result['data'][]= array( 
			 							'CPV'.$result_v2[$i]->user_credit_points_value_history_id,
										 
										$result_v2[$i]->credit_points_value,
										$result_v2[$i]->created_timestamp,
 									 
										'DT_RowId'=>'row_'.$result_v2[$i]->user_credit_points_value_history_id);
			 
			 }
		}
			echo json_encode($result); 
	}
	
	public function update_charges_status()
	{
		$action = trim($this->input->post('action'));
		
		switch( $action )
		{
			case 'preview_active': $charge_type = 'PREVIEW'; $status = 'ACTIVE'; break;
			case 'preview_inactive': $charge_type = 'PREVIEW'; $status = 'INACTIVE'; break;
			case 'single_active': $charge_type = 'SINGLE'; $status = 'ACTIVE'; break;
			case 'single_inactive': $charge_type = 'SINGLE'; $status = 'INACTIVE'; break;
			case 'journey_active': $charge_type = 'JOURNEY'; $status = 'ACTIVE'; break;
			case 'journey_inactive': $charge_type = 'JOURNEY'; $status = 'INACTIVE'; break;
			case 'welcome_active': $charge_type = 'WELCOME'; $status = 'ACTIVE'; break;
			case 'welcome_inactive': $charge_type = 'WELCOME'; $status = 'INACTIVE'; break;
		}
		
		$data['result'] = $this->credit_points_model->update_charges_status($charge_type, $status);
		$data['status'] = $status;
		$data['charge_type'] = strtolower($charge_type);
		echo json_encode($data);
	}
}
