<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Home extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	private $employee_login  ='';
	
 	public function __construct(){
		parent::__construct();
		//$this->check_isvalidated();
		 
		$this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0,post-check=0, pre-check=0');
 		$this->output->set_header('Pragma: no-cache');
		
 		$this->load->model('admin_model');
	  	$this->validate_admin_login();	
		
		
	}
	private function validate_admin_login(){
		 
		$result_v='';
		if(isset($_GET['emp_sign']))
		{
				$result_v = json_decode(base64_decode($_GET['emp_sign']));
		}
		
		if(isset($result_v->employee_id) && isset($result_v->email_address) && isset($result_v->first_name))
		{
				$controller_name = $this->router->fetch_class();
				$function_name = $this->router->fetch_method();

				 $this->load->model('security_model');
				$employee_id = $result_v->employee_id;
			   if(!$this->security_model->get_privileges_by_employee_id($employee_id,$controller_name,$function_name))
			   {			
					access_denied('error');
				}

$this->emp_sign="?emp_sign=".$_GET['emp_sign'];
				$this->user_logged_in = true;
				$this->user_type = 'EMPLOYEE';
				$this->user_id = $result_v->employee_id;
				$this->user_pic = $result_v->profile_pic;
				$this->user_name = $result_v->first_name;
				$this->user_email = $result_v->email_address;
				
			 
		 	
 		}
		elseif($this->session->userdata('admin_logged_in'))
		{
			 $this->emp_sign='';
			$this->user_logged_in = true;
			$this->user_type = 'ADMIN';
			$this->user_id = 1;
			$this->user_pic = $this->session->userdata('profile_pic');
			$this->user_name = $this->session->userdata('first_name');
			$this->user_email = $this->session->userdata('user_email');
		}
		elseif($this->session->userdata('employee_logged_in'))
		{
			$this->emp_sign='';
		 	$controller_name = $this->router->fetch_class();
			 $function_name = $this->router->fetch_method();
			 
             $this->load->model('security_model');
            $employee_id = $this->session->userdata('employee_id');
           if(!$this->security_model->get_privileges_by_employee_id($employee_id,$controller_name,$function_name))
		   {			
    	 	  	access_denied('error');
			}
			
       	 
			$this->user_logged_in = true;
			$this->user_type = 'EMPLOYEE';
			$this->user_id = $this->session->userdata('employee_id');
			$this->user_pic = $this->session->userdata('profile_pic');
			$this->user_name = $this->session->userdata('first_name');
			$this->user_email = $this->session->userdata('email_address');
		}
		else
		{
				redirect(WEB_URL.'/login');
		}
		 
		 $this->overlay_employee_details = $this->security_model->get_employee_id_name($this->user_id,$this->user_type);
    }
		public function index()
	{	
 		//echo '<pre/>';
		//print_r($this->session->userdata);exit;
		if($this->user_type == 'EMPLOYEE')
		{
			redirect(WEB_URL.'/employee_do/index'.$this->emp_sign,'refresh');
		}
		else
		{
		 $data['last_login'] = $this->admin_model->get_last_login_record();
		 
 		 $this->load->view('dashboard/admin_dashboard',$data);
		}
 	} 
		 
	 
	public function get_status_count()
	{
		 $this->load->model('cases_model');
		 $case_reference_num='';
		 $label_search='';
		 $airline_codeds='';
	 
		 
		 $status[]=3;$substatus[]=1;
		 $v1 = $this->cases_model->get_cases_all($case_reference_num,$status,$substatus,$label_search,$airline_codeds);
		 
		  $status1[]=3;$substatus1[]=2;
		 $v2 = $this->cases_model->get_cases_all($case_reference_num,$status1,$substatus1,$label_search,$airline_codeds);
		 
		  $status2[]=3;$substatus2[]=3;
		 $v3 = $this->cases_model->get_cases_all($case_reference_num,$status2,$substatus2,$label_search,$airline_codeds);
		 
		 echo json_encode(array('v1'=>$v1,'v2'=>$v2,'v3'=>$v3));
	}
	function my_profile($page_encrpt_data='')
	{
		if($page_encrpt_data!='')
		{
			$data['page_data'] = json_decode(base64_decode($page_encrpt_data));
  		}
		 
		$data['admin_profile_info'] = $this->admin_model->get_admin_details($this->user_id);
		$this->load->view('dashboard/profile/my_profile',$data);
 		/*elseif($this->session->userdata('employee_logged_in'))
		{
			$data['employee_profile_info'] = $this->admin_model->get_employee_details();
			 
			$this->load->view('employee/profile/my_profile',$data);
		}*/
 		
	}
	public function update_profile()
	{
		$admin_id =$this->session->userdata('admin_id');
		$this->load->library('form_validation');
		$this->form_validation->set_rules('admin_name', 'User Name', 'trim|required');
		$this->form_validation->set_rules('email_id', 'Email Address', 'trim|required|valid_email');
		$this->form_validation->set_rules('mobile_number', 'Mobile Number', 'trim|required');
		$this->form_validation->set_rules('agent_id', 'Agent ID', 'trim|required');
		 
 		if ( $this->form_validation->run() != false ) 
		{
  			 
			 
			 $data["admin_name"] = $this->input->post('admin_name');
			 $data["admin_email"] = $this->input->post('email_id');
			 $data["admin_mobile"] = $this->input->post('mobile_number');
			 $data["agent_id"] = $this->input->post('agent_id');
 			if($this->admin_model->update_users( array('admin_id' => $admin_id),$data))
				{
					$data_['module'] = 'account';
					$data_['sub_module'] = 'personal_info';
					$data_['msg_type'] = 'success';
					$data_['msg'] = 'Your profile information updated successfully';
					$page_encrpt_data = base64_encode(json_encode($data_));
					redirect(WEB_URL.'/home/my_profile/'.$page_encrpt_data,'refresh');
					
				}
				else
				{
					$data_['module'] = 'account';
					$data_['sub_module'] = 'personal_info';
					$data_['msg_type'] = 'error';
					$data_['msg'] = 'Failed';
					$page_encrpt_data = base64_encode(json_encode($data_));
					redirect(WEB_URL.'/home/my_profile/'.$page_encrpt_data,'refresh');
				}
				
			}	
			else
			{
					 
					$data_['module'] = 'account';
					$data_['sub_module'] = 'personal_info';
					$data_['msg_type'] = 'error';
					$data_['msg'] = 'Failed';
					$page_encrpt_data = base64_encode(json_encode($data_));
					redirect(WEB_URL.'/home/my_profile/'.$page_encrpt_data,'refresh');
					
			}
			
	        
	}
	public function change_password()
	{
		 	$admin_id =$this->session->userdata('admin_id');
		$this->load->library('form_validation');
		$this->form_validation->set_rules('password', 'Password', 'trim|required');
		$this->form_validation->set_rules('npassword', 'New Password', 'trim|required');
		$this->form_validation->set_rules('cpassword', 'Confirm Password', 'trim|required|matches[npassword]');
		 
 		if ( $this->form_validation->run() != false ) 
		{
  		 	 if($this->admin_model->check_admin_password($admin_id, $this->input->post('password')))
			 {
				  $cpassword = $this->input->post('cpassword');
				 
				 if($this->admin_model->update_admin_password($admin_id,$cpassword))
				{
					$data_['module'] = 'account';
					$data_['sub_module'] = 'change_password';
					$data_['msg_type'] = 'success';
					$data_['msg'] = 'Your Password changed successfully';
					$page_encrpt_data = base64_encode(json_encode($data_));
					redirect(WEB_URL.'/home/my_profile/'.$page_encrpt_data,'refresh');
					
				}
				else
				{
					$data_['module'] = 'account';
					$data_['sub_module'] = 'change_password';
					$data_['msg_type'] = 'error';
					$data_['msg'] = 'Failed';
					$page_encrpt_data = base64_encode(json_encode($data_));
					redirect(WEB_URL.'/home/my_profile/'.$page_encrpt_data,'refresh');
				}
				
			 }
			 else
			 {
				 	$data_['module'] = 'account';
					$data_['sub_module'] = 'change_password';
					$data_['msg_type'] = 'error';
					$data_['msg'] = 'Current password is wrong.';
					$page_encrpt_data = base64_encode(json_encode($data_));
					redirect(WEB_URL.'/home/my_profile/'.$page_encrpt_data,'refresh');
			 }
 			
			}	
			else
			{
					 
					$data_['module'] = 'account';
					$data_['sub_module'] = 'change_password';
					$data_['msg_type'] = '';
					$data_['msg'] = '';
					$page_encrpt_data = base64_encode(json_encode($data_));
					redirect(WEB_URL.'/home/my_profile/'.$page_encrpt_data,'refresh');
					
			}
			
	        
	}

	public function change_logo()
	{
		if($this->session->userdata('admin_logged_in'))
		{
		$admin_id =$this->session->userdata('admin_id');
		if($admin_id)
		{
			if ($_FILES["avatar_file"]["tmp_name"] != "") 
			{
				$config['upload_path'] = "data-file/employee/";
				$config['allowed_types'] = 'gif|jpg|png';
				$config['max_size']	= '2048';
				$config['max_width'] = '1024';
				$config['max_height'] = '768';
				$config['file_name'] = 'profile_pic_'.$_FILES["avatar_file"]["tmp_name"][0].date('ymdHis').time();
				$this->load->library('upload', $config);
				  if ( ! $this->upload->do_upload('avatar_file'))
                {
                       echo $this->upload->display_errors();
				}
				$upload_data = $this->upload->data();
				
				//echo $this->upload->display_errors();
				//echo "<pre>"; var_dump($upload_data);
				$data["admin_profile_pic"] = "employee/".$this->upload->file_name;
			
				if($this->admin_model->update_users( array('admin_id' => $admin_id),$data))
				{
					$data_['module'] = 'account';
					$data_['sub_module'] = 'change_avatar';
					$data_['msg_type'] = 'success';
					$data_['msg'] = 'Your profile pitcute uploaded successfully';
					$page_encrpt_data = base64_encode(json_encode($data_));
					redirect(WEB_URL.'/home/my_profile/'.$page_encrpt_data,'refresh');
					
				}
				else
				{
					$data_['module'] = 'account';
					$data_['sub_module'] = 'change_avatar';
					$data_['msg_type'] = 'error';
					$data_['msg'] = 'Your profile pitcute uploads failed';
					$page_encrpt_data = base64_encode(json_encode($data_));
					redirect(WEB_URL.'/home/my_profile/'.$page_encrpt_data,'refresh');
				}
			}
		}
		}
		/*elseif($this->session->userdata('employee_logged_in'))
		{
		$employee_id =$this->session->userdata('employee_id');
		if($employee_id)
		{
			if ($_FILES["avatar_file"]["tmp_name"] != "") 
			{
				$config['upload_path'] = "data-file/employee/";
				$config['allowed_types'] = 'gif|jpg|png';
				$config['max_size']	= '2048';
				$config['max_width'] = '1024';
				$config['max_height'] = '768';
				$config['file_name'] = 'profile_pic_'.$_FILES["avatar_file"]["tmp_name"][0].date('ymdHis').time();
				$this->load->library('upload', $config);
				  if ( ! $this->upload->do_upload('avatar_file'))
                {
                       echo $this->upload->display_errors();
				}
				$upload_data = $this->upload->data();
				
				//echo $this->upload->display_errors();
				//echo "<pre>"; var_dump($upload_data);
				$data["profile_pic"] = "employee/".$this->upload->file_name;
			
				if($this->admin_model->update_employee_users( array('employee_id' => $employee_id),$data))
				{
					$data_['module'] = 'account';
					$data_['sub_module'] = 'change_avatar';
					$data_['msg_type'] = 'success';
					$data_['msg'] = 'Your profile pitcute uploaded successfully';
					$page_encrpt_data = base64_encode(json_encode($data_));
					redirect(WEB_URL.'/home/my_profile/'.$page_encrpt_data,'refresh');
					
				}
				else
				{
					$data_['module'] = 'account';
					$data_['sub_module'] = 'change_avatar';
					$data_['msg_type'] = 'error';
					$data_['msg'] = 'Your profile pitcute uploads failed';
					$page_encrpt_data = base64_encode(json_encode($data_));
					redirect(WEB_URL.'/home/my_profile/'.$page_encrpt_data,'refresh');
				}
			}
		}
		}*/
	}
}
