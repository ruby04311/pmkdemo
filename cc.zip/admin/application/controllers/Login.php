<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Login extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	 public function __construct(){
		parent::__construct();
	  	$this->load->model('security_model');
	  	$this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0,post-check=0, pre-check=0');
 		$this->output->set_header('Pragma: no-cache');
 	  
	}
	public function index()
	{	
	
	
		if($this->session->userdata('admin_logged_in')) //Whether already panel logged or not.
		{
			 
			redirect(WEB_URL.'/home/index','refresh');
		} 
		elseif($this->session->userdata('employee_logged_in'))
		{
			
			redirect(WEB_URL.'/employee_do/index','refresh');
		}
		
		$this->load->library('form_validation');
		$this->form_validation->set_rules('username', 'User Name', 'trim|required');
		$this->form_validation->set_rules('password', 'Password', 'trim|required');
 
		$data['status']='';
		
		if ( $this->form_validation->run() != false ) 
		{
			if(strtolower($_POST['username'])=="admin")
			{
				
		 
			 
			$type ="URL";
			$last_track_id = $this->security_model->admin_ip_track($type);
			 
			 $result = $this->security_model->check_admin_login($this->input->post('username')); 
			 
					if($result['status']==1)
					{
						$result = $this->security_model->check_admin_login($this->input->post('username'),$this->input->post('password')); 
			 
							if($result['status']==1)
							{
								$type ="SUCCESS";
								$user_type = 'ADMIN';
								$this->security_model->admin_ip_track($type,$user_type,$result['result']->admin_id,$result['result']->admin_name,FILE_PATH.$result['result']->admin_profile_pic);
								$sessionUserInfo = array( 
								'admin_id' 		=> $result['result']->admin_id,
								'first_name'	 		=> $result['result']->admin_name,
								'user_email'	 		=> $result['result']->admin_email,
								'profile_pic'	 		=> FILE_PATH.$result['result']->admin_profile_pic,
								'admin_logged_in' 	=> TRUE
								);
								$this->session->set_userdata($sessionUserInfo);
		
								redirect(WEB_URL.'/home/index', 'refresh');
							}
							else
							{
								$type ="WRONG_PASSWORD";
								$last_track_id = $this->security_model->admin_ip_track($type);
								$data['status']='Incorrect Password';
								$this->load->view('login/admin_login',$data);
							}
							
						 
					}
					else
					{
						$type ="WRONG_USERNAME";
						$last_track_id = $this->security_model->admin_ip_track($type);
						$data['status']='Incorrect Username';
						$this->load->view('login/admin_login',$data);
					}
				
			
			}
			else
			{
				
		 
			
			//$type ="URL";
			//$last_track_id = $this->security_model->admin_ip_track($type);
			 
			 $result = $this->security_model->check_employee_login($this->input->post('username')); 
			 
					if($result['status']==1)
					{
						$result = $this->security_model->check_employee_login($this->input->post('username'),$this->input->post('password')); 
			 
							if($result['status']==1)
							{
								$type ="SUCCESS";
								$user_type = 'EMPLOYEE';
								$this->security_model->admin_ip_track($type,$user_type,$result['result']->employee_id,$result['result']->first_name,FILE_PATH.$result['result']->profile_pic);
								 
								$sessionUserInfo = array( 
								'employee_id' 		=> $result['result']->employee_id,
								'first_name'	 		=> $result['result']->first_name,
								'user_email'	 		=> $result['result']->email_address,
								'profile_pic'	 		=> FILE_PATH.$result['result']->profile_pic,
								'employee_logged_in' 	=> TRUE
								);
								$this->session->set_userdata($sessionUserInfo);
		
								redirect(WEB_URL.'/employee_do/index', 'refresh');
							}
							else
							{
							//	$type ="WRONG_PASSWORD";
							//	$last_track_id = $this->security_model->admin_ip_track($type);
								$data['status']='Incorrect Password';
								$this->load->view('login/admin_login',$data);
							}
							
						 
					}
					else
					{
					//	$type ="WRONG_USERNAME";
					//	$last_track_id = $this->security_model->admin_ip_track($type);
						$data['status']='Incorrect Username';
						$this->load->view('login/admin_login',$data);
					}
				
			
			}
			
			
		}	
		else
		{
		   $type ="URL";
		   $last_track_id = $this->security_model->admin_ip_track($type);
		 
		 if(validation_errors())
			{
				$data['status'] =  'Required Fileds Are Missing.';
			}
				 
				$this->load->view('login/admin_login',$data);
				
		}
			
	       
		 
	
	} 
	public function forget_password()
	{	
	
	
		if($this->session->userdata('admin_logged_in')) //Whether already panel logged or not.
		{
			 
			redirect(WEB_URL.'/home/index','refresh');
		} 
		elseif($this->session->userdata('employee_logged_in'))
		{
			
			redirect(WEB_URL.'/employee_do/index','refresh');
		}
		
		$this->load->library('form_validation');
		$this->form_validation->set_rules('username', 'User Name', 'trim|required');
  
		$data['status_f']='';
		
		if ( $this->form_validation->run() != false ) 
		{
			if(strtolower($_POST['username'])=="admin")
			{
				
		 
			 
			$type ="URL";
			$last_track_id = $this->security_model->admin_ip_track($type);
			 
			 $result = $this->security_model->check_admin_login($this->input->post('username')); 
			 
					if($result['status']==1)
					{ 
						$data['status_f']='Kindly contact to support.';
						$this->load->view('login/forget_password',$data);
					}
					else
					{
						$type ="WRONG_USERNAME";
						$last_track_id = $this->security_model->admin_ip_track($type);
						$data['status_f']='Incorrect Username';
						$this->load->view('login/forget_password',$data);
					}
				
			
			}
			else
			{
				
		 
			
			//$type ="URL";
			//$last_track_id = $this->security_model->admin_ip_track($type);
			 
					$result = $this->security_model->check_employee_login($this->input->post('username')); 
			 
					if($result['status']==1)
					{
 						 $this->load->model('email_model');
 						  $this->email_model->send_forget_password($result['result']->first_name,$result['result']->email_address,$result['result']->profile_pic,$result['result']->password);
						  $data['status_f']='Password has been sent to your email address.';
						 $this->load->view('login/forget_password',$data);
					}
					else
					{
					//	$type ="WRONG_USERNAME";
					//	$last_track_id = $this->security_model->admin_ip_track($type);
						$data['status_f']='Incorrect Username';
						$this->load->view('login/forget_password',$data);
					}
				
			
			}
			
			
		}	
		else
		{
		   $type ="URL";
		   $last_track_id = $this->security_model->admin_ip_track($type);
		 
		 if(validation_errors())
			{
				$data['status_f'] =  'Required Fileds Are Missing.';
			}
				 
				$this->load->view('login/forget_password',$data);
				
		}
			
	       
		 
	
	} 
	public function send_message()
	{	
	
	
		if($this->session->userdata('admin_logged_in')) //Whether already panel logged or not.
		{
			 
			redirect(WEB_URL.'/home/index','refresh');
		} 
		elseif($this->session->userdata('employee_logged_in'))
		{
			
			redirect(WEB_URL.'/employee_do/index','refresh');
		}
		
		$this->load->library('form_validation');
		$this->form_validation->set_rules('fullname', 'User Name', 'trim|required');
		$this->form_validation->set_rules('email', 'email', 'trim|required');
		$this->form_validation->set_rules('message', 'message', 'trim|required');
  
		$data['status_s']='';
		
		if ( $this->form_validation->run() != false ) 
		{
  			 $insert_id = $this->security_model->store_send_message($_POST['fullname'],$_POST['email'],$_POST['message']);
			 
			 ///////////////////////NOTIFICATION////////////////////////////
 						 $url=WEB_URL.'/notification/view/'.base64_encode($insert_id);
						$to_user_type='ADMIN';
						$to_user_id='1';
						$title='Send A Message';
						$icon='icon-support';
						$message = $_POST['message']."<br/>---------------------<br/>FROM : ".$_POST['email'];
						$this->notification_model->store_notification('','',$_POST['fullname'],FILE_PATH.'employee/profile-pic-default.png',$message,$url,$to_user_type,$to_user_id,$title,$icon);
						 
			///////////////////////NOTIFICATION////////////////////////////
			 $data['status_s']='Thank you for contact. We will respond as soon as possible.';
			 $this->load->view('login/send_message',$data);
					 
		}	
		else
		{
		  
 			 if(validation_errors())
			{
				$data['status_s'] =  'Required Fileds Are Missing.';
			}
				 
				$this->load->view('login/send_message',$data);
				
		}
			
	       
		 
	
	} 
	public function lockoff(){
       
			$sessionUserInfo_logoff = array( 
						'admin_logged_in' 		=> false
						);
						$this->session->set_userdata($sessionUserInfo_logoff);
        redirect(WEB_URL.'/login/login_off', 'refresh'); 
    }
	public function login_off(){
		
		if(!$this->session->userdata('admin_id')){
	      	redirect(WEB_URL.'/login');
		} 
		else
		{
			$data['admin_details'] =  $this->security_model->get_admin_details();
			 
			$this->load->view('login/logoff',$data);
		}
		
	
	}
	public function logoff_do(){
		 
		if(!$this->session->userdata('admin_id'))
		{
	      	redirect(WEB_URL.'/login');
		} 
		else
		{
			
		$this->load->library('form_validation'); 
		$this->form_validation->set_rules('password', 'Password', 'required'); 
	  
		if ( $this->form_validation->run() != false ) 
		{
			
		if($this->security_model->check_admin_password($this->session->userdata('admin_id'), $this->input->post('password')))
		 {
				$sessionUserInfo_logoff = array( 
						'admin_logged_in' 		=> true
						);
						$this->session->set_userdata($sessionUserInfo_logoff);
				redirect(WEB_URL);
			}
			else
			{
				 redirect(WEB_URL.'/login/login_off', 'refresh');
			}
		}
		else
		{
			 redirect(WEB_URL.'/login/login_off', 'refresh'); 
		}
		}
	
	}
	
	public function logout(){
        $this->session->unset_userdata('sessionUserInfo');
		$this->session->sess_destroy();
        redirect(WEB_URL.'/login', 'refresh'); 
    }
}
