<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Messages extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
 	public function __construct(){
		parent::__construct();
		//$this->check_isvalidated();
		 
		$this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0,post-check=0, pre-check=0');
 		$this->output->set_header('Pragma: no-cache');
		
 	 
	  	$this->validate_admin_login();	
	}
	private function validate_admin_login(){
		 
		 $result_v='';
		if(isset($_GET['emp_sign']))
		{
				$result_v = json_decode(base64_decode($_GET['emp_sign']));
		}
		
		if(isset($result_v->employee_id) && isset($result_v->email_address) && isset($result_v->first_name))
		{
				$controller_name = $this->router->fetch_class();
				$function_name = $this->router->fetch_method();

				 $this->load->model('security_model');
				$employee_id = $result_v->employee_id;
			 /*  if(!$this->security_model->get_privileges_by_employee_id($employee_id,$controller_name,$function_name))
			   {			
					access_denied('error');
				}*/

$this->emp_sign="?emp_sign=".$_GET['emp_sign'];
				$this->user_logged_in = true;
				$this->user_type = 'EMPLOYEE';
				$this->user_id = $result_v->employee_id;
				$this->user_pic = $result_v->profile_pic;
				$this->user_name = $result_v->first_name;
				$this->user_email = $result_v->email_address;
				
			 
		 	
 		}
		elseif($this->session->userdata('admin_logged_in'))
		{
			 $this->emp_sign='';
			$this->user_logged_in = true;
			$this->user_type = 'ADMIN';
			$this->user_id = 1;
			$this->user_pic = $this->session->userdata('profile_pic');
			$this->user_name = $this->session->userdata('first_name');
			$this->user_email = $this->session->userdata('user_email');
		}
		elseif($this->session->userdata('employee_logged_in'))
		{
			$this->emp_sign='';
		 	$controller_name = $this->router->fetch_class();
			 $function_name = $this->router->fetch_method();
			 
             $this->load->model('security_model');
            $employee_id = $this->session->userdata('employee_id');
        /*   if(!$this->security_model->get_privileges_by_employee_id($employee_id,$controller_name,$function_name))
		   {			
    	 	  	access_denied('error');
			}*/
			
       	 
			$this->user_logged_in = true;
			$this->user_type = 'EMPLOYEE';
			$this->user_id = $this->session->userdata('employee_id');
			$this->user_pic = $this->session->userdata('profile_pic');
			$this->user_name = $this->session->userdata('first_name');
			$this->user_email = $this->session->userdata('email_address');
		}
		else
		{
				redirect(WEB_URL.'/login');
		}
		 $this->overlay_employee_details = $this->security_model->get_employee_id_name($this->user_id,$this->user_type);
    }
	  
	function index()
	{
		 $search_text='';
		$result  =  $this->notification_model->get_message_all($this->user_type,$this->user_id,$search_text);
 		$data['result'] = $result['result'];
		$data['result_all_count'] = $result['count_all'];
		
		$data['start'] =  $result['offset']+1;
		$data['start_visible']='';$data['start_visible_v'] = '';
		if($data['start']==1)
		{
			$data['start_visible'] = 'disabled';
			$data['start_visible_v'] = 'style="    border-color: #d6d6d6; color: #060606;"';
			
		}
		$end = $result['offset']+10;
	 	if($data['result_all_count']< $end)
		{
			$data['end'] = $data['result_all_count'];
			$data['end_visible'] = 'disabled';
			$data['end_visible_v'] = 'style="    border-color: #d6d6d6; color: #060606;"';
		}
		else
		{
			$data['end'] = $end;
			$data['end_visible'] ='';$data['end_visible_v'] ='';
		}
		
		 
		// echo '<pre/>';
		// print_r($data);exit;
		$data['inbox_count'] =  $this->notification_model->get_message_all_inbox_count($this->user_type,$this->user_id); 
		$data['sent_count'] = $this->notification_model->get_message_all_sent_count($this->user_type,$this->user_id); 
  		 $this->load->view('messages/view',$data);
		 
	}
	function get_inbox_messages($offset=0,$search_text='')
	{
	 
		$result  =  $this->notification_model->get_message_all($this->user_type,$this->user_id,$search_text,$offset);
 		$data['result'] = $result['result'];
		$data['result_all_count'] = $result['count_all'];
		
		$data['start'] =  $result['offset']+1;
		$data['start_visible']='';$data['start_visible_v'] = '';
		if($data['start']==1)
		{
			$data['start_visible'] = 'disabled';
			$data['start_visible_v'] = 'style="    border-color: #d6d6d6; color: #060606;"';
			
		}
		$end = $result['offset']+10;
	 	if($data['result_all_count']< $end)
		{
			$data['end'] = $data['result_all_count'];
			$data['end_visible'] = 'disabled';
			$data['end_visible_v'] = 'style="    border-color: #d6d6d6; color: #060606;"';
		}
		else
		{
			$data['end'] = $end;
			$data['end_visible'] ='';$data['end_visible_v'] ='';
		}
   		$result = $this->load->view('messages/view_ajax',$data,true);
		
		echo json_encode(array('result'=>$result));
		 
	}
	   function sent()
	{
	 
		 $search_text='';
		$result  =  $this->notification_model->get_message_all_sent($this->user_type,$this->user_id,$search_text);
 		$data['result'] = $result['result'];
		$data['result_all_count'] = $result['count_all'];
		
		$data['start'] =  $result['offset']+1;
		$data['start_visible']='';$data['start_visible_v'] = '';
		if($data['start']==1)
		{
			$data['start_visible'] = 'disabled';
			$data['start_visible_v'] = 'style="    border-color: #d6d6d6; color: #060606;"';
			
		}
		$end = $result['offset']+10;
	 	if($data['result_all_count']< $end)
		{
			$data['end'] = $data['result_all_count'];
			$data['end_visible'] = 'disabled';
			$data['end_visible_v'] = 'style="    border-color: #d6d6d6; color: #060606;"';
		}
		else
		{
			$data['end'] = $end;
			$data['end_visible'] ='';$data['end_visible_v'] ='';
		}
		
		 
		// echo '<pre/>';
		// print_r($data);exit;
		$data['inbox_count'] =  $this->notification_model->get_message_all_inbox_count($this->user_type,$this->user_id); 
		$data['sent_count'] = $this->notification_model->get_message_all_sent_count($this->user_type,$this->user_id); 
  		 $this->load->view('messages/sent_view',$data);
		 
	}
	function get_inbox_messages_sent($offset=0,$search_text='')
	{
	 
		$result  =  $this->notification_model->get_message_all_sent($this->user_type,$this->user_id,$search_text,$offset);
 		$data['result'] = $result['result'];
		$data['result_all_count'] = $result['count_all'];
		
		$data['start'] =  $result['offset']+1;
		$data['start_visible']='';$data['start_visible_v'] = '';
		if($data['start']==1)
		{
			$data['start_visible'] = 'disabled';
			$data['start_visible_v'] = 'style="    border-color: #d6d6d6; color: #060606;"';
			
		}
		$end = $result['offset']+10;
	 	if($data['result_all_count']< $end)
		{
			$data['end'] = $data['result_all_count'];
			$data['end_visible'] = 'disabled';
			$data['end_visible_v'] = 'style="    border-color: #d6d6d6; color: #060606;"';
		}
		else
		{
			$data['end'] = $end;
			$data['end_visible'] ='';$data['end_visible_v'] ='';
		}
   		$result = $this->load->view('messages/view_ajax_sent',$data,true);
		
		echo json_encode(array('result'=>$result));
		 
	}
	function close($message_code)
	{
	 
		if($message_code!='')
		{
			$this->notification_model->close_message($this->user_type,$this->user_id,$message_code);
		 
			redirect(WEB_URL.'/messages/view/'.$message_code,'refresh');
			 
 		}
		else
		{
		 	redirect(WEB_URL.'/messages','refresh');
		}
		 
	}
	function delete($message_code)
	{
	 
		if($message_code!='')
		{
			$this->notification_model->delete_message($this->user_type,$this->user_id,$message_code);
		 
			redirect(WEB_URL.'/messages','refresh');
			 
 		}
		else
		{
		 	redirect(WEB_URL.'/messages','refresh');
		}
		 
	}
	function view($message_code='')
	{
		if($message_code!='')
		{
			$this->notification_model->update_message_visibilty($this->user_type,$this->user_id,$message_code);
			
			$data['result_v'] = $this->notification_model->get_message_all_code($message_code);
			$data['result'] = $this->notification_model->get_message_view_code($message_code); 
 			if($data['result_v'] && $data['result_v'])
			{
			 	$this->load->view('messages/view_message',$data);
			}
			else
			{
				redirect(WEB_URL.'/messages','refresh');
			}
 		}
		else
		{
		 	redirect(WEB_URL.'/messages','refresh');
		}
	}
	function reply_message($message_code='')
	{
		if($message_code!='')
		{
			if($this->notification_model->close_message_check($this->user_type,$this->user_id,$message_code))
			{
			if(isset($_POST['message']) && $_POST['message']!='')
			{
				 
				$profile_pic='';
			if (isset($_FILES["overlay_attachment"]["tmp_name"]) && $_FILES["overlay_attachment"]["tmp_name"] != "") 
			{
						$config['upload_path'] = "data-file/attachment/";
 						$config['max_size']	= '10048'; 
							$config['allowed_types'] = 'gif|jpg|png|jpeg|JPG|JPEG|DOC|pdf|PDF|ZIP|zip|docs|excel';
						$config['file_name'] = $message_code.date('ymdHis').time();
						$this->load->library('upload', $config);
				if ($this->upload->do_upload('overlay_attachment'))
                {
                     			$upload_data = $this->upload->data();
 								$profile_pic = FILE_PATH."attachment/".$this->upload->file_name;
				}
				else {
							  $error = array('error' => $this->upload->display_errors()); 
 							 echo '<pre/>';print_r($error);exit;
						}
  			 
			}
		 
				 $this->notification_model->store_overlay_message_reply($message_code,$this->user_type,$this->user_id,$this->user_name,$this->user_pic,$_POST['message'],$profile_pic);
				$notification_alert_v=array();
				
				$result_v1 = $this->notification_model->get_message_all_code($message_code);
				$other_user_list_v = explode(",",$result_v1->other_user_list);
				 for($i=0;$i<count($other_user_list_v);$i++)
				{
					$user_id_v = explode("|",$other_user_list_v[$i]);
			///////////////////////NOTIFICATION////////////////////////////
						if(strlen($_POST['message']) >24)
						{
						 $message_v= substr($_POST['message'],0,24).'...';
						}
						else
						{
						 $message_v= substr($_POST['message'],0,24);	
						}
						 $url=WEB_URL.'/messages/view/'.$message_code;
 						$title='Message';
						$icon = 'icon-bubbles';
						 $notification_alert=array();
						$notification_alert['notification'] = 'active';
						$notification_alert['ntfy_count'] = '999';
						$notification_alert['ntfy_count_other'] ='999';
						$notification_alert['ntfy_url'] =$url;
						$notification_alert['ntfy_pic'] =$this->user_pic;
						$notification_alert['ntfy_title'] =$this->user_name;
						$notification_alert['ntfy_time'] ='Now';
						$notification_alert['ntfy_msg'] =$message_v;
						$notification_alert['ntfy_from_user'] =$this->user_id;
						$notification_alert['ntfy_user'] =$user_id_v[0];
						$notification_alert_v[]=$notification_alert;
			///////////////////////NOTIFICATION////////////////////////////
				}
				 $this->session->set_flashdata('notification','active');
				 $this->session->set_flashdata('ntfy',$notification_alert_v);
						
						 
				 redirect(WEB_URL.'/messages/view/'.$message_code,'refresh');
			}
			else
			{
				 redirect(WEB_URL.'/messages/view/'.$message_code,'refresh');
			}
			
			}
			else
			{
				 redirect(WEB_URL.'/messages/view/'.$message_code,'refresh');
			}
			
		}
		else
		{
			redirect(WEB_URL.'/messages','refresh');
		}
 	}
}
