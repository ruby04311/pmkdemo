<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Email_Do extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
 	public function __construct(){
		parent::__construct();
		//$this->check_isvalidated();
		 
		$this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0,post-check=0, pre-check=0');
 		$this->output->set_header('Pragma: no-cache');
		
 		$this->load->model('email_model');
	  	$this->validate_admin_login();	

	}
	private function validate_admin_login(){
		 
		  $result_v='';
		if(isset($_GET['emp_sign']))
		{
				$result_v = json_decode(base64_decode($_GET['emp_sign']));
		}
		
		if(isset($result_v->employee_id) && isset($result_v->email_address) && isset($result_v->first_name))
		{
				$controller_name = $this->router->fetch_class();
				$function_name = $this->router->fetch_method();

				 $this->load->model('security_model');
				$employee_id = $result_v->employee_id;
			  /* if(!$this->security_model->get_privileges_by_employee_id($employee_id,$controller_name,$function_name))
			   {			
					access_denied('error');
				}*/

$this->emp_sign="?emp_sign=".$_GET['emp_sign'];
				$this->user_logged_in = true;
				$this->user_type = 'EMPLOYEE';
				$this->user_id = $result_v->employee_id;
				$this->user_pic = $result_v->profile_pic;
				$this->user_name = $result_v->first_name;
				$this->user_email = $result_v->email_address;
				
			 
		 	
 		}
		elseif($this->session->userdata('admin_logged_in'))
		{
			 $this->emp_sign='';
			$this->user_logged_in = true;
			$this->user_type = 'ADMIN';
			$this->user_id = 1;
			$this->user_pic = $this->session->userdata('profile_pic');
			$this->user_name = $this->session->userdata('first_name');
			$this->user_email = $this->session->userdata('user_email');
		}
		elseif($this->session->userdata('employee_logged_in'))
		{
			$this->emp_sign='';
		 	$controller_name = $this->router->fetch_class();
			 $function_name = $this->router->fetch_method();
			 
             $this->load->model('security_model');
            $employee_id = $this->session->userdata('employee_id');
           /*if(!$this->security_model->get_privileges_by_employee_id($employee_id,$controller_name,$function_name))
		   {			
    	 	  	access_denied('error');
			}*/
			
       	 
			$this->user_logged_in = true;
			$this->user_type = 'EMPLOYEE';
			$this->user_id = $this->session->userdata('employee_id');
			$this->user_pic = $this->session->userdata('profile_pic');
			$this->user_name = $this->session->userdata('first_name');
			$this->user_email = $this->session->userdata('email_address');
		}
		else
		{
				redirect(WEB_URL.'/login');
		}
		
    }
	function add_pdf_conversion()
	{
		 
		if($this->input->post('file_ex')  && $this->input->post('file_type') )
		{
		 if($this->email_model->add_pdf_conversion(trim($this->input->post('file_ex')),
																  trim($this->input->post('file_type'))))
				 {
					 
					  $a= 'true';
				 }
				 else
				 {
					   $a= 'false';
				 }
		}
				 else
				 {
					   $a= 'false';
				 } 
				 echo json_encode(array("result"=>$a));
				 
	}
	function delete_pdf_conversion($id)
	{
		$data_v = (base64_decode($id));
		
		  
		 if($this->email_model->delete_pdf_conversion($data_v))
		 {
 			  $a= 'true';
		 }
		 else
		 {
			   $a= 'false';
		 }
 
	    echo json_encode(array("result"=>$a));
	}
	 function get_pdf_conversion()
	{
		  
		 
 		$result_v2 = $this->email_model->get_pdf_conversion($_POST['order'],$_POST['start'], $_POST['length']);
		
		$result['draw']= $_POST['draw'];
		$result['recordsTotal']=  $this->email_model->get_pdf_conversion_all();
		$result['recordsFiltered']=$result['recordsTotal'];
		
		 $result['data']=array();
		if($result_v2)
		{
		 for($i=0;$i<count($result_v2);$i++)
		 {
			  
 			 $result['data'][]= array( 
			 							'PC'.$result_v2[$i]->pdf_convertion_types_id,
										$result_v2[$i]->file_type,
										$result_v2[$i]->file_mode,
										$result_v2[$i]->created_timestamp,
 										 '
                                                    <div class="btn-group btn-group-sm btn-group-solid">   
                                                                     	  
																		<a class="btn btn-xs red delete_flaggedword" id="'.base64_encode($result_v2[$i]->pdf_convertion_types_id).'">
                                                                        <i class="fa fa-trash"></i>   </a></div> ',
										'DT_RowId'=>'row_'.$result_v2[$i]->pdf_convertion_types_id);
			 
			 }
		}
			echo json_encode($result); 
			 
			
		 
	}
	function get_email_all()
	{
		
		 $e_type = ''; if(isset($_POST['e_type'])) { $e_type = $_POST['e_type']; }
		 $e_subject = ''; if(isset($_POST['e_subject'])) { $e_subject = $_POST['e_subject']; }
		 $e_address = ''; if(isset($_POST['e_address'])) { $e_address = $_POST['e_address']; }
		 $e_status = ''; if(isset($_POST['e_status'])) { $e_status = $_POST['e_status']; } 
		 $e_date = ''; if(isset($_POST['e_date'])) { $e_date = $_POST['e_date']; } 
			
		 
 		$result_v2 = $this->email_model->get_email_all($_POST['order'],$_POST['start'], $_POST['length'],$e_type,$e_subject,$e_address,$e_status,$e_date);
		 
		$result['draw']= $_POST['draw'];
		$result['recordsTotal']=  $this->email_model->get_email_all_all($e_type,$e_subject,$e_address,$e_status,$e_date);
		$result['recordsFiltered']=$result['recordsTotal'];
		
		 $result['data']=array();
		if($result_v2)
		{
		 for($i=0;$i<count($result_v2);$i++)
		 {
			 if($result_v2[$i]->status == 'SENT')
			 {
				 $status = $result_v2[$i]->status;
			 }
			 else
			 {
				  $status =  $result_v2[$i]->status;
			 }
 			 $result['data'][]= array( 
			 							'E'.$result_v2[$i]->email_tracking_id,
										$result_v2[$i]->email_type,
										$result_v2[$i]->subject,
										$result_v2[$i]->to_address,
										$status,
										$result_v2[$i]->created_timestamp,
 										 '<div class="btn-group btn-group-sm btn-group-solid">   
 																		<a class="btn btn-xs green " target="_blank" href="'.WEB_URL.'/email/view_email/all/'.base64_encode($result_v2[$i]->email_tracking_id).'">
                                                                        <i class="fa fa-eye"></i>   </a></div>',
										'DT_RowId'=>'row_'.$result_v2[$i]->email_tracking_id);
			 
			 }
		}
			echo json_encode($result); 
			 
			
		 
	
		
	}
	function get_email_success()
	{
		
		 $e_type = ''; if(isset($_POST['e_type'])) { $e_type = $_POST['e_type']; }
		 $e_subject = ''; if(isset($_POST['e_subject'])) { $e_subject = $_POST['e_subject']; }
		 $e_address = ''; if(isset($_POST['e_address'])) { $e_address = $_POST['e_address']; }
		 $e_status = 'SENT'; 
		 $e_date = ''; if(isset($_POST['e_date'])) { $e_date = $_POST['e_date']; } 
			
		 
 		$result_v2 = $this->email_model->get_email_all($_POST['order'],$_POST['start'], $_POST['length'],$e_type,$e_subject,$e_address,$e_status,$e_date);
		 
		$result['draw']= $_POST['draw'];
		$result['recordsTotal']=  $this->email_model->get_email_all_all($e_type,$e_subject,$e_address,$e_status,$e_date);
		$result['recordsFiltered']=$result['recordsTotal'];
		
		 $result['data']=array();
		if($result_v2)
		{
		 for($i=0;$i<count($result_v2);$i++)
		 {
			 if($result_v2[$i]->status == 'SENT')
			 {
				 $status = $result_v2[$i]->status;
			 }
			 else
			 {
				  $status =  $result_v2[$i]->status;
			 }
 			 $result['data'][]= array( 
			 							'E'.$result_v2[$i]->email_tracking_id,
										$result_v2[$i]->email_type,
										$result_v2[$i]->subject,
										$result_v2[$i]->to_address,
										 
										$result_v2[$i]->created_timestamp,
 										 '<div class="btn-group btn-group-sm btn-group-solid">   
 																		<a class="btn btn-xs green " target="_blank" href="'.WEB_URL.'/email/view_email/success/'.base64_encode($result_v2[$i]->email_tracking_id).'">
                                                                        <i class="fa fa-eye"></i>   </a></div>',
										'DT_RowId'=>'row_'.$result_v2[$i]->email_tracking_id);
			 
			 }
		}
			echo json_encode($result); 
			 
			
		 
	
		
	}
	function get_email_failure()
	{
		
		 $e_type = ''; if(isset($_POST['e_type'])) { $e_type = $_POST['e_type']; }
		 $e_subject = ''; if(isset($_POST['e_subject'])) { $e_subject = $_POST['e_subject']; }
		 $e_address = ''; if(isset($_POST['e_address'])) { $e_address = $_POST['e_address']; }
		 $e_status = 'FAILURE'; 
		 $e_date = ''; if(isset($_POST['e_date'])) { $e_date = $_POST['e_date']; } 
			
		 
 		$result_v2 = $this->email_model->get_email_all($_POST['order'],$_POST['start'], $_POST['length'],$e_type,$e_subject,$e_address,$e_status,$e_date);
		 
		$result['draw']= $_POST['draw'];
		$result['recordsTotal']=  $this->email_model->get_email_all_all($e_type,$e_subject,$e_address,$e_status,$e_date);
		$result['recordsFiltered']=$result['recordsTotal'];
		
		 $result['data']=array();
		if($result_v2)
		{
		 for($i=0;$i<count($result_v2);$i++)
		 {
			 if($result_v2[$i]->status == 'SENT')
			 {
				 $status = $result_v2[$i]->status;
			 }
			 else
			 {
				  $status =  $result_v2[$i]->status;
			 }
 			 $result['data'][]= array( 
			 							'E'.$result_v2[$i]->email_tracking_id,
										$result_v2[$i]->email_type,
										$result_v2[$i]->subject,
										$result_v2[$i]->to_address,
										 
										$result_v2[$i]->created_timestamp,
 										 '<div class="btn-group btn-group-sm btn-group-solid">   
 																		<a class="btn btn-xs green " target="_blank" href="'.WEB_URL.'/email/view_email/failure/'.base64_encode($result_v2[$i]->email_tracking_id).'">
                                                                        <i class="fa fa-eye"></i>   </a></div>',
										'DT_RowId'=>'row_'.$result_v2[$i]->email_tracking_id);
			 
			 }
		}
			echo json_encode($result); 
			 
			
		 
	
		
	}
	function resend_email($id)
	{
		 
		if($this->email_model->send_email_do_id($id))
		{
			$result['result']= '<span   class="caption-subject font-green-jungle bold "> SENT </span>';
		}
		else
		{
			$result['result']= '<span   class="caption-subject font-red-thunderbird bold "> FAILURE </span>';
		}
		echo json_encode($result);
	}
	function get_cron_email_indu($id='')
	{
		if($id!='')
		{
			$id1 = base64_decode($id);
			$data['result'] = $this->email_model->get_cron_email_indu($id1);
			$data['result_cron'] = $this->email_model->get_cron_email_id($id1);
			$this->load->view('email/cron_email_list',$data);
		}
		
	}
	
		 function get_email_cron()
	{
		    
		 $cron = ''; if(isset($_POST['cron'])) { $cron = $_POST['cron']; }
		 $case_number = ''; if(isset($_POST['case_number'])) { $case_number = $_POST['case_number']; }
		 $to_address = ''; if(isset($_POST['to_address'])) { $to_address = $_POST['to_address']; }
		 $status = ''; if(isset($_POST['status'])) { $status = $_POST['status']; } 
			$dates = ''; if(isset($_POST['dates'])) { $dates = $_POST['dates']; } 
 		 
		 
 		$result_v2 = $this->email_model->get_email_cron($_POST['order'],$_POST['start'], $_POST['length'],$cron,$case_number,$to_address,$status,$dates);
		
		$result['draw']= $_POST['draw'];
		$result['recordsTotal']=  $this->email_model->get_email_cron_all($cron,$case_number,$to_address,$status,$dates);
		$result['recordsFiltered']=$result['recordsTotal'];
		
		 $result['data']=array();
		if($result_v2)
		{
		 for($i=0;$i<count($result_v2);$i++)
		 {
			 if($result_v2[$i]->status == 'SENDING')
			 {
				  $status = $result_v2[$i]->status.' <img src="'.ASSETS.'/global/img/loading-spinner-blue.gif" >';
 			 }
			 elseif($result_v2[$i]->status == 'FAILURE')
			 {
				 $status = '<a class="ajax-demo  " id="" data-url="'.WEB_URL.'/email_do/get_cron_email_indu/'.base64_encode($result_v2[$i]->lawfirm_email_id).'" data-toggle="modal">
                             <font style="color:red">'.$result_v2[$i]->status.'<font></a>';
			 }
			 elseif($result_v2[$i]->status == 'START')
			 {
				 $status = $result_v2[$i]->status;
			 }
			 else
			 {
				 $get_count_mails_c=0;
				 $get_count_mails =  $this->email_model->get_cron_email_indu_v($result_v2[$i]->lawfirm_email_id);
				 if($get_count_mails) { $get_count_mails_c = count($get_count_mails); }
			  	if($result_v2[$i]->case_cnt!=0)
				{
				 $percentage = ceil(($get_count_mails_c/$result_v2[$i]->case_cnt)*100).'%';
				}
				else
				{
					$percentage = '';
				}
				  $status = '<a class="ajax-demo " id="" data-url="'.WEB_URL.'/email_do/get_cron_email_indu/'.base64_encode($result_v2[$i]->lawfirm_email_id).'" data-toggle="modal">
                             <font style="color:green">'.$result_v2[$i]->status.'<font></a> '.$percentage;
			 }
 			 $result['data'][]= array( 
			 							'C'.$result_v2[$i]->lawfirm_email_id,
										$result_v2[$i]->cron_type,
										$result_v2[$i]->case_number,
										$result_v2[$i]->to_address,
										$status,
										$result_v2[$i]->created_timestamp,
 										 
										'DT_RowId'=>'row_'.$result_v2[$i]->lawfirm_email_id);
			 
			 }
		}
			echo json_encode($result); 
			 
			
		 
	}
	 function change_template_status_active($data)
	{
		 
		$data_v = (base64_decode($data));
			 
		 $status='ACTIVE';
			if($this->email_model->change_template_status($data_v,$status))
			{
				return true;
			}
			else
			{
				return false;
			}
		 
	}
	function change_template_status_inactive($data)
	{
$data_v = (base64_decode($data));
 		  $status='INACTIVE';		
			if($this->email_model->change_template_status($data_v,$status))
			{
				return true;
			}
			else
			{
				return false;
			}
		 
	}
	
	function test_email()
	{
		$this->load->library('form_validation');
		$this->form_validation->set_rules('email_address', 'User Name', 'valid_email|required');
		if ( $this->form_validation->run() != false ) 
		{
			//$this->email_model->send_test_email(
 			if($this->email_model->send_test_email($this->input->post('email_address')))
			{
			 
				$data_['msg_type'] = 'success';
				$data_['msg'] = 'Email Send Successfully.';
				$page_encrpt_data = base64_encode(json_encode($data_));
				redirect(WEB_URL.'/email/email_settings/'.$page_encrpt_data,'refresh');
			}
			else
			{
				 
				$data_['msg_type'] = 'error';
				$data_['msg'] = 'Email.Not Send';
				$page_encrpt_data = base64_encode(json_encode($data_));
				redirect(WEB_URL.'/email/email_settings/'.$page_encrpt_data,'refresh');
			}
		}
		else
		{
			 
			$data_['msg_type'] = 'error';
			$data_['msg'] = 'Invalid Email.';
			$page_encrpt_data = base64_encode(json_encode($data_));
			redirect(WEB_URL.'/email/email_settings/'.$page_encrpt_data,'refresh');
		}

	}
	function view_template($id)
	{
		$data_v = (base64_decode($id));
		$result = $this->email_model->view_template_id($data_v);
		echo $result->message;
		
	}
	
	function update_email_template($id)
	{
			$data_v = (base64_decode($id));
			
		$this->load->library('form_validation');
		$this->form_validation->set_rules('subject', 'Subject', 'trim|required');
		$this->form_validation->set_rules('from_name', 'From Address', 'trim|required');
		$this->form_validation->set_rules('from_address', 'From Address', 'trim|required');
		$this->form_validation->set_rules('category', 'category', 'trim|required');
		$this->form_validation->set_rules('message', 'Message', 'trim|required'); 
	 
 		if ( $this->form_validation->run() != false ) 
		{
			 
			if (isset($_FILES["file_attach"]["tmp_name"][0]) && $_FILES["file_attach"]["tmp_name"][0] != "") 
			{
				$config = array(
            'upload_path'   => "data-file/attachment/",
            'allowed_types' => 'gif|jpg|png|jpeg|JPG|JPEG|DOC|pdf|PDF|ZIP|zip|docs|excel|txt|TXT' 
       			 );

       			 $this->load->library('upload', $config);

       			
				$files = $_FILES["file_attach"];
				$images=array();
				foreach ($files['name'] as $key => $image) {
					$_FILES['images[]']['name']= $files['name'][$key];
					$_FILES['images[]']['type']= $files['type'][$key];
					$_FILES['images[]']['tmp_name']= $files['tmp_name'][$key];
					$_FILES['images[]']['error']= $files['error'][$key];
					$_FILES['images[]']['size']= $files['size'][$key];
					$ac = explode(".",$image);
					$fileName = $ac[0]."_".date('ymdHis').time().".".$ac[1];
		
					$images[] = FILE_PATH."attachment/".$fileName;
		
					$config['file_name'] = $fileName;
		
					$this->upload->initialize($config);
		
					if ($this->upload->do_upload('images[]')) {
						$this->upload->data();
					} else {
						 
					}
				}
				$images_url = implode("||||",$images);
				if($this->input->post('images_url')!='')
				{
					$images_url = $this->input->post('images_url')."||||".$images_url;
				}
  			}
			else
			{
			$images_url = $this->input->post('images_url');	
			}
			
				 if($this->email_model->update_email_template($data_v,$this->input->post('subject'),
				 $this->input->post('category'),
				 $this->input->post('from_name'),
				 $this->input->post('from_address'),
				 $this->input->post('message'),$this->input->post('email_bcc'),$images_url))
				 {
					 $data_['msg_type'] = 'success';
						$data_['msg'] = 'Updated Successfully.';
						$page_encrpt_data = base64_encode(json_encode($data_));
						redirect(WEB_URL.'/email/edit_template/'.$id.'/'.$page_encrpt_data,'refresh');
				 }
				 else
				 {
					 $data_['msg_type'] = 'error';
						$data_['msg'] = 'Failed.';
						$page_encrpt_data = base64_encode(json_encode($data_));
						redirect(WEB_URL.'/email/edit_template/'.$id.'/'.$page_encrpt_data,'refresh');
				 }
		}
		else
		{
			
			$data_['msg_type'] = 'error';
			$data_['msg'] = 'Failed.';
			$page_encrpt_data = base64_encode(json_encode($data_));
			redirect(WEB_URL.'/email/edit_template/'.$id.'/'.$page_encrpt_data,'refresh');
		}
	
	}
	
	function get_language_data_v1($val='')
	{
		if($val=='')
		{
			$language = $this->email_model->get_language_data();
			$a='';
			for($i=0;$i<count($language);$i++)
			 {
				 $a .='   <option value="'.$language[$i]->lang_code.'">'.$language[$i]->lang_name.'</option>';
			 }
		     echo json_encode(array('result'=>$a,'lang'=>''));
		}
		else
		{
			
			$email = $this->email_model->view_template_type($val);
			$email_v=array();
			for($i=0;$i< count($email);$i++)
			 {
				 $email_v[] = $email[$i]->language_code;
			 }
			$language = $this->email_model->get_language_data();
			$a='';$b=' <label class="col-md-3 control-label" for="form_control_1">Exists
                                                    </label>
                                                  <div class="col-md-9">';
												  
			for($i=0;$i< count($language);$i++)
			 {
				 if (in_array($language[$i]->lang_code, $email_v)) {
					 $b .= '<span class="label label-danger">'.$language[$i]->lang_name.'</span> &nbsp;';
				 }
				 else
				 {
				 $a .='<option value="'.$language[$i]->lang_code.'">'.$language[$i]->lang_name.'</option>';
				 }
				 
			 }
			  echo json_encode(array('result'=>$a,'lang'=>$b.'</div></div>'));
													
		}
		
	}
	function add_email_template()
	{
		   
		  
		$this->load->library('form_validation');
		 
		$this->form_validation->set_rules('subject', 'Subject', 'trim|required');
		$this->form_validation->set_rules('from_name', 'From Address', 'trim|required');
		$this->form_validation->set_rules('from_address', 'From Address', 'trim|required');
		$this->form_validation->set_rules('message', 'Message', 'trim|required'); 
		$this->form_validation->set_rules('category', 'category', 'trim|required');
	 
 		if ( $this->form_validation->run() != false ) 
		{
			 $images_url = '';
			if (isset($_FILES["file_attach"]["tmp_name"][0]) && $_FILES["file_attach"]["tmp_name"][0] != "") 
			{
				$config = array(
            'upload_path'   => "data-file/attachment/",
            'allowed_types' => 'gif|jpg|png|jpeg|JPG|JPEG|DOC|pdf|PDF|ZIP|zip|docs|excel|txt|TXT' 
       			 );

       			 $this->load->library('upload', $config);

       			
				$files = $_FILES["file_attach"];
				$images=array();
				foreach ($files['name'] as $key => $image) {
					$_FILES['images[]']['name']= $files['name'][$key];
					$_FILES['images[]']['type']= $files['type'][$key];
					$_FILES['images[]']['tmp_name']= $files['tmp_name'][$key];
					$_FILES['images[]']['error']= $files['error'][$key];
					$_FILES['images[]']['size']= $files['size'][$key];
					$ac = explode(".",$image);
					$fileName = $ac[0]."_".date('ymdHis').time().".".$ac[1];
		
					$images[] = FILE_PATH."attachment/".$fileName;
		
					$config['file_name'] = $fileName;
		
					$this->upload->initialize($config);
		
					if ($this->upload->do_upload('images[]')) {
						$this->upload->data();
					} else {
						 
					}
				}
				$images_url = implode("||||",$images);
  			}
		
				 if($this->email_model->add_email_template($this->input->post('template_name'),
				 $this->input->post('template_type'),
				 $this->input->post('subject'),
				 $this->input->post('category'),
				 $this->input->post('from_name'),
				 $this->input->post('from_address'),
				 $this->input->post('message'),$this->input->post('email_bcc'),$this->input->post('email_cc')
				 ,$this->input->post('language'),$images_url))
				 {
					    $data_['msg_type'] = 'success';
						$data_['msg'] = 'Added Successfully.';
						$page_encrpt_data = base64_encode(json_encode($data_));
						redirect(WEB_URL.'/email/manage_emails/'.$page_encrpt_data,'refresh');
				 }
				 else
				 {
					 $data_['msg_type'] = 'error';
						$data_['msg'] = 'Failed.';
						$page_encrpt_data = base64_encode(json_encode($data_));
						redirect(WEB_URL.'/email/add_email_theme/'.$page_encrpt_data,'refresh');
				 }
		}
		else
		{
			
			 
			$data_['msg_type'] = 'error';
			$data_['msg'] = trim(preg_replace( "/\r|\n/", "",validation_errors()));
			$page_encrpt_data = base64_encode(json_encode($data_));
			redirect(WEB_URL.'/email/add_email_theme/'.$page_encrpt_data,'refresh');
		}
	
	}
	function limit_value()
	{
		if(isset($_POST['limit_value']) && $_POST['limit_value']!='')
		{
			 $this->email_model->update_limit_value($this->input->post('limit_value'));
		}
		$data_['msg_type'] = 'success';
		$data_['msg'] = 'Updated Successfully.';
		$page_encrpt_data = base64_encode(json_encode($data_));
		redirect(WEB_URL.'/email/email_settings/'.$page_encrpt_data,'refresh');
	}
	function update_email_settings()
	{
		$this->load->library('form_validation');
		$this->form_validation->set_rules('smtp', 'SMTP', 'trim|required');
		$this->form_validation->set_rules('port', 'Port', 'trim|required');
		$this->form_validation->set_rules('host_name', 'Host Name', 'trim|required');
		$this->form_validation->set_rules('email_address', 'User Name', 'trim|required');
		$this->form_validation->set_rules('password', 'Password', 'trim|required');
		 
	 
 		if ( $this->form_validation->run() != false ) 
		{
				 if($this->email_model->update_email_settings($this->input->post('smtp'),
				 $this->input->post('port'),
				 $this->input->post('host_name'),
				 $this->input->post('email_address'),
				 $this->input->post('password')))
				 {
					 $data_['msg_type'] = 'success';
						$data_['msg'] = 'Updated Successfully.';
						$page_encrpt_data = base64_encode(json_encode($data_));
						redirect(WEB_URL.'/email/email_settings/'.$page_encrpt_data,'refresh');
				 }
				 else
				 {
					 	$data_['msg_type'] = 'error';
						$data_['msg'] = 'Failed.';
						$page_encrpt_data = base64_encode(json_encode($data_));
						redirect(WEB_URL.'/email/email_settings/'.$page_encrpt_data,'refresh');
				 }
		}
		else
		{
			
			$data_['msg_type'] = 'error';
			$data_['msg'] = 'Failed.';
			$page_encrpt_data = base64_encode(json_encode($data_));
			redirect(WEB_URL.'/email/email_settings/'.$page_encrpt_data,'refresh');
		}
	}
}
