<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Bugs extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	 public function __construct(){
		parent::__construct();
	  	 
	  	$this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0,post-check=0, pre-check=0');
 		$this->output->set_header('Pragma: no-cache');
 	  $this->load->model('bugs_model');
	    	$this->validate_admin_login();	
	}
	private function validate_admin_login(){
		 
		
		 $result_v='';
		if(isset($_GET['emp_sign']))
		{
				$result_v = json_decode(base64_decode($_GET['emp_sign']));
		}
		
		if(isset($result_v->employee_id) && isset($result_v->email_address) && isset($result_v->first_name))
		{
				$controller_name = $this->router->fetch_class();
				$function_name = $this->router->fetch_method();

				
				$employee_id = $result_v->employee_id;
			   if(!$this->security_model->get_privileges_by_employee_id($employee_id,$controller_name,$function_name))
			   {			
					access_denied('error');
				}

$this->emp_sign="?emp_sign=".$_GET['emp_sign'];
				$this->user_logged_in = true;
				$this->user_type = 'EMPLOYEE';
				$this->user_id = $result_v->employee_id;
				$this->user_pic = $result_v->profile_pic;
				$this->user_name = $result_v->first_name;
				$this->user_email = $result_v->email_address;
				
			 
		 	
 		}
		elseif($this->session->userdata('admin_logged_in'))
		{
			 $this->emp_sign='';
			$this->user_logged_in = true;
			$this->user_type = 'ADMIN';
			$this->user_id = 1;
			$this->user_pic = $this->session->userdata('profile_pic');
			$this->user_name = $this->session->userdata('first_name');
			$this->user_email = $this->session->userdata('user_email');
		}
		elseif($this->session->userdata('employee_logged_in'))
		{
			$this->emp_sign='';
		 	$controller_name = $this->router->fetch_class();
			 $function_name = $this->router->fetch_method();
			 
            
            $employee_id = $this->session->userdata('employee_id');
           if(!$this->security_model->get_privileges_by_employee_id($employee_id,$controller_name,$function_name))
		   {			
    	 	  	access_denied('error');
			}
			
       	 
			$this->user_logged_in = true;
			$this->user_type = 'EMPLOYEE';
			$this->user_id = $this->session->userdata('employee_id');
			$this->user_pic = $this->session->userdata('profile_pic');
			$this->user_name = $this->session->userdata('first_name');
			$this->user_email = $this->session->userdata('email_address');
		}
		else
		{
				redirect(WEB_URL.'/login');
		}
		$this->overlay_employee_details = $this->security_model->get_employee_id_name($this->user_id,$this->user_type);
		 
    }
	 
	  
		public function store_bugs()
	{	
	
		  $this->load->library('form_validation'); 
		$this->form_validation->set_rules('page_url', 'Password', 'required'); 
		$this->form_validation->set_rules('bugs_type', 'Password', 'required'); 
		$this->form_validation->set_rules('img_url', 'Password', 'required'); 
	  
		if ( $this->form_validation->run() != false ) 
		{
			
		if($this->bugs_model->store_bugs($_POST['page_url'],$_POST['bugs_type'], $_POST['img_url']))
		 {
				 
			}
			else
			{
				 
			}
		}
		else
		{
			 
		}
    }
	function list_all($param='')
	{
		if($param!='')
		{
			$data['page_data'] = json_decode(base64_decode($param));
 		}
		 $data['result'] = $this->bugs_model->get_bugs_all();
		  
		 $this->load->view('dashboard/bugs_list',$data);
		 
	} 
	function track_employee($param='')
	{
		if($param!='')
		{
			$data['page_data'] = json_decode(base64_decode($param));
 		}
		  
		 $this->load->view('dashboard/track_employee',$data);
		 
	} 
	function error_logs($param='')
	{
		if($param!='')
		{
			$data['page_data'] = json_decode(base64_decode($param));
 		}
			$dir = APPPATH."\logs";
			$dh  = opendir($dir);
			
			while (false !== ($filename = readdir($dh))) {
				$files[] = $filename;
			}
			 
			rsort($files);
			
			$data['files'] = $files;
		//readfile($dir.'/'.$files[0]);
 
		 $this->load->view('dashboard/error_logs',$data);
		 
	} 
	function delete_bugs()
	{
		  $this->bugs_model->delete_bugs();
 		 redirect(WEB_URL.'/bugs/list_all','refresh');
		 
	} 
		function delete_logs()
	{
	 
		 
 		 redirect(WEB_URL.'/bugs/error_logs','refresh');
		 
	} 
	
	function view_screenshot($id='')
	{
		
		if($id!='')
		{
			$id = base64_decode($id);
			$result = $this->bugs_model->view_screenshot($id);
			$image_url = $result->image_path;
			echo '<img width="1200px" src="'.$image_url.'" />';
		}
		else
		{
			
		}
	}
	function view_files($filepath='')
	{
		
		if($filepath!='')
		{
			$filepath = base64_decode($filepath);
			$dir = APPPATH."\logs";
			echo '<pre>';
			readfile($dir.'/'.$filepath);
			echo '</pre>';
		}
		else
		{
			
		}
	}
}
