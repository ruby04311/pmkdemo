<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Support_Ticket extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
 	public function __construct(){
		parent::__construct();
		//$this->check_isvalidated();
		 
		$this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0,post-check=0, pre-check=0');
 		$this->output->set_header('Pragma: no-cache');
		
 		$this->load->model('support_model');
	  	$this->validate_admin_login();	
	}
	private function validate_admin_login(){
		 
		$result_v='';
		if(isset($_GET['emp_sign']))
		{
				$result_v = json_decode(base64_decode($_GET['emp_sign']));
		}
		
		if(isset($result_v->employee_id) && isset($result_v->email_address) && isset($result_v->first_name))
		{
				$controller_name = $this->router->fetch_class();
				$function_name = $this->router->fetch_method();

				 $this->load->model('security_model');
				$employee_id = $result_v->employee_id;
			   if(!$this->security_model->get_privileges_by_employee_id($employee_id,$controller_name,$function_name))
			   {			
					access_denied('error');
				}

$this->emp_sign="?emp_sign=".$_GET['emp_sign'];
				$this->user_logged_in = true;
				$this->user_type = 'EMPLOYEE';
				$this->user_id = $result_v->employee_id;
				$this->user_pic = $result_v->profile_pic;
				$this->user_name = $result_v->first_name;
				$this->user_email = $result_v->email_address;
				
			 
		 	
 		}
		elseif($this->session->userdata('admin_logged_in'))
		{
			 $this->emp_sign='';
			$this->user_logged_in = true;
			$this->user_type = 'ADMIN';
			$this->user_id = 1;
			$this->user_pic = $this->session->userdata('profile_pic');
			$this->user_name = $this->session->userdata('first_name');
			$this->user_email = $this->session->userdata('user_email');
		}
		elseif($this->session->userdata('employee_logged_in'))
		{
			$this->emp_sign='';
		 	$controller_name = $this->router->fetch_class();
			 $function_name = $this->router->fetch_method();
			 
             $this->load->model('security_model');
            $employee_id = $this->session->userdata('employee_id');
           if(!$this->security_model->get_privileges_by_employee_id($employee_id,$controller_name,$function_name))
		   {			
    	 	  	access_denied('error');
			}
			
       	 
			$this->user_logged_in = true;
			$this->user_type = 'EMPLOYEE';
			$this->user_id = $this->session->userdata('employee_id');
			$this->user_pic = $this->session->userdata('profile_pic');
			$this->user_name = $this->session->userdata('first_name');
			$this->user_email = $this->session->userdata('email_address');
		}
		else
		{
				redirect(WEB_URL.'/login');
		}
		$this->overlay_employee_details = $this->security_model->get_employee_id_name($this->user_id,$this->user_type); 
    }
	  
	function inbox($param='')
	{
		if($param!='')
		{
			$data['page_data'] = json_decode(base64_decode($param));
 		}
		 
 		 $data['privileges_actions'] = $this->general_model->get_privileges_actions($this->user_type,$this->user_id,strtolower($this->router->class));
		 
		 $this->load->view('support_ticket/inbox',$data);
	}
	
	function email_inbox()
	{
	 	$data='';	 
		 $this->load->view('support_ticket/email_inbox',$data);
	}
	function email_inbox_view()
	{
	 	$data='';	 
		 $this->load->view('support_ticket/email_inbox_view',$data);
	}
	
}
