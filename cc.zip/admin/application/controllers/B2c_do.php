<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
 class B2c_Do extends CI_Controller {
 
 	public function __construct(){
		parent::__construct();
		//$this->check_isvalidated();
		 
		$this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0,post-check=0, pre-check=0');
 		$this->output->set_header('Pragma: no-cache');
		$this->load->model('email_model');
 		$this->load->model('b2c_model');
	  	$this->validate_admin_login();	

	}
	private function validate_admin_login(){
		
		  $result_v='';
		if(isset($_GET['emp_sign']))
		{
				$result_v = json_decode(base64_decode($_GET['emp_sign']));
		}
		
		if(isset($result_v->employee_id) && isset($result_v->email_address) && isset($result_v->first_name))
		{
				$controller_name = $this->router->fetch_class();
				$function_name = $this->router->fetch_method();

				 $this->load->model('security_model');
				$employee_id = $result_v->employee_id;
 
			   /*if(!$this->security_model->get_privileges_by_employee_id($employee_id,$controller_name,$function_name))
			   {			
					access_denied('error');
				}
*/
				$this->emp_sign="?emp_sign=".$_GET['emp_sign'];
				$this->user_logged_in = true;
				$this->user_type = 'EMPLOYEE';
				$this->user_id = $result_v->employee_id;
				$this->user_pic = $result_v->profile_pic;
				$this->user_name = $result_v->first_name;
				$this->user_email = $result_v->email_address;
				
			 
		 	
 		}
		elseif($this->session->userdata('admin_logged_in'))
		{
			 $this->emp_sign='';
			$this->user_logged_in = true;
			$this->user_type = 'ADMIN';
			$this->user_id = 1;
			$this->user_pic = $this->session->userdata('profile_pic');
			$this->user_name = $this->session->userdata('first_name');
			$this->user_email = $this->session->userdata('user_email');
		}
		elseif($this->session->userdata('employee_logged_in'))
		{
			$this->emp_sign='';
		 	 
			 
			
			$this->user_logged_in = true;
			$this->user_type = 'EMPLOYEE';
			$this->user_id = $this->session->userdata('employee_id');
			$this->user_pic =$this->session->userdata('profile_pic');
			$this->user_name = $this->session->userdata('first_name');
			$this->user_email = $this->session->userdata('user_email');
		}
		else
		{
				redirect(WEB_URL.'/login');
		}
		 $this->overlay_employee_details = $this->security_model->get_employee_id_name($this->user_id,$this->user_type); 
    }
	  function add_user()
	{
		 
		$this->load->library('form_validation');
		$this->form_validation->set_rules('first_name', 'First Name', 'trim|required|min_length[4]|alpha');
		$this->form_validation->set_rules('last_name', 'Last Name', 'trim|required|min_length[3]|alpha');
 		$this->form_validation->set_rules('password', 'Password', 'trim|required');
 		$this->form_validation->set_rules('country', 'Country', 'trim|required');
		$this->form_validation->set_rules('postal', 'Postal', 'trim|required');
		$this->form_validation->set_rules('phone_number', 'Phone Number', 'trim|required');
		 
		$this->form_validation->set_rules('email_address', 'Email Address', 'trim|required|valid_email|is_unique[user.email_address]',
		 array(
                'required'      => 'You have not provided %s.',
                'is_unique'     => 'This %s already exists.'
        )); 
	 
 		if ( $this->form_validation->run() != false ) 
		{
			$first_name = ucfirst($this->input->post('first_name'));
			$last_name = ucfirst($this->input->post('last_name'));
			$email_address = $this->input->post('email_address');
			
			$password = $this->input->post('password');
			$street = $this->input->post('street');
			$city = $this->input->post('city');
			$state = $this->input->post('state');
			$country = $this->input->post('country');
			 
			$postal = $this->input->post('postal'); 
			$phone_number = $this->input->post('phone_number'); 
			 
			
			$emp_code_id_v =  "TSB2C";
			$emp_code_id =  $emp_code_id_v.(1000+$this->b2c_model->max_empid());
		 
			$profile_pic=FRONT_FILE_PATH.'user/profile-pic-default.png';
			  if ($_FILES["avatar_file"]["tmp_name"] != "") 
					{
						$config['upload_path'] = "../data-file/user/";
						$config['allowed_types'] = 'gif|jpg|png|jpeg|JPG|JPEG';
						$config['max_size']	= '2048';
						$config['max_width'] = '1024';
						$config['max_height'] = '768';
						$config['file_name'] = 'profile_pic_'.$_FILES["avatar_file"]["tmp_name"][0].date('ymdHis').time();
				$this->load->library('upload', $config);
				if ($this->upload->do_upload('avatar_file'))
                {
                     	   $upload_data = $this->upload->data();
 							$profile_pic = FRONT_FILE_PATH."user/".$this->upload->file_name;
				}
						else {
							  $error = array('error' => $this->upload->display_errors()); 
							
		 
						}
 			 
			}
		 
			 $password_v=base64_encode($password);
				 
				 
		 if ($this->b2c_model->add_user($emp_code_id,$first_name,$last_name,$email_address,$password_v,$street,$city,$state,$country,$postal,$profile_pic,$phone_number))
			{

				$this->email_model->send_password_to_new_user($first_name,$email_address,$profile_pic,$password);
				$data_['msg_type'] = 'success';
				$data_['msg'] = 'Added Successfully.';
				$page_encrpt_data = base64_encode(json_encode($data_));

				redirect(WEB_URL.'/b2c/list_all/'.$page_encrpt_data,'refresh');
			}
			else
			{
				$data_['msg_type'] = 'error';
				$data_['msg'] = 'Failed.';
				$page_encrpt_data = base64_encode(json_encode($data_));
				redirect(WEB_URL.'/b2c/add_user/'.$page_encrpt_data,'refresh');
			}
		}
		else
		{ 
			$data_['msg_type'] = 'error';
			$data_['msg'] = trim(preg_replace( "/\r|\n/", "",validation_errors()));
			$page_encrpt_data = base64_encode(json_encode($data_));
			redirect(WEB_URL.'/b2c/add_user/'.$page_encrpt_data,'refresh');
		}
	}
	 function list_all_b2c_ajax()
	{
			 $user_code = ''; if(isset($_POST['user_code'])) { $user_code = $_POST['user_code']; }
			  $first_name = ''; if(isset($_POST['first_name'])) { $first_name = $_POST['first_name']; }
		 
 		 $emailid = ''; if(isset($_POST['emailid'])) { $emailid = $_POST['emailid']; }
		 $contacts = ''; if(isset($_POST['contacts'])) { $contacts = $_POST['contacts']; }
		 
			$status = ''; if(isset($_POST['status'])) { $status = $_POST['status']; }
 		 
 		$result_v2 = $this->b2c_model->get_b2c_list($_POST['order'],$_POST['start'], $_POST['length'],$user_code,$first_name,$emailid,$contacts,$status);
		
		$result['draw']= $_POST['draw'];
		$result['recordsTotal']=  $this->b2c_model->get_b2c_list_all($user_code,$first_name,$emailid,$contacts,$status);
		$result['recordsFiltered']= $result['recordsTotal'];
		
		 $result['data']=array();
		if($result_v2)
		{
		 for($i=0;$i<count($result_v2);$i++)
		 {
			  
 			 $result['data'][]= array( 
			 					 '<img src="'.$result_v2[$i]->profile_pic.'" width="100">',
			 							$result_v2[$i]->user_code,
										$result_v2[$i]->first_name,
										$result_v2[$i]->email_address,
										$result_v2[$i]->phone_number,
										$result_v2[$i]->credit_points,
										$result_v2[$i]->created_timestamp,
										$result_v2[$i]->status,
										 ' <div class="btn-group btn-group-sm btn-group-solid">  <a href="'.WEB_URL.'/b2c/view/'.$result_v2[$i]->user_code.'" class="btn btn-xs   green-jungle">
                                                                            <i class="fa fa-eye"></i>
                                                                        </a>
																		<a href="'.WEB_URL.'/b2c/edit_user/'.base64_encode($result_v2[$i]->user_id).'" class="btn btn-xs   blue">
                                                                            <i class="fa fa-edit"></i>
                                                                        </a>
														
 																		<a class="btn btn-xs red _delete_airline" id="'.base64_encode($result_v2[$i]->user_id).'">
                                                                        <i class="fa fa-key"></i>   </a></div>',
										'DT_RowId'=>'row_'.$result_v2[$i]->user_id);
			 
			 }
		}
			echo json_encode($result); 
			 
			
		 
	}
	 function update_user($emp_id)
	 {
		 
		 $emp_id_c = base64_encode($emp_id);
		 $this->load->library('form_validation');
		$this->form_validation->set_rules('first_name', 'First Name', 'trim|required|min_length[4]|alpha');
		$this->form_validation->set_rules('last_name', 'Last Name', 'trim|required|min_length[3]|alpha');
  		$this->form_validation->set_rules('country', 'Country', 'trim|required');
		$this->form_validation->set_rules('postal', 'Postal', 'trim|required');
		$this->form_validation->set_rules('phone_number', 'Phone Number', 'trim|required');
	
	 
 		if ( $this->form_validation->run() != false ) 
		{
			$first_name = ucfirst($this->input->post('first_name'));
			$last_name = ucfirst($this->input->post('last_name'));
 			
 			$street = $this->input->post('street');
			$city = $this->input->post('city');
			$state = $this->input->post('state');
			$country = $this->input->post('country');
			 
			$postal = $this->input->post('postal'); 
			$phone_number = $this->input->post('phone_number'); 
			 
			$profile_pic='';
			if ($_FILES["avatar_file"]["tmp_name"] != "") 
			{
						$config['upload_path'] = "data-file/user/";
						$config['allowed_types'] = 'gif|jpg|png|jpeg|JPG|JPEG';
						$config['max_size']	= '2048';
						$config['max_width'] = '1024';
						$config['max_height'] = '768';
						$config['file_name'] = 'profile_pic_'.$_FILES["avatar_file"]["tmp_name"][0].date('ymdHis').time();
				$this->load->library('upload', $config);
				if ($this->upload->do_upload('avatar_file'))
                {
                     			$upload_data = $this->upload->data();
 							$profile_pic = "user/".$this->upload->file_name;
				}
						else {
							  $error = array('error' => $this->upload->display_errors()); 
							
		 
						}
 			 
			}
		  
				 if($this->b2c_model->update_user($emp_id,$first_name,$last_name,$street,$city,$state,$country,$postal,$profile_pic,$phone_number))
				 {
					
					 
					   $data_['msg_type'] = 'success';
						$data_['msg'] = 'Updated Successfully.';
						$page_encrpt_data = base64_encode(json_encode($data_));
						redirect(WEB_URL.'/b2c/edit_user/'.$emp_id_c.'/'.$page_encrpt_data,'refresh');
				 }
				 else
				 {
					 $data_['msg_type'] = 'error';
						$data_['msg'] = 'Failed.';
						$page_encrpt_data = base64_encode(json_encode($data_));
						redirect(WEB_URL.'/b2c/edit_user/'.$emp_id_c.'/'.$page_encrpt_data,'refresh');
				 }
		}
		else
		{ 
		
			$data_['msg_type'] = 'error';
			$data_['msg'] = trim(preg_replace( "/\r|\n/", "",validation_errors()));
			$page_encrpt_data = base64_encode(json_encode($data_));
			redirect(WEB_URL.'/b2c/edit_user/'.$emp_id_c.'/'.$page_encrpt_data,'refresh');
		}
		 
	 }
	 
	 
	function list_all_credit_point_transaction_ajax($user_code)
	{	
		$charge_type		=	!empty( $this->input->post('charge_type') ) ? $this->input->post('charge_type') : '';
		$credit_points		=	!empty( $this->input->post('credit_points') ) ? $this->input->post('credit_points') : '';
		$debit_points		=	!empty( $this->input->post('debit_points') ) ? $this->input->post('debit_points') : '';
		$balance_points		=	!empty( $this->input->post('balance_points') ) ? $this->input->post('balance_points') : '';
		
		$start				=	!empty( $this->input->post('start') ) ? $this->input->post('start') : 0;
		$length				=	!empty( $this->input->post('length') ) ? $this->input->post('length') : 10;
		$order				=	!empty( $this->input->post('order') ) ? $this->input->post('order') : '';
		
		$result_v	=	$this->b2c_model->get_all_credit_point_transaction( $user_code,$order,$start,$length,$charge_type,$credit_points,$debit_points,$balance_points );
		
		$totalRecords = $this->b2c_model->get_all_credit_point_transaction_count( $user_code,$charge_type,$credit_points,$debit_points,$balance_points );
		$result['recordsTotal'] 	= $totalRecords;
		$result['recordsFiltered']	= $totalRecords;
		$result['data']=array();
		if($result_v)
		{
			for($i=0; $i < count($result_v); $i++)
			{
				$credit_points = $debit_points = 0;
				if( $result_v[$i]->transaction_mode == 'CREDIT' )
				{
					$credit_points	=	$result_v[$i]->user_credit_points_value;
				}
				else
				{
					$debit_points	=	$result_v[$i]->user_credit_points_value;
				}
				
				$result['data'][] = array(
											$result_v[$i]->user_credit_points_transaction_id,
											$result_v[$i]->credit_points_charge_type,
											$credit_points,
											$debit_points,
											$result_v[$i]->user_credit_points_value_final,
											'<a class="ajax-demo purple-medium btn btn-icon-only" data-url="'.WEB_URL.'/b2c/credit_points_transaction_details" data-toggle="modal">
												<i class="fa fa-file-o"></i>
											</a>'
										);
			}
		}
		
		echo json_encode( $result );
	}
	
	function list_flights_under_observation( $user_code )
	{
		$flight_id				=	!empty( $this->input->post('flight_id') ) ? $this->input->post('flight_id') : '';
		$depature_airport_code	=	!empty( $this->input->post('depature_airport_code') ) ? $this->input->post('depature_airport_code') : '';
		$arrival_airport_code	=	!empty( $this->input->post('arrival_airport_code') ) ? $this->input->post('arrival_airport_code') : '';
		$airline_no				=	!empty( $this->input->post('airline_no') ) ? $this->input->post('airline_no') : '';
		
		$start				=	!empty( $this->input->post('start') ) ? $this->input->post('start') : 0;
		$length				=	!empty( $this->input->post('length') ) ? $this->input->post('length') : 10;
		$order				=	!empty( $this->input->post('order') ) ? $this->input->post('order') : '';
		
		$result_v	=	$this->b2c_model->get_all_flights_registration( $user_code,$status='ACTIVE',$order,$start,$length,$flight_id,$depature_airport_code,$arrival_airport_code,$airline_no );
		
		$totalRecords = $this->b2c_model->get_all_flights_registration_count( $user_code,$status='ACTIVE',$flight_id,$depature_airport_code,$arrival_airport_code,$airline_no );
		$result['recordsTotal'] 	= $totalRecords;
		$result['recordsFiltered']	= $totalRecords;
		$result['data']=array();
		if($result_v)
		{
			for($i=0; $i < count($result_v); $i++)
			{
				$result['data'][] = array(
											$result_v[$i]->flight_registration_id,
											$result_v[$i]->flight_id,
											$result_v[$i]->depature_airport_code,
											$result_v[$i]->arrival_airport_code,
											$result_v[$i]->airline_no,
											$result_v[$i]->date_of_journey,
											'<div class="btn-group btn-group-sm btn-group-solid">
												<a class="history_detail_observation purple-medium btn btn-icon-only" data-flightid="'.$result_v[$i]->flight_id.'" data-itineraryid="'.$result_v[$i]->itinerary_id.'" title="History">
													<i class="fa fa-file-o"></i>
												</a>
												<a class="history_detail_observation blue btn btn-icon-only" data-flightid="'.$result_v[$i]->flight_id.'" data-itineraryid="'.$result_v[$i]->itinerary_id.'" data-currentstatus="1" title="Current Status">
													<i class="fa fa-file-o"></i>
												</a>
											</div>'
										);
			}
		}
		
		echo json_encode( $result );
	}
	
	function list_flights_history( $user_code )
	{
		$flight_id				=	!empty( $this->input->post('flight_id_history') ) ? $this->input->post('flight_id_history') : '';
		$depature_airport_code	=	!empty( $this->input->post('depature_airport_code_history') ) ? $this->input->post('depature_airport_code_history') : '';
		$arrival_airport_code	=	!empty( $this->input->post('arrival_airport_code_history') ) ? $this->input->post('arrival_airport_code_history') : '';
		$airline_no				=	!empty( $this->input->post('airline_no_history') ) ? $this->input->post('airline_no_history') : '';
		
		$start				=	!empty( $this->input->post('start') ) ? $this->input->post('start') : 0;
		$length				=	!empty( $this->input->post('length') ) ? $this->input->post('length') : 10;
		$order				=	!empty( $this->input->post('order') ) ? $this->input->post('order') : '';
		
		$result_v	=	$this->b2c_model->get_all_flights_registration( $user_code,$status='INACTIVE',$order,$start,$length,$flight_id,$depature_airport_code,$arrival_airport_code,$airline_no );
		
		$totalRecords = $this->b2c_model->get_all_flights_registration_count( $user_code,$status='INACTIVE',$flight_id,$depature_airport_code,$arrival_airport_code,$airline_no );
		$result['recordsTotal'] 	= $totalRecords;
		$result['recordsFiltered']	= $totalRecords;
		$result['data']=array();
		if($result_v)
		{
			for($i=0; $i < count($result_v); $i++)
			{
				$result['data'][] = array(
											$result_v[$i]->flight_registration_id,
											$result_v[$i]->flight_id,
											$result_v[$i]->depature_airport_code,
											$result_v[$i]->arrival_airport_code,
											$result_v[$i]->airline_no,
											$result_v[$i]->date_of_journey,
											'<a class="history_detail purple-medium btn btn-icon-only" data-flightid="'.$result_v[$i]->flight_id.'" data-itineraryid="'.$result_v[$i]->itinerary_id.'">
												<i class="fa fa-file-o"></i>
											</a>'
										);
			}
		}
		
		echo json_encode( $result );
	}
	
	function flight_notification_history()
	{
		$flight_id		=	$this->input->post('flight_id');
		$itinerary_id	=	$this->input->post('itinerary_id');
		$current_status	=	$this->input->post('current_status');
		
		$result = $this->b2c_model->get_flight_notification_history($flight_id, $itinerary_id, $current_status);
		
		echo json_encode( $result );
	}
}
