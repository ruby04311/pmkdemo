<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-05-30 07:09:33 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-30 07:09:33 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-30 07:42:39 --> Severity: Notice --> Undefined property: CI_Loader::$overlay_employee_details D:\xampp\htdocs\travelsmart\admin\application\views\common\overlay.php 106
ERROR - 2017-05-30 10:03:44 --> 404 Page Not Found: Email/%7Buser.profile_image%7D
ERROR - 2017-05-30 10:03:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 109
ERROR - 2017-05-30 10:03:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 117
ERROR - 2017-05-30 10:03:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 131
ERROR - 2017-05-30 10:03:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 143
ERROR - 2017-05-30 10:03:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 152
ERROR - 2017-05-30 10:03:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 162
ERROR - 2017-05-30 10:03:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 171
ERROR - 2017-05-30 10:03:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 180
ERROR - 2017-05-30 10:03:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 189
ERROR - 2017-05-30 10:03:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 194
ERROR - 2017-05-30 10:03:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 214
ERROR - 2017-05-30 10:03:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 109
ERROR - 2017-05-30 10:03:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 117
ERROR - 2017-05-30 10:03:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 131
ERROR - 2017-05-30 10:03:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 143
ERROR - 2017-05-30 10:03:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 152
ERROR - 2017-05-30 10:03:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 162
ERROR - 2017-05-30 10:03:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 171
ERROR - 2017-05-30 10:03:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 180
ERROR - 2017-05-30 10:03:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 189
ERROR - 2017-05-30 10:03:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 194
ERROR - 2017-05-30 10:03:54 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 214
ERROR - 2017-05-30 10:03:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 109
ERROR - 2017-05-30 10:03:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 117
ERROR - 2017-05-30 10:03:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 131
ERROR - 2017-05-30 10:03:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 143
ERROR - 2017-05-30 10:03:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 152
ERROR - 2017-05-30 10:03:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 162
ERROR - 2017-05-30 10:03:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 171
ERROR - 2017-05-30 10:03:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 180
ERROR - 2017-05-30 10:03:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 189
ERROR - 2017-05-30 10:03:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 194
ERROR - 2017-05-30 10:03:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 214
ERROR - 2017-05-30 10:07:11 --> 404 Page Not Found: Email/http:
ERROR - 2017-05-30 10:07:11 --> 404 Page Not Found: Email/http:
ERROR - 2017-05-30 10:08:46 --> 404 Page Not Found: Email/%7BASSETS%7D
ERROR - 2017-05-30 10:08:46 --> 404 Page Not Found: Email/%7Buser.profile_image%7D
ERROR - 2017-05-30 10:09:06 --> 404 Page Not Found: Email/%7BASSETS%7D
ERROR - 2017-05-30 10:09:06 --> 404 Page Not Found: Email/%7Buser.profile_image%7D
ERROR - 2017-05-30 10:11:53 --> 404 Page Not Found: Email/%7BASSETS%7D
ERROR - 2017-05-30 10:11:53 --> 404 Page Not Found: Email/%7Buser.profile_image%7D
ERROR - 2017-05-30 14:40:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 109
ERROR - 2017-05-30 14:40:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 117
ERROR - 2017-05-30 14:40:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 131
ERROR - 2017-05-30 14:40:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 143
ERROR - 2017-05-30 14:40:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 152
ERROR - 2017-05-30 14:40:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 162
ERROR - 2017-05-30 14:40:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 171
ERROR - 2017-05-30 14:40:22 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 180
ERROR - 2017-05-30 14:40:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 189
ERROR - 2017-05-30 14:40:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 194
ERROR - 2017-05-30 14:40:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 214
ERROR - 2017-05-30 14:40:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 109
ERROR - 2017-05-30 14:40:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 117
ERROR - 2017-05-30 14:40:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 131
ERROR - 2017-05-30 14:40:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 143
ERROR - 2017-05-30 14:40:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 152
ERROR - 2017-05-30 14:40:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 162
ERROR - 2017-05-30 14:40:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 171
ERROR - 2017-05-30 14:40:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 180
ERROR - 2017-05-30 14:40:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 189
ERROR - 2017-05-30 14:40:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 194
ERROR - 2017-05-30 14:40:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 214
ERROR - 2017-05-30 14:40:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 109
ERROR - 2017-05-30 14:40:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 117
ERROR - 2017-05-30 14:40:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 131
ERROR - 2017-05-30 14:40:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 143
ERROR - 2017-05-30 14:40:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 152
ERROR - 2017-05-30 14:40:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 162
ERROR - 2017-05-30 14:40:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 171
ERROR - 2017-05-30 14:40:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 180
ERROR - 2017-05-30 14:40:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 189
ERROR - 2017-05-30 14:40:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 194
ERROR - 2017-05-30 14:40:23 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 214
ERROR - 2017-05-30 14:40:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 109
ERROR - 2017-05-30 14:40:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 117
ERROR - 2017-05-30 14:40:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 131
ERROR - 2017-05-30 14:40:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 143
ERROR - 2017-05-30 14:40:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 152
ERROR - 2017-05-30 14:40:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 162
ERROR - 2017-05-30 14:40:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 171
ERROR - 2017-05-30 14:40:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 180
ERROR - 2017-05-30 14:40:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 189
ERROR - 2017-05-30 14:40:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 194
ERROR - 2017-05-30 14:40:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 214
ERROR - 2017-05-30 14:40:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 109
ERROR - 2017-05-30 14:40:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 117
ERROR - 2017-05-30 14:40:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 131
ERROR - 2017-05-30 14:40:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 143
ERROR - 2017-05-30 14:40:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 152
ERROR - 2017-05-30 14:40:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 162
ERROR - 2017-05-30 14:40:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 171
ERROR - 2017-05-30 14:40:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 180
ERROR - 2017-05-30 14:40:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 189
ERROR - 2017-05-30 14:40:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 194
ERROR - 2017-05-30 14:40:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 214
ERROR - 2017-05-30 14:40:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 109
ERROR - 2017-05-30 14:40:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 117
ERROR - 2017-05-30 14:40:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 131
ERROR - 2017-05-30 14:40:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 143
ERROR - 2017-05-30 14:40:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 152
ERROR - 2017-05-30 14:40:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 162
ERROR - 2017-05-30 14:40:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 171
ERROR - 2017-05-30 14:40:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 180
ERROR - 2017-05-30 14:40:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 189
ERROR - 2017-05-30 14:40:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 194
ERROR - 2017-05-30 14:40:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 214
ERROR - 2017-05-30 14:40:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 109
ERROR - 2017-05-30 14:40:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 117
ERROR - 2017-05-30 14:40:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 131
ERROR - 2017-05-30 14:40:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 143
ERROR - 2017-05-30 14:40:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 152
ERROR - 2017-05-30 14:40:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 162
ERROR - 2017-05-30 14:40:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 171
ERROR - 2017-05-30 14:40:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 180
ERROR - 2017-05-30 14:40:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 189
ERROR - 2017-05-30 14:40:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 194
ERROR - 2017-05-30 14:40:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 214
ERROR - 2017-05-30 14:40:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 109
ERROR - 2017-05-30 14:40:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 117
ERROR - 2017-05-30 14:40:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 131
ERROR - 2017-05-30 14:40:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 143
ERROR - 2017-05-30 14:40:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 152
ERROR - 2017-05-30 14:40:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 162
ERROR - 2017-05-30 14:40:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 171
ERROR - 2017-05-30 14:40:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 180
ERROR - 2017-05-30 14:40:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 189
ERROR - 2017-05-30 14:40:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 194
ERROR - 2017-05-30 14:40:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 214
ERROR - 2017-05-30 14:40:28 --> 404 Page Not Found: Email/http:
ERROR - 2017-05-30 14:40:29 --> 404 Page Not Found: Email/http:
ERROR - 2017-05-30 14:40:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 109
ERROR - 2017-05-30 14:40:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 117
ERROR - 2017-05-30 14:40:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 131
ERROR - 2017-05-30 14:40:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 143
ERROR - 2017-05-30 14:40:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 152
ERROR - 2017-05-30 14:40:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 162
ERROR - 2017-05-30 14:40:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 171
ERROR - 2017-05-30 14:40:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 180
ERROR - 2017-05-30 14:40:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 189
ERROR - 2017-05-30 14:40:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 194
ERROR - 2017-05-30 14:40:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 214
ERROR - 2017-05-30 14:40:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 109
ERROR - 2017-05-30 14:40:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 117
ERROR - 2017-05-30 14:40:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 131
ERROR - 2017-05-30 14:40:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 143
ERROR - 2017-05-30 14:40:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 152
ERROR - 2017-05-30 14:40:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 162
ERROR - 2017-05-30 14:40:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 171
ERROR - 2017-05-30 14:40:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 180
ERROR - 2017-05-30 14:40:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 189
ERROR - 2017-05-30 14:40:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 194
ERROR - 2017-05-30 14:40:32 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 214
ERROR - 2017-05-30 14:42:11 --> 404 Page Not Found: Email/%7BASSETS%7D
ERROR - 2017-05-30 14:42:11 --> 404 Page Not Found: Email/%7Buser.profile_image%7D
