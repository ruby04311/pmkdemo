<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-05-01 10:50:47 --> 404 Page Not Found: Help/http:
ERROR - 2017-05-01 10:50:47 --> 404 Page Not Found: Help/http:
ERROR - 2017-05-01 10:50:50 --> 404 Page Not Found: Support_ticket/sent
ERROR - 2017-05-01 10:51:02 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\travelsmart\admin\application\controllers\Bugs.php 144
ERROR - 2017-05-01 11:01:59 --> Severity: Notice --> Undefined property: CI_Loader::$overlay_employee_details D:\xampp\htdocs\travelsmart\admin\application\views\common\overlay.php 106
ERROR - 2017-05-01 11:02:01 --> Severity: Notice --> Undefined property: CI_Loader::$overlay_employee_details D:\xampp\htdocs\travelsmart\admin\application\views\common\overlay.php 106
ERROR - 2017-05-01 11:02:02 --> Severity: Notice --> Undefined property: CI_Loader::$overlay_employee_details D:\xampp\htdocs\travelsmart\admin\application\views\common\overlay.php 106
ERROR - 2017-05-01 11:02:19 --> Severity: Notice --> Undefined property: CI_Loader::$overlay_employee_details D:\xampp\htdocs\travelsmart\admin\application\views\common\overlay.php 106
ERROR - 2017-05-01 11:02:31 --> Severity: Notice --> Undefined property: CI_Loader::$overlay_employee_details D:\xampp\htdocs\travelsmart\admin\application\views\common\overlay.php 106
ERROR - 2017-05-01 11:02:31 --> Severity: Notice --> Undefined property: CI_Loader::$overlay_employee_details D:\xampp\htdocs\travelsmart\admin\application\views\common\overlay.php 106
ERROR - 2017-05-01 11:02:31 --> Severity: Notice --> Undefined property: CI_Loader::$overlay_employee_details D:\xampp\htdocs\travelsmart\admin\application\views\common\overlay.php 106
ERROR - 2017-05-01 11:02:51 --> Severity: Notice --> Undefined property: CI_Loader::$overlay_employee_details D:\xampp\htdocs\travelsmart\admin\application\views\common\overlay.php 106
ERROR - 2017-05-01 11:27:13 --> 404 Page Not Found: B2c/all
ERROR - 2017-05-01 11:33:05 --> 404 Page Not Found: B2c/list_all
ERROR - 2017-05-01 11:36:47 --> 404 Page Not Found: B2c/list_all
ERROR - 2017-05-01 11:36:52 --> 404 Page Not Found: B2c/list_all
ERROR - 2017-05-01 11:36:58 --> 404 Page Not Found: B2c/list_all
ERROR - 2017-05-01 11:37:14 --> 404 Page Not Found: B2c/list_all
ERROR - 2017-05-01 11:37:28 --> 404 Page Not Found: B2c_do/list_all_b2c_ajax
