<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-05-17 08:47:35 --> 404 Page Not Found: Home/get_invoice_range
ERROR - 2017-05-17 08:51:10 --> 404 Page Not Found: Home/get_invoice_range
ERROR - 2017-05-17 08:51:49 --> 404 Page Not Found: Home/get_invoice_range
ERROR - 2017-05-17 08:51:51 --> Severity: Notice --> Undefined property: CI_Loader::$overlay_employee_details D:\xampp\htdocs\travelsmart\admin\application\views\common\overlay.php 106
ERROR - 2017-05-17 08:51:57 --> Severity: Notice --> Undefined property: CI_Loader::$overlay_employee_details D:\xampp\htdocs\travelsmart\admin\application\views\common\overlay.php 106
ERROR - 2017-05-17 08:52:13 --> 404 Page Not Found: B2c_do/list_all_b2c_ajax
ERROR - 2017-05-17 08:52:26 --> 404 Page Not Found: Support_ticket/subject_line
ERROR - 2017-05-17 08:52:29 --> 404 Page Not Found: B2c_do/list_all_b2c_ajax
ERROR - 2017-05-17 08:52:57 --> 404 Page Not Found: Employee/http:
ERROR - 2017-05-17 08:52:57 --> 404 Page Not Found: Employee/http:
ERROR - 2017-05-17 08:59:17 --> 404 Page Not Found: Home/get_invoice_range
ERROR - 2017-05-17 08:59:19 --> 404 Page Not Found: Home/get_invoice_range
ERROR - 2017-05-17 08:59:22 --> Severity: Notice --> Undefined property: CI_Loader::$overlay_employee_details D:\xampp\htdocs\travelsmart\admin\application\views\common\overlay.php 106
ERROR - 2017-05-17 08:59:25 --> Severity: Notice --> Undefined property: CI_Loader::$overlay_employee_details D:\xampp\htdocs\travelsmart\admin\application\views\common\overlay.php 106
ERROR - 2017-05-17 08:59:26 --> Severity: Notice --> Undefined property: CI_Loader::$overlay_employee_details D:\xampp\htdocs\travelsmart\admin\application\views\common\overlay.php 106
ERROR - 2017-05-17 08:59:28 --> Severity: Notice --> Undefined property: CI_Loader::$overlay_employee_details D:\xampp\htdocs\travelsmart\admin\application\views\common\overlay.php 106
ERROR - 2017-05-17 09:38:42 --> 404 Page Not Found: Home/get_invoice_range
ERROR - 2017-05-17 12:10:24 --> 404 Page Not Found: Home/get_invoice_range
ERROR - 2017-05-17 12:10:27 --> Severity: Notice --> Undefined property: CI_Loader::$overlay_employee_details D:\xampp\htdocs\travelsmart\admin\application\views\common\overlay.php 106
ERROR - 2017-05-17 12:11:10 --> Severity: Notice --> Undefined property: CI_Loader::$overlay_employee_details D:\xampp\htdocs\travelsmart\admin\application\views\common\overlay.php 106
ERROR - 2017-05-17 12:11:18 --> Severity: Notice --> Undefined property: CI_Loader::$overlay_employee_details D:\xampp\htdocs\travelsmart\admin\application\views\common\overlay.php 106
ERROR - 2017-05-17 12:11:21 --> Severity: Notice --> Undefined property: CI_Loader::$overlay_employee_details D:\xampp\htdocs\travelsmart\admin\application\views\common\overlay.php 106
ERROR - 2017-05-17 12:12:02 --> Severity: Notice --> Undefined property: CI_Loader::$overlay_employee_details D:\xampp\htdocs\travelsmart\admin\application\views\common\overlay.php 106
ERROR - 2017-05-17 12:12:37 --> 404 Page Not Found: Department/http:
ERROR - 2017-05-17 12:13:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\employee\edit_department.php 101
ERROR - 2017-05-17 12:13:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\employee\edit_department.php 116
ERROR - 2017-05-17 12:13:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\employee\edit_department.php 116
ERROR - 2017-05-17 12:13:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\employee\edit_department.php 116
ERROR - 2017-05-17 12:13:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\employee\edit_department.php 116
ERROR - 2017-05-17 12:13:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\employee\edit_department.php 116
ERROR - 2017-05-17 12:13:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\employee\edit_department.php 116
ERROR - 2017-05-17 12:13:53 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\employee\edit_department.php 133
ERROR - 2017-05-17 12:14:15 --> 404 Page Not Found: B2c_do/list_all_b2c_ajax
ERROR - 2017-05-17 12:15:13 --> 404 Page Not Found: Employee/http:
ERROR - 2017-05-17 12:15:13 --> 404 Page Not Found: Employee/http:
ERROR - 2017-05-17 12:15:50 --> 404 Page Not Found: Support_ticket/subject_line
ERROR - 2017-05-17 12:15:52 --> 404 Page Not Found: Employee/http:
ERROR - 2017-05-17 12:15:54 --> 404 Page Not Found: Support_ticket/closed
ERROR - 2017-05-17 12:15:58 --> 404 Page Not Found: Support_ticket/sent
ERROR - 2017-05-17 12:16:32 --> 404 Page Not Found: Home/get_invoice_range
ERROR - 2017-05-17 12:16:54 --> Severity: Notice --> Undefined property: CI_Loader::$overlay_employee_details D:\xampp\htdocs\travelsmart\admin\application\views\common\overlay.php 106
ERROR - 2017-05-17 12:17:17 --> Severity: Notice --> Undefined property: CI_Loader::$overlay_employee_details D:\xampp\htdocs\travelsmart\admin\application\views\common\overlay.php 106
ERROR - 2017-05-17 12:17:24 --> Severity: Notice --> Undefined property: CI_Loader::$overlay_employee_details D:\xampp\htdocs\travelsmart\admin\application\views\common\overlay.php 106
ERROR - 2017-05-17 12:17:27 --> Severity: Notice --> Undefined property: CI_Loader::$overlay_employee_details D:\xampp\htdocs\travelsmart\admin\application\views\common\overlay.php 106
ERROR - 2017-05-17 12:17:32 --> Severity: Notice --> Undefined property: CI_Loader::$overlay_employee_details D:\xampp\htdocs\travelsmart\admin\application\views\common\overlay.php 106
ERROR - 2017-05-17 12:22:00 --> 404 Page Not Found: Home/get_invoice_range
ERROR - 2017-05-17 12:22:34 --> 404 Page Not Found: Help/http:
ERROR - 2017-05-17 12:23:16 --> Severity: Notice --> Undefined property: CI_Loader::$overlay_employee_details D:\xampp\htdocs\travelsmart\admin\application\views\common\overlay.php 106
ERROR - 2017-05-17 12:23:41 --> Severity: Notice --> Undefined property: CI_Loader::$overlay_employee_details D:\xampp\htdocs\travelsmart\admin\application\views\common\overlay.php 106
ERROR - 2017-05-17 12:23:50 --> Severity: Notice --> Undefined property: CI_Loader::$overlay_employee_details D:\xampp\htdocs\travelsmart\admin\application\views\common\overlay.php 106
ERROR - 2017-05-17 12:23:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\employee\edit_privileges_module.php 96
ERROR - 2017-05-17 12:23:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\employee\edit_privileges_module.php 104
ERROR - 2017-05-17 12:23:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\employee\edit_privileges_module.php 112
ERROR - 2017-05-17 12:23:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\employee\edit_privileges_module.php 121
ERROR - 2017-05-17 12:23:50 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\employee\edit_privileges_module.php 130
ERROR - 2017-05-17 12:23:50 --> Severity: Notice --> Undefined property: CI_Loader::$overlay_employee_details D:\xampp\htdocs\travelsmart\admin\application\views\common\overlay.php 106
ERROR - 2017-05-17 12:23:52 --> Severity: Notice --> Undefined property: CI_Loader::$overlay_employee_details D:\xampp\htdocs\travelsmart\admin\application\views\common\overlay.php 106
ERROR - 2017-05-17 12:24:35 --> Severity: Notice --> Undefined property: CI_Loader::$overlay_employee_details D:\xampp\htdocs\travelsmart\admin\application\views\common\overlay.php 106
ERROR - 2017-05-17 12:24:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\employee\edit_privileges_module.php 96
ERROR - 2017-05-17 12:24:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\employee\edit_privileges_module.php 104
ERROR - 2017-05-17 12:24:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\employee\edit_privileges_module.php 112
ERROR - 2017-05-17 12:24:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\employee\edit_privileges_module.php 121
ERROR - 2017-05-17 12:24:35 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\employee\edit_privileges_module.php 130
ERROR - 2017-05-17 12:24:35 --> Severity: Notice --> Undefined property: CI_Loader::$overlay_employee_details D:\xampp\htdocs\travelsmart\admin\application\views\common\overlay.php 106
ERROR - 2017-05-17 12:24:38 --> Severity: Notice --> Undefined property: CI_Loader::$overlay_employee_details D:\xampp\htdocs\travelsmart\admin\application\views\common\overlay.php 106
ERROR - 2017-05-17 12:28:11 --> 404 Page Not Found: B2c_do/list_all_b2c_ajax
ERROR - 2017-05-17 12:28:18 --> 404 Page Not Found: B2c_do/list_all_b2c_ajax
ERROR - 2017-05-17 12:50:38 --> Severity: Notice --> Undefined property: CI_Loader::$overlay_employee_details D:\xampp\htdocs\travelsmart\admin\application\views\common\overlay.php 106
ERROR - 2017-05-17 12:53:32 --> 404 Page Not Found: error
ERROR - 2017-05-17 12:53:54 --> 404 Page Not Found: Employee/http:
ERROR - 2017-05-17 12:53:55 --> 404 Page Not Found: Employee/http:
ERROR - 2017-05-17 12:55:36 --> Severity: Notice --> Undefined property: CI_Loader::$overlay_employee_details D:\xampp\htdocs\travelsmart\admin\application\views\common\overlay.php 106
ERROR - 2017-05-17 12:56:55 --> 404 Page Not Found: Department/http:
ERROR - 2017-05-17 12:57:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\employee\edit_department.php 101
ERROR - 2017-05-17 12:57:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\employee\edit_department.php 116
ERROR - 2017-05-17 12:57:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\employee\edit_department.php 116
ERROR - 2017-05-17 12:57:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\employee\edit_department.php 116
ERROR - 2017-05-17 12:57:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\employee\edit_department.php 116
ERROR - 2017-05-17 12:57:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\employee\edit_department.php 116
ERROR - 2017-05-17 12:57:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\employee\edit_department.php 116
ERROR - 2017-05-17 12:57:42 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\employee\edit_department.php 133
ERROR - 2017-05-17 12:59:19 --> 404 Page Not Found: error
ERROR - 2017-05-17 13:00:42 --> Severity: Notice --> Undefined property: CI_Loader::$overlay_employee_details D:\xampp\htdocs\travelsmart\admin\application\views\common\overlay.php 106
ERROR - 2017-05-17 13:00:45 --> Severity: Notice --> Undefined property: CI_Loader::$overlay_employee_details D:\xampp\htdocs\travelsmart\admin\application\views\common\overlay.php 106
ERROR - 2017-05-17 13:00:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\employee\edit_privileges_module.php 96
ERROR - 2017-05-17 13:00:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\employee\edit_privileges_module.php 104
ERROR - 2017-05-17 13:00:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\employee\edit_privileges_module.php 112
ERROR - 2017-05-17 13:00:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\employee\edit_privileges_module.php 121
ERROR - 2017-05-17 13:00:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\employee\edit_privileges_module.php 130
ERROR - 2017-05-17 13:00:46 --> Severity: Notice --> Undefined property: CI_Loader::$overlay_employee_details D:\xampp\htdocs\travelsmart\admin\application\views\common\overlay.php 106
ERROR - 2017-05-17 13:01:32 --> Severity: Notice --> Undefined property: CI_Loader::$overlay_employee_details D:\xampp\htdocs\travelsmart\admin\application\views\common\overlay.php 106
ERROR - 2017-05-17 13:03:38 --> Severity: Notice --> Undefined property: CI_Loader::$overlay_employee_details D:\xampp\htdocs\travelsmart\admin\application\views\common\overlay.php 106
ERROR - 2017-05-17 13:04:15 --> Severity: Notice --> Undefined property: CI_Loader::$overlay_employee_details D:\xampp\htdocs\travelsmart\admin\application\views\common\overlay.php 106
ERROR - 2017-05-17 13:05:10 --> Severity: Notice --> Undefined property: CI_Loader::$overlay_employee_details D:\xampp\htdocs\travelsmart\admin\application\views\common\overlay.php 106
ERROR - 2017-05-17 13:05:15 --> Severity: Notice --> Undefined property: CI_Loader::$overlay_employee_details D:\xampp\htdocs\travelsmart\admin\application\views\common\overlay.php 106
ERROR - 2017-05-17 13:05:26 --> 404 Page Not Found: Department/http:
ERROR - 2017-05-17 13:05:26 --> 404 Page Not Found: Department/http:
ERROR - 2017-05-17 13:09:43 --> 404 Page Not Found: Support_ticket/subject_line
ERROR - 2017-05-17 13:09:51 --> 404 Page Not Found: Support_ticket/closed
ERROR - 2017-05-17 13:09:55 --> 404 Page Not Found: Support_ticket/sent
ERROR - 2017-05-17 13:11:21 --> 404 Page Not Found: Employee/http:
ERROR - 2017-05-17 13:11:21 --> 404 Page Not Found: Employee/http:
ERROR - 2017-05-17 13:15:11 --> Severity: Notice --> Undefined property: CI_Loader::$overlay_employee_details D:\xampp\htdocs\travelsmart\admin\application\views\common\overlay.php 106
ERROR - 2017-05-17 13:15:25 --> Severity: Notice --> Undefined property: CI_Loader::$overlay_employee_details D:\xampp\htdocs\travelsmart\admin\application\views\common\overlay.php 106
ERROR - 2017-05-17 13:15:26 --> Severity: Notice --> Undefined property: CI_Loader::$overlay_employee_details D:\xampp\htdocs\travelsmart\admin\application\views\common\overlay.php 106
ERROR - 2017-05-17 13:16:49 --> Severity: Notice --> Undefined property: CI_Loader::$overlay_employee_details D:\xampp\htdocs\travelsmart\admin\application\views\common\overlay.php 106
ERROR - 2017-05-17 13:19:46 --> Severity: Notice --> Undefined property: stdClass::$email_template_id D:\xampp\htdocs\travelsmart\admin\application\views\notification\view.php 188
ERROR - 2017-05-17 13:19:46 --> Severity: Notice --> Undefined property: stdClass::$email_type D:\xampp\htdocs\travelsmart\admin\application\views\notification\view.php 188
ERROR - 2017-05-17 13:19:46 --> Severity: Notice --> Undefined property: stdClass::$email_template_id D:\xampp\htdocs\travelsmart\admin\application\views\notification\view.php 188
ERROR - 2017-05-17 13:19:46 --> Severity: Notice --> Undefined property: stdClass::$email_type D:\xampp\htdocs\travelsmart\admin\application\views\notification\view.php 188
ERROR - 2017-05-17 13:19:46 --> Severity: Notice --> Undefined property: stdClass::$email_template_id D:\xampp\htdocs\travelsmart\admin\application\views\notification\view.php 188
ERROR - 2017-05-17 13:19:46 --> Severity: Notice --> Undefined property: stdClass::$email_type D:\xampp\htdocs\travelsmart\admin\application\views\notification\view.php 188
ERROR - 2017-05-17 13:19:46 --> Severity: Notice --> Undefined property: stdClass::$email_template_id D:\xampp\htdocs\travelsmart\admin\application\views\notification\view.php 188
ERROR - 2017-05-17 13:19:46 --> Severity: Notice --> Undefined property: stdClass::$email_type D:\xampp\htdocs\travelsmart\admin\application\views\notification\view.php 188
ERROR - 2017-05-17 13:19:46 --> Severity: Notice --> Undefined property: stdClass::$email_template_id D:\xampp\htdocs\travelsmart\admin\application\views\notification\view.php 188
ERROR - 2017-05-17 13:19:46 --> Severity: Notice --> Undefined property: stdClass::$email_type D:\xampp\htdocs\travelsmart\admin\application\views\notification\view.php 188
ERROR - 2017-05-17 13:19:46 --> Severity: Notice --> Undefined property: stdClass::$email_template_id D:\xampp\htdocs\travelsmart\admin\application\views\notification\view.php 188
ERROR - 2017-05-17 13:19:46 --> Severity: Notice --> Undefined property: stdClass::$email_type D:\xampp\htdocs\travelsmart\admin\application\views\notification\view.php 188
ERROR - 2017-05-17 13:19:46 --> Severity: Notice --> Undefined property: stdClass::$email_template_id D:\xampp\htdocs\travelsmart\admin\application\views\notification\view.php 188
ERROR - 2017-05-17 13:19:46 --> Severity: Notice --> Undefined property: stdClass::$email_type D:\xampp\htdocs\travelsmart\admin\application\views\notification\view.php 188
ERROR - 2017-05-17 13:19:46 --> Severity: Notice --> Undefined property: stdClass::$email_template_id D:\xampp\htdocs\travelsmart\admin\application\views\notification\view.php 188
ERROR - 2017-05-17 13:19:46 --> Severity: Notice --> Undefined property: stdClass::$email_type D:\xampp\htdocs\travelsmart\admin\application\views\notification\view.php 188
ERROR - 2017-05-17 13:19:46 --> Severity: Notice --> Undefined property: stdClass::$email_template_id D:\xampp\htdocs\travelsmart\admin\application\views\notification\view.php 188
ERROR - 2017-05-17 13:19:46 --> Severity: Notice --> Undefined property: stdClass::$email_type D:\xampp\htdocs\travelsmart\admin\application\views\notification\view.php 188
ERROR - 2017-05-17 13:19:46 --> Severity: Notice --> Undefined property: stdClass::$email_template_id D:\xampp\htdocs\travelsmart\admin\application\views\notification\view.php 188
ERROR - 2017-05-17 13:19:46 --> Severity: Notice --> Undefined property: stdClass::$email_type D:\xampp\htdocs\travelsmart\admin\application\views\notification\view.php 188
ERROR - 2017-05-17 13:19:48 --> 404 Page Not Found: SSSS/index
ERROR - 2017-05-17 13:27:25 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\travelsmart\admin\application\controllers\Bugs.php 144
ERROR - 2017-05-17 13:42:20 --> 404 Page Not Found: Home/get_invoice_range
ERROR - 2017-05-17 13:42:22 --> Severity: Notice --> Undefined property: CI_Loader::$overlay_employee_details D:\xampp\htdocs\travelsmart\admin\application\views\common\overlay.php 106
ERROR - 2017-05-17 13:42:25 --> 404 Page Not Found: Home/get_invoice_range
ERROR - 2017-05-17 13:48:58 --> 404 Page Not Found: Home/get_invoice_range
ERROR - 2017-05-17 14:38:28 --> 404 Page Not Found: B2c_do/list_all_b2c_ajax
ERROR - 2017-05-17 15:04:32 --> 404 Page Not Found: Home/get_invoice_range
ERROR - 2017-05-17 15:05:49 --> 404 Page Not Found: Home/get_invoice_range
ERROR - 2017-05-17 15:07:02 --> Severity: Notice --> Undefined property: CI_Loader::$overlay_employee_details D:\xampp\htdocs\travelsmart\admin\application\views\common\overlay.php 106
ERROR - 2017-05-17 15:07:03 --> Severity: Notice --> Undefined property: CI_Loader::$overlay_employee_details D:\xampp\htdocs\travelsmart\admin\application\views\common\overlay.php 106
ERROR - 2017-05-17 15:07:04 --> 404 Page Not Found: Assets/global
