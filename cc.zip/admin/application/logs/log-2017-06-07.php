<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-06-07 09:29:04 --> 404 Page Not Found: Email/http:
ERROR - 2017-06-07 09:29:05 --> 404 Page Not Found: Email/http:
ERROR - 2017-06-07 09:30:22 --> 404 Page Not Found: Email/%7BASSETS%7D
ERROR - 2017-06-07 09:30:22 --> 404 Page Not Found: Email/%7Buser.profile_image%7D
ERROR - 2017-06-07 09:33:02 --> 404 Page Not Found: Email/%7Buser.profile_image%7D
ERROR - 2017-06-07 09:33:02 --> 404 Page Not Found: Email/%7BASSETS%7D
ERROR - 2017-06-07 09:33:10 --> 404 Page Not Found: Assets/global
