<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-05-26 20:50:25 --> 404 Page Not Found: Home/get_invoice_range
ERROR - 2017-05-26 20:50:27 --> 404 Page Not Found: Home/get_invoice_range
ERROR - 2017-05-26 20:51:39 --> 404 Page Not Found: Home/get_invoice_range
ERROR - 2017-05-26 20:59:13 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\travelsmart\admin\application\controllers\Bugs.php 144
ERROR - 2017-05-26 20:59:34 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-26 20:59:34 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-26 20:59:34 --> 404 Page Not Found: B2c_do/list_all_b2c_ajax
