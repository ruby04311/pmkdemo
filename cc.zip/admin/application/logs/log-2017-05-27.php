<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-05-27 14:42:29 --> 404 Page Not Found: B2c_do/list_all_b2c_ajax
ERROR - 2017-05-27 14:44:30 --> 404 Page Not Found: B2c_do/list_all_b2c_ajax
ERROR - 2017-05-27 14:44:50 --> Severity: Notice --> Undefined property: CI_Loader::$overlay_employee_details D:\xampp\htdocs\travelsmart\admin\application\views\common\overlay.php 106
ERROR - 2017-05-27 14:44:51 --> Severity: Notice --> Undefined property: CI_Loader::$overlay_employee_details D:\xampp\htdocs\travelsmart\admin\application\views\common\overlay.php 106
ERROR - 2017-05-27 14:44:53 --> Severity: Notice --> Undefined property: CI_Loader::$overlay_employee_details D:\xampp\htdocs\travelsmart\admin\application\views\common\overlay.php 106
ERROR - 2017-05-27 19:13:01 --> 404 Page Not Found: B2c_do/list_all_b2c_ajax
ERROR - 2017-05-27 19:16:12 --> 404 Page Not Found: B2c_do/list_all_b2c_ajax
ERROR - 2017-05-27 19:16:12 --> 404 Page Not Found: B2c_do/list_all_b2c_ajax
ERROR - 2017-05-27 19:16:14 --> 404 Page Not Found: B2c_do/list_all_b2c_ajax
ERROR - 2017-05-27 19:29:03 --> 404 Page Not Found: B2c_do/list_all_b2c_ajax
ERROR - 2017-05-27 20:17:51 --> 404 Page Not Found: B2c_do/list_all_b2c_ajax
ERROR - 2017-05-27 20:29:52 --> 404 Page Not Found: B2c_do/list_all_b2c_ajax
ERROR - 2017-05-27 20:30:04 --> 404 Page Not Found: B2c_do/list_all_b2c_ajax
ERROR - 2017-05-27 20:35:30 --> 404 Page Not Found: B2c_do/list_all_b2c_ajax
ERROR - 2017-05-27 20:37:41 --> 404 Page Not Found: B2c_do/list_all_b2c_ajax
ERROR - 2017-05-27 20:39:17 --> 404 Page Not Found: B2c_do/list_all_b2c_ajax
ERROR - 2017-05-27 20:42:20 --> 404 Page Not Found: B2c_do/list_all_b2c_ajax
ERROR - 2017-05-27 20:46:45 --> 404 Page Not Found: B2c_do/list_all_b2c_ajax
ERROR - 2017-05-27 20:54:59 --> 404 Page Not Found: B2c_do/list_all_b2c_ajax
