<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-05-18 06:24:04 --> 404 Page Not Found: Home/get_invoice_range
ERROR - 2017-05-18 06:25:51 --> 404 Page Not Found: B2c_do/list_all_b2c_ajax
ERROR - 2017-05-18 13:11:31 --> 404 Page Not Found: Home/get_invoice_range
ERROR - 2017-05-18 14:33:01 --> 404 Page Not Found: Home/get_invoice_range
