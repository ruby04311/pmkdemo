<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-05-31 06:29:20 --> 404 Page Not Found: Hits/http:
ERROR - 2017-05-31 06:29:20 --> 404 Page Not Found: Hits/http:
ERROR - 2017-05-31 06:31:22 --> 404 Page Not Found: B2c/http:
ERROR - 2017-05-31 06:31:22 --> 404 Page Not Found: B2c/http:
ERROR - 2017-05-31 06:31:28 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-31 06:31:28 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-31 06:32:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 108
ERROR - 2017-05-31 06:32:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 121
ERROR - 2017-05-31 06:32:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 125
ERROR - 2017-05-31 06:32:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 125
ERROR - 2017-05-31 06:32:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 126
ERROR - 2017-05-31 06:32:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 131
ERROR - 2017-05-31 06:32:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 132
ERROR - 2017-05-31 06:32:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 174
ERROR - 2017-05-31 06:32:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 175
ERROR - 2017-05-31 06:32:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 176
ERROR - 2017-05-31 06:32:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 176
ERROR - 2017-05-31 06:32:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 179
ERROR - 2017-05-31 06:32:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 183
ERROR - 2017-05-31 06:32:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 187
ERROR - 2017-05-31 06:32:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 108
ERROR - 2017-05-31 06:32:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 121
ERROR - 2017-05-31 06:32:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 125
ERROR - 2017-05-31 06:32:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 125
ERROR - 2017-05-31 06:32:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 126
ERROR - 2017-05-31 06:32:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 131
ERROR - 2017-05-31 06:32:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 132
ERROR - 2017-05-31 06:32:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 174
ERROR - 2017-05-31 06:32:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 175
ERROR - 2017-05-31 06:32:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 176
ERROR - 2017-05-31 06:32:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 176
ERROR - 2017-05-31 06:32:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 179
ERROR - 2017-05-31 06:32:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 183
ERROR - 2017-05-31 06:32:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 187
ERROR - 2017-05-31 06:47:58 --> 404 Page Not Found: Employee/http:
ERROR - 2017-05-31 06:47:58 --> 404 Page Not Found: Employee/http:
ERROR - 2017-05-31 08:26:59 --> 404 Page Not Found: B2c/http:
ERROR - 2017-05-31 08:27:17 --> 404 Page Not Found: B2c/http:
ERROR - 2017-05-31 08:27:17 --> 404 Page Not Found: B2c/http:
ERROR - 2017-05-31 08:28:30 --> 404 Page Not Found: B2c/assets
ERROR - 2017-05-31 08:29:47 --> 404 Page Not Found: B2c/http:
ERROR - 2017-05-31 08:29:47 --> 404 Page Not Found: B2c/http:
ERROR - 2017-05-31 08:29:52 --> 404 Page Not Found: B2c/http:
ERROR - 2017-05-31 08:29:52 --> 404 Page Not Found: B2c/http:
ERROR - 2017-05-31 08:30:44 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-31 08:30:44 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-31 08:30:44 --> 404 Page Not Found: B2c/assets
ERROR - 2017-05-31 08:31:23 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-31 08:31:23 --> 404 Page Not Found: Assets/global
