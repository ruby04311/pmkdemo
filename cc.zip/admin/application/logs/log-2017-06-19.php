<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-06-19 09:49:15 --> 404 Page Not Found: Email/http:
ERROR - 2017-06-19 09:49:16 --> 404 Page Not Found: Email/http:
