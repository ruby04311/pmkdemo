<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-06-01 11:44:52 --> 404 Page Not Found: B2c/assets
ERROR - 2017-06-01 11:44:52 --> Query error: Unknown column 'flight_registration.flight_id' in 'field list' - Invalid query: SELECT flight_registration.`itinerary_id`, flight_registration.`flight_registration_id`, flight_registration.`flight_id`, flight_registration.`depature_airport_code`, flight_registration.`arrival_airport_code`, flight_registration.`airline_no`, flight_registration.`date_of_journey`, flight_registration.`depature_airport_city`, flight_registration.`arrival_airport_city`, flight_registration.`delay_index`, flight_registration.`delay_risk`
					FROM `flight_registration`
					JOIN user ON user.user_id = flight_registration.user_id
					WHERE user.user_code = 'TSB2C1002'
						 AND flight_registration.status = 'ACTIVE' 
					LIMIT 0,10
ERROR - 2017-06-01 11:44:53 --> Query error: Unknown column 'flight_registration.flight_id' in 'field list' - Invalid query: SELECT flight_registration.`itinerary_id`, flight_registration.`flight_registration_id`, flight_registration.`flight_id`, flight_registration.`depature_airport_code`, flight_registration.`arrival_airport_code`, flight_registration.`airline_no`, flight_registration.`date_of_journey`, flight_registration.`depature_airport_city`, flight_registration.`arrival_airport_city`, flight_registration.`delay_index`, flight_registration.`delay_risk`
					FROM `flight_registration`
					JOIN user ON user.user_id = flight_registration.user_id
					WHERE user.user_code = 'TSB2C1002'
						 AND flight_registration.status = 'INACTIVE' 
					LIMIT 0,10
ERROR - 2017-06-01 11:45:34 --> 404 Page Not Found: B2c/assets
ERROR - 2017-06-01 11:45:34 --> Query error: Unknown column 'flight_registration.flight_id' in 'field list' - Invalid query: SELECT flight_registration.`itinerary_id`, flight_registration.`flight_registration_id`, flight_registration.`flight_id`, flight_registration.`depature_airport_code`, flight_registration.`arrival_airport_code`, flight_registration.`airline_no`, flight_registration.`date_of_journey`, flight_registration.`depature_airport_city`, flight_registration.`arrival_airport_city`, flight_registration.`delay_index`, flight_registration.`delay_risk`
					FROM `flight_registration`
					JOIN user ON user.user_id = flight_registration.user_id
					WHERE user.user_code = 'TSB2C1002'
						 AND flight_registration.status = 'INACTIVE' 
					LIMIT 0,10
ERROR - 2017-06-01 11:46:18 --> 404 Page Not Found: B2c/assets
ERROR - 2017-06-01 11:46:18 --> Query error: Unknown column 'flight_registration.flight_id' in 'field list' - Invalid query: SELECT flight_registration.`itinerary_id`, flight_registration.`flight_registration_id`, flight_registration.`flight_id`, flight_registration.`depature_airport_code`, flight_registration.`arrival_airport_code`, flight_registration.`airline_no`, flight_registration.`date_of_journey`, flight_registration.`depature_airport_city`, flight_registration.`arrival_airport_city`, flight_registration.`delay_index`, flight_registration.`delay_risk`
					FROM `flight_registration`
					JOIN user ON user.user_id = flight_registration.user_id
					WHERE user.user_code = 'TSB2C1002'
						 AND flight_registration.status = 'INACTIVE' 
					LIMIT 0,10
ERROR - 2017-06-01 11:46:24 --> 404 Page Not Found: B2c/assets
ERROR - 2017-06-01 11:46:24 --> Query error: Unknown column 'flight_registration.flight_id' in 'field list' - Invalid query: SELECT flight_registration.`itinerary_id`, flight_registration.`flight_registration_id`, flight_registration.`flight_id`, flight_registration.`depature_airport_code`, flight_registration.`arrival_airport_code`, flight_registration.`airline_no`, flight_registration.`date_of_journey`, flight_registration.`depature_airport_city`, flight_registration.`arrival_airport_city`, flight_registration.`delay_index`, flight_registration.`delay_risk`
					FROM `flight_registration`
					JOIN user ON user.user_id = flight_registration.user_id
					WHERE user.user_code = 'TSB2C1002'
						 AND flight_registration.status = 'ACTIVE' 
					LIMIT 0,10
ERROR - 2017-06-01 11:46:41 --> 404 Page Not Found: Assets/global
ERROR - 2017-06-01 11:46:41 --> 404 Page Not Found: Assets/global
ERROR - 2017-06-01 11:46:45 --> 404 Page Not Found: Assets/global
ERROR - 2017-06-01 11:46:46 --> 404 Page Not Found: B2c/assets
ERROR - 2017-06-01 11:46:46 --> Query error: Unknown column 'flight_registration.flight_id' in 'field list' - Invalid query: SELECT flight_registration.`itinerary_id`, flight_registration.`flight_registration_id`, flight_registration.`flight_id`, flight_registration.`depature_airport_code`, flight_registration.`arrival_airport_code`, flight_registration.`airline_no`, flight_registration.`date_of_journey`, flight_registration.`depature_airport_city`, flight_registration.`arrival_airport_city`, flight_registration.`delay_index`, flight_registration.`delay_risk`
					FROM `flight_registration`
					JOIN user ON user.user_id = flight_registration.user_id
					WHERE user.user_code = 'TSB2C1003'
						 AND flight_registration.status = 'ACTIVE' 
					LIMIT 0,10
ERROR - 2017-06-01 11:46:46 --> Query error: Unknown column 'flight_registration.flight_id' in 'field list' - Invalid query: SELECT flight_registration.`itinerary_id`, flight_registration.`flight_registration_id`, flight_registration.`flight_id`, flight_registration.`depature_airport_code`, flight_registration.`arrival_airport_code`, flight_registration.`airline_no`, flight_registration.`date_of_journey`, flight_registration.`depature_airport_city`, flight_registration.`arrival_airport_city`, flight_registration.`delay_index`, flight_registration.`delay_risk`
					FROM `flight_registration`
					JOIN user ON user.user_id = flight_registration.user_id
					WHERE user.user_code = 'TSB2C1003'
						 AND flight_registration.status = 'INACTIVE' 
					LIMIT 0,10
ERROR - 2017-06-01 11:47:54 --> 404 Page Not Found: Assets/global
ERROR - 2017-06-01 11:47:54 --> Query error: Unknown column 'flight_registration.flight_id' in 'field list' - Invalid query: SELECT flight_registration.`itinerary_id`, flight_registration.`flight_registration_id`, flight_registration.`flight_id`, flight_registration.`depature_airport_code`, flight_registration.`arrival_airport_code`, flight_registration.`airline_no`, flight_registration.`date_of_journey`, flight_registration.`depature_airport_city`, flight_registration.`arrival_airport_city`, flight_registration.`delay_index`, flight_registration.`delay_risk`
					FROM `flight_registration`
					JOIN user ON user.user_id = flight_registration.user_id
					WHERE user.user_code = 'TSB2C1003'
						 AND flight_registration.status = 'ACTIVE' 
					LIMIT 0,10
ERROR - 2017-06-01 11:47:54 --> Query error: Unknown column 'flight_registration.flight_id' in 'field list' - Invalid query: SELECT flight_registration.`itinerary_id`, flight_registration.`flight_registration_id`, flight_registration.`flight_id`, flight_registration.`depature_airport_code`, flight_registration.`arrival_airport_code`, flight_registration.`airline_no`, flight_registration.`date_of_journey`, flight_registration.`depature_airport_city`, flight_registration.`arrival_airport_city`, flight_registration.`delay_index`, flight_registration.`delay_risk`
					FROM `flight_registration`
					JOIN user ON user.user_id = flight_registration.user_id
					WHERE user.user_code = 'TSB2C1003'
						 AND flight_registration.status = 'INACTIVE' 
					LIMIT 0,10
ERROR - 2017-06-01 11:47:54 --> 404 Page Not Found: B2c/assets
ERROR - 2017-06-01 11:48:32 --> 404 Page Not Found: Assets/global
ERROR - 2017-06-01 11:48:32 --> 404 Page Not Found: Assets/global
ERROR - 2017-06-01 11:48:38 --> 404 Page Not Found: Assets/global
ERROR - 2017-06-01 11:48:38 --> 404 Page Not Found: B2c/assets
ERROR - 2017-06-01 11:48:38 --> Query error: Unknown column 'flight_registration.flight_id' in 'field list' - Invalid query: SELECT flight_registration.`itinerary_id`, flight_registration.`flight_registration_id`, flight_registration.`flight_id`, flight_registration.`depature_airport_code`, flight_registration.`arrival_airport_code`, flight_registration.`airline_no`, flight_registration.`date_of_journey`, flight_registration.`depature_airport_city`, flight_registration.`arrival_airport_city`, flight_registration.`delay_index`, flight_registration.`delay_risk`
					FROM `flight_registration`
					JOIN user ON user.user_id = flight_registration.user_id
					WHERE user.user_code = 'TSB2C1004'
						 AND flight_registration.status = 'ACTIVE' 
					LIMIT 0,10
ERROR - 2017-06-01 11:48:38 --> Query error: Unknown column 'flight_registration.flight_id' in 'field list' - Invalid query: SELECT flight_registration.`itinerary_id`, flight_registration.`flight_registration_id`, flight_registration.`flight_id`, flight_registration.`depature_airport_code`, flight_registration.`arrival_airport_code`, flight_registration.`airline_no`, flight_registration.`date_of_journey`, flight_registration.`depature_airport_city`, flight_registration.`arrival_airport_city`, flight_registration.`delay_index`, flight_registration.`delay_risk`
					FROM `flight_registration`
					JOIN user ON user.user_id = flight_registration.user_id
					WHERE user.user_code = 'TSB2C1004'
						 AND flight_registration.status = 'INACTIVE' 
					LIMIT 0,10
ERROR - 2017-06-01 11:51:43 --> 404 Page Not Found: B2c/assets
ERROR - 2017-06-01 11:51:43 --> Query error: Unknown column 'flight_registration.flight_id' in 'field list' - Invalid query: SELECT flight_registration.`itinerary_id`, flight_registration.`flight_registration_id`, flight_registration.`flight_id`, flight_registration.`depature_airport_code`, flight_registration.`arrival_airport_code`, flight_registration.`airline_no`, flight_registration.`date_of_journey`, flight_registration.`depature_airport_city`, flight_registration.`arrival_airport_city`, flight_registration.`delay_index`, flight_registration.`delay_risk`
					FROM `flight_registration`
					JOIN user ON user.user_id = flight_registration.user_id
					WHERE user.user_code = 'TSB2C1004'
						 AND flight_registration.status = 'ACTIVE' 
					LIMIT 0,10
ERROR - 2017-06-01 11:51:43 --> Query error: Unknown column 'flight_registration.flight_id' in 'field list' - Invalid query: SELECT flight_registration.`itinerary_id`, flight_registration.`flight_registration_id`, flight_registration.`flight_id`, flight_registration.`depature_airport_code`, flight_registration.`arrival_airport_code`, flight_registration.`airline_no`, flight_registration.`date_of_journey`, flight_registration.`depature_airport_city`, flight_registration.`arrival_airport_city`, flight_registration.`delay_index`, flight_registration.`delay_risk`
					FROM `flight_registration`
					JOIN user ON user.user_id = flight_registration.user_id
					WHERE user.user_code = 'TSB2C1004'
						 AND flight_registration.status = 'INACTIVE' 
					LIMIT 0,10
ERROR - 2017-06-01 11:53:03 --> 404 Page Not Found: Assets/global
ERROR - 2017-06-01 11:53:03 --> 404 Page Not Found: B2c/assets
ERROR - 2017-06-01 11:53:03 --> Query error: Unknown column 'flight_registration.flight_id' in 'field list' - Invalid query: SELECT flight_registration.`itinerary_id`, flight_registration.`flight_registration_id`, flight_registration.`flight_id`, flight_registration.`depature_airport_code`, flight_registration.`arrival_airport_code`, flight_registration.`airline_no`, flight_registration.`date_of_journey`, flight_registration.`depature_airport_city`, flight_registration.`arrival_airport_city`, flight_registration.`delay_index`, flight_registration.`delay_risk`
					FROM `flight_registration`
					JOIN user ON user.user_id = flight_registration.user_id
					WHERE user.user_code = 'TSB2C1004'
						 AND flight_registration.status = 'ACTIVE' 
					LIMIT 0,10
ERROR - 2017-06-01 11:53:03 --> Query error: Unknown column 'flight_registration.flight_id' in 'field list' - Invalid query: SELECT flight_registration.`itinerary_id`, flight_registration.`flight_registration_id`, flight_registration.`flight_id`, flight_registration.`depature_airport_code`, flight_registration.`arrival_airport_code`, flight_registration.`airline_no`, flight_registration.`date_of_journey`, flight_registration.`depature_airport_city`, flight_registration.`arrival_airport_city`, flight_registration.`delay_index`, flight_registration.`delay_risk`
					FROM `flight_registration`
					JOIN user ON user.user_id = flight_registration.user_id
					WHERE user.user_code = 'TSB2C1004'
						 AND flight_registration.status = 'INACTIVE' 
					LIMIT 0,10
ERROR - 2017-06-01 11:55:03 --> 404 Page Not Found: B2c/assets
ERROR - 2017-06-01 11:55:03 --> Query error: Unknown column 'flight_registration.flight_id' in 'field list' - Invalid query: SELECT flight_registration.`itinerary_id`, flight_registration.`flight_registration_id`, flight_registration.`flight_id`, flight_registration.`depature_airport_code`, flight_registration.`arrival_airport_code`, flight_registration.`airline_no`, flight_registration.`date_of_journey`, flight_registration.`depature_airport_city`, flight_registration.`arrival_airport_city`, flight_registration.`delay_index`, flight_registration.`delay_risk`
					FROM `flight_registration`
					JOIN user ON user.user_id = flight_registration.user_id
					WHERE user.user_code = 'TSB2C1004'
						 AND flight_registration.status = 'ACTIVE' 
					LIMIT 0,10
ERROR - 2017-06-01 11:55:03 --> Query error: Unknown column 'flight_registration.flight_id' in 'field list' - Invalid query: SELECT flight_registration.`itinerary_id`, flight_registration.`flight_registration_id`, flight_registration.`flight_id`, flight_registration.`depature_airport_code`, flight_registration.`arrival_airport_code`, flight_registration.`airline_no`, flight_registration.`date_of_journey`, flight_registration.`depature_airport_city`, flight_registration.`arrival_airport_city`, flight_registration.`delay_index`, flight_registration.`delay_risk`
					FROM `flight_registration`
					JOIN user ON user.user_id = flight_registration.user_id
					WHERE user.user_code = 'TSB2C1004'
						 AND flight_registration.status = 'INACTIVE' 
					LIMIT 0,10
ERROR - 2017-06-01 11:55:08 --> 404 Page Not Found: B2c/assets
ERROR - 2017-06-01 11:55:08 --> Query error: Unknown column 'flight_registration.flight_id' in 'field list' - Invalid query: SELECT flight_registration.`itinerary_id`, flight_registration.`flight_registration_id`, flight_registration.`flight_id`, flight_registration.`depature_airport_code`, flight_registration.`arrival_airport_code`, flight_registration.`airline_no`, flight_registration.`date_of_journey`, flight_registration.`depature_airport_city`, flight_registration.`arrival_airport_city`, flight_registration.`delay_index`, flight_registration.`delay_risk`
					FROM `flight_registration`
					JOIN user ON user.user_id = flight_registration.user_id
					WHERE user.user_code = 'TSB2C1001'
						 AND flight_registration.status = 'ACTIVE' 
					LIMIT 0,10
ERROR - 2017-06-01 11:55:08 --> Query error: Unknown column 'flight_registration.flight_id' in 'field list' - Invalid query: SELECT flight_registration.`itinerary_id`, flight_registration.`flight_registration_id`, flight_registration.`flight_id`, flight_registration.`depature_airport_code`, flight_registration.`arrival_airport_code`, flight_registration.`airline_no`, flight_registration.`date_of_journey`, flight_registration.`depature_airport_city`, flight_registration.`arrival_airport_city`, flight_registration.`delay_index`, flight_registration.`delay_risk`
					FROM `flight_registration`
					JOIN user ON user.user_id = flight_registration.user_id
					WHERE user.user_code = 'TSB2C1001'
						 AND flight_registration.status = 'INACTIVE' 
					LIMIT 0,10
ERROR - 2017-06-01 11:55:15 --> 404 Page Not Found: B2c/assets
ERROR - 2017-06-01 11:55:15 --> Query error: Unknown column 'flight_registration.flight_id' in 'field list' - Invalid query: SELECT flight_registration.`itinerary_id`, flight_registration.`flight_registration_id`, flight_registration.`flight_id`, flight_registration.`depature_airport_code`, flight_registration.`arrival_airport_code`, flight_registration.`airline_no`, flight_registration.`date_of_journey`, flight_registration.`depature_airport_city`, flight_registration.`arrival_airport_city`, flight_registration.`delay_index`, flight_registration.`delay_risk`
					FROM `flight_registration`
					JOIN user ON user.user_id = flight_registration.user_id
					WHERE user.user_code = 'TSB2C1004'
						 AND flight_registration.status = 'ACTIVE' 
					LIMIT 0,10
ERROR - 2017-06-01 11:55:15 --> Query error: Unknown column 'flight_registration.flight_id' in 'field list' - Invalid query: SELECT flight_registration.`itinerary_id`, flight_registration.`flight_registration_id`, flight_registration.`flight_id`, flight_registration.`depature_airport_code`, flight_registration.`arrival_airport_code`, flight_registration.`airline_no`, flight_registration.`date_of_journey`, flight_registration.`depature_airport_city`, flight_registration.`arrival_airport_city`, flight_registration.`delay_index`, flight_registration.`delay_risk`
					FROM `flight_registration`
					JOIN user ON user.user_id = flight_registration.user_id
					WHERE user.user_code = 'TSB2C1004'
						 AND flight_registration.status = 'INACTIVE' 
					LIMIT 0,10
ERROR - 2017-06-01 11:55:21 --> Query error: Unknown column 'flight_registration.flight_id' in 'field list' - Invalid query: SELECT flight_registration.`itinerary_id`, flight_registration.`flight_registration_id`, flight_registration.`flight_id`, flight_registration.`depature_airport_code`, flight_registration.`arrival_airport_code`, flight_registration.`airline_no`, flight_registration.`date_of_journey`, flight_registration.`depature_airport_city`, flight_registration.`arrival_airport_city`, flight_registration.`delay_index`, flight_registration.`delay_risk`
					FROM `flight_registration`
					JOIN user ON user.user_id = flight_registration.user_id
					WHERE user.user_code = 'TSB2C1003'
						 AND flight_registration.status = 'ACTIVE' 
					LIMIT 0,10
ERROR - 2017-06-01 11:55:21 --> Query error: Unknown column 'flight_registration.flight_id' in 'field list' - Invalid query: SELECT flight_registration.`itinerary_id`, flight_registration.`flight_registration_id`, flight_registration.`flight_id`, flight_registration.`depature_airport_code`, flight_registration.`arrival_airport_code`, flight_registration.`airline_no`, flight_registration.`date_of_journey`, flight_registration.`depature_airport_city`, flight_registration.`arrival_airport_city`, flight_registration.`delay_index`, flight_registration.`delay_risk`
					FROM `flight_registration`
					JOIN user ON user.user_id = flight_registration.user_id
					WHERE user.user_code = 'TSB2C1003'
						 AND flight_registration.status = 'INACTIVE' 
					LIMIT 0,10
ERROR - 2017-06-01 11:55:21 --> 404 Page Not Found: B2c/assets
ERROR - 2017-06-01 11:57:18 --> Severity: error --> Exception: syntax error, unexpected '$flight_id' (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\controllers\B2c_do.php 339
ERROR - 2017-06-01 11:57:18 --> Severity: error --> Exception: syntax error, unexpected '$flight_id' (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\controllers\B2c_do.php 339
ERROR - 2017-06-01 11:57:19 --> Severity: error --> Exception: syntax error, unexpected '$flight_id' (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\controllers\B2c_do.php 339
ERROR - 2017-06-01 11:57:19 --> 404 Page Not Found: B2c/assets
ERROR - 2017-06-01 11:57:27 --> 404 Page Not Found: Assets/global
ERROR - 2017-06-01 11:57:27 --> Severity: error --> Exception: syntax error, unexpected '$flight_id' (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\controllers\B2c_do.php 339
ERROR - 2017-06-01 11:57:27 --> 404 Page Not Found: B2c/assets
ERROR - 2017-06-01 11:57:27 --> Severity: error --> Exception: syntax error, unexpected '$flight_id' (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\controllers\B2c_do.php 339
ERROR - 2017-06-01 11:57:27 --> Severity: error --> Exception: syntax error, unexpected '$flight_id' (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\controllers\B2c_do.php 339
ERROR - 2017-06-01 11:57:54 --> 404 Page Not Found: Assets/global
ERROR - 2017-06-01 11:57:54 --> 404 Page Not Found: B2c/assets
ERROR - 2017-06-01 11:57:54 --> Query error: Unknown column 'flight_registration.flight_id' in 'field list' - Invalid query: SELECT flight_registration.`itinerary_id`, flight_registration.`flight_registration_id`, flight_registration.`flight_id`, flight_registration.`depature_airport_code`, flight_registration.`arrival_airport_code`, flight_registration.`airline_no`, flight_registration.`date_of_journey`, flight_registration.`depature_airport_city`, flight_registration.`arrival_airport_city`, flight_registration.`delay_index`, flight_registration.`delay_risk`
					FROM `flight_registration`
					JOIN user ON user.user_id = flight_registration.user_id
					WHERE user.user_code = 'TSB2C1003'
						 AND flight_registration.status = 'INACTIVE' 
					LIMIT 0,10
ERROR - 2017-06-01 11:58:21 --> 404 Page Not Found: Assets/global
ERROR - 2017-06-01 11:58:22 --> Query error: Unknown column 'flight_registration.flight_id' in 'field list' - Invalid query: SELECT flight_registration.`itinerary_id`, flight_registration.`flight_registration_id`, flight_registration.`flight_id`, flight_registration.`depature_airport_code`, flight_registration.`arrival_airport_code`, flight_registration.`airline_no`, flight_registration.`date_of_journey`, flight_registration.`depature_airport_city`, flight_registration.`arrival_airport_city`, flight_registration.`delay_index`, flight_registration.`delay_risk`
					FROM `flight_registration`
					JOIN user ON user.user_id = flight_registration.user_id
					WHERE user.user_code = 'TSB2C1003'
						 AND flight_registration.status = 'ACTIVE' 
					LIMIT 0,10
ERROR - 2017-06-01 11:58:22 --> 404 Page Not Found: B2c/assets
ERROR - 2017-06-01 11:58:22 --> Query error: Unknown column 'flight_registration.flight_id' in 'field list' - Invalid query: SELECT flight_registration.`itinerary_id`, flight_registration.`flight_registration_id`, flight_registration.`flight_id`, flight_registration.`depature_airport_code`, flight_registration.`arrival_airport_code`, flight_registration.`airline_no`, flight_registration.`date_of_journey`, flight_registration.`depature_airport_city`, flight_registration.`arrival_airport_city`, flight_registration.`delay_index`, flight_registration.`delay_risk`
					FROM `flight_registration`
					JOIN user ON user.user_id = flight_registration.user_id
					WHERE user.user_code = 'TSB2C1003'
						 AND flight_registration.status = 'INACTIVE' 
					LIMIT 0,10
ERROR - 2017-06-01 12:21:08 --> 404 Page Not Found: B2c/assets
ERROR - 2017-06-01 13:01:01 --> 404 Page Not Found: B2c/assets
ERROR - 2017-06-01 13:01:05 --> 404 Page Not Found: B2c/assets
ERROR - 2017-06-01 13:01:09 --> 404 Page Not Found: B2c/assets
ERROR - 2017-06-01 13:01:13 --> 404 Page Not Found: B2c/assets
ERROR - 2017-06-01 13:18:47 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-06-01 13:18:48 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-06-01 13:19:46 --> 404 Page Not Found: B2c/assets
ERROR - 2017-06-01 13:20:10 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-06-01 13:20:11 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-06-01 13:23:44 --> 404 Page Not Found: Credit_points_distribution/history
ERROR - 2017-06-01 13:23:52 --> 404 Page Not Found: Credit_points_distribution/http:
ERROR - 2017-06-01 13:23:55 --> 404 Page Not Found: Credit_points_distribution/http:
ERROR - 2017-06-01 13:24:20 --> 404 Page Not Found: Hits/http:
ERROR - 2017-06-01 13:24:20 --> 404 Page Not Found: Hits/http:
ERROR - 2017-06-01 13:24:50 --> 404 Page Not Found: Credit_points_distribution/http:
ERROR - 2017-06-01 13:24:51 --> 404 Page Not Found: Credit_points_distribution/http:
ERROR - 2017-06-01 13:25:10 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-06-01 13:25:10 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-06-01 13:25:24 --> 404 Page Not Found: Credit_points_distribution/http:
ERROR - 2017-06-01 13:25:29 --> 404 Page Not Found: Credit_points_distribution/http:
ERROR - 2017-06-01 13:25:31 --> 404 Page Not Found: Credit_points_distribution/http:
