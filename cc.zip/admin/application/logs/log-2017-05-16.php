<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-05-16 11:40:20 --> 404 Page Not Found: Home/get_invoice_range
ERROR - 2017-05-16 11:47:42 --> 404 Page Not Found: B2c_do/list_all_b2c_ajax
ERROR - 2017-05-16 11:52:14 --> 404 Page Not Found: Department/http:
ERROR - 2017-05-16 11:52:14 --> 404 Page Not Found: Department/http:
