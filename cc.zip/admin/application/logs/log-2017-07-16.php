<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-07-16 10:41:09 --> Severity: Notice --> Undefined property: CI_Loader::$overlay_employee_details D:\xampp\htdocs\travelsmart\admin\application\views\common\overlay.php 106
ERROR - 2017-07-16 14:40:47 --> 404 Page Not Found: Node/admin
ERROR - 2017-07-16 14:40:47 --> 404 Page Not Found: Node/admin
ERROR - 2017-07-16 14:40:47 --> 404 Page Not Found: Node/admin
ERROR - 2017-07-16 14:40:47 --> 404 Page Not Found: Node/admin
ERROR - 2017-07-16 14:40:47 --> 404 Page Not Found: Node/admin
ERROR - 2017-07-16 14:40:47 --> 404 Page Not Found: Node/admin
ERROR - 2017-07-16 14:40:47 --> 404 Page Not Found: Node/admin
ERROR - 2017-07-16 14:40:47 --> 404 Page Not Found: Node/admin
ERROR - 2017-07-16 14:40:47 --> 404 Page Not Found: Node/admin
ERROR - 2017-07-16 14:40:47 --> 404 Page Not Found: Node/admin
ERROR - 2017-07-16 14:40:51 --> 404 Page Not Found: Node/admin
ERROR - 2017-07-16 14:40:51 --> 404 Page Not Found: Node/admin
ERROR - 2017-07-16 14:40:51 --> 404 Page Not Found: Node/admin
ERROR - 2017-07-16 14:40:51 --> 404 Page Not Found: Node/admin
ERROR - 2017-07-16 14:40:51 --> 404 Page Not Found: Node/admin
ERROR - 2017-07-16 14:41:26 --> 404 Page Not Found: Node/admin
ERROR - 2017-07-16 14:41:26 --> 404 Page Not Found: Node/admin
ERROR - 2017-07-16 14:41:26 --> 404 Page Not Found: Node/admin
ERROR - 2017-07-16 14:41:26 --> 404 Page Not Found: Node/admin
ERROR - 2017-07-16 14:41:26 --> 404 Page Not Found: Node/admin
ERROR - 2017-07-16 14:41:53 --> 404 Page Not Found: Node/sds
