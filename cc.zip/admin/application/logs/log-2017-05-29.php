<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-05-29 06:44:24 --> 404 Page Not Found: Credit_points/welcome_credits
ERROR - 2017-05-29 06:45:51 --> 404 Page Not Found: Credit_points/welcome_credits
ERROR - 2017-05-29 06:52:10 --> 404 Page Not Found: Credit_points/charges
ERROR - 2017-05-29 06:55:37 --> Severity: error --> Exception: Unable to locate the model you have specified: Credit_points_model D:\xampp\htdocs\travelsmart\system\core\Loader.php 344
ERROR - 2017-05-29 06:56:51 --> 404 Page Not Found: Help/http:
ERROR - 2017-05-29 06:56:52 --> 404 Page Not Found: Help/http:
ERROR - 2017-05-29 06:59:23 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 06:59:23 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:00:55 --> Severity: error --> Exception: syntax error, unexpected '<', expecting end of file D:\xampp\htdocs\travelsmart\admin\application\views\credit_points\charges.php 157
ERROR - 2017-05-29 07:01:06 --> Severity: Notice --> Undefined property: stdClass::$charge_type D:\xampp\htdocs\travelsmart\admin\application\views\credit_points\charges.php 99
ERROR - 2017-05-29 07:01:06 --> Severity: Notice --> Undefined property: stdClass::$charge_type D:\xampp\htdocs\travelsmart\admin\application\views\credit_points\charges.php 99
ERROR - 2017-05-29 07:01:06 --> Severity: Notice --> Undefined property: stdClass::$charge_type D:\xampp\htdocs\travelsmart\admin\application\views\credit_points\charges.php 99
ERROR - 2017-05-29 07:01:06 --> Severity: Notice --> Undefined property: stdClass::$charge_type D:\xampp\htdocs\travelsmart\admin\application\views\credit_points\charges.php 99
ERROR - 2017-05-29 07:01:07 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:01:07 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:01:28 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:01:28 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:03:23 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:03:23 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:03:45 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:03:45 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:04:49 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:04:49 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:04:57 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:04:57 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:07:13 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:07:13 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:07:58 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:07:58 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:08:24 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:08:25 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:08:52 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:08:52 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:08:58 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:08:59 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:09:28 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:09:28 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:09:31 --> 404 Page Not Found: Support_ticket/closed
ERROR - 2017-05-29 07:09:37 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 07:09:38 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 07:09:38 --> 404 Page Not Found: B2c_do/list_all_b2c_ajax
ERROR - 2017-05-29 07:09:40 --> 404 Page Not Found: Credit_points/welcome_credits
ERROR - 2017-05-29 07:09:42 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 07:09:43 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 07:09:43 --> 404 Page Not Found: B2c_do/list_all_b2c_ajax
ERROR - 2017-05-29 07:09:45 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:09:45 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:11:38 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:11:38 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:11:39 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:11:40 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:20:30 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:20:31 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:25:34 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:25:34 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:25:55 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:25:56 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:34:01 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:34:02 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:34:37 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:34:38 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:34:49 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:34:49 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:35:09 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:35:09 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:35:35 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:35:36 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:35:58 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:35:58 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:36:12 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:36:12 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:36:26 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:36:27 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:36:35 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:36:35 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:36:36 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:36:36 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:36:44 --> 404 Page Not Found: Credit_points/welcome_credits
ERROR - 2017-05-29 07:38:14 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:38:15 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:38:32 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:38:32 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:38:39 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:38:40 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:39:11 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:39:11 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:39:12 --> 404 Page Not Found: Credit_points/history
ERROR - 2017-05-29 07:39:14 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:39:16 --> 404 Page Not Found: Credit_points/credit_points_value
ERROR - 2017-05-29 07:40:19 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:40:19 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:46:50 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:46:51 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:55:43 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:55:43 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:58:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\credit_points\welcome_credits.php 171
ERROR - 2017-05-29 07:58:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\credit_points\welcome_credits.php 171
ERROR - 2017-05-29 07:58:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\credit_points\welcome_credits.php 172
ERROR - 2017-05-29 07:58:09 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\credit_points\welcome_credits.php 172
ERROR - 2017-05-29 07:58:09 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:58:09 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:58:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\credit_points\welcome_credits.php 171
ERROR - 2017-05-29 07:58:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\credit_points\welcome_credits.php 171
ERROR - 2017-05-29 07:58:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\credit_points\welcome_credits.php 172
ERROR - 2017-05-29 07:58:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\credit_points\welcome_credits.php 172
ERROR - 2017-05-29 07:58:24 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:58:24 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:58:44 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:58:44 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:59:15 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:59:15 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:59:38 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 07:59:38 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:00:06 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:00:07 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:04:48 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:04:48 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:06:18 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:06:18 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:07:33 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:07:33 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:07:33 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 08:08:28 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:08:28 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:08:29 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 08:09:02 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:09:03 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:09:03 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 08:10:00 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:10:00 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:10:00 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 08:10:17 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:10:18 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:10:18 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 08:10:24 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:10:25 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:10:25 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 08:10:31 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:10:31 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:10:31 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 08:10:36 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:10:36 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:10:37 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 08:21:54 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:21:55 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:21:55 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 08:22:56 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:22:57 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:22:57 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 08:26:02 --> Severity: Notice --> Undefined property: stdClass::$user_credit_points_charges_id D:\xampp\htdocs\travelsmart\admin\application\views\credit_points\welcome_credits.php 170
ERROR - 2017-05-29 08:26:02 --> Severity: Notice --> Undefined property: stdClass::$user_credit_points_charges_id D:\xampp\htdocs\travelsmart\admin\application\views\credit_points\welcome_credits.php 170
ERROR - 2017-05-29 08:26:02 --> Severity: Notice --> Undefined property: stdClass::$user_credit_points_charges_id D:\xampp\htdocs\travelsmart\admin\application\views\credit_points\welcome_credits.php 170
ERROR - 2017-05-29 08:26:02 --> Severity: Notice --> Undefined property: stdClass::$user_credit_points_charges_id D:\xampp\htdocs\travelsmart\admin\application\views\credit_points\welcome_credits.php 170
ERROR - 2017-05-29 08:26:02 --> Severity: Notice --> Undefined property: stdClass::$user_credit_points_charges_id D:\xampp\htdocs\travelsmart\admin\application\views\credit_points\welcome_credits.php 170
ERROR - 2017-05-29 08:26:02 --> Severity: Notice --> Undefined property: stdClass::$user_credit_points_charges_id D:\xampp\htdocs\travelsmart\admin\application\views\credit_points\welcome_credits.php 170
ERROR - 2017-05-29 08:26:02 --> Severity: Notice --> Undefined property: stdClass::$user_credit_points_charges_id D:\xampp\htdocs\travelsmart\admin\application\views\credit_points\welcome_credits.php 170
ERROR - 2017-05-29 08:26:02 --> Severity: Notice --> Undefined property: stdClass::$user_credit_points_charges_id D:\xampp\htdocs\travelsmart\admin\application\views\credit_points\welcome_credits.php 170
ERROR - 2017-05-29 08:26:02 --> Severity: Notice --> Undefined property: stdClass::$user_credit_points_charges_id D:\xampp\htdocs\travelsmart\admin\application\views\credit_points\welcome_credits.php 170
ERROR - 2017-05-29 08:26:02 --> Severity: Notice --> Undefined property: stdClass::$user_credit_points_charges_id D:\xampp\htdocs\travelsmart\admin\application\views\credit_points\welcome_credits.php 170
ERROR - 2017-05-29 08:26:02 --> Severity: Notice --> Undefined property: stdClass::$user_credit_points_charges_id D:\xampp\htdocs\travelsmart\admin\application\views\credit_points\welcome_credits.php 170
ERROR - 2017-05-29 08:26:02 --> Severity: Notice --> Undefined property: stdClass::$user_credit_points_charges_id D:\xampp\htdocs\travelsmart\admin\application\views\credit_points\welcome_credits.php 170
ERROR - 2017-05-29 08:26:02 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:26:02 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:26:03 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 08:26:22 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:26:23 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:26:23 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 08:28:09 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:28:09 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:28:09 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 08:28:15 --> Severity: Notice --> Undefined index: draw D:\xampp\htdocs\travelsmart\admin\application\controllers\Credit_points_do.php 132
ERROR - 2017-05-29 08:28:21 --> Severity: Notice --> Undefined index: draw D:\xampp\htdocs\travelsmart\admin\application\controllers\Credit_points_do.php 132
ERROR - 2017-05-29 08:29:12 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:29:12 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:29:13 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 08:29:45 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:29:45 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:29:45 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 08:30:11 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:30:12 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:30:43 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:30:43 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:30:49 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:30:49 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:35:36 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:35:36 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:36:06 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:36:06 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:36:08 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:36:08 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:36:59 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:36:59 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:37:50 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:37:50 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:38:15 --> 404 Page Not Found: Credit_points/credit_points_value
ERROR - 2017-05-29 08:38:16 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:38:17 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:38:26 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:38:26 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:38:28 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:38:28 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:38:38 --> 404 Page Not Found: Credit_points/credit_points_value
ERROR - 2017-05-29 08:51:39 --> Severity: Warning --> Missing argument 1 for Credit_Points_Model::get_points_value_history(), called in D:\xampp\htdocs\travelsmart\admin\application\views\credit_points\credit_points_value.php on line 163 and defined D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 69
ERROR - 2017-05-29 08:51:40 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:51:40 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:51:53 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:51:53 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:51:58 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:51:58 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:52:31 --> 404 Page Not Found: Credit_points/allot_to_users
ERROR - 2017-05-29 08:53:39 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:53:39 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:53:40 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 08:54:24 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:54:24 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:54:25 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 08:55:49 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:55:49 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:55:49 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 08:55:55 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:55:55 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:55:56 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 08:56:01 --> 404 Page Not Found: Credit_points_distribution/http:
ERROR - 2017-05-29 08:56:01 --> 404 Page Not Found: Credit_points_distribution/http:
ERROR - 2017-05-29 08:56:02 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 08:56:05 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:56:05 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:56:06 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 08:56:07 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:56:07 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:56:08 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 08:56:08 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:56:09 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 08:56:09 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 08:56:12 --> 404 Page Not Found: Credit_points_distribution/history
ERROR - 2017-05-29 08:56:15 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 08:56:17 --> 404 Page Not Found: Credit_points_distribution/http:
ERROR - 2017-05-29 08:56:18 --> 404 Page Not Found: Credit_points_distribution/http:
ERROR - 2017-05-29 08:56:18 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 08:56:21 --> 404 Page Not Found: Credit_points_distribution/allot_to_users
ERROR - 2017-05-29 08:56:23 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 09:02:55 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 09:02:55 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 09:11:20 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 09:11:21 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 09:11:21 --> 404 Page Not Found: B2c_do/list_all_b2c_ajax
ERROR - 2017-05-29 09:17:27 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 09:17:28 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 09:17:28 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 09:17:43 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 09:17:44 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 09:17:44 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 09:18:01 --> 404 Page Not Found: Credit_points_distribution/http:
ERROR - 2017-05-29 09:18:01 --> 404 Page Not Found: Credit_points_distribution/http:
ERROR - 2017-05-29 09:18:02 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 09:18:30 --> 404 Page Not Found: Credit_points_distribution/http:
ERROR - 2017-05-29 09:18:30 --> 404 Page Not Found: Credit_points_distribution/http:
ERROR - 2017-05-29 09:18:31 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 09:34:55 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 09:34:55 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 09:35:03 --> 404 Page Not Found: B2c_do/list_all_b2c_ajax
ERROR - 2017-05-29 09:43:05 --> 404 Page Not Found: Credit_points_distribution/http:
ERROR - 2017-05-29 09:43:05 --> 404 Page Not Found: Credit_points_distribution/http:
ERROR - 2017-05-29 09:43:06 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 09:43:25 --> 404 Page Not Found: Credit_points_distribution/http:
ERROR - 2017-05-29 09:43:26 --> 404 Page Not Found: Credit_points_distribution/http:
ERROR - 2017-05-29 09:43:26 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 09:43:41 --> 404 Page Not Found: B2c/add_user
ERROR - 2017-05-29 09:59:51 --> 404 Page Not Found: B2c_do/list_all_b2c_ajax
ERROR - 2017-05-29 10:00:33 --> 404 Page Not Found: B2c/add_user
ERROR - 2017-05-29 10:01:09 --> Severity: Notice --> Undefined property: B2c::$employee_model D:\xampp\htdocs\travelsmart\admin\application\controllers\B2c.php 141
ERROR - 2017-05-29 10:01:09 --> Severity: error --> Exception: Call to a member function get_module_all() on null D:\xampp\htdocs\travelsmart\admin\application\controllers\B2c.php 141
ERROR - 2017-05-29 10:05:05 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 10:05:11 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 10:05:11 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 10:05:11 --> 404 Page Not Found: B2c_do/list_all_b2c_ajax
ERROR - 2017-05-29 10:05:16 --> Severity: Notice --> Undefined variable: department D:\xampp\htdocs\travelsmart\admin\application\views\b2c\add_user.php 139
ERROR - 2017-05-29 10:05:16 --> Severity: Notice --> Undefined variable: module D:\xampp\htdocs\travelsmart\admin\application\views\b2c\add_user.php 293
ERROR - 2017-05-29 10:05:16 --> 404 Page Not Found: B2c/http:
ERROR - 2017-05-29 10:05:17 --> 404 Page Not Found: B2c/http:
ERROR - 2017-05-29 10:09:51 --> 404 Page Not Found: B2c/http:
ERROR - 2017-05-29 10:09:51 --> 404 Page Not Found: B2c/http:
ERROR - 2017-05-29 10:10:35 --> 404 Page Not Found: B2c/http:
ERROR - 2017-05-29 10:10:35 --> 404 Page Not Found: B2c/http:
ERROR - 2017-05-29 10:11:25 --> 404 Page Not Found: B2c/http:
ERROR - 2017-05-29 10:11:26 --> 404 Page Not Found: B2c/http:
ERROR - 2017-05-29 10:13:32 --> 404 Page Not Found: B2c/http:
ERROR - 2017-05-29 10:13:33 --> 404 Page Not Found: B2c/http:
ERROR - 2017-05-29 10:16:31 --> 404 Page Not Found: B2c/http:
ERROR - 2017-05-29 10:16:31 --> 404 Page Not Found: B2c/http:
ERROR - 2017-05-29 10:16:37 --> 404 Page Not Found: B2c/http:
ERROR - 2017-05-29 10:16:37 --> 404 Page Not Found: B2c/http:
ERROR - 2017-05-29 10:18:54 --> 404 Page Not Found: B2c/http:
ERROR - 2017-05-29 10:18:55 --> 404 Page Not Found: B2c/http:
ERROR - 2017-05-29 11:00:57 --> Query error: Table 'travelsmart.pdf_convertion_types' doesn't exist - Invalid query: SELECT * FROM pdf_convertion_types   ORDER BY pdf_convertion_types_id ASC  LIMIT 10 OFFSET 0 
ERROR - 2017-05-29 11:01:01 --> Query error: Table 'travelsmart.lawfirm_email' doesn't exist - Invalid query: SELECT * FROM lawfirm_email   ORDER BY  lawfirm_email_id DESC  LIMIT 10 OFFSET 0 
ERROR - 2017-05-29 11:06:52 --> Severity: Notice --> Undefined variable: res D:\xampp\htdocs\travelsmart\admin\application\controllers\Email.php 257
ERROR - 2017-05-29 11:06:52 --> Severity: Warning --> implode(): Invalid arguments passed D:\xampp\htdocs\travelsmart\admin\application\controllers\Email.php 257
ERROR - 2017-05-29 11:06:52 --> Severity: Notice --> Undefined variable: document_type D:\xampp\htdocs\travelsmart\admin\application\views\email\add_template.php 249
ERROR - 2017-05-29 11:06:52 --> 404 Page Not Found: Email/http:
ERROR - 2017-05-29 11:06:52 --> 404 Page Not Found: Email/http:
ERROR - 2017-05-29 11:07:07 --> Severity: Notice --> Undefined variable: document_type D:\xampp\htdocs\travelsmart\admin\application\views\email\add_template.php 249
ERROR - 2017-05-29 11:07:07 --> 404 Page Not Found: Email/http:
ERROR - 2017-05-29 11:07:07 --> 404 Page Not Found: Email/http:
ERROR - 2017-05-29 11:07:34 --> Severity: Notice --> Undefined variable: document_type D:\xampp\htdocs\travelsmart\admin\application\views\email\add_template.php 249
ERROR - 2017-05-29 11:07:34 --> 404 Page Not Found: Email/http:
ERROR - 2017-05-29 11:07:35 --> 404 Page Not Found: Email/http:
ERROR - 2017-05-29 11:08:23 --> 404 Page Not Found: Email/http:
ERROR - 2017-05-29 11:08:23 --> 404 Page Not Found: Email/http:
ERROR - 2017-05-29 11:12:13 --> 404 Page Not Found: B2c/http:
ERROR - 2017-05-29 11:12:14 --> 404 Page Not Found: B2c/http:
ERROR - 2017-05-29 11:12:57 --> 404 Page Not Found: Email/http:
ERROR - 2017-05-29 11:12:58 --> 404 Page Not Found: Email/http:
ERROR - 2017-05-29 11:16:40 --> Severity: error --> Exception: Call to undefined method Email_Model::get_document_type_list() D:\xampp\htdocs\travelsmart\admin\application\controllers\Email.php 224
ERROR - 2017-05-29 11:17:48 --> Severity: error --> Exception: Call to undefined method Email_Model::get_document_type_list() D:\xampp\htdocs\travelsmart\admin\application\controllers\Email.php 224
ERROR - 2017-05-29 11:18:03 --> Severity: Warning --> implode(): Invalid arguments passed D:\xampp\htdocs\travelsmart\admin\application\controllers\Email.php 238
ERROR - 2017-05-29 11:18:03 --> Severity: Notice --> Undefined variable: document_type D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 218
ERROR - 2017-05-29 11:18:03 --> Severity: Warning --> implode(): Invalid arguments passed D:\xampp\htdocs\travelsmart\admin\application\controllers\Email.php 238
ERROR - 2017-05-29 11:18:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 109
ERROR - 2017-05-29 11:18:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 117
ERROR - 2017-05-29 11:18:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 131
ERROR - 2017-05-29 11:18:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 143
ERROR - 2017-05-29 11:18:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 152
ERROR - 2017-05-29 11:18:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 162
ERROR - 2017-05-29 11:18:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 171
ERROR - 2017-05-29 11:18:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 180
ERROR - 2017-05-29 11:18:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 189
ERROR - 2017-05-29 11:18:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 194
ERROR - 2017-05-29 11:18:03 --> Severity: Notice --> Undefined variable: document_type D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 218
ERROR - 2017-05-29 11:18:03 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 235
ERROR - 2017-05-29 11:18:20 --> Severity: Notice --> Undefined variable: document_type D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 218
ERROR - 2017-05-29 11:18:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 109
ERROR - 2017-05-29 11:18:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 117
ERROR - 2017-05-29 11:18:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 131
ERROR - 2017-05-29 11:18:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 143
ERROR - 2017-05-29 11:18:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 152
ERROR - 2017-05-29 11:18:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 162
ERROR - 2017-05-29 11:18:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 171
ERROR - 2017-05-29 11:18:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 180
ERROR - 2017-05-29 11:18:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 189
ERROR - 2017-05-29 11:18:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 194
ERROR - 2017-05-29 11:18:20 --> Severity: Notice --> Undefined variable: document_type D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 218
ERROR - 2017-05-29 11:18:20 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 235
ERROR - 2017-05-29 11:20:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 109
ERROR - 2017-05-29 11:20:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 117
ERROR - 2017-05-29 11:20:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 131
ERROR - 2017-05-29 11:20:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 143
ERROR - 2017-05-29 11:20:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 152
ERROR - 2017-05-29 11:20:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 162
ERROR - 2017-05-29 11:20:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 171
ERROR - 2017-05-29 11:20:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 180
ERROR - 2017-05-29 11:20:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 189
ERROR - 2017-05-29 11:20:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 194
ERROR - 2017-05-29 11:20:18 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 214
ERROR - 2017-05-29 11:22:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 109
ERROR - 2017-05-29 11:22:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 117
ERROR - 2017-05-29 11:22:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 131
ERROR - 2017-05-29 11:22:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 143
ERROR - 2017-05-29 11:22:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 152
ERROR - 2017-05-29 11:22:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 162
ERROR - 2017-05-29 11:22:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 171
ERROR - 2017-05-29 11:22:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 180
ERROR - 2017-05-29 11:22:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 189
ERROR - 2017-05-29 11:22:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 194
ERROR - 2017-05-29 11:22:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 214
ERROR - 2017-05-29 11:22:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 109
ERROR - 2017-05-29 11:22:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 117
ERROR - 2017-05-29 11:22:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 131
ERROR - 2017-05-29 11:22:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 143
ERROR - 2017-05-29 11:22:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 152
ERROR - 2017-05-29 11:22:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 162
ERROR - 2017-05-29 11:22:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 171
ERROR - 2017-05-29 11:22:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 180
ERROR - 2017-05-29 11:22:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 189
ERROR - 2017-05-29 11:22:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 194
ERROR - 2017-05-29 11:22:44 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\email\edit_template.php 214
ERROR - 2017-05-29 11:28:13 --> 404 Page Not Found: B2c/http:
ERROR - 2017-05-29 11:28:13 --> 404 Page Not Found: B2c/http:
ERROR - 2017-05-29 11:36:34 --> 404 Page Not Found: B2c/http:
ERROR - 2017-05-29 11:36:34 --> 404 Page Not Found: B2c/http:
ERROR - 2017-05-29 11:37:09 --> Severity: error --> Exception: syntax error, unexpected 'if' (T_IF) D:\xampp\htdocs\travelsmart\admin\application\controllers\B2c_do.php 137
ERROR - 2017-05-29 11:41:46 --> 404 Page Not Found: B2c_do/add_user
ERROR - 2017-05-29 11:42:04 --> 404 Page Not Found: B2c_do/add_user
ERROR - 2017-05-29 11:42:40 --> 404 Page Not Found: B2c_do/add_user
ERROR - 2017-05-29 11:43:06 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 11:43:06 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 11:43:07 --> 404 Page Not Found: B2c_do/list_all_b2c_ajax
ERROR - 2017-05-29 11:43:07 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 11:43:08 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 11:43:08 --> 404 Page Not Found: B2c_do/list_all_b2c_ajax
ERROR - 2017-05-29 11:43:10 --> 404 Page Not Found: B2c/http:
ERROR - 2017-05-29 11:43:10 --> 404 Page Not Found: B2c/http:
ERROR - 2017-05-29 11:43:10 --> 404 Page Not Found: B2c/http:
ERROR - 2017-05-29 11:43:10 --> 404 Page Not Found: B2c/http:
ERROR - 2017-05-29 11:43:35 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 11:43:36 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 11:43:36 --> 404 Page Not Found: B2c_do/list_all_b2c_ajax
ERROR - 2017-05-29 11:43:36 --> 404 Page Not Found: B2c/assets
ERROR - 2017-05-29 11:49:08 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 11:49:08 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 11:49:08 --> 404 Page Not Found: B2c_do/list_all_b2c_ajax
ERROR - 2017-05-29 11:49:08 --> 404 Page Not Found: B2c/assets
ERROR - 2017-05-29 11:54:14 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 11:54:14 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 11:54:14 --> Severity: Notice --> Undefined property: B2c_Do::$employee_model D:\xampp\htdocs\travelsmart\admin\application\controllers\B2c_do.php 176
ERROR - 2017-05-29 11:54:14 --> Severity: error --> Exception: Call to a member function get_employee_list() on null D:\xampp\htdocs\travelsmart\admin\application\controllers\B2c_do.php 176
ERROR - 2017-05-29 12:06:48 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 12:06:49 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 12:06:49 --> Severity: Notice --> Undefined property: B2c_Do::$employee_model D:\xampp\htdocs\travelsmart\admin\application\controllers\B2c_do.php 177
ERROR - 2017-05-29 12:06:49 --> Severity: error --> Exception: Call to a member function get_b2c_list_all() on null D:\xampp\htdocs\travelsmart\admin\application\controllers\B2c_do.php 177
ERROR - 2017-05-29 12:07:05 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 12:07:06 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 12:07:39 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 12:07:39 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 12:08:01 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 12:08:02 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 12:08:29 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 12:08:29 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 12:08:33 --> 404 Page Not Found: B2c/edit_user
ERROR - 2017-05-29 12:08:33 --> 404 Page Not Found: B2c/assets
ERROR - 2017-05-29 12:08:33 --> 404 Page Not Found: B2c/assets
ERROR - 2017-05-29 12:08:33 --> 404 Page Not Found: B2c/assets
ERROR - 2017-05-29 12:08:33 --> 404 Page Not Found: B2c/assets
ERROR - 2017-05-29 12:23:07 --> Query error: Unknown column 'employee.user_id' in 'on clause' - Invalid query: SELECT `user`.*, `user_details`.*
FROM `user`
LEFT JOIN `user_details` ON `user_details`.`user_id` = `employee`.`user_id`
WHERE `user`.`user_id` = '1'
ERROR - 2017-05-29 12:23:22 --> Severity: Notice --> Undefined variable: country D:\xampp\htdocs\travelsmart\admin\application\views\b2c\edit_user.php 200
ERROR - 2017-05-29 12:23:23 --> 404 Page Not Found: error
ERROR - 2017-05-29 12:23:23 --> 404 Page Not Found: error
ERROR - 2017-05-29 12:23:37 --> 404 Page Not Found: error
ERROR - 2017-05-29 12:34:04 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 12:34:05 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 12:34:05 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 12:34:08 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 12:34:08 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 12:34:19 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 12:34:19 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 12:35:32 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 12:35:32 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 12:35:33 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 12:35:43 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 12:35:44 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 12:36:37 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 12:36:37 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 12:36:38 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 12:36:38 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 12:36:43 --> 404 Page Not Found: Credit_points_distribution/http:
ERROR - 2017-05-29 12:36:43 --> 404 Page Not Found: Credit_points_distribution/http:
ERROR - 2017-05-29 12:40:33 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 12:40:35 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 12:44:55 --> 404 Page Not Found: error
ERROR - 2017-05-29 12:44:55 --> 404 Page Not Found: error
ERROR - 2017-05-29 12:44:56 --> 404 Page Not Found: error
ERROR - 2017-05-29 12:48:45 --> 404 Page Not Found: error
ERROR - 2017-05-29 12:58:02 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 12:58:02 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 12:58:33 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 12:58:33 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 12:59:14 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 12:59:14 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 12:59:30 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 12:59:30 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 13:00:01 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 13:00:52 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 13:00:52 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 13:01:15 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 13:01:34 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 13:03:02 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 13:06:04 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 13:06:53 --> Severity: error --> Exception: syntax error, unexpected ',' D:\xampp\htdocs\travelsmart\admin\application\controllers\B2c_do.php 203
ERROR - 2017-05-29 13:07:06 --> 404 Page Not Found: B2c/assets
ERROR - 2017-05-29 13:07:20 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 13:07:45 --> 404 Page Not Found: B2c/assets
ERROR - 2017-05-29 13:07:49 --> 404 Page Not Found: B2c/assets
ERROR - 2017-05-29 13:07:53 --> 404 Page Not Found: B2c/assets
ERROR - 2017-05-29 13:08:26 --> 404 Page Not Found: B2c/assets
ERROR - 2017-05-29 13:08:28 --> 404 Page Not Found: B2c/assets
ERROR - 2017-05-29 13:10:32 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 13:10:32 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 13:16:22 --> Severity: error --> Exception: syntax error, unexpected 'get_credit_charges_status' (T_STRING), expecting variable (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 110
ERROR - 2017-05-29 13:16:23 --> Severity: error --> Exception: syntax error, unexpected 'get_credit_charges_status' (T_STRING), expecting variable (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 110
ERROR - 2017-05-29 13:16:28 --> Severity: error --> Exception: syntax error, unexpected 'get_credit_charges_status' (T_STRING), expecting variable (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 110
ERROR - 2017-05-29 13:16:28 --> Severity: error --> Exception: syntax error, unexpected 'get_credit_charges_status' (T_STRING), expecting variable (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 110
ERROR - 2017-05-29 13:16:29 --> Severity: error --> Exception: syntax error, unexpected 'get_credit_charges_status' (T_STRING), expecting variable (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 110
ERROR - 2017-05-29 13:16:29 --> Severity: error --> Exception: syntax error, unexpected 'get_credit_charges_status' (T_STRING), expecting variable (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 110
ERROR - 2017-05-29 13:16:29 --> Severity: error --> Exception: syntax error, unexpected 'get_credit_charges_status' (T_STRING), expecting variable (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 110
ERROR - 2017-05-29 13:16:36 --> Severity: error --> Exception: syntax error, unexpected 'get_credit_charges_status' (T_STRING), expecting variable (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 110
ERROR - 2017-05-29 13:16:37 --> Severity: error --> Exception: syntax error, unexpected 'get_credit_charges_status' (T_STRING), expecting variable (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 110
ERROR - 2017-05-29 13:16:37 --> Severity: error --> Exception: syntax error, unexpected 'get_credit_charges_status' (T_STRING), expecting variable (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 110
ERROR - 2017-05-29 13:16:37 --> Severity: error --> Exception: syntax error, unexpected 'get_credit_charges_status' (T_STRING), expecting variable (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 110
ERROR - 2017-05-29 13:16:37 --> Severity: error --> Exception: syntax error, unexpected 'get_credit_charges_status' (T_STRING), expecting variable (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 110
ERROR - 2017-05-29 13:16:38 --> Severity: error --> Exception: syntax error, unexpected 'get_credit_charges_status' (T_STRING), expecting variable (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 110
ERROR - 2017-05-29 13:16:40 --> Severity: error --> Exception: syntax error, unexpected 'get_credit_charges_status' (T_STRING), expecting variable (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 110
ERROR - 2017-05-29 13:16:53 --> Severity: error --> Exception: syntax error, unexpected 'get_credit_charges_status' (T_STRING), expecting variable (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 110
ERROR - 2017-05-29 13:16:54 --> Severity: error --> Exception: syntax error, unexpected 'get_credit_charges_status' (T_STRING), expecting variable (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 110
ERROR - 2017-05-29 13:16:54 --> Severity: error --> Exception: syntax error, unexpected 'get_credit_charges_status' (T_STRING), expecting variable (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 110
ERROR - 2017-05-29 13:16:54 --> Severity: error --> Exception: syntax error, unexpected 'get_credit_charges_status' (T_STRING), expecting variable (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 110
ERROR - 2017-05-29 13:16:55 --> Severity: error --> Exception: syntax error, unexpected 'get_credit_charges_status' (T_STRING), expecting variable (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 110
ERROR - 2017-05-29 13:16:55 --> Severity: error --> Exception: syntax error, unexpected 'get_credit_charges_status' (T_STRING), expecting variable (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 110
ERROR - 2017-05-29 13:16:55 --> Severity: error --> Exception: syntax error, unexpected 'get_credit_charges_status' (T_STRING), expecting variable (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 110
ERROR - 2017-05-29 13:16:55 --> Severity: error --> Exception: syntax error, unexpected 'get_credit_charges_status' (T_STRING), expecting variable (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 110
ERROR - 2017-05-29 13:16:56 --> Severity: error --> Exception: syntax error, unexpected 'get_credit_charges_status' (T_STRING), expecting variable (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 110
ERROR - 2017-05-29 13:16:56 --> Severity: error --> Exception: syntax error, unexpected 'get_credit_charges_status' (T_STRING), expecting variable (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 110
ERROR - 2017-05-29 13:16:56 --> Severity: error --> Exception: syntax error, unexpected 'get_credit_charges_status' (T_STRING), expecting variable (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 110
ERROR - 2017-05-29 13:16:56 --> Severity: error --> Exception: syntax error, unexpected 'get_credit_charges_status' (T_STRING), expecting variable (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 110
ERROR - 2017-05-29 13:16:57 --> Severity: error --> Exception: syntax error, unexpected 'get_credit_charges_status' (T_STRING), expecting variable (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 110
ERROR - 2017-05-29 13:16:57 --> Severity: error --> Exception: syntax error, unexpected 'get_credit_charges_status' (T_STRING), expecting variable (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 110
ERROR - 2017-05-29 13:16:58 --> Severity: error --> Exception: syntax error, unexpected 'get_credit_charges_status' (T_STRING), expecting variable (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 110
ERROR - 2017-05-29 13:16:59 --> Severity: error --> Exception: syntax error, unexpected 'get_credit_charges_status' (T_STRING), expecting variable (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 110
ERROR - 2017-05-29 13:17:02 --> Severity: error --> Exception: syntax error, unexpected 'get_credit_charges_status' (T_STRING), expecting variable (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 110
ERROR - 2017-05-29 13:17:02 --> Severity: error --> Exception: syntax error, unexpected 'get_credit_charges_status' (T_STRING), expecting variable (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 110
ERROR - 2017-05-29 13:17:03 --> Severity: error --> Exception: syntax error, unexpected 'get_credit_charges_status' (T_STRING), expecting variable (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 110
ERROR - 2017-05-29 13:17:03 --> Severity: error --> Exception: syntax error, unexpected 'get_credit_charges_status' (T_STRING), expecting variable (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 110
ERROR - 2017-05-29 13:17:05 --> Severity: error --> Exception: syntax error, unexpected 'get_credit_charges_status' (T_STRING), expecting variable (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 110
ERROR - 2017-05-29 13:17:06 --> Severity: error --> Exception: syntax error, unexpected 'get_credit_charges_status' (T_STRING), expecting variable (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 110
ERROR - 2017-05-29 13:17:10 --> Severity: error --> Exception: syntax error, unexpected 'get_credit_charges_status' (T_STRING), expecting variable (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 110
ERROR - 2017-05-29 13:17:10 --> Severity: error --> Exception: syntax error, unexpected 'get_credit_charges_status' (T_STRING), expecting variable (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 110
ERROR - 2017-05-29 13:17:10 --> Severity: error --> Exception: syntax error, unexpected 'get_credit_charges_status' (T_STRING), expecting variable (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 110
ERROR - 2017-05-29 13:17:11 --> Severity: error --> Exception: syntax error, unexpected 'get_credit_charges_status' (T_STRING), expecting variable (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 110
ERROR - 2017-05-29 13:17:11 --> Severity: error --> Exception: syntax error, unexpected 'get_credit_charges_status' (T_STRING), expecting variable (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 110
ERROR - 2017-05-29 13:17:14 --> Severity: error --> Exception: syntax error, unexpected 'get_credit_charges_status' (T_STRING), expecting variable (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 110
ERROR - 2017-05-29 13:17:14 --> Severity: error --> Exception: syntax error, unexpected 'get_credit_charges_status' (T_STRING), expecting variable (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 110
ERROR - 2017-05-29 13:17:15 --> Severity: error --> Exception: syntax error, unexpected 'get_credit_charges_status' (T_STRING), expecting variable (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 110
ERROR - 2017-05-29 13:17:15 --> Severity: error --> Exception: syntax error, unexpected 'get_credit_charges_status' (T_STRING), expecting variable (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 110
ERROR - 2017-05-29 13:17:23 --> Severity: error --> Exception: syntax error, unexpected 'get_credit_charges_status' (T_STRING), expecting variable (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 110
ERROR - 2017-05-29 13:17:24 --> Severity: error --> Exception: syntax error, unexpected 'get_credit_charges_status' (T_STRING), expecting variable (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 110
ERROR - 2017-05-29 13:17:24 --> Severity: error --> Exception: syntax error, unexpected 'get_credit_charges_status' (T_STRING), expecting variable (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 110
ERROR - 2017-05-29 13:17:25 --> Severity: error --> Exception: syntax error, unexpected 'get_credit_charges_status' (T_STRING), expecting variable (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 110
ERROR - 2017-05-29 13:17:25 --> Severity: error --> Exception: syntax error, unexpected 'get_credit_charges_status' (T_STRING), expecting variable (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 110
ERROR - 2017-05-29 13:17:25 --> Severity: error --> Exception: syntax error, unexpected 'get_credit_charges_status' (T_STRING), expecting variable (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 110
ERROR - 2017-05-29 13:17:26 --> Severity: error --> Exception: syntax error, unexpected 'get_credit_charges_status' (T_STRING), expecting variable (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 110
ERROR - 2017-05-29 13:17:26 --> Severity: error --> Exception: syntax error, unexpected 'get_credit_charges_status' (T_STRING), expecting variable (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 110
ERROR - 2017-05-29 13:17:26 --> Severity: error --> Exception: syntax error, unexpected 'get_credit_charges_status' (T_STRING), expecting variable (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 110
ERROR - 2017-05-29 13:17:26 --> Severity: error --> Exception: syntax error, unexpected 'get_credit_charges_status' (T_STRING), expecting variable (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 110
ERROR - 2017-05-29 13:17:32 --> Severity: error --> Exception: syntax error, unexpected 'get_credit_charges_status' (T_STRING), expecting variable (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 110
ERROR - 2017-05-29 13:17:32 --> Severity: error --> Exception: syntax error, unexpected 'get_credit_charges_status' (T_STRING), expecting variable (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 110
ERROR - 2017-05-29 13:17:32 --> Severity: error --> Exception: syntax error, unexpected 'get_credit_charges_status' (T_STRING), expecting variable (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 110
ERROR - 2017-05-29 13:17:33 --> Severity: error --> Exception: syntax error, unexpected 'get_credit_charges_status' (T_STRING), expecting variable (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 110
ERROR - 2017-05-29 13:17:33 --> Severity: error --> Exception: syntax error, unexpected 'get_credit_charges_status' (T_STRING), expecting variable (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 110
ERROR - 2017-05-29 13:17:34 --> Severity: error --> Exception: syntax error, unexpected 'get_credit_charges_status' (T_STRING), expecting variable (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 110
ERROR - 2017-05-29 13:17:35 --> Severity: error --> Exception: syntax error, unexpected 'get_credit_charges_status' (T_STRING), expecting variable (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 110
ERROR - 2017-05-29 13:17:35 --> Severity: error --> Exception: syntax error, unexpected 'get_credit_charges_status' (T_STRING), expecting variable (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 110
ERROR - 2017-05-29 13:17:35 --> Severity: error --> Exception: syntax error, unexpected 'get_credit_charges_status' (T_STRING), expecting variable (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 110
ERROR - 2017-05-29 13:17:35 --> Severity: error --> Exception: syntax error, unexpected 'get_credit_charges_status' (T_STRING), expecting variable (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 110
ERROR - 2017-05-29 13:17:36 --> Severity: error --> Exception: syntax error, unexpected 'get_credit_charges_status' (T_STRING), expecting variable (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 110
ERROR - 2017-05-29 13:17:36 --> Severity: error --> Exception: syntax error, unexpected 'get_credit_charges_status' (T_STRING), expecting variable (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 110
ERROR - 2017-05-29 13:17:36 --> Severity: error --> Exception: syntax error, unexpected 'get_credit_charges_status' (T_STRING), expecting variable (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 110
ERROR - 2017-05-29 13:17:36 --> Severity: error --> Exception: syntax error, unexpected 'get_credit_charges_status' (T_STRING), expecting variable (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 110
ERROR - 2017-05-29 13:17:37 --> Severity: error --> Exception: syntax error, unexpected 'get_credit_charges_status' (T_STRING), expecting variable (T_VARIABLE) D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 110
ERROR - 2017-05-29 13:17:42 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 13:17:44 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 13:17:44 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 13:19:17 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 13:19:17 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 13:19:22 --> 404 Page Not Found: Hits/generic_preview
ERROR - 2017-05-29 13:19:24 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 13:19:30 --> 404 Page Not Found: Credit_points_distribution/allot_to_users
ERROR - 2017-05-29 13:20:03 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 13:20:04 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 13:20:24 --> 404 Page Not Found: Credit_points_distribution/allot_to_users
ERROR - 2017-05-29 13:23:41 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 13:23:41 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 13:23:41 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 13:25:06 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 13:25:06 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 13:25:18 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 13:25:18 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 13:25:19 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 13:25:34 --> Severity: Notice --> Undefined variable: single D:\xampp\htdocs\travelsmart\admin\application\views\credit_points\charges.php 110
ERROR - 2017-05-29 13:25:34 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 13:25:34 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 13:25:35 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 13:25:43 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 13:25:43 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 13:26:05 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 13:26:06 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 13:26:58 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 13:26:58 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 13:26:58 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 13:27:46 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 13:27:47 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 13:27:47 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 13:28:26 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 13:28:26 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 13:28:27 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 13:28:58 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 13:28:59 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 13:28:59 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 13:42:34 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 13:42:34 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 13:42:35 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 13:44:02 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 13:44:03 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 13:44:03 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 13:44:39 --> 404 Page Not Found: Credit_points_distribution/http:
ERROR - 2017-05-29 13:44:39 --> 404 Page Not Found: Credit_points_distribution/http:
ERROR - 2017-05-29 13:45:07 --> 404 Page Not Found: Credit_points_distribution/http:
ERROR - 2017-05-29 13:45:07 --> 404 Page Not Found: Credit_points_distribution/http:
ERROR - 2017-05-29 13:49:37 --> 404 Page Not Found: Hits/generic_preview
ERROR - 2017-05-29 13:49:49 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 13:49:50 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 13:49:51 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 13:50:13 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 13:50:14 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 13:50:43 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 13:50:43 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 13:50:43 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 13:53:17 --> 404 Page Not Found: Credit_points_distribution/http:
ERROR - 2017-05-29 13:53:17 --> 404 Page Not Found: Credit_points_distribution/http:
ERROR - 2017-05-29 13:57:20 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 13:57:20 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 13:57:51 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 13:57:51 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 13:58:19 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 13:58:19 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 13:58:20 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 14:01:46 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 14:01:47 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 14:01:47 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 14:03:03 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 14:03:07 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 14:03:07 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 14:03:08 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 14:04:06 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 14:04:06 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 14:04:07 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 14:04:32 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 14:04:33 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 14:04:33 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 14:05:36 --> 404 Page Not Found: Hits/generic_preview
ERROR - 2017-05-29 14:11:33 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 14:11:35 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 14:11:35 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 14:12:03 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 14:12:03 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 14:12:14 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 14:12:14 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 14:12:28 --> 404 Page Not Found: Hits/http:
ERROR - 2017-05-29 14:12:28 --> 404 Page Not Found: Hits/http:
ERROR - 2017-05-29 14:12:50 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 14:12:51 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 14:12:51 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 14:13:01 --> 404 Page Not Found: Hits/http:
ERROR - 2017-05-29 14:13:01 --> 404 Page Not Found: Hits/http:
ERROR - 2017-05-29 14:13:09 --> 404 Page Not Found: Hits/http:
ERROR - 2017-05-29 14:13:09 --> 404 Page Not Found: Hits/http:
ERROR - 2017-05-29 14:13:21 --> 404 Page Not Found: Hits/http:
ERROR - 2017-05-29 14:13:21 --> 404 Page Not Found: Hits/http:
ERROR - 2017-05-29 14:13:30 --> 404 Page Not Found: Hits/http:
ERROR - 2017-05-29 14:13:31 --> 404 Page Not Found: Hits/http:
ERROR - 2017-05-29 14:17:58 --> 404 Page Not Found: Credit_points_distribution/http:
ERROR - 2017-05-29 14:17:58 --> 404 Page Not Found: Credit_points_distribution/http:
ERROR - 2017-05-29 14:18:00 --> 404 Page Not Found: Hits/http:
ERROR - 2017-05-29 14:18:00 --> 404 Page Not Found: Hits/http:
ERROR - 2017-05-29 14:18:08 --> 404 Page Not Found: Hits/http:
ERROR - 2017-05-29 14:18:08 --> 404 Page Not Found: Hits/http:
ERROR - 2017-05-29 14:18:09 --> 404 Page Not Found: Hits/http:
ERROR - 2017-05-29 14:18:09 --> 404 Page Not Found: Hits/http:
ERROR - 2017-05-29 14:18:12 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 14:18:14 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 14:18:14 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 14:19:01 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 14:19:02 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 14:19:02 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 14:19:45 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 14:19:46 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 14:19:48 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 14:20:10 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 14:20:12 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 14:20:12 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 14:20:25 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 14:20:27 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 14:20:28 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 14:22:00 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 14:22:01 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 14:22:03 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 14:25:59 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 14:26:00 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 14:26:00 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 14:26:11 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 14:26:11 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 14:26:11 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 14:26:23 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 14:26:30 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 14:26:35 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 14:28:42 --> Severity: Notice --> Undefined variable: preview D:\xampp\htdocs\travelsmart\admin\application\views\credit_points\welcome_credits.php 110
ERROR - 2017-05-29 14:28:42 --> Severity: Notice --> Undefined variable: preview D:\xampp\htdocs\travelsmart\admin\application\views\credit_points\welcome_credits.php 110
ERROR - 2017-05-29 14:28:44 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 14:28:45 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 14:28:46 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 14:29:54 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 14:29:54 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 14:30:27 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 14:30:27 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 14:30:27 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 14:30:37 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 14:30:37 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 14:30:37 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 14:30:40 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 14:31:16 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 14:31:17 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 14:31:17 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 14:31:21 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 14:31:21 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 14:31:29 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 14:31:59 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 14:31:59 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 14:32:05 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 14:32:05 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 14:32:06 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 14:32:59 --> 404 Page Not Found: Credit_points_distribution/http:
ERROR - 2017-05-29 14:32:59 --> 404 Page Not Found: Credit_points_distribution/http:
ERROR - 2017-05-29 14:33:49 --> Query error: Table 'travelsmart.flight_notification' doesn't exist - Invalid query: SELECT *
FROM `flight_notification`
ORDER BY `created_timestamp` DESC
ERROR - 2017-05-29 14:36:16 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 14:36:16 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 14:36:16 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 14:36:16 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 14:36:17 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 14:36:46 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 14:36:46 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 14:36:46 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 14:36:47 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 14:36:48 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 14:37:39 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 14:37:39 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 14:37:39 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 14:37:39 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 14:37:39 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 14:38:26 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 14:38:26 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 14:38:30 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 14:38:30 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 14:38:30 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 14:38:30 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 14:38:30 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 14:38:30 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 14:38:30 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 14:40:07 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 14:40:08 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 14:40:08 --> 404 Page Not Found: Flight_notification/assets
ERROR - 2017-05-29 14:40:33 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 14:40:33 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 14:40:36 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 14:40:37 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 14:40:38 --> 404 Page Not Found: Flight_notification/assets
ERROR - 2017-05-29 14:41:00 --> 404 Page Not Found: Flight_notification/assets
ERROR - 2017-05-29 14:41:02 --> 404 Page Not Found: Flight_notification/assets
ERROR - 2017-05-29 14:41:03 --> 404 Page Not Found: Flight_notification/assets
ERROR - 2017-05-29 14:41:10 --> 404 Page Not Found: Flight_notification/assets
ERROR - 2017-05-29 14:41:11 --> 404 Page Not Found: Flight_notification/assets
ERROR - 2017-05-29 14:41:13 --> 404 Page Not Found: Flight_notification/assets
ERROR - 2017-05-29 14:41:29 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 14:41:29 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 14:45:33 --> 404 Page Not Found: Flight_notification/assets
ERROR - 2017-05-29 14:45:48 --> 404 Page Not Found: Flight_notification/assets
ERROR - 2017-05-29 14:45:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\controllers\Flight_notification.php 119
ERROR - 2017-05-29 14:45:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\controllers\Flight_notification.php 121
ERROR - 2017-05-29 14:45:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\controllers\Flight_notification.php 122
ERROR - 2017-05-29 14:45:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\controllers\Flight_notification.php 123
ERROR - 2017-05-29 14:45:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\controllers\Flight_notification.php 124
ERROR - 2017-05-29 14:45:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\controllers\Flight_notification.php 125
ERROR - 2017-05-29 14:45:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\controllers\Flight_notification.php 126
ERROR - 2017-05-29 14:45:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\controllers\Flight_notification.php 127
ERROR - 2017-05-29 14:45:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\controllers\Flight_notification.php 128
ERROR - 2017-05-29 14:45:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\controllers\Flight_notification.php 129
ERROR - 2017-05-29 14:45:48 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\controllers\Flight_notification.php 130
ERROR - 2017-05-29 14:46:03 --> 404 Page Not Found: Flight_notification/assets
ERROR - 2017-05-29 14:46:12 --> 404 Page Not Found: Flight_notification/assets
ERROR - 2017-05-29 14:47:00 --> 404 Page Not Found: Flight_notification/assets
ERROR - 2017-05-29 14:47:13 --> 404 Page Not Found: Flight_notification/assets
ERROR - 2017-05-29 14:47:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\controllers\Flight_notification.php 119
ERROR - 2017-05-29 14:47:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\controllers\Flight_notification.php 121
ERROR - 2017-05-29 14:47:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\controllers\Flight_notification.php 122
ERROR - 2017-05-29 14:47:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\controllers\Flight_notification.php 123
ERROR - 2017-05-29 14:47:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\controllers\Flight_notification.php 124
ERROR - 2017-05-29 14:47:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\controllers\Flight_notification.php 125
ERROR - 2017-05-29 14:47:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\controllers\Flight_notification.php 126
ERROR - 2017-05-29 14:47:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\controllers\Flight_notification.php 127
ERROR - 2017-05-29 14:47:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\controllers\Flight_notification.php 128
ERROR - 2017-05-29 14:47:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\controllers\Flight_notification.php 129
ERROR - 2017-05-29 14:47:24 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\controllers\Flight_notification.php 130
ERROR - 2017-05-29 14:47:24 --> 404 Page Not Found: Flight_notification/assets
ERROR - 2017-05-29 14:47:53 --> Severity: Notice --> Undefined property: CI_Loader::$overlay_employee_details D:\xampp\htdocs\travelsmart\admin\application\views\common\overlay.php 106
ERROR - 2017-05-29 14:47:58 --> Severity: Notice --> Undefined property: CI_Loader::$overlay_employee_details D:\xampp\htdocs\travelsmart\admin\application\views\common\overlay.php 106
ERROR - 2017-05-29 14:48:01 --> Severity: Notice --> Undefined property: CI_Loader::$overlay_employee_details D:\xampp\htdocs\travelsmart\admin\application\views\common\overlay.php 106
ERROR - 2017-05-29 14:48:30 --> 404 Page Not Found: Credit_points_distribution/http:
ERROR - 2017-05-29 14:48:30 --> 404 Page Not Found: Credit_points_distribution/http:
ERROR - 2017-05-29 14:50:58 --> 404 Page Not Found: Flight_notification/assets
ERROR - 2017-05-29 14:51:06 --> 404 Page Not Found: Flight_notification/assets
ERROR - 2017-05-29 14:51:10 --> 404 Page Not Found: Flight_notification/assets
ERROR - 2017-05-29 14:51:23 --> 404 Page Not Found: Flight_notification/assets
ERROR - 2017-05-29 14:51:45 --> 404 Page Not Found: Flight_notification/assets
ERROR - 2017-05-29 14:54:26 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 14:54:34 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 14:54:35 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 14:54:35 --> 404 Page Not Found: Flight_notification/assets
ERROR - 2017-05-29 14:55:06 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 14:55:06 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 15:00:12 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 15:00:14 --> 404 Page Not Found: Credit_points_distribution/http:
ERROR - 2017-05-29 15:00:14 --> 404 Page Not Found: Credit_points_distribution/http:
ERROR - 2017-05-29 15:00:42 --> 404 Page Not Found: Hits/http:
ERROR - 2017-05-29 15:00:42 --> 404 Page Not Found: Hits/http:
ERROR - 2017-05-29 15:01:23 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 15:01:23 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 15:01:23 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 15:02:46 --> 404 Page Not Found: Hits/http:
ERROR - 2017-05-29 15:02:47 --> 404 Page Not Found: Hits/http:
ERROR - 2017-05-29 15:02:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\models\Email_model.php 380
ERROR - 2017-05-29 15:02:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\models\Email_model.php 389
ERROR - 2017-05-29 15:02:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\models\Email_model.php 390
ERROR - 2017-05-29 15:02:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\models\Email_model.php 391
ERROR - 2017-05-29 15:02:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\models\Email_model.php 392
ERROR - 2017-05-29 15:02:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\models\Email_model.php 393
ERROR - 2017-05-29 15:06:50 --> 404 Page Not Found: B2c/http:
ERROR - 2017-05-29 15:06:50 --> 404 Page Not Found: B2c/http:
ERROR - 2017-05-29 15:06:53 --> 404 Page Not Found: error
ERROR - 2017-05-29 15:13:07 --> 404 Page Not Found: Hits/http:
ERROR - 2017-05-29 15:13:07 --> 404 Page Not Found: Hits/http:
ERROR - 2017-05-29 15:13:08 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 16:14:13 --> 404 Page Not Found: Hits/http:
ERROR - 2017-05-29 16:14:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 121
ERROR - 2017-05-29 16:14:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 125
ERROR - 2017-05-29 16:14:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 125
ERROR - 2017-05-29 16:14:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 126
ERROR - 2017-05-29 16:14:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 131
ERROR - 2017-05-29 16:14:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 132
ERROR - 2017-05-29 16:14:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 121
ERROR - 2017-05-29 16:14:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 125
ERROR - 2017-05-29 16:14:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 125
ERROR - 2017-05-29 16:14:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 126
ERROR - 2017-05-29 16:14:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 131
ERROR - 2017-05-29 16:14:34 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 132
ERROR - 2017-05-29 16:14:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 121
ERROR - 2017-05-29 16:14:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 125
ERROR - 2017-05-29 16:14:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 125
ERROR - 2017-05-29 16:14:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 126
ERROR - 2017-05-29 16:14:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 131
ERROR - 2017-05-29 16:14:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 132
ERROR - 2017-05-29 16:14:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 121
ERROR - 2017-05-29 16:14:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 125
ERROR - 2017-05-29 16:14:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 125
ERROR - 2017-05-29 16:14:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 126
ERROR - 2017-05-29 16:14:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 131
ERROR - 2017-05-29 16:14:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 132
ERROR - 2017-05-29 16:19:50 --> 404 Page Not Found: B2c/http:
ERROR - 2017-05-29 16:19:50 --> 404 Page Not Found: B2c/http:
ERROR - 2017-05-29 19:01:31 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 19:01:45 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 19:01:45 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 19:02:45 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 19:02:45 --> 404 Page Not Found: Credit_points/http:
ERROR - 2017-05-29 19:03:11 --> 404 Page Not Found: Credit_points_distribution/http:
ERROR - 2017-05-29 19:03:11 --> 404 Page Not Found: Credit_points_distribution/http:
ERROR - 2017-05-29 19:18:32 --> 404 Page Not Found: Credit_points_distribution/http:
ERROR - 2017-05-29 19:18:32 --> 404 Page Not Found: Credit_points_distribution/http:
ERROR - 2017-05-29 19:18:33 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 19:18:41 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 60
ERROR - 2017-05-29 19:18:55 --> 404 Page Not Found: Credit_points_distribution/http:
ERROR - 2017-05-29 19:18:56 --> 404 Page Not Found: Credit_points_distribution/http:
ERROR - 2017-05-29 19:18:56 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 19:19:37 --> 404 Page Not Found: Credit_points_distribution/http:
ERROR - 2017-05-29 19:19:37 --> 404 Page Not Found: Credit_points_distribution/http:
ERROR - 2017-05-29 19:19:38 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 19:20:21 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ';' D:\xampp\htdocs\travelsmart\admin\application\models\Credit_points_model.php 70
ERROR - 2017-05-29 19:20:29 --> 404 Page Not Found: Credit_points_distribution/http:
ERROR - 2017-05-29 19:20:30 --> 404 Page Not Found: Credit_points_distribution/http:
ERROR - 2017-05-29 19:20:30 --> 404 Page Not Found: Assets/global
ERROR - 2017-05-29 19:59:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 108
ERROR - 2017-05-29 19:59:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 121
ERROR - 2017-05-29 19:59:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 125
ERROR - 2017-05-29 19:59:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 125
ERROR - 2017-05-29 19:59:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 126
ERROR - 2017-05-29 19:59:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 131
ERROR - 2017-05-29 19:59:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 132
ERROR - 2017-05-29 19:59:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 174
ERROR - 2017-05-29 19:59:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 175
ERROR - 2017-05-29 19:59:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 176
ERROR - 2017-05-29 19:59:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 176
ERROR - 2017-05-29 19:59:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 179
ERROR - 2017-05-29 19:59:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 183
ERROR - 2017-05-29 19:59:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 187
ERROR - 2017-05-29 19:59:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 108
ERROR - 2017-05-29 19:59:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 121
ERROR - 2017-05-29 19:59:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 125
ERROR - 2017-05-29 19:59:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 125
ERROR - 2017-05-29 19:59:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 126
ERROR - 2017-05-29 19:59:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 131
ERROR - 2017-05-29 19:59:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 132
ERROR - 2017-05-29 19:59:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 174
ERROR - 2017-05-29 19:59:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 175
ERROR - 2017-05-29 19:59:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 176
ERROR - 2017-05-29 19:59:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 176
ERROR - 2017-05-29 19:59:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 179
ERROR - 2017-05-29 19:59:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 183
ERROR - 2017-05-29 19:59:31 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 187
ERROR - 2017-05-29 19:59:55 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 108
ERROR - 2017-05-29 19:59:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 121
ERROR - 2017-05-29 19:59:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 125
ERROR - 2017-05-29 19:59:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 125
ERROR - 2017-05-29 19:59:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 126
ERROR - 2017-05-29 19:59:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 131
ERROR - 2017-05-29 19:59:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 132
ERROR - 2017-05-29 19:59:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 174
ERROR - 2017-05-29 19:59:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 175
ERROR - 2017-05-29 19:59:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 176
ERROR - 2017-05-29 19:59:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 176
ERROR - 2017-05-29 19:59:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 179
ERROR - 2017-05-29 19:59:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 183
ERROR - 2017-05-29 19:59:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 187
ERROR - 2017-05-29 19:59:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 108
ERROR - 2017-05-29 19:59:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 121
ERROR - 2017-05-29 19:59:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 125
ERROR - 2017-05-29 19:59:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 125
ERROR - 2017-05-29 19:59:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 126
ERROR - 2017-05-29 19:59:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 131
ERROR - 2017-05-29 19:59:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 132
ERROR - 2017-05-29 19:59:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 174
ERROR - 2017-05-29 19:59:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 175
ERROR - 2017-05-29 19:59:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 176
ERROR - 2017-05-29 19:59:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 176
ERROR - 2017-05-29 19:59:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 179
ERROR - 2017-05-29 19:59:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 183
ERROR - 2017-05-29 19:59:56 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 187
ERROR - 2017-05-29 20:10:52 --> 404 Page Not Found: B2c/assets
ERROR - 2017-05-29 20:11:00 --> 404 Page Not Found: B2c/assets
ERROR - 2017-05-29 20:12:33 --> 404 Page Not Found: B2c/assets
ERROR - 2017-05-29 20:13:05 --> 404 Page Not Found: B2c/assets
ERROR - 2017-05-29 20:15:56 --> 404 Page Not Found: B2c/assets
ERROR - 2017-05-29 20:43:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 108
ERROR - 2017-05-29 20:43:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 121
ERROR - 2017-05-29 20:43:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 125
ERROR - 2017-05-29 20:43:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 125
ERROR - 2017-05-29 20:43:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 126
ERROR - 2017-05-29 20:43:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 131
ERROR - 2017-05-29 20:43:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 132
ERROR - 2017-05-29 20:43:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 174
ERROR - 2017-05-29 20:43:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 175
ERROR - 2017-05-29 20:43:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 176
ERROR - 2017-05-29 20:43:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 176
ERROR - 2017-05-29 20:43:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 179
ERROR - 2017-05-29 20:43:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 183
ERROR - 2017-05-29 20:43:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 187
ERROR - 2017-05-29 20:43:57 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 108
ERROR - 2017-05-29 20:43:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 121
ERROR - 2017-05-29 20:43:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 125
ERROR - 2017-05-29 20:43:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 125
ERROR - 2017-05-29 20:43:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 126
ERROR - 2017-05-29 20:43:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 131
ERROR - 2017-05-29 20:43:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 132
ERROR - 2017-05-29 20:43:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 174
ERROR - 2017-05-29 20:43:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 175
ERROR - 2017-05-29 20:43:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 176
ERROR - 2017-05-29 20:43:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 176
ERROR - 2017-05-29 20:43:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 179
ERROR - 2017-05-29 20:43:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 183
ERROR - 2017-05-29 20:43:58 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\travelsmart\admin\application\views\b2c\view.php 187
