<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Help_Model extends CI_Model {
	
 	 public function add_help($question,$answer)
	{
		
		$help_code_id_v =  "RFM-HLP-";
		$help_code_id =  $help_code_id_v.(1000+$this->max_empid());
	  $question= $this->db->escape($question);
	 $answer = $this->db->escape($answer);
  		$query = "INSERT INTO help (help_code,question,answer, status  ) VALUES
  ('$help_code_id',$question,$answer,'ACTIVE');";
    
 		if ($this->db->query($query)) 
		{
			$insert_id = $this->db->insert_id();

   return  $insert_id;
		}
		else
		{
			return false;
		}
	}	
	public function get_help_all()
	{
		
 		$query1 = "SELECT * FROM help ORDER BY help_id ASC ";
		$query = $this->db->query($query1);
		 
		if ( $query->num_rows() > 0 ) 
		{
			return $query->result();	
		}
		else
		{
			return false;
		}
	}	
	public function update_help($id, $code, $name)
	{
		  $code= $this->db->escape($code);
	 $name	 = $this->db->escape($name);
 		$query = "UPDATE help SET question=$code,answer=$name 
		 WHERE  help_id='$id'";
 		if ($this->db->query($query)) 
		{
			return true;	
		}
		else
		{
			return false;
		}
	}
	 public function view_help_id($id)
	{
		$query1 = "SELECT * FROM help WHERE help_id='$id'";
		$query = $this->db->query($query1);
		 
		if ( $query->num_rows() > 0 ) 
		{
			return $query->row();	
		}
		else
		{
			return false;
		}
	}
	public function max_empid(){
        $result = $this->db->select_max('help_id')->get('help')->row();
       $help_code = $result->help_id;
        if($help_code == ''){
            $help_code = 0;
        }
		 
      $help_code = $help_code+1;
        
        return $help_code;
    }
	 public function delete_help($helptid)
	{
  		$query = "DELETE FROM help  WHERE help_id='$helptid'";
 		if ($this->db->query($query)) 
		{
			 
			return true;	
		}
		else
		{
				 
			return false;
		}
	}	
	public function change_help_status($id,$status)
	{
  		$query = "UPDATE help SET status='$status' 
		 WHERE  help_id='$id'";
 		if ($this->db->query($query)) 
		{
			return true;	
		}
		else
		{
			return false;
		}
	}	
}
