<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Bugs_Model extends CI_Model {
 	 public function get_bugs_all()
	{
		$query1 = "SELECT * FROM bugs_tracking ORDER BY bugs_tracking_id DESC";
		$query = $this->db->query($query1);
		 
		if ( $query->num_rows() > 0 ) 
		{
			return $query->result();	
		}
		else
		{
			return false;
		}
	}
	 public function view_screenshot($id)
	{
		$query1 = "SELECT * FROM bugs_tracking WHERE bugs_tracking_id='$id'";
		$query = $this->db->query($query1);
		 
		if ( $query->num_rows() > 0 ) 
		{
			return $query->row();	
		}
		else
		{
			return false;
		}
	}
	 public function store_bugs($page_url,$type,$image)
	{
		$query1 = "INSERT INTO bugs_tracking (page_url,bugs_type, image_path) VALUES
  ('$page_url','$type', '$image');";
		  $this->db->query($query1);
		  
	}
	 public function delete_bugs()
	{
		$query1 = "TRUNCATE bugs_tracking;";
		  $this->db->query($query1);
		  
	}

}
