<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class B2c_Model extends CI_Model {
 
	public function get_country_all()
	{
		 
 		$query1 = "SELECT * FROM country ORDER BY  country_name ASC "; 
		 
		
		$query = $this->db->query($query1);
		 
		if ( $query->num_rows() > 0 ) 
		{
			return $query->result();	
		}
		else
		{
			return false;
		}
	}	
	 	public function max_empid(){
        $result = $this->db->select_max('user_id')->get('user')->row();
       $emp_code = $result->user_id;
        if($emp_code == ''){
            $emp_code = 0;
        }
      $emp_code = $emp_code+1;
        
        return $emp_code;
    } 
	public function add_user($emp_code_id,$first_name,$last_name,$email_address,$password,$street,$city,$state,$country,$postal,$profile_pic,$phone_number)
	{
  		$query = "INSERT INTO user ( user_code,email_address,first_name,last_name,status,profile_pic,password  ) VALUES
  ( '$emp_code_id','$email_address','$first_name','$last_name','ACTIVE','$profile_pic','$password');";
 		if ($this->db->query($query)) 
		{
			$user_id = $this->db->insert_id();
			
			//////////////////
			$credit_points = 0;
			$querycp = "SELECT * FROM user_credit_points_charges WHERE charge_type='WELCOME' AND status='ACTIVE'  "; 
			$querycp1 = $this->db->query($querycp);
 			if ( $querycp1->num_rows() > 0 ) 
			{
				$res_cp =  $querycp1->row();	
				$credit_points = $res_cp->charge_value;
				$query2_cp = "INSERT INTO user_credit_points_transaction (credit_points_charge_type,user_credit_points_value,user_credit_points_value_final,transaction_mode) VALUES
		  ('WELCOME','$credit_points','$credit_points','CREDIT');";
				if ($this->db->query($query2_cp))
				{
					$trans_id = $this->db->insert_id();
					$ipaddress  = CLIENT_ADDR;
					$query3_cp = "INSERT INTO user_transaction (user_id,user_credit_points_transaction_id,process_by,ip_address) VALUES
			  ('$user_id','$trans_id','ADMIN','$ipaddress');";
					$this->db->query($query3_cp);
				}

			}
			else
			{
				$credit_points = 0;
			}
			$query1_cp = "INSERT INTO user_credit_points (user_id,credit_points ) VALUES
		  ('$user_id','$credit_points');";
			$this->db->query($query1_cp);
			
  			$data22 = array( 
			 'user_id'=>$user_id
 			 );
			$this->db->insert('user_verifications', $data22);
			
			////////////////
			
			 
			
			 $street = $this->db->escape_str($street); 
			 $city = $this->db->escape_str($city); 
			$state = $this->db->escape_str($state); 
			$country = $this->db->escape_str($country); 
			$postal = $this->db->escape_str($postal); 
			$phone_number = $this->db->escape_str($phone_number);
			
			$query1 = "INSERT INTO user_details (user_id,city,street,country,state,postal_code,phone_number  ) VALUES
		  ('$user_id','$city','$street','$country','$state','$postal','$phone_number');";
				if ($this->db->query($query1)) 
				{
					
					
  					return $user_id;	
				}
				else
				{
					return false;
				}
		}
		else
		{
			return false;
		}
	}
	public function update_user($emp_id,$first_name,$last_name,$street,$city,$state,$country,$postal,$profile_pic,$phone_number)
	{
		if($profile_pic!='')
		{
			$query = "UPDATE user SET  first_name='$first_name',last_name='$last_name', profile_pic='$profile_pic' 
			 WHERE  user_id='$emp_id'";
		}
			else
			{
				
				$query = "UPDATE user SET  first_name='$first_name',last_name='$last_name'
			 WHERE  user_id='$emp_id'";
			}
			if ($this->db->query($query)) 
			{
				$query_v = "UPDATE user_details SET city='$city',street='$street',country='$country',state='$state' 
				,postal_code='$postal' ,phone_number='$phone_number' 
			 WHERE  user_id='$emp_id'";
				$this->db->query($query_v);
				return true;	
			}
			else
			{
				return false;
			}
		
	}
	public function get_b2c_list($orders,$offset='',$limit='',$user_code,$first_name,$emailid,$contacts,$status)
	{
		 $order_column = $orders['0']['column'];
		$order_dir = $orders['0']['dir'];
		$orders_v1='';
		if($order_column==0)
		{
			$order_dt = " user.user_code ";
			$orders_v1 = " ORDER BY ".$order_dt.strtoupper($order_dir);
		}
		elseif($order_column==1)
		{
			$order_dt = " user.first_name ";
			$orders_v1 = " ORDER BY ".$order_dt.strtoupper($order_dir);
		}
		elseif($order_column==2)
		{
			$order_dt = " user.email_address ";
			$orders_v1 = " ORDER BY ".$order_dt.strtoupper($order_dir);
		}
		elseif($order_column==3)
		{
			$order_dt = " user_details.phone_number ";
			$orders_v1 = " ORDER BY ".$order_dt.strtoupper($order_dir);
		}
 		elseif($order_column==5)
		{
			$order_dt = " user.status ";
			$orders_v1 = " ORDER BY ".$order_dt.strtoupper($order_dir);
		}
		else
		{
			$orders_v1 = " ORDER BY user.user_code ASC";
		}
		
		
		$filter=array();
		if($user_code!='') {	$filter[] = " user.user_code LIKE '$user_code%' ";	}
		if($first_name!='') {	$filter[] = " user.first_name = '$first_name' ";	}
		if($emailid!='') {	$filter[] = " user.email_address LIKE '$emailid%' ";	}
		if($contacts!='') {	$filter[] = " user_details.phone_number LIKE '$contacts%' ";	}
 		 
		if($status!='') {	$filter[] = " user.status LIKE '$status%' ";	}
 		$filter_v ='';
		if(!empty($filter))
		{
		 $filter_v = " WHERE ".implode(" AND ",$filter);
		}
 		
		$query1 = "SELECT user.*,user_details.phone_number,user_credit_points.credit_points  FROM user 
		LEFT JOIN user_details ON user.user_id = user_details.user_id
	 LEFT JOIN user_credit_points ON user.user_id = user_credit_points.user_id
		 $filter_v $orders_v1  LIMIT $limit OFFSET $offset ";
	 
		$query = $this->db->query($query1);
		 
		if ( $query->num_rows() > 0 ) 
		{
			return $query->result();	
		}
		else
		{
			return false;
		}
	}	
	public function get_b2c_list_all($user_code,$first_name,$emailid,$contacts,$status)
	{
		$filter=array();
		if($user_code!='') {	$filter[] = " user.user_code LIKE '$user_code%' ";	}
		if($first_name!='') {	$filter[] = " user.first_name = '$first_name' ";	}
		if($emailid!='') {	$filter[] = " user.email_address LIKE '$emailid%' ";	}
		if($contacts!='') {	$filter[] = " user_details.phone_number LIKE '$contacts%' ";	}
 		 
		if($status!='') {	$filter[] = " user.status LIKE '$status%' ";	}
 		$filter_v ='';
		if(!empty($filter))
		{
		 $filter_v = " WHERE ".implode(" AND ",$filter);
		}
 	
		$query1 = "SELECT user.*,user_details.phone_number,user_credit_points.credit_points  FROM user 
		LEFT JOIN user_details ON user.user_id = user_details.user_id
	 LEFT JOIN user_credit_points ON user.user_id = user_credit_points.user_id $filter_v ORDER BY user.user_id ASC   ";
	 
		$query = $this->db->query($query1);
		 
		return $query->num_rows();
	}	
	public function get_b2c_details($user_id)
	{
		 
	 
		$this->db->select('user.*,user_details.*')->where('user.user_id', $user_id);
		$this->db->join('user_details','user_details.user_id = user.user_id','left');
 		$query = $this->db->get('user');
		 
		if ( $query->num_rows() > 0 ) 
		{
			return $query->row();	
		}
		else
		{
			return '';	
		}
	}
	public function get_b2c_details_code($user_id)
	{
		 
	 
		$this->db->select('user.*,user_details.*')->where('user.user_code', $user_id);
		$this->db->join('user_details','user_details.user_id = user.user_id','left');
 		$query = $this->db->get('user');
		 
		if ( $query->num_rows() > 0 ) 
		{
			return $query->row();	
		}
		else
		{
			return '';	
		}
	}
	
	public function get_b2c_details_all()
	{		 
	 
		$this->db->select('*');
  		$query = $this->db->get('user');
		 
		if ( $query->num_rows() > 0 ) 
		{
			return $query->result();	
		}
		else
		{
			return '';	
		}
	}
	
	public function get_credit_points_info_by_user( $user_code='' )
	{
		$query1 = "SELECT user_credit_points_transaction.`user_credit_points_value`, user_credit_points_transaction.`credit_points_charge_type`, user_credit_points_transaction.`transaction_mode`, user_credit_points_transaction.created_timestamp 
					FROM user_credit_points_transaction
					INNER JOIN user_transaction ON user_transaction.user_credit_points_transaction_id = user_credit_points_transaction.user_credit_points_transaction_id
					INNER JOIN user ON user.user_id = user_transaction.user_id
					WHERE user.user_code = '$user_code'
					ORDER BY user_credit_points_transaction.created_timestamp DESC
					LIMIT 5";
		$query = $this->db->query( $query1 );
		
		if( $query->num_rows() > 0 )
		{
			return $query->result();
		}
		else
		{
			return false;
		}
	}
	
	function get_total_generic_hits_by_user( $user_code='', $from_date='' )
	{
		$where = '';
		
		if( !empty($from_date) )
		{
			$where .= " AND DATE(user_generic_hits.created_timestamp) >= '$from_date' ";
		}
		
		$query1 = "SELECT SUM(user_generic_hits.`hits_count`) AS total 
					FROM `user_generic_hits` 
					JOIN user ON user.user_id = user_generic_hits.user_id 
					WHERE user.user_code = '$user_code' 
						AND user_generic_hits.`hits_type` = 'GENERIC'
						$where";
						
		$query = $this->db->query( $query1 );
		
		if( $query->num_rows() > 0 )
		{
			return $query->row()->total;
		}
		else
		{
			return false;
		}
	}
	
	function get_total_paid_hits_by_user( $user_code='', $from_date='' )
	{
		$where = '';
		
		if( !empty($from_date) )
		{
			$where .= " AND DATE(user_generic_hits.created_timestamp) >= '$from_date' ";
		}
		
		$query1 = "SELECT SUM(user_generic_hits.`hits_count`) AS total 
					FROM `user_generic_hits` 
					JOIN user ON user.user_id = user_generic_hits.user_id 
					WHERE user.user_code = '$user_code' 
						AND user_generic_hits.`hits_type` = 'ONETIMESEARCH'
						$where";
						
		$query = $this->db->query( $query1 );
		
		if( $query->num_rows() > 0 )
		{
			return $query->row()->total;
		}
		else
		{
			return false;
		}
	}
	
	function get_generic_hits_by_user( $user_code='', $from_date='' )
	{
		$where = '';
		
		if( !empty($from_date) )
		{
			$where .= " AND DATE(user_generic_hits.created_timestamp) >= '$from_date' ";
		}
		
		$query1 = "SELECT user_generic_hits.`hits_count`, DATE_FORMAT (user_generic_hits.created_timestamp, '%m/%d') AS datee
					FROM `user_generic_hits` 
					JOIN user ON user.user_id = user_generic_hits.user_id 
					WHERE user.user_code = '$user_code' 
						AND user_generic_hits.`hits_type` = 'GENERIC' 
						$where
					ORDER BY user_generic_hits.created_timestamp DESC 
					LIMIT 10";
					
		$query = $this->db->query( $query1 );
		
		if( $query->num_rows() > 0 )
		{
			return $query->result();
		}
		else
		{
			return false;
		}
	}
	
	function get_paid_hits_by_user( $user_code='', $from_date='' )
	{
		$where = '';
		
		if( !empty($from_date) )
		{
			$where .= " AND DATE(user_generic_hits.created_timestamp) >= '$from_date' ";
		}
		
		$query1 = "SELECT user_generic_hits.`hits_count`, DATE_FORMAT (user_generic_hits.created_timestamp, '%m/%d') AS datee
					FROM `user_generic_hits` 
					JOIN user ON user.user_id = user_generic_hits.user_id 
					WHERE user.user_code = '$user_code' 
						AND user_generic_hits.`hits_type` = 'ONETIMESEARCH'
						$where						
					ORDER BY user_generic_hits.created_timestamp DESC 
					LIMIT 10";
					
		$query = $this->db->query( $query1 );
		
		if( $query->num_rows() > 0 )
		{
			return $query->result();
		}
		else
		{
			return false;
		}
	}
	
	function get_all_credit_point_transaction($user_code='',$order='',$start='',$length='',$charge_type='',$credit_points='',$debit_points='',$balance_points='')
	{
		$order_column 	= 	$order['0']['column'];
		$order_dir 		= 	$order['0']['dir'];
		$order_by		=	'';
		
		if( $order_column == 0 )
		{
			$order_by	=	" ORDER BY user_credit_points_transaction.user_credit_points_transaction_id $order_dir ";
		}
		elseif( $order_column == 1 )
		{
			$order_by	=	" ORDER BY user_credit_points_transaction.`credit_points_charge_type` $order_dir ";
		}
		else
		{
			$order_by	=	" ORDER BY user_credit_points_transaction.created_timestamp DESC ";
		}
	#echo $order_by;
		$where = '';
		if( !empty($charge_type) )
		{
			$where	.=	" AND user_credit_points_transaction.credit_points_charge_type LIKE '$charge_type%' ";
		}
		if( !empty($credit_points) )
		{
			$where	.=	" AND user_credit_points_transaction.user_credit_points_value LIKE '$credit_points%' AND user_credit_points_transaction.transaction_mode = 'CREDIT' ";
		}
		if( !empty($debit_points) )
		{
			$where	.=	" AND user_credit_points_transaction.user_credit_points_value LIKE '$debit_points%' AND user_credit_points_transaction.transaction_mode = 'DEBIT' ";
		}
		if( !empty($balance_points) )
		{
			$where	.=	" AND user_credit_points_transaction.user_credit_points_value_final LIKE '$balance_points%' ";
		}
		
		$query1 = "SELECT user_credit_points_transaction.user_credit_points_transaction_id, user_credit_points_transaction.`user_credit_points_value`, user_credit_points_transaction.`credit_points_charge_type`, user_credit_points_transaction.`transaction_mode`, user_credit_points_transaction.created_timestamp, user_credit_points_transaction.user_credit_points_value_final
					FROM user_credit_points_transaction
					INNER JOIN user_transaction ON user_transaction.user_credit_points_transaction_id = user_credit_points_transaction.user_credit_points_transaction_id
					INNER JOIN user ON user.user_id = user_transaction.user_id
					WHERE user.user_code = '$user_code'
					$where
					$order_by
					LIMIT $start,$length";
		$query = $this->db->query( $query1 );
	
		if( $query->num_rows() > 0 )
		{
			return $query->result();
		}
		else
		{
			return false;
		}
	}
	
	function get_all_credit_point_transaction_count($user_code='',$charge_type='',$credit_points='',$debit_points='',$balance_points='')
	{
		$where = '';
		if( !empty($charge_type) )
		{
			$where	.=	" AND user_credit_points_transaction.credit_points_charge_type LIKE '$charge_type%' ";
		}
		if( !empty($credit_points) )
		{
			$where	.=	" AND user_credit_points_transaction.user_credit_points_value LIKE '$credit_points%' AND user_credit_points_transaction.transaction_mode = 'CREDIT' ";
		}
		if( !empty($debit_points) )
		{
			$where	.=	" AND user_credit_points_transaction.user_credit_points_value LIKE '$debit_points%' AND user_credit_points_transaction.transaction_mode = 'DEBIT' ";
		}
		if( !empty($balance_points) )
		{
			$where	.=	" AND user_credit_points_transaction.user_credit_points_value_final LIKE '$balance_points%' ";
		}
		
		$query1 = "SELECT user_credit_points_transaction.user_credit_points_transaction_id, user_credit_points_transaction.`user_credit_points_value`, user_credit_points_transaction.`credit_points_charge_type`, user_credit_points_transaction.`transaction_mode`, user_credit_points_transaction.created_timestamp, user_credit_points_transaction.user_credit_points_value_final
					FROM user_credit_points_transaction
					INNER JOIN user_transaction ON user_transaction.user_credit_points_transaction_id = user_credit_points_transaction.user_credit_points_transaction_id
					INNER JOIN user ON user.user_id = user_transaction.user_id
					WHERE user.user_code = '$user_code'
					$where";
		$query = $this->db->query( $query1 );
	
		if( $query->num_rows() > 0 )
		{
			return $query->num_rows();
		}
		else
		{
			return 0;
		}
	}
	
	function get_all_flights_registration( $user_code='',$status='',$order='',$start='',$length='',$flight_id,$depature_airport_code,$arrival_airport_code,$airline_no)
	{
		$where = '';
		if( !empty($status) )
		{
			$where	.=	" AND flight_registration.status = '$status' "; 
		}
		if( !empty($flight_id) )
		{
			$where	.=	" AND flight_registration.flight_id LIKE '$flight_id%' ";
		}
		if( !empty($depature_airport_code) )
		{
			$where	.=	" AND flight_registration.depature_airport_code LIKE '$depature_airport_code%' ";
		}
		if( !empty($arrival_airport_code) )
		{
			$where	.=	" AND flight_registration.arrival_airport_code LIKE '$arrival_airport_code%' ";
		}
		if( !empty($airline_no) )
		{
			$where	.=	" AND flight_registration.airline_no LIKE '$airline_no%' ";
		}
		
		$query1 = "SELECT flight_registration.`itinerary_id`, flight_registration.`flight_registration_id`, flight_registration.`flight_id`, flight_registration.`depature_airport_code`, flight_registration.`arrival_airport_code`, flight_registration.`airline_no`, flight_registration.`date_of_journey`, flight_registration.`depature_airport_city`, flight_registration.`arrival_airport_city`, flight_registration.`delay_index`, flight_registration.`delay_risk`
					FROM `flight_registration`
					JOIN user ON user.user_id = flight_registration.user_id
					WHERE user.user_code = '$user_code'
						$where
					LIMIT $start,$length";
		$query = $this->db->query( $query1 );
		
		if( $query->num_rows() > 0 )
		{
			return $query->result();
		}
		else
		{
			return false;
		}
	}
	
	function get_all_flights_registration_count( $user_code='',$status='',$flight_id,$depature_airport_code,$arrival_airport_code,$airline_no)
	{
		$where = '';
		if( !empty($status) )
		{
			$where	.=	" AND flight_registration.status = '$status' "; 
		}
		if( !empty($flight_id) )
		{
			$where	.=	" AND flight_registration.flight_id LIKE '$flight_id%' ";
		}
		if( !empty($depature_airport_code) )
		{
			$where	.=	" AND flight_registration.depature_airport_code LIKE '$depature_airport_code%' ";
		}
		if( !empty($arrival_airport_code) )
		{
			$where	.=	" AND flight_registration.arrival_airport_code LIKE '$arrival_airport_code%' ";
		}
		if( !empty($airline_no) )
		{
			$where	.=	" AND flight_registration.airline_no LIKE '$airline_no%' ";
		}
		
		$query1 = "SELECT flight_registration.`flight_registration_id`, flight_registration.`flight_id`, flight_registration.`depature_airport_code`, flight_registration.`arrival_airport_code`, flight_registration.`airline_no`, flight_registration.`date_of_journey`, flight_registration.`depature_airport_city`, flight_registration.`arrival_airport_city`, flight_registration.`delay_index`, flight_registration.`delay_risk`
					FROM `flight_registration`
					JOIN user ON user.user_id = flight_registration.user_id
					WHERE user.user_code = '$user_code'
						$where";
		$query = $this->db->query( $query1 );
		
		if( $query->num_rows() > 0 )
		{
			return $query->num_rows();
		}
		else
		{
			return 0;
		}
	}
	
	function get_flight_notification_history($flight_id='', $itinerary_id='', $current_status='')
	{
		if( !empty($current_status) )
		{
			$this->db->order_by( 'flight_notification_id', 'desc' );
			$this->db->limit(1);
		}
		
		$this->db->where('flight_id', $flight_id);
		$this->db->where('itinerary_id', $itinerary_id);
		$query 	=	$this->db->get('flight_notification');
	//echo $this->db->last_query();	
		if( $query->num_rows() > 0 )
		{
			return $query->result();
		}
		else
		{
			return false;
		}
	}	 
}
