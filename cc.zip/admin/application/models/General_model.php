<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class General_Model extends CI_Model { 
public function get_side_bar_menu($group='',$where='',$module='')
	{
		if($this->session->userdata('admin_id')!= ADMIN_ID)
		{
 			$sub_admin_id = $this->session->userdata('admin_id');
			$this->db->where('admin_role_details.admin_id',$sub_admin_id);
		}
		if($where!='')
		{
			
			$this->db->where('privilege_title',$where);
		}
		if($module!='')
		{
			$this->db->where('privilege_module',$module);
		}
		//$this->db->where('privilege_functions.menu_status','ACTIVE');
		$this->db->join('privilege_admin_roles', 'privilege_admin_roles.admin_role_id = admin_role_details.admin_roles_id','right');
		$this->db->join('privilege_actions', 'privilege_actions.privilege_id = privilege_admin_roles.privilege_id','right');
			$this->db->join('privilege_functions', 'privilege_functions.privilege_functions_id = privilege_actions.privilege_functions_id','left');
	 
		if($group!='')
		{
			$this->db->group_by($group);
		}
		$query = $this->db->get('admin_role_details');
		
		if ( $query->num_rows > 0 ) 
		{
			return $query->result();	
			
		}
		else
		{
			return '';	
		}
	}
	
	public function get_side_bar_menu_v1($user_type,$user_id,$group='',$where='',$module='')
	{
		 
		if($user_type=='EMPLOYEE')
		{
 			 
			$this->db->select('*');
			$this->db->where('employee_privileges.employee_id',$user_id); 
			$this->db->where('privileges.visibility_status','SHOW'); 
			$this->db->join('privileges', 'privileges.privileges_id = employee_privileges.privileges_id','left');
			$this->db->join('privileges_module', 'privileges.privileges_module_id = privileges_module.privileges_module_id','left');
			$this->db->order_by('privileges_module.priority','ASC');
			 
			$query2 = $this->db->get('employee_privileges');
		 
			if ( $query2->num_rows() > 0 ) 
			{
				$result_v = $query2->result();
 				return $result_v;	
			}
			else
			{
				return false;	
			}
		 
		
		}
		elseif($user_type=='ADMIN')
		{
 			 
			 
			$this->db->select('*'); 
			$this->db->where('privileges.visibility_status','SHOW'); 
 			$this->db->join('privileges_module', 'privileges.privileges_module_id = privileges_module.privileges_module_id','left');
			$this->db->order_by('privileges_module.priority','ASC');
			 
			$query2 = $this->db->get('privileges');
		 
			if ( $query2->num_rows() > 0 ) 
			{
				$result_v = $query2->result();
 				return $result_v;	
			}
			else
			{
				return false;	
			}
		
		 
		
		}
		
	 
	}
	public function get_side_bar_menu_v2($privileges_module_id)
	{
		
		if($this->session->userdata('employee_logged_in'))
		{
 			$employee_id = $this->session->userdata('employee_id');
			$query1 = "SELECT role_id FROM employee_role WHERE employee_id='$employee_id'";
			$query = $this->db->query($query1);
		
		if ( $query->num_rows() > 0 ) 
		{
			
			$result = $query->row();
			$role_id = $result->role_id;
			$this->db->select('*');
			$this->db->where('role_actions.role_id',$role_id); 
			$this->db->where('privileges_module.privileges_module_id',$privileges_module_id); 
 			$this->db->join('privileges', 'privileges.privileges_id = role_actions.privileges_id','left');
			$this->db->join('privileges_module', 'privileges.privileges_module_id = privileges_module.privileges_module_id','left');
 			$query2 = $this->db->get('role_actions');
		 
			if ( $query2->num_rows() > 0 ) 
			{
				$result_v = $query2->result();
				echo '<pre/>';
				print_r($result_v);exit;
 				return $result_v;	
			}
			else
			{
				return false;	
			}
		}
		else
		{
			return false;
		}
		
		}
	 
	}
	 public function get_country_all()
	{
		$query1 = "SELECT * FROM country ORDER BY country_name ASC";
		$query = $this->db->query($query1);
		 
		if ( $query->num_rows() > 0 ) 
		{
			return $query->result();	
		}
		else
		{
			return false;
		}
	}
	
	public function get_privileges_actions($user_type,$user_id,$cl_name)
	{
		if($user_type=='EMPLOYEE')
		{
 			 $query1 = "SELECT privileges.method_name FROM employee_privileges
			LEFT JOIN privileges ON employee_privileges.privileges_id = privileges.privileges_id
			 
			WHERE employee_privileges.employee_id='$user_id' AND privileges.controller_name='$cl_name'
			 ";  
			
			$query = $this->db->query($query1);
			// echo $this->db->last_query();exit;
			if ( $query->num_rows() > 0 ) 
			{
				 $result =  $query->result_array();	
				 $privileges_actions_do=array();
				 if($result)
				 {
					 for($i=0;$i<count($result);$i++)
					 {
						 $privileges_actions_do[] = $result[$i]['method_name'];
					 }
				 }
				 return $privileges_actions_do;
			}
			else
			{
				return array();
			}
		}
		else
		{
			 
 			 	
			$query1 = "SELECT privileges.method_name FROM privileges
			 
			WHERE  privileges.controller_name='$cl_name'
			 ";  
			
			$query = $this->db->query($query1);
			// echo $this->db->last_query();exit;
			if ( $query->num_rows() > 0 ) 
			{
				 $result =  $query->result_array();	
				 $privileges_actions_do=array();
				 if($result)
				 {
					 for($i=0;$i<count($result);$i++)
					 {
						 $privileges_actions_do[] = $result[$i]['method_name'];
					 }
				 }
				 return $privileges_actions_do;
				 
			}
			else
			{
				return array();
			}
		}
	}
	function get_class_name($number)
	{
		$random=0;
		if($number % 2 == 0)
		{
			$random=1;
		}
		
		
			switch ($random) {
				case "1":
					$data= "font-white bg-blue";
					break; 
				default:
					$data= "bg-default";
			} 
			return $data;
	}
	
	
	
	function get_date_time_diff( $datetime1='', $datetime2='' )
	{
		if( !empty($datetime1) )
		{
			$datetime1 = new DateTime( $datetime1 );
		}
		else
		{
			$datetime1 = new DateTime();
		}
		$datetime2 = new DateTime( $datetime2 );
		$interval = $datetime1->diff($datetime2);
		
		$year 	= $interval->format('%Y');
		$month 	= $interval->format('%M');
		$day 	= $interval->format('%D');
		$hour 	= $interval->format('%H');
		$minute = $interval->format('%I');
		
		$return_string = '';
		
		if( !empty($year) && $year != 00 )
		{
			$return_string	.=	$year.' years ';
		}
		elseif( !empty($month) && $month != 00 )
		{
			$return_string	.=	$month.' months ';
		}
		elseif( !empty($day)&& $day != 00 )
		{
			$return_string	.=	$day.' days ';
		}
		elseif( !empty($hour)&& $hour != 00 )
		{
			$return_string	.=	$hour.' hrs ';
		}
		elseif( !empty($minute)&& $minute != 00 )
		{
			$return_string	.=	$minute.' mins ';
		}
		
		$return_string .= ' ago';
		
		return $return_string;
	}
}
