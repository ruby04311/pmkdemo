<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Admin_Model extends CI_Model {
 	public function get_admin_details($user_id)
	{
		 
		$this->db->select('*')->from('admin_details')->where('admin_id', $user_id)->where('admin_status', 'ACTIVE');
		
		$query = $this->db->get();
		 
		if ( $query->num_rows() > 0 ) 
		{
			return $query->row();	
		}
		else
		{
			return '';	
		}
	}
	 public function get_last_login_record()
	{
		$query1 = "SELECT  created_timestamp FROM admin_login_tracking WHERE user_type='ADMIN' ORDER BY created_timestamp DESC LIMIT 1,1";
		$query = $this->db->query($query1);
		 
		if ( $query->num_rows() > 0 ) 
		{
			$a =  $query->row();	
			return $a->created_timestamp;
		}
		else
		{
			return false;
		}
	}
		public function get_employee_details($user_id)
	{
		 
		$this->db->select('employee.*,employee_details.*')->where('employee.employee_id', $user_id)->where('employee.status', 'ACTIVE');
		$this->db->join('employee_details','employee_details.employee_id = employee.employee_id','left');
 		$query = $this->db->get('employee');
		 
		if ( $query->num_rows() > 0 ) 
		{
			return $query->row();	
		}
		else
		{
			return '';	
		}
	}
		public function update_users($cond = array() , $data = array())
	{
		$this->db->where($cond);
		if($this->db->update('admin_details',$data))
		{
			return true;	
		}
		return false;
		
	}
		public function update_employee_users($cond = array() , $data = array())
	{
		$this->db->where($cond);
		if($this->db->update('employee',$data))
		{
			return true;	
		}
		return false;
		
	}
	public function check_admin_password($admin_id, $password)
	{
  		$query1 = "SELECT * FROM admin_login WHERE password='$password' AND admin_id='$admin_id'";
		$query = $this->db->query($query1);
		 
		if ( $query->num_rows() > 0 ) 
		{
			return true;	
		}
		else
		{
			return false;
		}
	}	
	public function update_admin_password($admin_id, $password)
	{
 //	$query = "UPDATE admin_login SET password=crypt('$password', gen_salt('bf',8)) 
		$query = "UPDATE admin_login SET password='$password' 
		 WHERE  admin_id='$admin_id'";
	 
		if ($this->db->query($query)) 
		{
			return true;	
		}
		else
		{
			return false;
		}
	}	
}
