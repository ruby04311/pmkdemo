<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Hits_Model extends CI_Model {
 	
	public function get_user_generic_hits_count()
	{
		 
		
 		$query1 = "SELECT * FROM user_generic_hits_count ";
		$query = $this->db->query($query1);
		 
		if ( $query->num_rows() > 0 ) 
		{
			return $query->row();	
		}
		else
		{
			return false;
		}
	}	
	 
	public function update_generic_hits($val)
	{
		$query = "UPDATE user_generic_hits_count SET  total_hits='$val' 
			 WHERE  user_generic_hits_count_id='1'";
			 
			if($this->db->query($query))
			{
				return true;
			}
			else
			{
			return false;
			}
	}
}
