<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Credit_Points_Model extends CI_Model {
 	
	public function get_charges_details()
	{
	
 		$query1 = "SELECT * FROM user_credit_points_charges ";
		$query = $this->db->query($query1);
		 
		if ( $query->num_rows() > 0 ) 
		{
			return $query->result();	
		}
		else
		{
			return false;
		}
	}	
	public function update_charges($val,$type)
	{
		$query1 = "INSERT INTO user_credit_points_charges_history (charge_type,charge_value   ) VALUES
  ('$type','$val' );";
 		
		
		if ($this->db->query($query1)) 
		{
			$history_id = $this->db->insert_id();
			
			$query = "UPDATE user_credit_points_charges SET charge_value='$val', user_credit_points_charges_history_id = '$history_id'
			 WHERE  charge_type='$type'";
			$this->db->query($query);
			
			return true;	
		}
		else
		{
			return false;
		}
	}
	public function allot_to_user($user_id,$val)
	{
		$query2_cp = "INSERT INTO user_credit_points_transaction (credit_points_charge_type,user_credit_points_value,transaction_mode) VALUES
		  ('RECHARGE','$val','CREDIT');";
				if ($this->db->query($query2_cp))
				{
					$trans_id = $this->db->insert_id();
					$ipaddress  = CLIENT_ADDR;
					$query3_cp = "INSERT INTO user_transaction (user_id,user_credit_points_transaction_id,process_by,ip_address) VALUES
			  ('$user_id','$trans_id','ADMIN','$ipaddress');";
					$this->db->query($query3_cp);
				}
		
		$query1 = "SELECT credit_points FROM user_credit_points WHERE user_id='$user_id' ";
		$query = $this->db->query($query1);
		 
		if ( $query->num_rows() > 0 ) 
		{
			$res = $query->row();	
			$cp = $res->credit_points;
 		}
		else
		{
			$cp=0;
		}
		$cptotal = $cp+$val;
		$query4_cp = " UPDATE user_credit_points SET credit_points = '$cptotal' WHERE user_id= '$user_id' ;";
		$this->db->query($query4_cp);
		return true;
	}
	public function update_cp_value($val)
	{
		$query1 = "INSERT INTO user_credit_points_value_history (credit_points_value  ) VALUES
  ( '$val' );";
		 
		 
 		if ($this->db->query($query1)) 
		{
			$history_id = $this->db->insert_id();
			$query = "UPDATE user_credit_points_value SET credit_points_value='$val' , user_credit_points_value_history_id = '$history_id'
		 WHERE  user_credit_points_value_id='1'";
			$this->db->query($query);
			return true;	
		}
		else
		{
			return false;
		}
	}
	public function get_charges_history($type)
	{
		
 		$query1 = "SELECT * FROM user_credit_points_charges_history WHERE charge_type='$type' ORDER BY created_timestamp DESC ";
		$query = $this->db->query($query1);
		 
		if ( $query->num_rows() > 0 ) 
		{
			return $query->result();	
		}
		else
		{
			return false;
		}
	}
	public function get_points_value_history()
	{
		
 		$query1 = "SELECT * FROM user_credit_points_value_history  ORDER BY created_timestamp DESC ";
		$query = $this->db->query($query1);
		 
		if ( $query->num_rows() > 0 ) 
		{
			return $query->result();	
		}
		else
		{
			return false;
		}
	}
	
	public function get_charges_value_details()
	{
		
 		$query1 = "SELECT * FROM user_credit_points_value ";
		$query = $this->db->query($query1);
		 
		if ( $query->num_rows() > 0 ) 
		{
			return $query->row();	
		}
		else
		{
			return false;
		}
	}	
	
	public function get_credit_charges_status()
	{
		$query1 = "SELECT * FROM user_credit_points_charges";
		$query = $this->db->query($query1);
		
		if( $query->num_rows() > 0 )
		{
			return $query->result();
		}
		else
		{
			return false;
		}
	}
	
	public function update_charges_status($charge_type, $status)
	{
		$query1 = "UPDATE user_credit_points_charges SET status='$status' WHERE charge_type='$charge_type'";
		$query = $this->db->query($query1);
		
		if( $this->db->affected_rows() )
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
}
