<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Notification_Model extends CI_Model {
	public function store_overlay_message($notification_message_code,$user_type,$user_id,$user_name,$user_pic,$user,$message,$overlay_subject,$attachurl='')
	{
		$notification_alert_v=array();
		$userlist = explode(",",$user);
	 
		for($i=0;$i<count($userlist);$i++)
		{
			$bc = explode("|",$userlist[$i]);
			$user_type_v = $bc[1];
			$user_id_v = $bc[0];
			
			$user_info_f = $this->security_model->get_user_info($user_id_v,$user_type_v);
			$email_to='';
			if($user_info_f)
			{
			 $email_to = $user_info_f['user_email'];
			}
			 $paperclip='NO';
			if($attachurl!='')
			{
				$paperclip='YES';
			}
			$last_update_time = date("Y-m-d H:i:s");
			
			$query = "INSERT INTO notification_message (notification_message_code, user_type, user_id,status,subject,last_update_time,from_user_id,from_user_type,from_user_name,from_user_picture,other_user_list,paperclip) VALUES
	  ('$notification_message_code','$user_type_v','$user_id_v','OPEN','$overlay_subject','$last_update_time','$user_id','$user_type','$user_name','$user_pic','$user','$paperclip'); ";
			$this->db->query($query);

			///////////////////////NOTIFICATION////////////////////////////
						 
						 $url=WEB_URL.'/messages/view/'.$notification_message_code;
 						$title='Message';
						$icon = 'icon-bubbles';
						 $notification_alert=array();
						$notification_alert['notification'] = 'active';
						$notification_alert['ntfy_count'] = '999';
						$notification_alert['ntfy_count_other'] ='999';
						$notification_alert['ntfy_url'] =$url;
						$notification_alert['ntfy_pic'] =$user_pic;
						$notification_alert['ntfy_title'] =$user_name;
						$notification_alert['ntfy_time'] ='Now';
						$notification_alert['ntfy_msg'] =$overlay_subject;
						$notification_alert['ntfy_from_user'] =$user_id;
						$notification_alert['ntfy_user'] =$user_id_v;
						$notification_alert_v[]=$notification_alert;
						 
			///////////////////////NOTIFICATION////////////////////////////
		$this->email_model->send_message_to_user($overlay_subject,$message,$url,$user_pic,$user_name,$email_to);		
			 
		}
 
$message = $this->db->escape_str($message); 
		$query2 = "INSERT INTO notification_message_history (notification_message_code, from_usertype, from_userid,to_userlist,message
		,attachment_url,from_user_picture,from_user_name) VALUES
  ('$notification_message_code','$user_type','$user_id','$user','$message','$attachurl','$user_pic','$user_name'); ";
  		$this->db->query($query2);
  		return $notification_alert_v;
	
	}
	public function store_overlay_message_reply($code,$user_type,$user_id,$username,$userpic,$message,$url='')
	{
	 
		$user='';
		$message = $this->db->escape_str($message); 
		$query2 = "INSERT INTO notification_message_history (notification_message_code, from_usertype, from_userid,to_userlist,message
		,attachment_url,from_user_picture,from_user_name) VALUES
  ('$code','$user_type','$user_id','$user','$message','$url','$userpic','$username'); ";
  		$this->db->query($query2);
  		 
	
	}
 	 public function store_notification($user_type,$user_id,$user_name,$user_pic,$message,$url,$to_user_type,$to_user_id,$title,$icon)
	{
		$query='';
	 if($to_user_type == 'ALL')
	 {
		/* $to_user_type11 = 'ADMIN';
		 $to_user_id11 = 1;
		 $query .= "INSERT INTO notification (from_user_type, from_user_id, titile,picture,message,url,to_user_type,to_user_id  ) VALUES
  ('$user_type','$user_id','$user_titile','$user_pic','$message','$url','$to_user_type11','$to_user_id11'); ";
		*/	
		if($user_type=='EMPLOYEE')
		{
		 $querye1 = "SELECT * FROM employee WHERE employee_id!='$user_id'  "; 
		 $to_user_type11 = 'ADMIN';
		 $to_user_id11 = 1;
		 $message = $this->db->escape_str($message); 
		 $query = "INSERT INTO notification (from_user_type, from_user_id, name,picture,message,url,to_user_type,to_user_id,title,faicon) VALUES
  ('$user_type','$user_id','$user_name','$user_pic','$message','$url','$to_user_type11','$to_user_id11','$title','$icon'); ";
    $this->db->query($query);
		}
		else
		{
			$querye1 = "SELECT * FROM employee  "; 
		}
	 
		$querye = $this->db->query($querye1);
		 
		if ( $querye->num_rows() > 0 ) 
		{
			$resultasa = $querye->result();	
			for($i=0;$i<count($resultasa);$i++)
			{
				$to_user_type1 = 'EMPLOYEE';
				$to_user_id1 = $resultasa[$i]->employee_id;
				$message = $this->db->escape_str($message); 
			$query = "INSERT INTO notification (from_user_type, from_user_id, name,picture,message,url,to_user_type,to_user_id,title,faicon) VALUES
  ('$user_type','$user_id','$user_name','$user_pic','$message','$url','$to_user_type1','$to_user_id1','$title','$icon'); ";
    $this->db->query($query);
			}
		}
		else
		{
			 
		}
	 }
  	else
	{
		$message = $this->db->escape_str($message); 
		$query = "INSERT INTO notification (from_user_type, from_user_id, name,picture,message,url,to_user_type,to_user_id,title,faicon) VALUES
  ('$user_type','$user_id','$user_name','$user_pic','$message','$url','$to_user_type','$to_user_id','$title','$icon'); ";
  $this->db->query($query);
	}
 
 		 
			$query1 = "SELECT * FROM notification WHERE   to_user_id='$user_id' AND to_user_type='$user_type'    AND status='NONE' ORDER BY created_timestamp DESC  ";
			$query11 = $this->db->query($query1);
			
			$query14 = "SELECT * FROM notification WHERE    to_user_id='$user_id' AND to_user_type='$user_type'    AND status='NONE' ORDER BY created_timestamp DESC  ";
			$query114 = $this->db->query($query14);
			
			return array("me"=>$query11->num_rows(),'other'=>$query114->num_rows());	
	 
	}	
	public function get_notification($usertype,$id)
	{
		 
 		$query1 = "SELECT * FROM notification WHERE   to_user_id='$id' AND to_user_type='$usertype'   AND status='NONE' ORDER BY created_timestamp DESC  ";
		$query2 = "SELECT * FROM notification WHERE   to_user_id='$id' AND to_user_type='$usertype'  ORDER BY created_timestamp DESC  LIMIT 5  ";
		$query11 = $this->db->query($query1);
	    $query22 = $this->db->query($query2);
		
		$data['new_data_noti_count'] =  $query11->num_rows();
		$data['all_data_noti_count'] =  $query22->num_rows();
		 $data['all_data_noti']='';
		 if($query22->num_rows() > 0)
		 {
			 $data['all_data_noti']  = $query22->result();
		 }
		 return $data;
	}
	public function get_notification_id($id)
	{
		 
 		$query1 = "SELECT * FROM send_message_to_support WHERE  send_message_to_support_id='$id'    ";
		 
		$query11 = $this->db->query($query1);
	  
 
		 if($query11->num_rows() > 0)
		 {
			return $query11->row();
		 }
		 else
		 {
		 return false;
		 }
	}
	public function get_messages($usertype,$id)
	{
		 
 		$query1 = "SELECT * FROM notification_message WHERE  user_id='$id' AND user_type='$usertype'   AND visiblity='NONE' ORDER BY created_timestamp DESC  ";
	
		$query2 = "SELECT notification_message.notification_message_code,
		notification_message.created_timestamp as n_created_timestamp, 
		notification_message.last_update_time , 
		notification_message.visiblity,notification_message.subject,
		notification_message.status,
		notification_message_history.* FROM notification_message 
		 
		 LEFT JOIN notification_message_history ON notification_message.notification_message_code =notification_message_history.notification_message_code
		
		WHERE  notification_message.user_id='$id' AND notification_message.user_type='$usertype'  ORDER BY  notification_message_history.created_timestamp DESC  LIMIT 5  ";
		$query11 = $this->db->query($query1);
	    $query22 = $this->db->query($query2);
		
		$data['new_data_noti_count'] =  $query11->num_rows();
		$data['all_data_noti_count'] =  $query22->num_rows();
		 $data['all_data_noti']='';
		 if($query22->num_rows() > 0)
		 {
			 $data['all_data_noti']  = $query22->result();
		 }
		 return $data;
	}
	public function get_notification_all($usertype,$id,$offset=0)
	{
		  
		 
 	 	$query2 = "SELECT notification.*  FROM notification
 	  WHERE   notification.to_user_id='$id' AND notification.to_user_type='$usertype' ORDER BY created_timestamp DESC    LIMIT 10 OFFSET $offset";
	    $query22 = $this->db->query($query2);
		
	 
		 
		 if($query22->num_rows() > 0)
		 {
			return $query22->result();
		 }
		 else
		 {
		 return false;
		 }
	}
	public function get_message_all($usertype,$id,$search_text='',$offset=0)
	{
		  $filter='';
		 if($search_text!='')
		 {
			$filter=" AND (from_user_name LIKE '%$search_text%' OR subject LIKE '%$search_text%' )"; 
		 }
 	 	$query2 = "SELECT * FROM notification_message WHERE 
		notification_message.user_id='$id' 
		AND user_type='$usertype' $filter ORDER BY created_timestamp DESC
		 LIMIT 10 OFFSET $offset";
		// echo $query2;exit; 
		//echo $query2;exit; ORDER BY created_timestamp DESC
	    $query22 = $this->db->query($query2);
		
		
		$query2_v = "SELECT * FROM notification_message WHERE 
		notification_message.user_id='$id' 
		AND user_type='$usertype' $filter";
	    $query22_v = $this->db->query($query2_v);
		
	  	 
		 if($query22->num_rows() > 0)
		 {
			$result = $query22->result();
			return array('result'=>$result,'count_all'=>$query22_v->num_rows(),'offset'=>$offset);
		 }
		 else
		 {
		 return array('result'=>'','count_all'=>0,'offset'=>0);
		 }
	}
	public function get_message_all_inbox_count($usertype,$id)
	{
		  
  	 	$query2 = "SELECT   *  
		 FROM notification_message 
 		WHERE user_id='$id' AND user_type='$usertype' AND visiblity='NONE' ";
	    $query22 = $this->db->query($query2);
		return $query22->num_rows();
	}
	public function get_message_all_sent_count($usertype,$id)
	{
		  
  	 	$query2 = "SELECT   *  
		 FROM notification_message 
 		WHERE from_user_id='$id' AND from_user_type='$usertype' AND visiblity='NONE'  ";
	    $query22 = $this->db->query($query2);
		return $query22->num_rows();
	}
	public function get_message_all_sent($usertype,$id,$search_text='',$offset=0)
	{
		  
		 
 	 $filter='';
		 if($search_text!='')
		 {
			$filter=" AND (from_user_name LIKE '%$search_text%' OR subject LIKE '%$search_text%' )"; 
		 }
 	 	$query2 = "SELECT * FROM notification_message WHERE 
		notification_message.from_user_id='$id' 
		AND from_user_type='$usertype' $filter GROUP BY notification_message.notification_message_code,notification_message.notification_message_id  ORDER BY created_timestamp DESC
		 LIMIT 10 OFFSET $offset";
		// echo $query2;exit; 
		//echo $query2;exit; ORDER BY created_timestamp DESC
	    $query22 = $this->db->query($query2);
		
		
		$query2_v = "SELECT * FROM notification_message WHERE 
		notification_message.from_user_id='$id' 
		AND from_user_type='$usertype' $filter GROUP BY notification_message.notification_message_code,notification_message.notification_message_id "; 
	    $query22_v = $this->db->query($query2_v);
		
	  	 
		 if($query22->num_rows() > 0)
		 {
			$result = $query22->result();
			return array('result'=>$result,'count_all'=>$query22_v->num_rows(),'offset'=>$offset);
		 }
		 else
		 {
		 return array('result'=>'','count_all'=>0,'offset'=>0);
		 }
	}
	public function get_message_all_close($usertype,$id,$offset=0)
	{
		  
		 
 	 	$query2 = "SELECT   notification_message.*  
		 FROM notification_message 
		 	 
		WHERE notification_message.from_user_id='$id'  AND status='CLOSE' AND notification_message.from_user_type='$usertype'  ORDER BY notification_message.created_timestamp DESC    LIMIT 10 OFFSET $offset";
	    $query22 = $this->db->query($query2);
		
	 
		 
		 if($query22->num_rows() > 0)
		 {
			return $query22->result();
		 }
		 else
		 {
		 return false;
		 }
	}
	public function get_message_user_details($userid,$usertype)
	{
		 if($usertype=='ADMIN')
		 {
			 $query2 = "SELECT  admin_name as name, admin_profile_pic as pic   
		 FROM admin_details 
		 	 
		WHERE admin_id='$userid' ";
	    $query22 = $this->db->query($query2);
			  if($query22->num_rows() > 0)
			 {
				return $query22->row();
			 }
			 else
			 {
			 return false;
			 }
		 }
		 else
		 {
			  $query2 = "SELECT  first_name	 as name, profile_pic as pic   
		 FROM employee 
		 	 
		WHERE employee_id='$userid' ";
	    $query22 = $this->db->query($query2);
			  if($query22->num_rows() > 0)
			 {
				return $query22->row();
			 }
			 else
			 {
			 return false;
			 }
		 }
		 
 	 	
		
	 
		 
		
	}
	public function get_message_all_code($message_code)
	{
		  
		 
 	 	$query2 = "SELECT   notification_message.*  
		 FROM notification_message 
		 	 
		WHERE notification_message.notification_message_code='$message_code'  ORDER BY notification_message.created_timestamp DESC   ";
	    $query22 = $this->db->query($query2);
		
	 
		 
		 if($query22->num_rows() > 0)
		 {
			return $query22->row();
		 }
		 else
		 {
		 return false;
		 }
	}
	public function get_message_view_code($code)
	{
		  
		 
 	 	$query2 = "SELECT   notification_message_history.*  
		 FROM notification_message_history 
		 	 
		WHERE notification_message_history.notification_message_code='$code'     ORDER BY notification_message_history.created_timestamp DESC   ";
	    $query22 = $this->db->query($query2);
		
	 
		 
		 if($query22->num_rows() > 0)
		 {
			return $query22->result();
		 }
		 else
		 {
		 	return false;
		 }
	}
	public function close_message($usertype,$id,$code)
	{
		  
		 
 	 	$query2 = "SELECT * FROM notification_message WHERE   from_user_type='$usertype' AND from_user_id='$id' AND notification_message_code='$code' ";
	    $query22 = $this->db->query($query2);
  		 
		 if($query22->num_rows() > 0)
		 {
			 $query = "UPDATE notification_message SET status='CLOSE'  WHERE     notification_message_code='$code'";
 			 $this->db->query($query);
			  return true;
		 }
		 else
		 {
		 return false;
		 }
	}
	public function delete_message($usertype,$id,$code)
	{
		  
		 
 	 	$query2 = "SELECT * FROM notification_message WHERE   from_user_type='$usertype' AND from_user_id='$id' AND notification_message_code='$code' ";
	    $query22 = $this->db->query($query2);
  		 
		 if($query22->num_rows() > 0)
		 {
			 $query_c = "DELETE FROM notification_message WHERE notification_message_code='$code';";
			 $this->db->query($query_c);
		
			  $query_c1 = "DELETE FROM notification_message_history WHERE notification_message_code='$code';";
			 $this->db->query($query_c1);
			  return true;
		 }
		 else
		 {
		 return false;
		 }
	}
	public function close_message_check($usertype,$id,$code)
	{
		  
		 
 	 	$query2 = "SELECT * FROM notification_message WHERE   notification_message_code='$code'  AND status!='CLOSE' ";
	    $query22 = $this->db->query($query2);
  	 
		 if($query22->num_rows() > 0)
		 {
			 
 			  return true;
		 }
		 else
		 {  
		 	return false;
		 }
	}
	public function change_status_none($usertype,$id)
	{
		  
		 
 	 $query = "UPDATE notification SET status='READ'  WHERE  to_user_id='$id' AND  to_user_type='$usertype'";
	 
	 $this->db->query($query);
		 
	}
	public function update_message_visibilty($usertype,$id,$code)
	{
		  
		 
 	 $query = "UPDATE notification_message SET visiblity='READ'  WHERE  user_id='$id' AND  user_type='$usertype' AND  notification_message_code='$code'";
	 
	 $this->db->query($query);
		 
	}
	public function get_notification_list_all($usertype,$id)
	{
  	$query1 = "SELECT notification.*  FROM notification
 	  WHERE   notification.to_user_id='$id' AND notification.to_user_type='$usertype'  ORDER BY created_timestamp DESC  ";
	 
		$query = $this->db->query($query1);
		 
		return $query->num_rows();
	}	
	public function get_notification_list($usertype,$id,$orders,$offset='',$limit='')
	{
 
  	$query1 = "SELECT notification.*  FROM notification
 	  WHERE   notification.to_user_id='$id' AND notification.to_user_type='$usertype'  ORDER BY created_timestamp DESC  LIMIT $limit OFFSET $offset ";
	 
		$query = $this->db->query($query1);
		 
		if ( $query->num_rows() > 0 ) 
		{
			return $query->result();	
		}
		else
		{
			return false;
		}
	}	
}
