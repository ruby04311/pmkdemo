<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Security_Model extends CI_Model {
 	public function admin_ip_track($type,$user_type='',$user_id='',$user_name='',$user_pic='')
   	{
		$this->load->library('user_agent');
		if ($this->agent->is_browser())
		{
				$user_agent = $this->agent->browser().' '.$this->agent->version();
		}
		elseif ($this->agent->is_robot())
		{
				$user_agent = $this->agent->robot();
		}
		elseif ($this->agent->is_mobile())
		{
				$user_agent = $this->agent->mobile();
		}
		else
		{
				$user_agent = 'Unidentified User Agent';
		}
		$user_agent_final = $user_agent.'-'.$this->agent->platform(); 
		$data = array(
		//'admin_id' => ADMIN_ID,
		'ip_address' => CLIENT_ADDR,
		'browser_info' => $user_agent_final,
		
		'user_id' => $user_id,
		'user_type' => $user_type,
		'user_name' => $user_name,
		'user_pic' => $user_pic,
		
		'login_type' => $type,
		'user_agent_info' =>  $this->agent->agent_string()
		);
		$this->db->insert('admin_login_tracking', $data);
		return $this->db->insert_id();
   }
   public function store_send_message($fullname,$email,$msg)
   	{
		 $msg = $this->db->escape_str($msg);  
		$data = array(
 		'ip_address' => CLIENT_ADDR,
 		'from_name' => $fullname,
		'from_email' => $email,
		'message' => $msg 
		);
		$this->db->insert('send_message_to_support', $data);
		 return $this->db->insert_id();
   }
    public function check_admin_login($username,$password='')
   	{
	 
	 if($password!='')
	 {
		 $query = "SELECT admin_login.*, admin_details.* FROM admin_login LEFT JOIN admin_details ON admin_login.admin_id = admin_details.admin_id WHERE admin_login.user_name = '$username' AND admin_login.password = '$password'";
	 }
	 else
	 {
		 $query = "SELECT admin_login.*, admin_details.* FROM admin_login LEFT JOIN admin_details ON admin_login.admin_id = admin_details.admin_id WHERE admin_login.user_name = '$username' ";
	 }
	 
		$query = $this->db->query($query);
		 
		if ( $query->num_rows() > 0 ) 
		{
			$data['status']=1;
			$data['result']=$query->row();
			return $data;	
	    }
		else
		{
			$data['status']=0;
			$data['result']='';
			return $data;
		}
   }
   public function get_employee_id_name($employee_id,$user_type)
   {
	    $this->load->library('user_agent');
		if ($this->agent->is_browser())
		{
				$user_agent = $this->agent->browser().' '.$this->agent->version();
		}
		elseif ($this->agent->is_robot())
		{
				$user_agent = $this->agent->robot();
		}
		elseif ($this->agent->is_mobile())
		{
				$user_agent = $this->agent->mobile();
		}
		else
		{
				$user_agent = 'Unidentified User Agent';
		}
	 
		$user_agent_final = $user_agent.'-'.$this->agent->platform(); 
		$userurl= WEB_URL.'/'.$this->uri->uri_string();
		$data = array(
		//'admin_id' => ADMIN_ID,
		'ip_address' => CLIENT_ADDR,
		'browser_info' => $user_agent_final,
		
		'user_id' => $employee_id,
		'user_type' => $user_type,
		'user_pic'=>$this->user_pic,
 		'url' => $userurl,
 		'user_agent_info' =>  $this->agent->agent_string()
		);
		$this->db->insert('employee_tracking', $data);
		
	    $querys = "SELECT employee_id as user_id,first_name FROM employee WHERE employee_id!='$employee_id' order by first_name ";
 		$query = $this->db->query($querys);
		$data_v=array();
		
		if($user_type!='ADMIN')
		{
			$querys_v = "SELECT admin_id as user_id,admin_name as first_name FROM admin_details";
			$query_vv = $this->db->query($querys_v);
			$result2= $query_vv->result();
			for($i=0;$i<count($result2);$i++)
			{
				$data['user_name'] = $result2[$i]->first_name;
				$data['user_id'] = $result2[$i]->user_id;
				$data['user_type'] ='ADMIN';
				$data_v[] = $data;
			}
		}
		if ( $query->num_rows() > 0 ) 
		{
			 
		 	$result1= $query->result();
			for($i=0;$i<count($result1);$i++)
			{
				$data['user_name'] = $result1[$i]->first_name;
				$data['user_id'] = $result1[$i]->user_id;
				$data['user_type'] ='EMPLOYEE';
				$data_v[] = $data;
			}
			 
	    }
			return $data_v;
			 
   }
    public function get_user_info($user_id,$user_type)
   {
	    
		 
		if($user_type=='ADMIN')
		{
			$querys_v = "SELECT admin_email FROM admin_details WHERE admin_id='$user_id' ";
			$query_vv = $this->db->query($querys_v);
			if ( $query_vv->num_rows() > 0 ) 
			{
				$result = $query_vv->row();
				$data['user_email'] = $result->admin_email;
				return $data;
			}
			else
			{
				return false;
			}
			 
		}
		else
		{
			$querys_v = "SELECT email_address FROM employee WHERE employee_id='$user_id' ";
			$query_vv = $this->db->query($querys_v);
			if ( $query_vv->num_rows() > 0 ) 
			{
				$result = $query_vv->row();
				$data['user_email'] = $result->email_address;
				return $data;
			}
			else
			{
				return false;
			}
		}
	 
			 
   }
     public function get_user_info_v2($user_id,$user_type)
   {
	    
		 
		if($user_type=='ADMIN')
		{
			$querys_v = "SELECT agent_id FROM admin_details WHERE admin_id='$user_id' ";
			$query_vv = $this->db->query($querys_v);
			if ( $query_vv->num_rows() > 0 ) 
			{
				$result = $query_vv->row();
 				return $result->agent_id;
			}
			else
			{
				return false;
			}
			 
		}
		else
		{
			$querys_v = "SELECT agent_id FROM employee WHERE employee_id='$user_id' ";
			$query_vv = $this->db->query($querys_v);
			if ( $query_vv->num_rows() > 0 ) 
			{
				$result = $query_vv->row();
				 
				return $result->agent_id;
			}
			else
			{
				return false;
			}
		}
	 
			 
   }
    public function check_employee_login($username,$password='')
   	{
	 
	 if($password!='')
	 {
		 $query = "SELECT  *   FROM employee  WHERE  email_address = '$username' AND password = '$password'";
	 }
	 else
	 {
		 $query = "SELECT *  FROM employee   WHERE email_address = '$username' ";
	 }
	 
		$query = $this->db->query($query);
		 
		if ( $query->num_rows() > 0 ) 
		{
			$data['status']=1;
			$data['result']=$query->row();
			return $data;	
	    }
		else
		{
			$data['status']=0;
			$data['result']='';
			return $data;
		}
   }
    public function get_admin_details()
   	{

		if($this->session->userdata('admin_id'))
		{
		$admin_id =$this->session->userdata('admin_id');
		$this->db->select('*')->from('admin_details')->where('admin_id', $admin_id)->where('admin_status', 'ACTIVE');
		$query = $this->db->get();
	
    	if ( $query->num_rows() > 0 ) 
		{
				return $query->row();	
		}
		else
		{
			return '';	
		}
		}
		else
		{
			return '';	
		}
   }
   	public function check_admin_password($admin_id, $password)
	{
		
	
		$query1 = "SELECT * FROM admin_login WHERE password='$password' AND admin_id='$admin_id'";
		$query = $this->db->query($query1);
		 
		if ( $query->num_rows() > 0 ) 
		{
			return true;	
		}
		else
		{
			return false;
		}
	}	
	public function get_privileges_by_employee_id($employee_id,$controller_name,$function_name){
		 
		
		 
		 
		$this->db->where('employee_privileges.employee_id',$employee_id);
		$this->db->where('privileges.controller_name',$controller_name);
		if($controller_name!='cases')
		{
			$this->db->where('privileges.method_name',$function_name);
		}
		$this->db->join('privileges', 'privileges.privileges_id = employee_privileges.privileges_id','left'); 
		
		$query2 = $this->db->get('employee_privileges');
 
		if ( $query2->num_rows() > 0 ) 
		{
			return true;	
		}
		else
		{
			return false;	
		}
		 
		
	}
}
