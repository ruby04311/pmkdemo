<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Employee_Model extends CI_Model {
 	
	 
	public function get_employee_all()
	{
		 
 		$query1 = "SELECT * FROM employee LEFT JOIN employee_details ON employee.employee_id = employee_details.employee_id ORDER BY  employee.employee_id ASC "; 
		 
		
		$query = $this->db->query($query1);
		 
		if ( $query->num_rows() > 0 ) 
		{
			return $query->result();	
		}
		else
		{
			return false;
		}
	}	
	 public function get_privileges_id($id)
	{
  		$query = "SELECT * FROM privileges WHERE privileges_module_id='$id' AND status='ACTIVE'  ";
 		if ($query1=$this->db->query($query)) 
		{
			 
			return $query1->result();	
		}
		else
		{
				 
			return false;
		}
	}	
	public function get_module_all()
	{
  		$query = "SELECT * FROM privileges_module ORDER BY privileges_module_id
ASC   ";
 		if ($query1=$this->db->query($query)) 
		{
			 
			return $query1->result();	
		}
		else
		{
				 
			return false;
		}
	}
	 public function get_last_login_record($user_id)
	{
		 
		$query1 = "SELECT  created_timestamp FROM admin_login_tracking WHERE user_type='EMPLOYEE' AND user_id='$user_id' ORDER BY created_timestamp DESC LIMIT 1,1";
		$query = $this->db->query($query1);
		 
		if ( $query->num_rows() > 0 ) 
		{
			$a =  $query->row();	
			return $a->created_timestamp;
		}
		else
		{
			return false;
		}
	}
		public function get_employee_filter($offset='',$limit='')
	{
		 
 		$query1 = "SELECT employee_details.*,employee.* ,department.department_name FROM employee 
		LEFT JOIN employee_details ON employee.employee_id = employee_details.employee_id
  		LEFT JOIN department ON employee.department_id = department.department_id
		 ORDER BY  employee.employee_id ASC ";  
		
		$query = $this->db->query($query1);
		// echo $this->db->last_query();exit;
		if ( $query->num_rows() > 0 ) 
		{
			return $query->result();	
		}
		else
		{
			return false;
		}
	}	
	public function get_employee_all_count()
	{
		
 		$query1 = "SELECT employee.employee_id FROM employee LEFT JOIN employee_details ON employee.employee_id = employee_details.employee_id ORDER BY  employee.employee_id ASC ";
		$query = $this->db->query($query1);
		 
		return $query->num_rows();
	}	
		public function get_employee_list($orders,$offset='',$limit='',$emp_code,$agent_id,$department,$job_title,$username,$skype,$emailid,$contacts,$status)
	{
		 $order_column = $orders['0']['column'];
		$order_dir = $orders['0']['dir'];
		$orders_v1='';
		if($order_column==0)
		{
			$order_dt = " employee.employee_code ";
			$orders_v1 = " ORDER BY ".$order_dt.strtoupper($order_dir);
		}
		elseif($order_column==1)
		{
			$order_dt = " employee.agent_id ";
			$orders_v1 = " ORDER BY ".$order_dt.strtoupper($order_dir);
		}
		elseif($order_column==2)
		{
			$order_dt = " department.department_name ";
			$orders_v1 = " ORDER BY ".$order_dt.strtoupper($order_dir);
		}
		elseif($order_column==3)
		{
			$order_dt = " employee_details.job_title ";
			$orders_v1 = " ORDER BY ".$order_dt.strtoupper($order_dir);
		}
		elseif($order_column==4)
		{
			$order_dt = " employee.first_name ";
			$orders_v1 = " ORDER BY ".$order_dt.strtoupper($order_dir);
		}
		elseif($order_column==5)
		{
			$order_dt = " employee.email_address ";
			$orders_v1 = " ORDER BY ".$order_dt.strtoupper($order_dir);
		}
		elseif($order_column==6)
		{
			$order_dt = " employee_details.phone_number ";
			$orders_v1 = " ORDER BY ".$order_dt.strtoupper($order_dir);
		}
		elseif($order_column==7)
		{
			$order_dt = " employee_details.skype_id ";
			$orders_v1 = " ORDER BY ".$order_dt.strtoupper($order_dir);
		}
		elseif($order_column==8)
		{
			$order_dt = " employee.created_timestamp ";
			$orders_v1 = " ORDER BY ".$order_dt.strtoupper($order_dir);
		}
		elseif($order_column==9)
		{
			$order_dt = " employee.status ";
			$orders_v1 = " ORDER BY ".$order_dt.strtoupper($order_dir);
		}
		else
		{
			$orders_v1 = " ORDER BY employee.employee_code ASC";
		}
		
		
		$filter=array();
		if($emp_code!='') {	$filter[] = " employee.employee_code LIKE '$emp_code%' ";	}
		if($agent_id!='') {	$filter[] = " employee.agent_id = '$agent_id' ";	}
		if($department!='') {	$filter[] = " department.department_name LIKE '$department%' ";	}
		if($job_title!='') {	$filter[] = " employee_details.job_title LIKE '$job_title%' ";	}
 		if($username!='') {	$filter[] = " employee.first_name LIKE '$username%' ";	}
		if($skype!='') {	$filter[] = " employee_details.skype_id LIKE '$skype%' ";	}
		if($emailid!='') {	$filter[] = " employee.email_address LIKE '$emailid%' ";	}
		if($contacts!='') {	$filter[] = " employee_details.phone_number LIKE '$contacts%' ";	}
		if($status!='') {	$filter[] = " employee.status LIKE '$status%' ";	}
 		$filter_v ='';
		if(!empty($filter))
		{
		 $filter_v = " WHERE ".implode(" AND ",$filter);
		}
 		
		$query1 = "SELECT employee_details.*,employee.*,department.department_name FROM employee 
		LEFT JOIN employee_details ON employee.employee_id = employee_details.employee_id
	 
		LEFT JOIN department ON employee.department_id = department.department_id $filter_v $orders_v1  LIMIT $limit OFFSET $offset ";
	 
		$query = $this->db->query($query1);
		 
		if ( $query->num_rows() > 0 ) 
		{
			return $query->result();	
		}
		else
		{
			return false;
		}
	}	
	public function get_employee_list_all($emp_code,$agent_id,$department,$job_title,$username,$skype,$emailid,$contacts,$status)
	{
		$filter=array();
		if($emp_code!='') {	$filter[] = " employee.employee_code LIKE '$emp_code%' ";	}
		if($agent_id!='') {	$filter[] = " employee.agent_id = '$agent_id' ";	}
		if($department!='') {	$filter[] = " department.department_name LIKE '$department%' ";	}
		if($job_title!='') {	$filter[] = " employee_details.job_title LIKE '$job_title%' ";	}
 		if($username!='') {	$filter[] = " employee.first_name LIKE '$username%' ";	}
		if($skype!='') {	$filter[] = " employee_details.skype_id LIKE '$skype%' ";	}
		if($emailid!='') {	$filter[] = " employee.email_address LIKE '$emailid%' ";	}
		if($contacts!='') {	$filter[] = " employee_details.phone_number LIKE '$contacts%' ";	}
		if($status!='') {	$filter[] = " employee.status LIKE '$status%' ";	}
 		$filter_v ='';
		if(!empty($filter))
		{
		 $filter_v = " WHERE ".implode(" AND ",$filter);
		}
 		
 	
		$query1 = "SELECT employee_details.*,employee.*,department.department_name FROM employee 
		LEFT JOIN employee_details ON employee.employee_id = employee_details.employee_id
 		LEFT JOIN department ON employee.department_id = department.department_id $filter_v ORDER BY employee.employee_id ASC   ";
	 
		$query = $this->db->query($query1);
		 
		return $query->num_rows();
	}	
	 
	public function get_department_all()
	{
		
 		$query1 = "SELECT  department.department_id,department.department_code,department.department_name FROM department  ORDER BY department_id ASC ";
		$query = $this->db->query($query1);
		 
		if ( $query->num_rows() > 0 ) 
		{
			return $query->result();	
		}
		else
		{
			return false;
		}
	}	
	
		public function get_employee_details($user_id)
	{
		 
	 
		$this->db->select('employee.*,employee_details.*')->where('employee.employee_id', $user_id)->where('employee.status', 'ACTIVE');
		$this->db->join('employee_details','employee_details.employee_id = employee.employee_id','left');
 		$query = $this->db->get('employee');
		 
		if ( $query->num_rows() > 0 ) 
		{
			return $query->row();	
		}
		else
		{
			return '';	
		}
	}
	public function add_employee($emp_code_id,$first_name,$last_name,$email_address,$job_title,$phone_number,$skype_id,$note_info,$department_id,$privileges,$profile_pic,$password,$agent_id)
	{
  		$query = "INSERT INTO employee (agent_id,employee_code,email_address,first_name,last_name,status,profile_pic,department_id,password  ) VALUES
  ('$agent_id','$emp_code_id','$email_address','$first_name','$last_name','ACTIVE','$profile_pic',$department_id,'$password');";
 		if ($this->db->query($query)) 
		{
			$employee_id = $this->db->insert_id();
			 $job_title = $this->db->escape_str($job_title); 
			 $note_info = $this->db->escape_str($note_info); 
			$query1 = "INSERT INTO employee_details (employee_id,job_title,note_info,phone_number,skype_id  ) VALUES
		  ('$employee_id','$job_title','$note_info' ,'$phone_number','$skype_id');";
				if ($this->db->query($query1)) 
				{
					
					
		 $query_c = "DELETE FROM employee_privileges WHERE employee_id='$employee_id';";
		$this->db->query($query_c);
		if(!empty($privileges))
		{
		foreach($privileges as $row=>$value)
		{
			$query = "INSERT INTO employee_privileges (employee_id,privileges_id   ) VALUES
  ('$employee_id','$value' );";
			$this->db->query($query);
		}
		}
					
					 
					
					
					
					return $employee_id;	
				}
				else
				{
					return false;
				}
		}
		else
		{
			return false;
		}
	}	
	public function update_employee($emp_id,$first_name,$last_name,$job_title,$phone_number,$skype_id,$note_info,$department_id,$profile_pic,$agent_id)
	{
		if($profile_pic!='')
		{
			$query = "UPDATE employee SET agent_id='$agent_id',first_name='$first_name',last_name='$last_name',department_id='$department_id',profile_pic='$profile_pic' 
			 WHERE  employee_id='$emp_id'";
		}
			else
			{
				
				$query = "UPDATE employee SET agent_id='$agent_id',first_name='$first_name',last_name='$last_name',department_id='$department_id' 
			 WHERE  employee_id='$emp_id'";
			}
			if ($this->db->query($query)) 
			{
				$query_v = "UPDATE employee_details SET job_title='$job_title',phone_number='$phone_number',skype_id='$skype_id',note_info='$note_info' 
			 WHERE  employee_id='$emp_id'";
				$this->db->query($query_v);
				return true;	
			}
			else
			{
				return false;
			}
		
	}
	public function update_employee_data($emp_id,$first_name,$last_name,$skype_id,$phone_number,$note_info)
	{
		 
				
				$query = "UPDATE employee SET first_name='$first_name',last_name='$last_name'
			 WHERE  employee_id='$emp_id'";
			 
			if ($this->db->query($query)) 
			{
				$query_v = "UPDATE employee_details SET  phone_number='$phone_number',skype_id='$skype_id',note_info='$note_info' 
			 WHERE  employee_id='$emp_id'";
				$this->db->query($query_v);
				return true;	
			}
			else
			{
				return false;
			}
		
	}
	public function update_employee_logo($emp_id,$image)
	{
		 
				
				$query = "UPDATE employee SET profile_pic='$image' 
			 WHERE  employee_id='$emp_id'";
			 
			if ($this->db->query($query)) 
			{
				 
				return true;	
			}
			else
			{
				return false;
			}
		
	}
	public function check_employee_password($user_id, $password)
	{
  		$query1 = "SELECT * FROM employee WHERE password='$password' AND employee_id='$user_id'";
		$query = $this->db->query($query1);
		 
		if ( $query->num_rows() > 0 ) 
		{
			return true;	
		}
		else
		{
			return false;
		}
	}	
	public function update_employee_password($user_id, $password)
	{
 
		$query = "UPDATE employee SET password='$password'	 WHERE  employee_id='$user_id'";
	 
		if ($this->db->query($query)) 
		{
			return true;	
		}
		else
		{
			return false;
		}
	}	
	public function update_users($cond = array() , $data = array())
	{
		$this->db->where($cond);
		if($this->db->update('admin_details',$data))
		{
			return true;	
		}
		return false;
		
	}
	public function max_empid(){
        $result = $this->db->select_max('employee_id')->get('employee')->row();
       $emp_code = $result->employee_id;
        if($emp_code == ''){
            $emp_code = 0;
        }
      $emp_code = $emp_code+1;
        
        return $emp_code;
    }
	
}
