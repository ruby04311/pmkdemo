<?php	if(! defined('BASEPATH')) exit('No direct script access allowed');

class Flight_Notification_Model extends CI_Model {
	
	public function __construct(){
		parent::__construct();
	}
	
	public function get_all_notification( $start='', $length='', $itinerary_id='', $flight_change='', $flight_number='', $origin_iata='', $destination_iata='', $delay_risk='', $delay_causes='', $flight_status='', $flight_id='', $flight_name='', $delay_index='', $created_date_from='', $created_date_to='', $departure_date_from='', $departure_date_to='', $arrival_date_from='', $arrival_date_to=''){
		
		if( !empty( $itinerary_id ) ){
			$this->db->like( 'itinerary_id', $itinerary_id, 'after' );
		}
		if( !empty( $flight_change ) ){
			$this->db->where( 'flight_change', $flight_change );
		}
		if( !empty( $flight_id ) ){
			$this->db->like( 'flight_id', $flight_id );
		}
		if( !empty( $flight_number ) ){
			$this->db->where( 'flight_number', $flight_number, 'after' );
		}
		if( !empty( $flight_name ) ){
			$this->db->like( 'flight_name', $flight_name, 'after' );
		}
		if( !empty( $origin_iata ) ){
			$this->db->like( 'origin_iata', $origin_iata );
		}
		if( !empty( $destination_iata ) ){
			$this->db->like( 'destination_iata', $destination_iata, 'after' );
		}
		if( !empty( $delay_index ) ){
			$this->db->where( 'delay_index', $delay_index );
		}
		if( !empty( $delay_risk ) ){
			$this->db->where( 'delay_risk', $delay_risk );
		}
		if( !empty( $delay_causes ) ){
			$this->db->like( 'delay_causes', $delay_causes, 'after' );
		}
		if( !empty( $flight_status ) ){
			$this->db->where( 'flight_status', $flight_status, 'after' );
		}
		if( !empty( $created_date_from ) || !empty( $created_date_to ) ){
			$this->db->where( "DATE(created_timestamp) BETWEEN '$created_date_from' AND '$created_date_to'", null, false );
		}
		if( !empty( $departure_date_from ) || !empty( $departure_date_to ) ){
			$this->db->where( "DATE(departure_scheduled) BETWEEN '$departure_date_from' AND '$departure_date_to'", null, false );
		}
		if( !empty( $arrival_date_from ) || !empty( $arrival_date_to ) ){
			$this->db->where( "DATE(arrival_scheduled) BETWEEN '$arrival_date_from' AND '$arrival_date_to'", null, false );
		}
		
		$this->db->order_by('created_timestamp', 'DESC');
		$this->db->limit( $length, $start );
		$query = $this->db->get('flight_notification');
	//echo $this->db->last_query();	
		if( $query->num_rows() > 0 ){
			return $query->result();
		}else{
			return false;
		}
	}
	
	public function get_all_notification_count($itinerary_id='', $flight_change='', $flight_number='', $origin_city='', $destination_city='', $delay_risk='', $delay_causes='', $flight_status='', $flight_id='', $flight_name='', $delay_index='', $created_date_from='', $created_date_to='', $departure_date_from='', $departure_date_to='', $arrival_date_from='', $arrival_date_to=''){

		if( !empty( $itinerary_id ) ){
			$this->db->like( 'itinerary_id', $itinerary_id, 'after' );
		}
		if( !empty( $flight_change ) ){
			$this->db->where( 'flight_change', $flight_change );
		}
		if( !empty( $flight_id ) ){
			$this->db->like( 'flight_id', $flight_id );
		}
		if( !empty( $flight_number ) ){
			$this->db->where( 'flight_number', $flight_number, 'after' );
		}
		if( !empty( $flight_name ) ){
			$this->db->like( 'flight_name', $flight_name, 'after' );
		}
		if( !empty( $origin_iata ) ){
			$this->db->like( 'origin_iata', $origin_iata );
		}
		if( !empty( $destination_iata ) ){
			$this->db->like( 'destination_iata', $destination_iata, 'after' );
		}
		if( !empty( $delay_index ) ){
			$this->db->where( 'delay_index', $delay_index );
		}
		if( !empty( $delay_risk ) ){
			$this->db->where( 'delay_risk', $delay_risk );
		}
		if( !empty( $delay_causes ) ){
			$this->db->like( 'delay_causes', $delay_causes, 'after' );
		}
		if( !empty( $flight_status ) ){
			$this->db->where( 'flight_status', $flight_status, 'after' );
		}
		if( !empty( $created_date_from ) || !empty( $created_date_to ) ){
			$this->db->where( "DATE(created_timestamp) BETWEEN '$created_date_from' AND '$created_date_to'", null, false );
		}
		if( !empty( $departure_date_from ) || !empty( $departure_date_to ) ){
			$this->db->where( "DATE(departure_scheduled) BETWEEN '$departure_date_from' AND '$departure_date_to'", null, false );
		}
		if( !empty( $arrival_date_from ) || !empty( $arrival_date_to ) ){
			$this->db->where( "DATE(arrival_scheduled) BETWEEN '$arrival_date_from' AND '$arrival_date_to'", null, false );
		}
		
		$query = $this->db->get('flight_notification');
		
		if( $query->num_rows() > 0 ){
			return $query->num_rows();
		}else{
			return false;
		}
	}
	
	function get_notification_details_by_id($flight_notification_id=''){
		if( !empty($flight_notification_id) ){
			$this->db->where('flight_notification_id', $flight_notification_id);
			$query = $this->db->get('flight_notification');
			
			if( $query->num_rows() > 0 ){
				return $query->result();
			}
		}
		
		return false;
	}
	
	function get_flight_id_autocomp($flight_id=''){
		if( !empty($flight_id) ){
			$this->db->select('DISTINCT(flight_id)');
			$this->db->like('flight_id', $flight_id, 'after');
			$query = $this->db->get('flight_notification');
			
			if( $query->num_rows() > 0 ){
				
				$result = $query->result();
				foreach($result as $value){
					$dataArr[] = $value->flight_id;
				}
				
				return $dataArr;
			}
		}
		
		return false;
	}
	
	function get_flight_number_autocomp($flight_number=''){
		if( !empty($flight_number) ){
			$this->db->select('DISTINCT(flight_number)');
			$this->db->like('flight_number', $flight_number);
			$query = $this->db->get('flight_notification');
			
			if( $query->num_rows() > 0 ){
				
				$result = $query->result();
				foreach($result as $value){
					$dataArr[] = $value->flight_number;
				}
				
				return $dataArr;
			}
		}
		
		return false;
	}
	
	function get_flight_name_autocomp($flight_name=''){
		if( !empty($flight_name) ){
			$this->db->select('DISTINCT(flight_name)');
			$this->db->like('flight_name', $flight_name);
			$query = $this->db->get('flight_notification');
			
			if( $query->num_rows() > 0 ){
				
				$result = $query->result();
				foreach($result as $value){
					$dataArr[] = $value->flight_name;
				}
				
				return $dataArr;
			}
		}
		
		return false;
	}
	
	function get_origin_iata_autocomp($origin_iata=''){
		if( !empty($origin_iata) ){
			$this->db->select('DISTINCT(origin_iata)');
			$this->db->like('origin_iata', $origin_iata);
			$query = $this->db->get('flight_notification');
			
			if( $query->num_rows() > 0 ){
				
				$result = $query->result();
				foreach($result as $value){
					$dataArr[] = $value->origin_iata;
				}
				
				return $dataArr;
			}
		}
		
		return false;
	}
	
	function get_destination_iata_autocomp($destination_iata=''){
		if( !empty($destination_iata) ){
			$this->db->select('DISTINCT(destination_iata)');
			$this->db->like('destination_iata', $destination_iata);
			$query = $this->db->get('flight_notification');
			
			if( $query->num_rows() > 0 ){
				
				$result = $query->result();
				foreach($result as $value){
					$dataArr[] = $value->destination_iata;
				}
				
				return $dataArr;
			}
		}
		
		return false;
	}
	
	function get_delay_index_autocomp($delay_index=''){
		if( !empty($delay_index) ){
			$this->db->select('DISTINCT(delay_index)');
			$this->db->like('delay_index', $delay_index);
			$query = $this->db->get('flight_notification');
			
			if( $query->num_rows() > 0 ){
				
				$result = $query->result();
				foreach($result as $value){
					$dataArr[] = $value->delay_index;
				}
				
				return $dataArr;
			}
		}
		
		return false;
	}
	
	function get_itinerary_id_autocomp($itinerary_id=''){
		if( !empty($itinerary_id) ){
			$this->db->select('DISTINCT(itinerary_id)');
			$this->db->like('itinerary_id', $itinerary_id);
			$query = $this->db->get('flight_notification');
			
			if( $query->num_rows() > 0 ){
				
				$result = $query->result();
				foreach($result as $value){
					$dataArr[] = $value->itinerary_id;
				}
				
				return $dataArr;
			}
		}
		
		return false;
	}
}