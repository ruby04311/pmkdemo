<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Support_Model extends CI_Model {
	
 	 
}
