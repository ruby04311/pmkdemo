<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Email_Model extends CI_Model {
 	 
   	public function get_email()
	{
		
 		$query1 = "SELECT * FROM email_access ";
		$query = $this->db->query($query1);
		 
		if ( $query->num_rows() > 0 ) 
		{
			return $query->row();	
		}
		else
		{
			return false;
		}
	}
	public function get_email_category()
	{
		
 		$query1 = "SELECT * FROM email_categories ORDER BY category_name ASC ";
		$query = $this->db->query($query1);
		 
		if ( $query->num_rows() > 0 ) 
		{
			return $query->result();	
		}
		else
		{
			return false;
		}
	}
	public function get_cron_email_indu($id)
	{
		
 		$query1 = "SELECT * FROM email_tracking  WHERE email_tracking_sub_id = '$id' ";
		$query = $this->db->query($query1);
		 
		if ( $query->num_rows() > 0 ) 
		{
			return $query->result();	
		}
		else
		{
			return false;
		}
	}
	public function get_cron_email_indu_v($id)
	{
		
 		$query1 = "SELECT * FROM email_tracking  WHERE status='SENT' AND email_tracking_sub_id = '$id' ";
		$query = $this->db->query($query1);
		 
		if ( $query->num_rows() > 0 ) 
		{
			return $query->result();	
		}
		else
		{
			return false;
		}
	}
	public function get_email_tracking_id($id)
	{
		
 		$query1 = "SELECT * FROM email_tracking  WHERE email_tracking_id = '$id' ";
		$query = $this->db->query($query1);
		 
		if ( $query->num_rows() > 0 ) 
		{
			return $query->row();	
		}
		else
		{
			return false;
		}
	}
	public function get_cron_email_id($id)
	{
		
 		$query1 = "SELECT * FROM lawfirm_email  WHERE lawfirm_email_id = '$id' ";
		$query = $this->db->query($query1);
		 
		if ( $query->num_rows() > 0 ) 
		{
			return $query->row();	
		}
		else
		{
			return false;
		}
	}
	  	public function get_language_data()
	{
		
 		$query1 = "SELECT * FROM language ORDER BY lang_name ASC";
		$query = $this->db->query($query1);
		 
		if ( $query->num_rows() > 0 ) 
		{
			return $query->result();	
		}
		else
		{
			return false;
		}
	}		
	  	public function get_atachment_limit()
	{
		
 		$query1 = "SELECT * FROM email_access";
		$query = $this->db->query($query1);
		 
		if ( $query->num_rows() > 0 ) 
		{
			$a= $query->row();	
			return $a->attachment_limit;
		}
		else
		{
			return 10;
		}
	}	
	public function update_limit_value($val)
	{
		$query = "UPDATE email_access SET attachment_limit='$val'  WHERE  email_access_id='1'";
 		if ($this->db->query($query)) 
		{
			return true;	
		}
		else
		{
			return false;
		}
	}
	public function update_email_settings($smtp, $port, $host_name, $username, $password)
	{
 		$query = "UPDATE email_access SET smtp='$smtp',port='$port',host='$host_name',username='$username',password='$password' 
		 WHERE  email_access_id='1'";
 		if ($this->db->query($query)) 
		{
			return true;	
		}
		else
		{
			return false;
		}
	}	
	public function update_email_template($id, $subject, $cat,$from_name, $from_address, $message, $bcc,$images_url)
	{
		 
		$message = $this->db->escape_str($message);
		$subject = $this->db->escape_str($subject);
  		$query = "UPDATE email_template SET subject='$subject',email_categories_id='$cat',email_from_name='$from_name',email_from='$from_address',message='$message',email_bcc='$bcc',attachments='$images_url' 
		 WHERE  email_template_id='$id'";
 		if ($this->db->query($query)) 
		{
			return true;	
		}
		else
		{
			return false;
		}
	}
	public function add_email_template($name,$type, $subject,$cat, $from_name, $from_address, $message, $bcc,$cc,$language_code,$images_url)
	{
			 
		if($type=='')
		{
			$name = strtoupper($name);
			$query45 = "SELECT * FROM email_template WHERE email_type='$name' ";
			$query35 = $this->db->query($query45);
			 
			if ( $query35->num_rows() > 0 ) 
			{
				return false;	
			}
			else
			{
 			 
		$message = $this->db->escape_str($message);
		$subject = $this->db->escape_str($subject);
							$query = "INSERT INTO email_template (email_categories_id,email_type,subject, message,email_from, email_from_name, status, email_bcc, email_cc,language_code,attachments ) VALUES
								  ('$cat','$name','$subject','$message','$from_address','$from_name','ACTIVE','$bcc','$cc','$language_code','$images_url');";
										if ($this->db->query($query)) 
										{
											return true;	
										}
										else
										{
											return false;
										}	
			}
			
		}
		else
		{
				 
			$message = $this->db->escape_str($message);
			$subject = $this->db->escape_str($subject); 
			$query = "INSERT INTO email_template (email_categories_id,email_type,subject, message,email_from, email_from_name, status, email_bcc, email_cc,language_code,attachments ) VALUES
	  ('$cat','$type','$subject','$message','$from_address','$from_name','ACTIVE','$bcc','$cc','$language_code','$images_url');";
			if ($this->db->query($query)) 
			{
				return true;	
			}
			else
			{
				return false;
			}	
		}
 		
	}
	public function view_template_id($id)
	{
		$query1 = "SELECT * FROM email_template WHERE email_template_id='$id'";
		$query = $this->db->query($query1);
		 
		if ( $query->num_rows() > 0 ) 
		{
			return $query->row();	
		}
		else
		{
			return false;
		}
	}
	public function view_template_type($id)
	{
		$query1 = "SELECT * FROM email_template WHERE email_type='$id'";
		$query = $this->db->query($query1);
		 
		if ( $query->num_rows() > 0 ) 
		{
			return $query->result();	
		}
		else
		{
			return false;
		}
	}
	
	public function change_template_status($id,$status)
	{
  		$query = "UPDATE email_template SET status='$status' 
		 WHERE  email_template_id='$id'";
 		if ($this->db->query($query)) 
		{
			return true;	
		}
		else
		{
			return false;
		}
	}	
	
	 public function get_email_template($email_type)
	{
 		$query = "SELECT * FROM email_template	 WHERE  email_type='$email_type' AND status='ACTIVE'";
 		if ($query = $this->db->query($query)) 
		{
			return $query->row();	
		}
		else
		{
			return false;
		}
	}	
	 
	 public function get_email_template_language($email_type,$lang)
	{
 		$query = "SELECT * FROM email_template	 WHERE  email_type='$email_type' AND language_code='$lang' AND status='ACTIVE'";
 		if ($querys = $this->db->query($query)) 
		{
			return $querys->row();	
		}
		else
		{
			$query1 = "SELECT * FROM email_template	 WHERE  email_type='$email_type' AND language_code='en' AND status='ACTIVE'";
			if ($querys1 = $this->db->query($query1)) 
			{
				return $querys1->row();	
			}
			else
			{
				return false;
			}
		}
	}	
	 public function get_email_template_all()
	{
 		$query = "SELECT * FROM email_template	";
 		if ($query = $this->db->query($query)) 
		{
			return $query->result();	
		}
		else
		{
			return false;
		}
	}
	 public function get_email_template_all_group()
	{
 		$query = "SELECT email_type FROM email_template	GROUP BY email_type";
 		if ($query = $this->db->query($query)) 
		{
			return $query->result();	
		}
		else
		{
			return false;
		}
	}	
	 public function get_email_variables()
	{
 		$query = "SELECT * FROM email_variables ";
 		if ($query = $this->db->query($query)) 
		{
			return $query->result();	
		}
		else
		{
			return false;
		}
	}	
    public function send_test_email($email_to){
     $email_type = 'TEST_EMAIL';
	 	$template = $this->get_email_template($email_type);
		 
 		$message =  str_replace("[[[##LOGO_PATH##]]]",ASSETS.'/layouts/layout/img/logo.png', $template->message);
		
		$subject = $template->subject;
		$email_from = $template->email_from;
		$email_from_name = $template->email_from_name;
		
		return $this->send_email_do($subject,$email_from,$email_from_name,$email_to,$message,$email_type);
		
	}
	 public function send_password_to_new_user($first_name,$email_to,$profile_pic,$password){
		 $email_type = 'SEND_PASSWORD_TO_USER';
	 	$template = $this->get_email_template($email_type);
		 
			 
 		$message =  str_replace("{siteurl}",WEB_FRONT_URL.'/login', $template->message);
		 $message =  str_replace("{user.firstname}",$first_name, $message);
		 $message =  str_replace("{user.profile_image}",$profile_pic,$message);
		 $message =  str_replace("{user.password}",$password, $message);
		
		$subject = $template->subject;
		$email_from = $template->email_from;
		$email_from_name = $template->email_from_name;
		
		return $this->send_email_do($subject,$email_from,$email_from_name,$email_to,$message,$email_type);
		
	}
	 public function send_forget_password($first_name,$email_to,$profile_pic,$password){
		 $email_type = 'SEND_PASSWORD_TO_USER';
	 	$template = $this->get_email_template($email_type);
		 
			 
 		$message =  str_replace("@web_url",WEB_URL, $template->message);
		 $message =  str_replace("@username",$first_name, $message);
		 $message =  str_replace("@user_image",FILE_PATH.$profile_pic,$message);
		 $message =  str_replace("@user_password",$password, $message);
		
		$subject = $template->subject;
		$email_from = $template->email_from;
		$email_from_name = $template->email_from_name;
		
		return $this->send_email_do($subject,$email_from,$email_from_name,$email_to,$message,$email_type);
		
	}
	 public function send_message_to_user($message_subject,$message_msg,$message_url,$from_user_image,$from_user_name,$email_to){
		 $email_type = 'SEND_MESSAGE_TO_USERS';
	 	$template = $this->get_email_template($email_type);
		 
 
 		$message =  str_replace("@message_subject",$message_subject, $template->message);
		
		 $message =  str_replace("@message_msg",$message_msg, $message);
		 $message =  str_replace("@message_url",$message_url, $message);
		 $message =  str_replace("@from_user_image",$from_user_image, $message);
		 $message =  str_replace("@from_user_name",$from_user_name, $message);
		 
		  
		
		$subject = $template->subject;
		$email_from = $template->email_from;
		$email_from_name = $template->email_from_name;
		$email_cc = $template->email_cc;
		$email_bcc = $template->email_bcc;
	 
		return $this->send_email_do($subject,$email_from,$email_from_name,$email_to,$message,$email_type,$email_cc,$email_bcc);
		
	}
	function GeraHash($qtd){ 
//Under the string $Caracteres you write all the characters you want to be used to randomly generate the code. 
$Caracteres = 'ABCDEFGHIJKLMOPQRSTUVXWYZ0123456789'; 
$QuantidadeCaracteres = strlen($Caracteres); 
$QuantidadeCaracteres--; 

$Hash=NULL; 
    for($x=1;$x<=$qtd;$x++){ 
        $Posicao = rand(0,$QuantidadeCaracteres); 
        $Hash .= substr($Caracteres,$Posicao,1); 
    } 

return $Hash; 
} 
	function get_email_counts()
	{
		$query = "select  
 COUNT(*) as overall,
SUM(CASE WHEN status = 'SENT' THEN 1 ELSE 0 END) success,
SUM(CASE WHEN status = 'FAILURE' THEN 1 ELSE 0 END) failure 
from email_tracking";
if ($querya = $this->db->query($query)) 
		{
			return $querya->row();	
		}
		else
		{
			return '';
		}

	}
	function send_email_do($subject,$email_from,$email_from_name,$email_to,$message,$email_type,$bcc_address='',$cc_address='')
	{
		 		
	    $data = $this->db->get('email_access')->row();
         $config = Array(
            'protocol' => $data->smtp,
            'smtp_host' => $data->host,
            'smtp_port' => $data->port,
            'smtp_user' => $data->username,
            'smtp_pass' => $data->password,
            'mailtype' => 'html', 
			  'charset' => 'iso-8859-1',
            'wordwrap' => TRUE
        );
  
        $this->load->library('email', $config);

        $this->email->set_newline("\r\n");
        $this->email->to($email_to);
        //$this->email->to($user->user_email);
        $this->email->from($email_from, $email_from_name);
        $this->email->subject($subject);
		if($cc_address!='') {
	    $this->email->cc($cc_address); }
	    if($bcc_address!='') {
	    $this->email->bcc($bcc_address); }
        $this->email->message($message);
      
          if($this->email->send())
        {
			 
			$error_message='';
			 $message = $this->db->escape_str($message);
			 $subject = $this->db->escape_str($subject); 
			$this->db->query("INSERT INTO email_tracking (email_type,subject, message,from_address, to_address, bcc_address,error_message,status ) VALUES
  ('$email_type','$subject','$message','$email_from','$email_to','$bcc_address','$error_message','SENT');");
 		  return true;
        }
        else
        {

            $error_message=$this->email->print_debugger();
			$message = $this->db->escape_str($message);
			 $subject = $this->db->escape_str($subject); 	 
			$this->db->query("INSERT INTO email_tracking (email_type,subject, message,from_address, to_address, bcc_address,error_message,status ) VALUES
  ('$email_type','$subject','$message','$email_from','$email_to','$bcc_address','$error_message','FAILURE');");
  return false;
        }
          
	 
	}
	function send_email_do_cron($case_id, $subject, $email_from,$email_from_name,$email_to,$message,$email_type,$bcc_address='', $cc_address='' , $legacy_attachment = '', 
													    $attachment_url = '' )
	{
	    
	    $DB1 = $this->load->database('live', TRUE);		
	    $data = $this->db->get('email_access')->row();
         $config = Array(
            'protocol' => $data->smtp,
            'smtp_host' => $data->host,
            'smtp_port' => $data->port,
            'smtp_user' => $data->username,
            'smtp_pass' => $data->password,
            'mailtype' => 'html', 
			  'charset' => 'utf-8',
            'wordwrap' => TRUE
        );
  
        $this->load->library('email', $config);

        $this->email->set_newline("\r\n");
        $this->email->to($email_to);
        //$this->email->to($user->user_email);
        $this->email->from($email_from, $email_from_name);
        $this->email->subject($subject);

		if($cc_address!='') {

	    $this->email->cc($cc_address); }

	    if($bcc_address!='') {
	    $this->email->bcc($bcc_address); }
        $this->email->message($message);

	################ Attachements ###################
	$complete_atatchment_data = array();
	$attachment_tracking[] = array();
	$attachment_tracking_name[] = array();
	$exists_attachment_tracking[] = array();
	$exists_attachment_tracking_name[] = array();

	if($attachment_url!='') 
	{
		$complete_atatchment_data[] = $attachment_url;
		$this->email->attach($attachment_url); 
	}


	$case_id_vs = $case_id ;
	$atachment_limit = $this->get_atachment_limit();

	$document_type_v = $legacy_attachment;
	if($document_type_v!='')
	{
		$query4590s_ild = "SELECT   string_agg(doc_url, '|||SPLIT|||' ORDER BY modified_utc DESC) as cs_doc_url, 
string_agg(doc_name, '|||SPLIT|||' ORDER BY modified_utc DESC) as cs_doc_name, 
string_agg(doc_key, '|||SPLIT|||' ORDER BY modified_utc DESC) as cs_doc_key, 
 MAX(modified_utc) FROM case_documents WHERE case_id='$case_id_vs' AND doc_subtype_id IS NULL AND doc_type_id IN ($document_type_v)  
 UNION
 SELECT   string_agg(doc_url, '|||SPLIT|||' ORDER BY modified_utc DESC) as cs_doc_url, 
string_agg(doc_name, '|||SPLIT|||' ORDER BY modified_utc DESC) as cs_doc_name, 
string_agg(doc_key, '|||SPLIT|||' ORDER BY modified_utc DESC) as cs_doc_key, 
 MAX(modified_utc) FROM case_documents WHERE case_id='$case_id_vs'  AND doc_subtype_id IS NOT NULL AND doc_subtype_id IN ($document_type_v);";

  $query4590s =" select *  from case_documents WHERE case_id='$case_id_vs'";
		$query3590d = $DB1->query($query4590s);

		if ( $query3590d->num_rows() > 0 ) 
						{
							$query3590_v =  $query3590d->result();	
 							 $document_type_v_array = explode(",",$document_type_v);
							//http://localhost/claims/data-file/gdocs/322-test_document.txt
  							for($jk=0;$jk<count($query3590_v);$jk++)
							{
							 
								$elg='NOK';
								if($query3590_v[$jk]->doc_subtype_id!='')
								{
									if (in_array($query3590_v[$jk]->doc_subtype_id, $document_type_v_array)) {
										$elg='OK';
									}
								 
 								}
								else
								{
								if (in_array($query3590_v[$jk]->doc_type_id, $document_type_v_array)) {
											$elg='OK';
											
										}
										 
								}
								if($elg=='OK')
								{
								
 								$doc_name='';
								if($query3590_v[$jk]->doc_name!='')
								{
 										$doc_name = $query3590_v[$jk]->doc_name;
 								}
								$doc_url='';
								if($query3590_v[$jk]->doc_url!='')
								{
 										$doc_url = $query3590_v[$jk]->doc_url;
 								}
								$doc_key='';
								if($query3590_v[$jk]->doc_key!='')
								{
 										$doc_key = $query3590_v[$jk]->doc_key;
 								}
								 
 								if($jk < $atachment_limit)
								{
 									 
 									$doc_name_split = explode(".",$doc_name);
									if(count($doc_name_split) == 1)
									{
										 
										 
										if(isset($doc_key) && $doc_key!='')
										{
											$doc_name_v1_d = explode(".",$doc_key);
 											if(count($doc_name_v1_d) == 1)
											{
												//echo $query3590_v[$jk]->doc_name;exit;
												//custom name
												$s_g_file = $this->set_get_attachmentfile($doc_name,$doc_url);
												$doc_name = $s_g_file['doc_name'];
												$doc_url = $s_g_file['doc_url'];
												
												$missing_docs[] = array($doc_name,$doc_url);
												$attachment_tracking[] = $doc_url;
												$attachment_tracking_name[] = $doc_name;
												$complete_atatchment_data[] = $doc_url;
												$this->email->attach($doc_url,'attachment',$doc_name);
											}
											else
											{
												
											 	$doc_name_v2='';
												if(end($doc_name_v1_d) !='')
												{
													$doc_name_v2 = $doc_name.'.'.end($doc_name_v1_d);
													$s_g_file = $this->set_get_attachmentfile($doc_name_v2,$doc_url);
													$doc_name = $s_g_file['doc_name'];
													$doc_url = $s_g_file['doc_url'];
												}
												else
												{
													$s_g_file = $this->set_get_attachmentfile($doc_name,$doc_url);
													$doc_name = $s_g_file['doc_name'];
													$doc_url = $s_g_file['doc_url'];
													$missing_docs[] = array($doc_name,$doc_url);
												}
												
												$attachment_tracking[] = $doc_url;
												$attachment_tracking_name[] = $doc_name;
												$complete_atatchment_data[] = $doc_url;
 												$this->email->attach($doc_url,'attachment',$doc_name);
											}
										}
										else
										{
												$s_g_file = $this->set_get_attachmentfile($doc_name,$doc_url);
												$doc_name = $s_g_file['doc_name'];
												$doc_url = $s_g_file['doc_url'];
													
											$missing_docs[] = array($doc_name,$doc_url);
											$attachment_tracking[] = $doc_url;
											$attachment_tracking_name[] = $doc_name;
											$complete_atatchment_data[] = $doc_url;
											$this->email->attach($doc_url,'attachment',$doc_name);
										}
									}
									else
									{
										$s_g_file = $this->set_get_attachmentfile($doc_name,$doc_url);
												$doc_name = $s_g_file['doc_name'];
												$doc_url = $s_g_file['doc_url'];
												
										 $attachment_tracking[] = $doc_url;
										 $attachment_tracking_name[] = $doc_name;
										 $complete_atatchment_data[] = $doc_url;
										 $this->email->attach($doc_url,'attachment',$doc_name);
									}
 									 
									 
								}
								else
								{
									 $attachment_tracking[] = $doc_url;
									 $attachment_tracking_name[] = $doc_name;
									 $exists_attachment_tracking[] = $doc_url;
									 $exists_attachment_tracking_name[] = $doc_name;
								}
  							
							
								}
							}
 						}
		 
	}


	$document_content_msg='<br/><hr><br/>';
	if(!empty($attachment_tracking))
	{
	 $document_content_msg .='<strong>Link to document in attachment : </strong><br/>';
	 for($hj=0;$hj<count($attachment_tracking);$hj++)
	 {
		 $exists = '';
		 if (!in_array($attachment_tracking[$hj], $exists_attachment_tracking)) {
			$document_content_msg .=$attachment_tracking_name[$hj].' - <em><a href="'.$attachment_tracking[$hj].'" target="_blank" >'.$attachment_tracking[$hj].'</a></em> '.$exists.'<br/>';
		}
	
	 }
	  $document_content_msg .='<br/>';
	}
	if(!empty($exists_attachment_tracking))
	{
	 $document_content_msg .='<strong>Link to document due to exceed in Threshold size : </strong><br/>';
	 for($hj=0;$hj<count($exists_attachment_tracking);$hj++)
	 {
		$document_content_msg .=$exists_attachment_tracking_name[$hj].' - <em><a href="'.$exists_attachment_tracking[$hj].'" target="_blank" >'.$exists_attachment_tracking[$hj].'</a></em><br/>';
	 }
	  $document_content_msg .='<br/>';
	}
	if(!empty($missing_docs))
	{
	 $document_content_msg .='<strong>Link to document without extension in attachment :</strong><br/>';
	 for($hj=0;$hj<count($missing_docs);$hj++)
	 {
		 $document_content_msg .=$missing_docs[$hj][0].' : <a href="'.$missing_docs[$hj][1].'" target="_blank" >'.$missing_docs[$hj][1].'</a><br/>';
	 }
	  $document_content_msg .='<br/>';
	}

	$attachment_tracking_v='';
	if(!empty($complete_atatchment_data))
	{
		$attachment_tracking_v = implode("||||",$complete_atatchment_data);
	}
	$message = $message . $document_content_msg;
	#################################################
      
        if($this->email->send())
        {
			 
			 $error_message='';
			 $message = $this->db->escape_str($message);
			 $subject = $this->db->escape_str($subject); 
			$this->db->query("INSERT INTO email_tracking (email_type,subject, message,from_address, to_address, bcc_address,error_message,status, attachments ) VALUES
  ('$email_type','$subject','$message','$email_from','$email_to','$bcc_address','$error_message','SENT', '$attachment_tracking_v' );");
 		  return true;
        }
        else
        {

            $error_message=$this->email->print_debugger();
			$message = $this->db->escape_str($message);
			 $subject = $this->db->escape_str($subject); 	 
			$this->db->query("INSERT INTO email_tracking (email_type,subject, message,from_address, to_address, bcc_address,error_message,status, attachments ) VALUES
  ('$email_type','$subject','$message','$email_from','$email_to','$bcc_address','$error_message','FAILURE', '$attachment_tracking_v' );");
  return false;
        }
          
	 
	}
	function send_email_do_id($id)
	{
		$query1 = "SELECT * FROM email_tracking  WHERE email_tracking_id = '$id' ";
		$query = $this->db->query($query1);
		 
		if ( $query->num_rows() > 0 ) 
		{
			$result_data =  $query->row();	
			 $data = $this->db->get('email_access')->row();
         $config = Array(
            'protocol' => $data->smtp,
            'smtp_host' => $data->host,
            'smtp_port' => $data->port,
            'smtp_user' => $data->username,
            'smtp_pass' => $data->password,
            'mailtype' => 'html', 
			  'charset' => 'iso-8859-1',
            'wordwrap' => TRUE
        );
  
        $this->load->library('email', $config);

        $this->email->set_newline("\r\n");
        $this->email->to($result_data->to_address);
        //$this->email->to($user->user_email);
        $this->email->from($result_data->from_address);
        $this->email->subject($result_data->subject);
	 
	    if($result_data->bcc_address!='') {
	    $this->email->bcc($result_data->bcc_address); }
        $this->email->message($result_data->message);
		$attachment_custom_v = $result_data->attachments;
      	if($attachment_custom_v!='') 
				{
					$attachment_custom_vz = explode("||||",$attachment_custom_v);
					for($k=0;$k<count($attachment_custom_vz);$k++)
					{
						if($attachment_custom_vz[$k]!='')
						{
  							$this->email->attach($attachment_custom_vz[$k]);
						}
					}
				}
          if($this->email->send())
        {
			 
			$error_message='';
			 
			$this->db->query("UPDATE email_tracking SET status='SENT',error_message='$error_message'  WHERE  email_tracking_id='$id';");
 		  return true;
        }
        else
        {

            $error_message=$this->email->print_debugger();
  
			 $this->db->query("UPDATE email_tracking SET status='FAILURE',error_message='$error_message'  WHERE  email_tracking_id='$id';");
			 
  return false;
        }
		}
		else
		{
			return false;
		}
	   
          
	 
	}
	
	function send_email_do_multiple($eamiltemp_id,$subject,$email_from,$email_from_name,$get_cases_info,$message,$email_type,$attachment_custom_v,$default_attach,$attachment_url,$agent_id,$user_name,$user_email,$bcc_address='',$cc_address='',$is_attach_case_document,$track_id='')
	{
		 
		//echo $attachment_custom_v.'-';echo $attachment_url;exit;
		$DB1 = $this->load->database('live', TRUE);
 		 
	    $data = $this->db->get('email_access')->row();
         $config = array(
            'protocol' => $data->smtp,
            'smtp_host' => $data->host,
            'smtp_port' => $data->port,
            'smtp_user' => $data->username,
            'smtp_pass' => $data->password,
            'mailtype' => 'html', 
			  'charset' => 'iso-8859-1',
            'wordwrap' => TRUE
        );
  
        $this->load->library('email', $config);
	 
		foreach ($get_cases_info as $key => $vall)
		{
				
				$this->email->clear('TRUE');
				
				$this->email->set_newline("\r\n");
				$this->email->to($vall['email']);
				//$this->email->to('ruby.refundme16@gmail.com');
 				$this->email->from($email_from, $email_from_name);
			 
				if($cc_address!='') {
				$this->email->cc($cc_address); }
				if($bcc_address!='') {
				$this->email->bcc($bcc_address); }
				$complete_atatchment_data = array();
 				if($attachment_custom_v!='') 
				{
					$attachment_custom_vz = explode("||||",$attachment_custom_v);
					for($k=0;$k<count($attachment_custom_vz);$k++)
					{
						$complete_atatchment_data[] = $attachment_custom_vz[$k];
 						$this->email->attach($attachment_custom_vz[$k]);
					}
				}
				if($attachment_url!='') 
				{
					$complete_atatchment_data[] = $attachment_url;
 					$this->email->attach($attachment_url); 
				}
				if(isset($vall['fileurl']) && $vall['fileurl']!='')
				{
					$complete_atatchment_data[] = $vall['fileurl'];
 					 $this->email->attach($vall['fileurl']); 
				}
				if($default_attach!='') 
				{
					$default_attach1 = explode("||||",$default_attach);
					for($k=0;$k<count($default_attach1);$k++)
					{
						$complete_atatchment_data[] = $default_attach1[$k];
 						$this->email->attach($default_attach1[$k]);
					}
 				}
  				//$this->email->attach('https://www.refund.me/wp-content/uploads/2015/08/refundme-Logo-2015R-02_313x67.png');
 			    // $this->email->attach('http://refundme-b2c.quantumsoftech.com/data-file/temp/claim_reports_03032017_083905.pdf');
 				$attachment_tracking=array();
				$attachment_tracking_name=array();
				$exists_attachment_tracking=array();
				$exists_attachment_tracking_name = array();
				$missing_docs=array();
				if($eamiltemp_id=='')
				{
					$message_v = $message;
					$subject_v1 = $subject;
				}
				else
				{
					 if($email_type=='Airline')
					 {
 						 $result_message_v = $this->get_message_content_lang_v1($eamiltemp_id);
 					 }
					 else
					 {
						 $result_message_v = $this->get_message_content_lang($eamiltemp_id,$vall['language']);
					 }
 					
					$atachment_limit = $this->get_atachment_limit();
 				 	$message_v = $result_message_v['message'];
					$subject_v1 = $result_message_v['subject'];
 					$document_type_v = $result_message_v['document_type'];
   					if($document_type_v!='' && $is_attach_case_document=='true')
					{
						//$document_type_v = str_replace(",","','",$document_type_v);
						 
						$case_id_vs = $vall['result']->case_id;
						$query4590s_old = "SELECT   string_agg(doc_url, '|||SPLIT|||' ORDER BY modified_utc DESC) as cs_doc_url, 
string_agg(doc_name, '|||SPLIT|||' ORDER BY modified_utc DESC) as cs_doc_name, 
string_agg(doc_key, '|||SPLIT|||' ORDER BY modified_utc DESC) as cs_doc_key, 
 MAX(modified_utc) FROM case_documents WHERE case_id='$case_id_vs' AND doc_subtype_id IS NULL AND doc_type_id IN ($document_type_v)   
 UNION
 SELECT   string_agg(doc_url, '|||SPLIT|||' ORDER BY modified_utc DESC) as cs_doc_url, 
string_agg(doc_name, '|||SPLIT|||' ORDER BY modified_utc DESC) as cs_doc_name, 
string_agg(doc_key, '|||SPLIT|||' ORDER BY modified_utc DESC) as cs_doc_key, 
 MAX(modified_utc) FROM case_documents WHERE case_id='$case_id_vs'  AND doc_subtype_id IS NOT NULL AND doc_subtype_id IN ($document_type_v)  ;
 ";
 
 $query4590s =" select *  from case_documents WHERE case_id='$case_id_vs'";
 						$query3590d = $DB1->query($query4590s);
					// echo $query4590s;
 						if ( $query3590d->num_rows() > 0 ) 
						{
							$query3590_v =  $query3590d->result();	
 							 $document_type_v_array = explode(",",$document_type_v);
							//http://localhost/claims/data-file/gdocs/322-test_document.txt
							$jk_count = 0;
  							for($jk=0;$jk<count($query3590_v);$jk++)
							{
							 
								$elg='NOK';
								if($query3590_v[$jk]->doc_subtype_id!='')
								{
									if (in_array($query3590_v[$jk]->doc_subtype_id, $document_type_v_array)) {
										$elg='OK';
									}
								 
 								}
								else
								{
								if (in_array($query3590_v[$jk]->doc_type_id, $document_type_v_array)) {
											$elg='OK';
											
										}
										 
								}
								if($elg=='OK')
								{
								
 								$doc_name='';
								if($query3590_v[$jk]->doc_name!='')
								{
 										$doc_name = $query3590_v[$jk]->doc_name;
 								}
								$doc_url='';
								if($query3590_v[$jk]->doc_url!='')
								{
 										$doc_url = $query3590_v[$jk]->doc_url;
 								}
								$doc_key='';
								if($query3590_v[$jk]->doc_key!='')
								{
 										$doc_key = $query3590_v[$jk]->doc_key;
 								}
								 
 								if($jk_count < $atachment_limit)
								{
 									 
 									$doc_name_split = explode(".",$doc_name);
									if(count($doc_name_split) == 1)
									{
										 
										 
										if(isset($doc_key) && $doc_key!='')
										{
											$doc_name_v1_d = explode(".",$doc_key);
 											if(count($doc_name_v1_d) == 1)
											{
												//echo $query3590_v[$jk]->doc_name;exit;
												//custom name
												$s_g_file = $this->set_get_attachmentfile($doc_name,$doc_url);
												$doc_name = $s_g_file['doc_name'];
												$doc_url = $s_g_file['doc_url'];
												
												$missing_docs[] = array($doc_name,$doc_url);
												$attachment_tracking[] = $doc_url;
												$attachment_tracking_name[] = $doc_name;
												$complete_atatchment_data[] = $doc_url;
												$this->email->attach($doc_url,'attachment',$doc_name);
											}
											else
											{
												
											 	$doc_name_v2='';
												if(end($doc_name_v1_d) !='')
												{
													$doc_name_v2 = $doc_name.'.'.end($doc_name_v1_d);
													$s_g_file = $this->set_get_attachmentfile($doc_name_v2,$doc_url);
													$doc_name = $s_g_file['doc_name'];
													$doc_url = $s_g_file['doc_url'];
												}
												else
												{
													$s_g_file = $this->set_get_attachmentfile($doc_name,$doc_url);
													$doc_name = $s_g_file['doc_name'];
													$doc_url = $s_g_file['doc_url'];
													$missing_docs[] = array($doc_name,$doc_url);
												}
												
												$attachment_tracking[] = $doc_url;
												$attachment_tracking_name[] = $doc_name;
												$complete_atatchment_data[] = $doc_url;
 												$this->email->attach($doc_url,'attachment',$doc_name);
											}
										}
										else
										{
												$s_g_file = $this->set_get_attachmentfile($doc_name,$doc_url);
												$doc_name = $s_g_file['doc_name'];
												$doc_url = $s_g_file['doc_url'];
													
											$missing_docs[] = array($doc_name,$doc_url);
											$attachment_tracking[] = $doc_url;
											$attachment_tracking_name[] = $doc_name;
											$complete_atatchment_data[] = $doc_url;
											$this->email->attach($doc_url,'attachment',$doc_name);
										}
									}
									else
									{
										$s_g_file = $this->set_get_attachmentfile($doc_name,$doc_url);
												$doc_name = $s_g_file['doc_name'];
												$doc_url = $s_g_file['doc_url'];
												
										 $attachment_tracking[] = $doc_url;
										 $attachment_tracking_name[] = $doc_name;
										 $complete_atatchment_data[] = $doc_url;
										 $this->email->attach($doc_url,'attachment',$doc_name);
									}
 									 
									 
								}
								else
								{
									 $attachment_tracking[] = $doc_url;
									 $attachment_tracking_name[] = $doc_name;
									 $exists_attachment_tracking[] = $doc_url;
									 $exists_attachment_tracking_name[] = $doc_name;
								}
  							
									$jk_count++;
								}
							}
 						}
						 
					}
					 
				}
				
 				 $document_content_msg='<br/><hr><br/>';
				 if(!empty($attachment_tracking))
				 {
					 $document_content_msg .='<strong>Link to document in attachment : </strong><br/>';
					 for($hj=0;$hj<count($attachment_tracking);$hj++)
					 {
						 $exists = '';
						 if (!in_array($attachment_tracking[$hj], $exists_attachment_tracking)) {
							 $document_content_msg .=$attachment_tracking_name[$hj].' - <em><a href="'.$attachment_tracking[$hj].'" target="_blank" >'.$attachment_tracking[$hj].'</a></em> '.$exists.'<br/>';
						}
						
					 }
					  $document_content_msg .='<br/>';
				 }
				 if(!empty($exists_attachment_tracking))
				 {
					 $document_content_msg .='<strong>Link to document due to exceed in Threshold size : </strong><br/>';
					 for($hj=0;$hj<count($exists_attachment_tracking);$hj++)
					 {
 						 $document_content_msg .=$exists_attachment_tracking_name[$hj].' - <em><a href="'.$exists_attachment_tracking[$hj].'" target="_blank" >'.$exists_attachment_tracking[$hj].'</a></em><br/>';
					 }
					  $document_content_msg .='<br/>';
				 }
  				 if(!empty($missing_docs))
				 {
					 $document_content_msg .='<strong>Link to document without extension in attachment :</strong><br/>';
					 for($hj=0;$hj<count($missing_docs);$hj++)
					 {
						 $document_content_msg .=$missing_docs[$hj][0].' : <a href="'.$missing_docs[$hj][1].'" target="_blank" >'.$missing_docs[$hj][1].'</a><br/>';
					 }
					  $document_content_msg .='<br/>';
				 }
				  
				 $message_v = $message_v.$document_content_msg;
				 $message2 = str_replace("{{caseReference}}",$vall['result']->case_reference_num,$message_v);
				 $message2 = str_replace("{{precedentCaseReference}}",$vall['result']->precedent_case_ref_num,$message2);
				 $message2 = str_replace("{{refundAmount}}",$vall['result']->refundamount,$message2);
				 $message2 = str_replace("{{refundAmount}}",$vall['result']->refundamount,$message2);
				 $message2 = str_replace("{{caseReceivedUTC}}",$vall['result']->casereceivedutc,$message2);
				 $message2 = str_replace("{{casePassenger.passengerID}}",$vall['result']->p_passenger_id,$message2);
				 $message2 = str_replace("{{casePassenger.firstName}}",$vall['result']->p_first_name,$message2);
				 $message2 = str_replace("{{casePassenger.lastName}}",$vall['result']->p_last_name,$message2);
				 $message2 = str_replace("{{casePassenger.address}}",$vall['result']->p_address,$message2);
				 $message2 = str_replace("{{casePassenger.countryCode}}",$vall['result']->p_country_code,$message2);
				 $message2 = str_replace("{{casePassenger.telephone}}",$vall['result']->p_telephone,$message2);
				 $message2 = str_replace("{{casePassenger.email}}",$vall['result']->p_email,$message2);
				 $message2 = str_replace("{{operatingAirline}}",$vall['result']->c_operating_airline_name,$message2); 
 				 $message2 = str_replace("{{current_date}}",date("m/d/Y"),$message2);
				  
				 if((strpos($message2, "{{current_date+") !== false)) 
				 {
				   $start = '{{current_date+'; $end = '}}';
 				   $regex = "/$start(.*?)$end/";
 					 preg_match_all($regex, $message2, $matches);
					  if(isset($matches[1]) && $matches[1]!='' && !empty($matches[1]))
					  {
					   for($lkj=0;$lkj<count($matches[1]);$lkj++)
					   {
						   $days = (int)str_replace(" ","",$matches[1][$lkj]);
						   $c = date('Y-m-d');
 						   $message2 = str_replace($matches[0][$lkj],date('m/d/Y', ( strtotime($c)+($days*24*60*60) ) ),$message2);
					   }
					  }
 			 	 }  
				  
				 
				 $subject_v1 = str_replace("{{caseReference}}",$vall['result']->case_reference_num,$subject_v1);
				 $subject_v1 = str_replace("{{precedentCaseReference}}",$vall['result']->precedent_case_ref_num,$subject_v1);
				 $subject_v1 = str_replace("{{refundAmount}}",$vall['result']->refundamount,$subject_v1);
				 $subject_v1 = str_replace("{{refundAmount}}",$vall['result']->refundamount,$subject_v1);
				 $subject_v1 = str_replace("{{caseReceivedUTC}}",$vall['result']->casereceivedutc,$subject_v1);
				 $subject_v1 = str_replace("{{casePassenger.passengerID}}",$vall['result']->p_passenger_id,$subject_v1);
				 $subject_v1 = str_replace("{{casePassenger.firstName}}",$vall['result']->p_first_name,$subject_v1);
				 $subject_v1 = str_replace("{{casePassenger.lastName}}",$vall['result']->p_last_name,$subject_v1);
				 $subject_v1 = str_replace("{{casePassenger.address}}",$vall['result']->p_address,$subject_v1);
				 $subject_v1 = str_replace("{{casePassenger.countryCode}}",$vall['result']->p_country_code,$subject_v1);
				 $subject_v1 = str_replace("{{casePassenger.telephone}}",$vall['result']->p_telephone,$subject_v1);
				 $subject_v1 = str_replace("{{casePassenger.email}}",$vall['result']->p_email,$subject_v1);
				 $subject_v1 = str_replace("{{operatingAirline}}",$vall['result']->c_operating_airline_name,$subject_v1); 
 				 $subject_v1 = str_replace("{{current_date}}",date("M/d/Y"),$subject_v1);
				 if((strpos($subject_v1, "{{current_date+") !== false)) 
				 {
				   $start = '{{current_date+'; $end = '}}';
 				   $regex = "/$start(.*?)$end/";
 					 preg_match_all($regex, $subject_v1, $matches);
					  if(isset($matches[1]) && $matches[1]!='' && !empty($matches[1]))
					  {
					   for($lkj=0;$lkj<count($matches[1]);$lkj++)
					   {
						   $days = (int)str_replace(" ","",$matches[1][$lkj]);
						   $c = date('Y-m-d');
 						   $subject_v1 = str_replace($matches[0][$lkj],date('m/d/Y', ( strtotime($c)+($days*24*60*60) ) ),$subject_v1);
					   }
					  }
 			 	 }  
				
				 
				$this->email->subject($subject_v1);
			 	$this->email->message($message2);
				$email_tof =$vall['email'];
			  
			 	 if($this->email->send())
				{
					 //////////ACTIVITIES LEGACEY SYSTEM/////////
 						  $t_data['action'] = 'EMAIL';
						  $t_data['loggable_type'] = 'B2C';
						  $t_data['loggable_id'] = '';
						  $t_data['agent_id'] = $agent_id;
						  $t_data['case_id'] = $vall['result']->case_id;
						  $t_data['data'] = '';
						  $t_data['message'] = 'Email sent to '.$vall['email'].' with body text: '.$message2;
						  $t_data['agent_name'] = $user_name;
						  $t_data['agent_email'] = $user_email;
 						  $DB1->insert('activities',$t_data);
					//////////ACTIVITIES LEGACEY SYSTEM/////////
						  
					$error_message='';
					$attachment_tracking_v='';
					if(!empty($complete_atatchment_data))
					{
						$attachment_tracking_v = implode("||||",$complete_atatchment_data);
					}
					$message2 = $this->db->escape_str($message2);
 					$subject = $this->db->escape_str($subject); 
					$this->db->query("INSERT INTO email_tracking (email_type,subject, message,from_address, to_address, bcc_address,error_message,status,attachments,email_tracking_sub_id ) VALUES
		  ('$email_type','$subject_v1','$message2','$email_from','$email_tof','$bcc_address','$error_message','SENT','$attachment_tracking_v','$track_id');");
		  			
 				 
				}
				else
				{
 					$error_message=$this->email->print_debugger();
					$attachment_tracking_v='';
					if(!empty($complete_atatchment_data))
					{
						$attachment_tracking_v = implode("||||",$complete_atatchment_data);
					}		
					$message2 = $this->db->escape_str($message2); 
					$subject = $this->db->escape_str($subject); 
					$this->db->query("INSERT INTO email_tracking (email_type,subject, message,from_address, to_address, bcc_address,error_message,status,attachments,email_tracking_sub_id ) VALUES
		  ('$email_type','$subject_v1','$message2','$email_from','$email_tof','$bcc_address','$error_message','FAILURE','$attachment_tracking_v','$track_id');");
		 
				} 
				 
		}
       
          
	 
	}
 	public function get_pdf_conversion_all()
	{
		 
		 
 	$query1 = "SELECT pdf_convertion_types_id FROM pdf_convertion_types ORDER BY pdf_convertion_types_id ASC  ";
	 
		$query = $this->db->query($query1);
		 
		return $query->num_rows();
	}
	public function get_email_cron_all($cron,$case_number,$to_address,$status,$dates)
	{
		 
		 $filter=array();
		if($cron!='') {	$filter[] = " cron_type LIKE '$cron%' ";	}
		if($case_number!='') {	$filter[] = " case_number LIKE '%$case_number%' ";	}
		if($to_address!='') {	$filter[] = " to_address LIKE '%$to_address%' ";	}
		if($status!='') {	$filter[] = " status = '$status' ";	}
		if($dates!='') {	$filter[] = " created_timestamp LIKE '$dates%' ";	} 
 		$filter_v ='';
		if(!empty($filter))
		{
		 $filter_v = " WHERE ".implode(" AND ",$filter);
		}
 	$query1 = "SELECT lawfirm_email_id FROM lawfirm_email $filter_v ORDER BY lawfirm_email_id ASC  ";
	 
		$query = $this->db->query($query1);
		 
		return $query->num_rows();
	}
	public function get_email_all_all($e_type,$e_subject,$e_address,$e_status,$e_date)
	{
		 $filter=array();
		if($e_type!='') {	$filter[] = " email_type LIKE '$e_type%' ";	}
		if($e_subject!='') {	$filter[] = " subject LIKE '%$e_subject%' ";	}
		if($e_address!='') {	$filter[] = " to_address LIKE '%$e_address%' ";	}
		if($e_status!='') {	$filter[] = " status = '$e_status' ";	}
		if($e_date!='') {	$filter[] = " created_timestamp LIKE '$e_date%' ";	} 
 		$filter_v ='';
		if(!empty($filter))
		{
		 $filter_v = " WHERE ".implode(" AND ",$filter);
		}
 		
		 
 	$query1 = "SELECT email_tracking_id FROM email_tracking $filter_v ORDER BY email_tracking_id ASC  ";
	 
		$query = $this->db->query($query1);
		 
		return $query->num_rows();
	}
	 public function add_pdf_conversion($f_start_time,$vat)
	{
		 
 		  $query2 = "INSERT INTO pdf_convertion_types(file_type,file_mode) VALUES ('$f_start_time','$vat')";
 		if ($this->db->query($query2)) 
		{
			return true;	
		}
		else
		{
			return false;
		}
	}
	public function delete_pdf_conversion($id)
	{
 			$query2 = "DELETE FROM pdf_convertion_types WHERE pdf_convertion_types_id = '$id' ";
			if ($this->db->query($query2)) 
		{
			return true;	
		}
		else
		{
			return false;
		}	
		 
	}	
	
	public function get_pdf_conversion($orders,$offset='',$limit='')
	{
		 $order_column = $orders['0']['column'];
		$order_dir = $orders['0']['dir'];
		$orders_v1='';
		if($order_column==1)
		{
			$order_dt = " file_type ";
			$orders_v1 = " ORDER BY ".$order_dt.strtoupper($order_dir);
		}
		elseif($order_column==2)
		{
			$order_dt = " file_mode ";
			$orders_v1 = " ORDER BY ".$order_dt.strtoupper($order_dir);
		}
		elseif($order_column==3)
		{
			$order_dt = " created_timestamp ";
			$orders_v1 = " ORDER BY ".$order_dt.strtoupper($order_dir);
		}
		else
		{
			$orders_v1 = " ORDER BY pdf_convertion_types_id ASC";
		}
 	$query1 = "SELECT * FROM pdf_convertion_types  $orders_v1  LIMIT $limit OFFSET $offset ";
	 
		$query = $this->db->query($query1);
		 
		if ( $query->num_rows() > 0 ) 
		{
			return $query->result();	
		}
		else
		{
			return false;
		}
	}	
		public function get_email_cron($orders,$offset='',$limit='',$cron,$case_number,$to_address,$status,$dates)
	{
		 $order_column = $orders['0']['column'];
		$order_dir = $orders['0']['dir'];
		$orders_v1='';
		if($order_column==0)
		{
			$order_dt = " lawfirm_email_id ";
			$orders_v1 = " ORDER BY ".$order_dt.strtoupper($order_dir);
		}
		elseif($order_column==1)
		{
			$order_dt = " cron_type ";
			$orders_v1 = " ORDER BY ".$order_dt.strtoupper($order_dir);
		}
		elseif($order_column==3)
		{
			$order_dt = " to_address ";
			$orders_v1 = " ORDER BY ".$order_dt.strtoupper($order_dir);
		}
		elseif($order_column==4)
		{
			$order_dt = " status ";
			$orders_v1 = " ORDER BY ".$order_dt.strtoupper($order_dir);
		}
		elseif($order_column==5)
		{
			$order_dt = " created_timestamp ";
			$orders_v1 = " ORDER BY ".$order_dt.strtoupper($order_dir);
		}
		else
		{
			$orders_v1 = " ORDER BY lawfirm_email_id DESC";
		}
		
		$filter=array();
		if($cron!='') {	$filter[] = " cron_type LIKE '$cron%' ";	}
		if($case_number!='') {	$filter[] = " case_number LIKE '%$case_number%' ";	}
		if($to_address!='') {	$filter[] = " to_address LIKE '%$to_address%' ";	}
		if($status!='') {	$filter[] = " status = '$status' ";	}
		if($dates!='') {	$filter[] = " created_timestamp LIKE '$dates%' ";	} 
 		$filter_v ='';
		if(!empty($filter))
		{
		 $filter_v = " WHERE ".implode(" AND ",$filter);
		}
		
 	$query1 = "SELECT * FROM lawfirm_email $filter_v $orders_v1  LIMIT $limit OFFSET $offset ";
	 
		$query = $this->db->query($query1);
		 
		if ( $query->num_rows() > 0 ) 
		{
			return $query->result();	
		}
		else
		{
			return false;
		}
	}	
	public function get_email_all($orders,$offset='',$limit='',$e_type,$e_subject,$e_address,$e_status,$e_date)
	{
		 $order_column = $orders['0']['column'];
		$order_dir = $orders['0']['dir'];
		$orders_v1='';
		if($order_column==0)
		{
			$order_dt = " email_tracking_id ";
			$orders_v1 = " ORDER BY ".$order_dt.strtoupper($order_dir);
		}
		elseif($order_column==1)
		{
			$order_dt = " email_type ";
			$orders_v1 = " ORDER BY ".$order_dt.strtoupper($order_dir);
		} 
		elseif($order_column==2)
		{
			$order_dt = " subject ";
			$orders_v1 = " ORDER BY ".$order_dt.strtoupper($order_dir);
		}
		elseif($order_column==3)
		{
			$order_dt = " to_address ";
			$orders_v1 = " ORDER BY ".$order_dt.strtoupper($order_dir);
		}
		elseif($order_column==4)
		{
			$order_dt = " status ";
			$orders_v1 = " ORDER BY ".$order_dt.strtoupper($order_dir);
		}
		elseif($order_column==5)
		{
			$order_dt = " created_timestamp ";
			$orders_v1 = " ORDER BY ".$order_dt.strtoupper($order_dir);
		}
		else
		{
			$orders_v1 = " ORDER BY email_tracking_id DESC";
		}
		
		 
		$filter=array();
		if($e_type!='') {	$filter[] = " email_type LIKE '$e_type%' ";	}
		if($e_subject!='') {	$filter[] = " subject LIKE '%$e_subject%' ";	}
		if($e_address!='') {	$filter[] = " to_address LIKE '%$e_address%' ";	}
		if($e_status!='') {	$filter[] = " status = '$e_status' ";	}
		if($e_date!='') {	$filter[] = " created_timestamp LIKE '$e_date%' ";	} 
 		$filter_v ='';
		if(!empty($filter))
		{
		 $filter_v = " WHERE ".implode(" AND ",$filter);
		}
 		
 		$query1 = "SELECT * FROM email_tracking $filter_v $orders_v1 LIMIT $limit OFFSET $offset ";
	 
		$query = $this->db->query($query1);
		 
		if ( $query->num_rows() > 0 ) 
		{
			return $query->result();	
		}
		else
		{
			return false;
		}
	}	
	function set_get_attachmentfile($doc_name,$doc_url)
	{
		$res['doc_name'] = $doc_name;
				$res['doc_url'] = $doc_url;
				return $res;
 		/* $doc_name_v = explode(".",$doc_name);
		 
		if(isset($doc_name_v[1]) && $doc_name_v[1]!='')
		{
			$doc_name_v1 = $doc_name_v[1];
			$queryqwq = "select * from pdf_convertion_types WHERE file_type='$doc_name_v1' ";
  			$queryqw = $this->db->query($queryqwq);
			 
			if ( $queryqw->num_rows() > 0 ) 
			{
				$result =  $queryqw->row();
				if($result->file_mode == 'image')
				{
					 	$this->load->library('Pdf');
						  $obj_pdf = new Pdf('P', 'mm', 'A4', true, 'UTF-8', false);
						  $obj_pdf->SetCreator(PDF_CREATOR);
						  $doc_url_vsd = explode(".",$doc_name);
						  $doc_name = $doc_url_vsd[0].".pdf";
						  $obj_pdf->SetTitle($doc_name);
						  $obj_pdf->SetPrintHeader(false);
						  $obj_pdf->SetPrintFooter(false);
						  $obj_pdf->SetDefaultMonospacedFont('helvetica');
						  $obj_pdf->SetMargins(PDF_MARGIN_LEFT, 10, PDF_MARGIN_RIGHT);
						  $obj_pdf->SetAutoPageBreak(True, 10);
						  $obj_pdf->SetFont('helvetica', '', 10);
						  $obj_pdf->setFontSubsetting(false);
						  $obj_pdf->AddPage();
						
						
						 // $obj_pdf->writeHTML(file_get_contents('http://localhost/claims/assets/layouts/layout/img/logo.png'), true, false, true, false, '');
						$obj_pdf->Image($doc_url, '', '', '', '', 'JPG', '', '', true, 75, '', false, false, 1, false, false, true);
						  //$obj_pdf->writeHTMLCell(0, 0, '', '', $result, 0, 1, 0, true, '', true);   
	 
						 ob_clean();
						 
						  $file_path = 'data-file/temp/'.$doc_url_vsd[0].'.pdf';
						  $doc_url = WEB_URL.'/data-file/temp/'.$doc_url_vsd[0].'.pdf';
						  $obj_pdf->Output(FCPATH.$file_path, 'F');
						  
						  $res['doc_name'] = $doc_name;
							$res['doc_url'] = $doc_url;
							return $res;	
							
				}
				elseif($result->file_mode == 'text')
				{
					
					 	$this->load->library('Pdf');
						  $obj_pdf = new Pdf('P', 'mm', 'A4', true, 'UTF-8', false);
						  $obj_pdf->SetCreator(PDF_CREATOR);
						  $doc_url_vsd = explode(".",$doc_name);
						  $doc_name = $doc_url_vsd[0].".pdf";
						  $obj_pdf->SetTitle($doc_name);
						  $obj_pdf->SetPrintHeader(false);
						  $obj_pdf->SetPrintFooter(false);
						  $obj_pdf->SetDefaultMonospacedFont('helvetica');
						  $obj_pdf->SetMargins(PDF_MARGIN_LEFT, 10, PDF_MARGIN_RIGHT);
						  $obj_pdf->SetAutoPageBreak(True, 10);
						  $obj_pdf->SetFont('helvetica', '', 10);
						  $obj_pdf->setFontSubsetting(false);
						  $obj_pdf->AddPage();
						
						
						  $obj_pdf->writeHTML(file_get_contents($doc_url), true, false, true, false, '');
						 
						  //$obj_pdf->writeHTMLCell(0, 0, '', '', $result, 0, 1, 0, true, '', true);   
	 
						 ob_clean();
						 
						  $file_path = 'data-file/temp/'.$doc_url_vsd[0].'.pdf';
						  $doc_url = WEB_URL.'/data-file/temp/'.$doc_url_vsd[0].'.pdf';
						  $obj_pdf->Output(FCPATH.$file_path, 'F');
						  
						  $res['doc_name'] = $doc_name;
							$res['doc_url'] = $doc_url;
							return $res;	
							
				
				}
				else
				{
					$res['doc_name'] = $doc_name;
					$res['doc_url'] = $doc_url;
					return $res;	
				}
			}
			else
			{
				$res['doc_name'] = $doc_name;
				$res['doc_url'] = $doc_url;
				return $res;
			}
		}
		else
		{
			$res['doc_name'] = $doc_name;
			$res['doc_url'] = $doc_url;
			return $res;
		}
		 */
		 
	}
	function get_message_content_lang($email_type,$lang)
	{
 			 	 
		$queryqwq = "select * from email_template where email_type='$email_type' AND language_code='$lang' AND status='ACTIVE' ";
		$queryqw = $this->db->query($queryqwq);
		if ( $queryqw->num_rows() > 0 ) 
		{
			$result =  $queryqw->row();	
			$message = array('message'=>$result->message,'subject'=>$result->subject,'document_type'=>$result->case_attachment_doc);
		}
		else
		{
			$queryqw1 = $this->db->query("select * from email_template where email_type='$email_type' AND language_code='en'  AND status='ACTIVE' ");
			if ( $queryqw1->num_rows() > 0 ) 
			{
				$result2 =  $queryqw1->row();	
				$message = array('message'=>$result2->message,'subject'=>$result2->subject,'document_type'=>$result2->case_attachment_doc);
			}
			else
			{
				 $message = array('message'=>'','subject'=>'','document_type'=>'');
			} 
		}
		
		return $message;
	}
	function get_message_content_lang_v1($email_type)
	{
 			 	 
		$queryqwq = "select * from email_template where email_type='$email_type' AND language_code='en' AND status='ACTIVE' ";
		$queryqw = $this->db->query($queryqwq);
		if ( $queryqw->num_rows() > 0 ) 
		{
			$result =  $queryqw->row();	
			$message = array('message'=>$result->message,'subject'=>$result->subject,'document_type'=>$result->case_attachment_doc);
		}
		else
		{
 				 $message = array('message'=>'','subject'=>'','document_type'=>'');
 		}
		
		return $message;
	}
}
