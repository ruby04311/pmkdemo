<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Department_Model extends CI_Model {
 	
	public function get_department_all()
	{
		
 		$query1 = "SELECT * FROM department ORDER BY department_id ASC ";
		$query = $this->db->query($query1);
		 
		if ( $query->num_rows() > 0 ) 
		{
			return $query->result();	
		}
		else
		{
			return false;
		}
	}	
	
		 public function get_department_type()
	{
		$query1 = "SELECT * FROM department_type ";
		$query = $this->db->query($query1);
		 
		if ( $query->num_rows() > 0 ) 
		{
			return $query->result();	
		}
		else
		{
			return false;
		}
	}
	 public function view_department_id($id)
	{
		$query1 = "SELECT * FROM department WHERE department_id='$id'";
		$query = $this->db->query($query1);
		 
		if ( $query->num_rows() > 0 ) 
		{
			return $query->row();	
		}
		else
		{
			return false;
		}
	}
	public function update_department($id, $department_type_id, $name)
	{
		$query1 = "SELECT * FROM department WHERE department_id='$id'  ";
		$query11 = $this->db->query($query1);
		 
		if ( $query11->num_rows() > 0 ) 
		{
			$result1 = $query11->row();	
			if($result1->department_type_id==$department_type_id)
			{
				$dep_code = $result1->department_code;
			}
			else
			{
				$querya1 = "SELECT * FROM department_type WHERE department_type_id='$department_type_id'";
				$querya11 = $this->db->query($querya1);
				if ( $querya11->num_rows() > 0 ) 
				{
					 
					$va1 =  $querya11->row();	
				$queryv2 = "SELECT department_id FROM `department` WHERE department_type_id='$department_type_id'  ";
				$queryv21 = $this->db->query($queryv2);
				$queryv21s =  $queryv21->num_rows()+1;
 				$dep_code = $va1->department_type_code.'_'.sprintf('%02d',$queryv21s);
				}
				else
				{
					return false;
				}
			}
			
		
		
			$query = "UPDATE department SET department_type_id='$department_type_id',department_code='$dep_code',department_name='$name' 
			 WHERE  department_id='$id'";
			if ($this->db->query($query)) 
			{
				return true;	
			}
			else
			{
				return false;
			}
			
		}
		else
		{
			return false;
		}
		
	}
	public function change_department_status($id,$status)
	{
  		$query = "UPDATE department SET status='$status' 
		 WHERE  department_id='$id'";
 		if ($this->db->query($query)) 
		{
			return true;	
		}
		else
		{
			return false;
		}
	}	
	public function add_department($code,$name)
	{
		
		$query1 = "SELECT * FROM department_type WHERE department_type_id='$code'";
		$query = $this->db->query($query1);
		 
		if ( $query->num_rows() > 0 ) 
		{
			$queryv2 = "SELECT department_id FROM `department` WHERE department_type_id='$code'  ";
			$queryv21 = $this->db->query($queryv2);
		   	$queryv21s =  $queryv21->num_rows()+1;
			 
			$v1 =  $query->row();	
			$department_type_id = $v1->department_type_id; 
			
			$dep_code = $v1->department_type_code.'_'.sprintf('%02d',$queryv21s);
			 
 			$query = "INSERT INTO department (department_type_id,department_code,department_name, status  ) VALUES
				  ('$department_type_id','$dep_code','$name','ACTIVE');";
						if ($this->db->query($query)) 
						{
							return true;	
						}
						else
						{
							return false;
						}
		}
		else
		{
			return false;
		}
		
		
  		
	}	
	 public function delete_department($departmentid)
	{
  		$query = "DELETE FROM department  WHERE department_id='$departmentid'";
 		if ($this->db->query($query)) 
		{
			 
			return true;	
		}
		else
		{
				 
			return false;
		}
	}	
}
