<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Role_Model extends CI_Model {
 	
	public function get_role_all()
	{
		
 		$query1 = "SELECT role.*,department.department_code,department.department_name FROM role LEFT JOIN department ON role.department_id = department.department_id ORDER BY role_id ASC ";
		$query = $this->db->query($query1);
		 
		if ( $query->num_rows() > 0 ) 
		{
			return $query->result();	
		}
		else
		{
			return false;
		}
	}
	public function get_employee_all()
	{
		
 		$query1 = "SELECT * FROM employee LEFT JOIN employee_details ON employee.employee_id = employee_details.employee_id ORDER BY  employee.employee_id ASC "; 
		$query = $this->db->query($query1);
		 
		if ( $query->num_rows() > 0 ) 
		{
			return $query->result();	
		}
		else
		{
			return false;
		}
	}
	public function get_department_all()
	{
		
 		$query1 = "SELECT * FROM department ORDER BY department_id ASC ";
		$query = $this->db->query($query1);
		 
		if ( $query->num_rows() > 0 ) 
		{
			return $query->result();	
		}
		else
		{
			return false;
		}
	}
		public function get_privileges_module_all()
	{
		
 		$query1 = "SELECT * FROM privileges_module ORDER BY privileges_module_id ASC ";
		$query = $this->db->query($query1);
		 
		if ( $query->num_rows() > 0 ) 
		{
			return $query->result();	
		}
		else
		{
			return false;
		}
	}
	public function get_modules_all()
	{
		
 		$query1 = "SELECT * FROM privileges_module ORDER BY privileges_module_id ASC ";
		$query = $this->db->query($query1);
		 
		if ( $query->num_rows() > 0 ) 
		{
			return $query->result();	
		}
		else
		{
			return false;
		}
	}
	 public function view_role_id($id)
	{
		$query1 = "SELECT * FROM role WHERE role_id='$id'";
		$query = $this->db->query($query1);
		 
		if ( $query->num_rows() > 0 ) 
		{
			return $query->row();	
		}
		else
		{
			return false;
		}
	}
	public function update_role($id, $depart_id, $code, $name)
	{
 		$query = "UPDATE role SET department_id='$depart_id',role_code='$code',role_name='$name' 
		 WHERE  role_id='$id'";
 		if ($this->db->query($query)) 
		{
			return true;	
		}
		else
		{
			return false;
		}
	}
	
	public function change_privileges_status($id,$status)
	{
  		$query = "UPDATE privileges SET status='$status' 
		 WHERE  privileges_id='$id'";
 		if ($this->db->query($query)) 
		{
			return true;	
		}
		else
		{
			return false;
		}
	}	
	
	public function change_role_status($id,$status)
	{
  		$query = "UPDATE role SET status='$status' 
		 WHERE  role_id='$id'";
 		if ($this->db->query($query)) 
		{
			return true;	
		}
		else
		{
			return false;
		}
	}	
	public function add_role($department_id,$code,$name)
	{
  		$query = "INSERT INTO role (department_id,role_code,role_name, status  ) VALUES
  ('$department_id','$code','$name','ACTIVE');";
 		if ($this->db->query($query)) 
		{
			return true;	
		}
		else
		{
			return false;
		}
	}	
	public function update_privileges_module_do($id,$g_name,$m_name,$m_icon,$m_pos)
	{
  	 	$query = "UPDATE privileges_module SET group_name='$g_name',module_name='$m_name',module_icon='$m_icon',priority='$m_pos' 
		 WHERE  privileges_module_id='$id'";
 		if ($this->db->query($query)) 
		{
			return true;	
		}
		else
		{
			return false;
		}
	}	
	
	public function add_privileges_module_do($g_name,$m_name,$m_icon,$m_pos)
	{
		 
  		$query = "INSERT INTO privileges_module (group_name,module_name,module_icon,priority ) VALUES
  ('$g_name','$m_name','$m_icon','$m_pos');";
 		if ($this->db->query($query)) 
		{
			return true;	
		}
		else
		{
			return false;
		}
	}	
	
	public function add_privileges_do($modules,$p_name,$c_name,$m_name,$p_icon,$visi)
	{
		$visia =strtoupper($visi);
  		$query = "INSERT INTO privileges (privileges_module_id,privileges_name,controller_name,method_name,privileges_icon,visibility_status, status  ) VALUES
  ('$modules','$p_name','$c_name','$m_name','$p_icon','$visia','ACTIVE');";
 		if ($this->db->query($query)) 
		{
			return true;	
		}
		else
		{
			return false;
		}
	}	
	 public function delete_role($role_id)
	{
  		$query = "DELETE FROM role  WHERE role_id='$role_id'";
 		if ($this->db->query($query)) 
		{
			 
			return true;	
		}
		else
		{
				 
			return false;
		}
	}
	public function get_privileges_all()
	{
		
 		$query1 = "SELECT privileges.*,privileges_module.module_name FROM privileges LEFT JOIN privileges_module ON privileges.privileges_module_id = privileges_module.privileges_module_id ORDER BY privileges_id ASC ";
		$query = $this->db->query($query1);
		 
		if ( $query->num_rows() > 0 ) 
		{
			return $query->result();	
		}
		else
		{
			return false;
		}
	}	
	 public function get_module_all()
	{
  		$query = "SELECT * FROM privileges_module ORDER BY privileges_module_id
ASC   ";
 		if ($query1=$this->db->query($query)) 
		{
			 
			return $query1->result();	
		}
		else
		{
				 
			return false;
		}
	}
	 public function get_module_all_id($id)
	{
  		$query = "SELECT * FROM privileges_module WHERE privileges_module_id='$id'
   ";
 		if ($query1=$this->db->query($query)) 
		{
			 
			return $query1->row();	
		}
		else
		{
				 
			return false;
		}
	}
	 public function get_privileges_id($id)
	{
  		$query = "SELECT * FROM privileges WHERE privileges_module_id='$id' AND status='ACTIVE'  ";
 		if ($query1=$this->db->query($query)) 
		{
			 
			return $query1->result();	
		}
		else
		{
				 
			return false;
		}
	}	
	 public function get_privileges_id_with_status($id)
	{
  		$query = "SELECT * FROM privileges WHERE privileges_module_id='$id'  ";
 		if ($query1=$this->db->query($query)) 
		{
			 
			return $query1->result();	
		}
		else
		{
				 
			return false;
		}
	}	
	public function get_privileges_action_all($id)
	{
		$query = "SELECT privileges.privileges_id FROM employee_privileges LEFT JOIN privileges ON employee_privileges.privileges_id = privileges.privileges_id
		  WHERE employee_privileges.employee_id='$id' ";
 		if ($query1=$this->db->query($query)) 
		{
			 
			return $query1->result();	
		}
		else
		{
				 
			return false;
		}
	}
	public function allot_privileges_do($role_id,$privileges)
	{
		$query_c = "DELETE FROM employee_privileges WHERE employee_id='$role_id';";
		$this->db->query($query_c);
		
		foreach($privileges as $row=>$value)
		{
			$query = "INSERT INTO employee_privileges (employee_id,privileges_id  ) VALUES
  ('$role_id','$value' );";
			$this->db->query($query);
		}
		 return true;
	}
		
}
