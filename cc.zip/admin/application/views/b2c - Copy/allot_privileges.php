<!DOCTYPE html>
<html lang="en">
    <!--<![endif]-->
    <!-- BEGIN HEAD -->
    <head>
        <meta charset="utf-8" />
        <title><?php echo PROJECT_TITLE; ?></title>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta content="width=device-width, initial-scale=1" name="viewport" />
        <meta content="Flight is canceled, delayed or missed connecting flight ? Up to 600 € compensation received ✓ 98% success rate ✓ More than 120 countries ✓ Check your claim!" name="description" />
        <meta content="" name="author" />
        <!-- BEGIN GLOBAL MANDATORY STYLES -->
        <link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700&subset=all" rel="stylesheet" type="text/css" />
        <link href="<?php echo ASSETS; ?>/global/plugins/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo ASSETS; ?>/global/plugins/simple-line-icons/simple-line-icons.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo ASSETS; ?>/global/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo ASSETS; ?>/global/plugins/bootstrap-switch/css/bootstrap-switch.min.css" rel="stylesheet" type="text/css" />
        <!-- END GLOBAL MANDATORY STYLES -->
        <!-- BEGIN PAGE LEVEL PLUGINS -->
        
    
        <!-- BEGIN THEME GLOBAL STYLES -->
        <link href="<?php echo ASSETS; ?>/global/css/components-md.min.css" rel="stylesheet" id="style_components" type="text/css" />
        <link href="<?php echo ASSETS; ?>/global/css/plugins-md.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo ASSETS; ?>/global/plugins/bootstrap-toastr/toastr.min.css" rel="stylesheet" type="text/css" />
        <!-- END THEME GLOBAL STYLES -->
        <!-- BEGIN THEME LAYOUT STYLES -->
        <link href="<?php echo ASSETS; ?>/layouts/layout/css/layout.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo ASSETS; ?>/layouts/layout/css/themes/darkblue.min.css" rel="stylesheet" type="text/css" id="style_color" />
        <link href="<?php echo ASSETS; ?>/layouts/layout/css/custom.min.css" rel="stylesheet" type="text/css" />
        <!-- END THEME LAYOUT STYLES -->
 <link rel="shortcut icon" href="<?php echo ASSETS; ?>/pages/img/refundmeico.png" /> </head>
    <!-- END HEAD -->

    <body class="page-header-fixed page-sidebar-closed-hide-logo page-content-white page-md">
        <div class="page-wrapper">
            <!-- BEGIN HEADER -->
             <div class="page-header navbar navbar-fixed-top">
                <!-- BEGIN HEADER INNER -->
                  <?php $this->load->view('common/header',''); ?>
                <!-- END HEADER INNER -->
            </div>
            <!-- END HEADER -->
            <!-- BEGIN HEADER & CONTENT DIVIDER -->
            <div class="clearfix"> </div>
            <!-- END HEADER & CONTENT DIVIDER -->
            <!-- BEGIN CONTAINER -->
            <div class="page-container">
                <!-- BEGIN SIDEBAR -->
                                 <?php $this->load->view('common/side_bar',''); ?>

                <!-- END SIDEBAR -->
                <!-- BEGIN CONTENT -->
                <div class="page-content-wrapper">
                    <!-- BEGIN CONTENT BODY -->
                    <div class="page-content">
                        <!-- BEGIN PAGE HEADER-->
                        <!-- BEGIN THEME PANEL -->
                         
                        <!-- END THEME PANEL -->
                        <!-- BEGIN PAGE BAR -->
                        <div class="page-bar">
                            <ul class="page-breadcrumb">
                             <li>
                                    <a href="<?php echo WEB_URL; ?>">Home</a>
                                    <i class="fa fa-circle"></i>
                                </li>
                                <li>
                                    <a href="<?php echo WEB_URL; ?>role/manage_privileges">Manage Privileges</a>
                                    <i class="fa fa-circle"></i>
                                </li>
                                <li>
                                    <span>Allot Privileges</span>
                                </li>
                            </ul>
                            
                        </div>
                        <!-- END PAGE BAR -->
                        <!-- BEGIN PAGE TITLE-->
                        <h1 class="page-title"> Allot Privileges To Employee
                         </h1>
                        <!-- END PAGE TITLE-->
                        <!-- END PAGE HEADER-->
                        
                        <div class="row">
                            <div class="col-md-12">
                                <!-- BEGIN EXTRAS PORTLET-->
                                <div class="portlet light ">
                                     
                                    <div class="portlet-body form">
                                        <form class="form-horizontal "  action="<?php echo WEB_URL; ?>/role/allot_privileges_do" method="post"  id="form_sample_1">
                                            <div class="form-body">
                                                <div class="form-group last">
                                                 <div class="col-md-7">
                                                 <div class="form-group form-md-line-input">
                                                    <label class="col-md-3 control-label" for="form_control_1">Employee                                                       <span class="required">*</span>
                                                    </label>
                                                    <div class="col-md-9">
                                                        <select onChange="get_privileges(this.value)" class="form-control" name="role_id">
                                                            <option value="">Select</option>
                                                            <?php 
															if($result) {
																for($i=0;$i<count($result);$i++) { ?>
                                                            <option value="<?php echo $result[$i]->employee_id; ?>"><?php echo $result[$i]->first_name." : ".$result[$i]->job_title; ?></option>
                                                            <?php
																}
															}
															?>
                                                        </select>
                                                        <div class="form-control-focus"> </div>
                                                    </div>
                                                </div>
                                                      
                                                
                                                 
                                                 
                                                 
                                                    </div>
                                                     
                                                </div>
                                                <div class="col-md-12" id="privileges_do">
                                               
                            </div>
                                            </div>
                                           
                                            <div class="form-actions">
                                                <div class="row">
                                                    <div class="col-md-offset-2 col-md-10">
                                                    <input type="submit" class="btn green" value="Save Changes"> 
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                          
                    </div>
                    <!-- END CONTENT BODY -->
                </div>
                <!-- END CONTENT -->
                <!-- BEGIN QUICK SIDEBAR -->
                
                   <?php   $this->load->view('common/right_bar',''); ?>
                <!-- END QUICK SIDEBAR -->
            </div>
            <!-- END CONTAINER -->
            <!-- BEGIN FOOTER -->
                        <?php   $this->load->view('common/footer',''); ?>

            <!-- END FOOTER -->
        </div>
        <!-- BEGIN QUICK NAV -->
         <?php   $this->load->view('common/overlay',''); ?>
        <!-- END QUICK NAV -->
        <!--[if lt IE 9]>
<script src="<?php echo ASSETS; ?>/global/plugins/respond.min.js"></script>
<script src="<?php echo ASSETS; ?>/global/plugins/excanvas.min.js"></script> 
<script src="<?php echo ASSETS; ?>/global/plugins/ie8.fix.min.js"></script> 
<![endif]-->
        <!-- BEGIN CORE PLUGINS -->
        <script src="<?php echo ASSETS; ?>/global/plugins/jquery.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/js.cookie.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/jquery-slimscroll/jquery.slimscroll.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/jquery.blockui.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/bootstrap-switch/js/bootstrap-switch.min.js" type="text/javascript"></script>
        <!-- END CORE PLUGINS -->
        <!-- BEGIN PAGE LEVEL PLUGINS -->
      
        <!-- END PAGE LEVEL PLUGINS -->
        <!-- BEGIN THEME GLOBAL SCRIPTS -->
         <!-- END PAGE LEVEL PLUGINS -->
        <!-- BEGIN THEME GLOBAL SCRIPTS -->
        <script src="<?php echo ASSETS; ?>/global/scripts/app.min.js" type="text/javascript"></script>
        <!-- END THEME GLOBAL SCRIPTS -->
               <script>
	 var FormValidationMd = function() {

    var handleValidation1 = function() {
        // for more info visit the official plugin documentation: 
        // http://docs.jquery.com/Plugins/Validation
        var form1 = $('#form_sample_1');
        var error1 = $('.alert-danger', form1);
        var success1 = $('.alert-success', form1);
		

        form1.validate({
            errorElement: 'span', //default input error message container
            errorClass: 'help-block help-block-error', // default input error message class
            focusInvalid: false, // do not focus the last invalid input
            ignore: "", // validate all fields including form hidden input
            messages: { },
            rules: {
				role_id: {
					required: true 
                }  
            },
        errorPlacement: function(error, element) {
                if (element.is(':checkbox')) {
                    error.insertAfter(element.closest(".md-checkbox-list, .md-checkbox-inline, .checkbox-list, .checkbox-inline"));
                } else if (element.is(':radio')) {
                    error.insertAfter(element.closest(".md-radio-list, .md-radio-inline, .radio-list,.radio-inline"));
                } else {
                    error.insertAfter(element); // for other inputs, just perform default behavior
                }
            },

            highlight: function(element) { // hightlight error inputs
                $(element)
                    .closest('.form-group').addClass('has-error'); // set error class to the control group
            },

            unhighlight: function(element) { // revert the change done by hightlight
                $(element)
                    .closest('.form-group').removeClass('has-error'); // set error class to the control group
            },

            success: function(label) {
				 
                label
                    .closest('.form-group').removeClass('has-error'); // set success class to the control group
            }
        });
		$('#form_sample_2').validate({ });
    }
 

    return {
        //main function to initiate the module
        init: function() {
            handleValidation1(); 
        }
    };
}();

jQuery(document).ready(function() {
    FormValidationMd.init();
});
var WEB_URL = "<?php echo WEB_URL; ?>";
function get_privileges($id)
{
	 
 		$.ajax({
					url: WEB_URL+"/role/get_privileges_based/"+$id,  
					success:function(data) {
					   $("#privileges_do").html(data);
					}
				  }); 
	 
}
	 
		$(document).ready(function(){
			
		 	
				  
			
		toastr.options = {
		    "closeButton": false,
  "debug": false,
  "newestOnTop": false,
  "progressBar": false,
  "positionClass": "toast-bottom-right",
  "preventDuplicates": false,
  "onclick": null,
  "showDuration": "300",
  "hideDuration": "1000",
  "timeOut": "5000",
  "extendedTimeOut": "1000",
  "showEasing": "swing",
  "hideEasing": "linear",
  "showMethod": "fadeIn",
  "hideMethod": "fadeOut",
  "body-output-type": "trustedHtml"
		};
		 <?php   if(isset($page_data->msg_type)) { ?>
		toastr.<?php  echo $page_data->msg_type;  ?>("<?php echo $page_data->msg;  ?>");
		<?php }  ?>
		 

		});
</script>

         <script src="<?php echo ASSETS; ?>/global/plugins/jquery-validation/js/jquery.validate.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/jquery-validation/js/additional-methods.min.js" type="text/javascript"></script>
        <!-- END THEME GLOBAL SCRIPTS -->
        <!-- BEGIN PAGE LEVEL SCRIPTS -->
       
 
<script src="<?php echo ASSETS; ?>/layouts/layout/scripts/layout.min.js" type="text/javascript"></script>
         <script src="<?php echo ASSETS; ?>/global/plugins/bootstrap-toastr/toastr.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/layouts/layout/scripts/demo.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/layouts/global/scripts/quick-sidebar.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/layouts/global/scripts/quick-nav.min.js" type="text/javascript"></script>
        <!-- END THEME LAYOUT SCRIPTS -->
        
<script src="<?php echo ASSETS.'/pages/scripts/appconnect.js'; ?>"></script>
    </body>

</html>