 <?php
												if($module) {
												 
											for($i=0;$i<count($module);$i++)
											{
												
								$privileges = $this->role_model->get_privileges_id($module[$i]->privileges_module_id); 		?>
                            <div class="col-md-4">
                                <div class="portlet light bordered">
                                    <div class="portlet-title">
                                        <div class="caption">
                                            <i class="<?php echo $module[$i]->module_icon; ?>"></i>
                                            <span class="caption-subject font-green-sharp bold uppercase"><?php echo $module[$i]->module_name; ?></span>
                                        </div>
                                       
                                    </div>
                                    <div class="portlet-body">
                                        <div   class="tree-demo  "> 
                                          <?php
										 
											for($j=0;$j<count($privileges);$j++)
								 {
								?>
                                        <div class="md-checkbox">
                                                                <input id="checkbox<?php echo $i.$j; ?>" class="md-check" type="checkbox"  <?php if (in_array($privileges[$j]->privileges_id, $privileges_active)) { echo 'checked'; } ?>
                                                                
                                                                 name="privileges[<?php echo $i.$j; ?>]" value="<?php echo $privileges[$j]->privileges_id; ?>">
                                                                <label for="checkbox<?php echo $i.$j; ?>">
                                                                    <span class="inc"></span>
                                                                    <span class="check"></span>
                                                                    <span class="box"></span> <i class="<?php echo $privileges[$j]->privileges_icon; ?>"></i>&nbsp; <?php echo $privileges[$j]->privileges_name; ?> </label>
                                                            </div>
                                         
                                         <?php
											}
												 
												?>
                                                            </div>
                                    </div>
                                </div>
                            </div>
                             
                             <?php
											}
											}
											?>