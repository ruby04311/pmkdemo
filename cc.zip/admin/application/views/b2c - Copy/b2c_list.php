<!DOCTYPE html>
<html lang="en">
    <!--<![endif]-->
    <!-- BEGIN HEAD -->
    <head>
        <meta charset="utf-8" />
        <title><?php echo PROJECT_TITLE; ?></title>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta content="width=device-width, initial-scale=1" name="viewport" />
        <meta content="Flight is canceled, delayed or missed connecting flight ? Up to 600 € compensation received ✓ 98% success rate ✓ More than 120 countries ✓ Check your claim!" name="description" />
        <meta content="" name="author" />
        <!-- BEGIN GLOBAL MANDATORY STYLES -->
<!--        <link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700&subset=all" rel="stylesheet" type="text/css" />
-->        <link href="<?php echo ASSETS; ?>/global/plugins/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo ASSETS; ?>/global/plugins/simple-line-icons/simple-line-icons.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo ASSETS; ?>/global/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo ASSETS; ?>/global/plugins/bootstrap-switch/css/bootstrap-switch.min.css" rel="stylesheet" type="text/css" />
        <!-- END GLOBAL MANDATORY STYLES -->
        <!-- BEGIN PAGE LEVEL PLUGINS -->
        <link href="<?php echo ASSETS; ?>/global/plugins/datatables/datatables.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo ASSETS; ?>/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap.css" rel="stylesheet" type="text/css" />
          <link href="<?php echo ASSETS; ?>/global/plugins/bootstrap-modal/css/bootstrap-modal-bs3patch.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo ASSETS; ?>/global/plugins/bootstrap-modal/css/bootstrap-modal.css" rel="stylesheet" type="text/css" />
        <!-- END PAGE LEVEL PLUGINS -->
          <link href="<?php echo ASSETS; ?>/global/plugins/bootstrap-multiselect/css/bootstrap-multiselect.css" rel="stylesheet" type="text/css" />
 <link href="<?php echo ASSETS; ?>/global/plugins/bootstrap-tagsinput/bootstrap-tagsinput.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo ASSETS; ?>/global/plugins/bootstrap-tagsinput/bootstrap-tagsinput-typeahead.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo ASSETS; ?>/global/plugins/select2/css/select2.min.css" rel="stylesheet" type="text/css" />
<link href="<?php echo ASSETS; ?>/global/plugins/select2/css/select2-bootstrap.min.css" rel="stylesheet" type="text/css" />
<link href="<?php echo ASSETS; ?>/global/plugins/bootstrap-fileinput/bootstrap-fileinput.css" rel="stylesheet" type="text/css" />
<link href="<?php echo ASSETS; ?>/global/plugins/bootstrap-sweetalert/sweetalert.css" rel="stylesheet" type="text/css" />


        <!-- BEGIN THEME GLOBAL STYLES -->
        <link href="<?php echo ASSETS; ?>/global/css/components-md.min.css" rel="stylesheet" id="style_components" type="text/css" />
        <link href="<?php echo ASSETS; ?>/global/css/plugins-md.min.css" rel="stylesheet" type="text/css" />
        <!-- END THEME GLOBAL STYLES -->
             <link href="<?php echo ASSETS; ?>/global/plugins/jquery-notific8/jquery.notific8.min.css" rel="stylesheet" type="text/css" />
          <link href="<?php echo ASSETS; ?>/global/plugins/bootstrap-toastr/toastr.min.css" rel="stylesheet" type="text/css" />
        <!-- BEGIN THEME LAYOUT STYLES -->
                      
        <link href="<?php echo ASSETS; ?>/layouts/layout/css/layout.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo ASSETS; ?>/layouts/layout/css/themes/darkblue.min.css" rel="stylesheet" type="text/css" id="style_color" />
        <link href="<?php echo ASSETS; ?>/layouts/layout/css/custom.min.css" rel="stylesheet" type="text/css" />
        <!-- END THEME LAYOUT STYLES -->
              <link rel="shortcut icon" href="<?php echo ASSETS; ?>/pages/img/refundmeico.png" /> 
                <style>
		 
 
		.checkbox, .form-horizontal .checkbox { padding: 3px 20px 3px 40px; }
		</style>
 </head>
    <!-- END HEAD -->

    <body class="page-header-fixed page-sidebar-closed-hide-logo page-content-white page-md">
        <div class="page-wrapper">
            <!-- BEGIN HEADER -->
            <div class="page-header navbar navbar-fixed-top">
                <!-- BEGIN HEADER INNER -->
                  <?php $this->load->view('common/header',''); ?>

                <!-- END HEADER INNER -->
            </div>
            <!-- END HEADER -->
            <!-- BEGIN HEADER & CONTENT DIVIDER -->
            <div class="clearfix"> </div>
            <!-- END HEADER & CONTENT DIVIDER -->
            <!-- BEGIN CONTAINER -->
            <div class="page-container">
                <!-- BEGIN SIDEBAR -->
                 <?php $this->load->view('common/side_bar',''); ?>
                <!-- END SIDEBAR -->
                <!-- BEGIN CONTENT -->
                <div class="page-content-wrapper">
                    <!-- BEGIN CONTENT BODY -->
                    <div class="page-content">
                        <!-- BEGIN PAGE HEADER-->
                        <!-- BEGIN THEME PANEL -->
                         
                        <!-- END THEME PANEL -->
                        <!-- BEGIN PAGE BAR -->
                       <div class="page-bar">
                            <ul class="page-breadcrumb">
                                <li>
                                    <a href="<?php echo WEB_URL; ?>">Home</a>
                                    <i class="fa fa-circle"></i>
                                </li>
                                <li>
                                    <a href="#">B2C</a>
                                    <i class="fa fa-circle"></i>
                                </li>
                                <li>
                                    <span>List All</span>
                                </li>
                            </ul>
                             
                        </div>
                        <!-- END PAGE BAR -->
                        <!-- BEGIN PAGE TITLE-->
                        <h1 class="page-title"> B2C<br/>
                            <small>List all the b2c customer details.</small>
                        </h1>
                        <!-- END PAGE TITLE-->
                         
                        <!-- END PAGE HEADER-->
                            
                        
                        <div class="row">
                            <div class="col-md-12" >
                                <!-- BEGIN EXAMPLE TABLE PORTLET-->
                                <div class="portlet light bordered" id="tablebox">
                                     
                                    <div class="portlet-body">
                                      
    
<table id="example" class="display select table table-striped table-bordered table-hover table-checkable order-column" cellspacing="0" width="100%">
   <thead>
   
 <tr>
                 
                                                        
                                                     
                                                        <th width="10%"> User Code </th>
                                                         <th width="2%"> Agent ID </th>
                                                        <th width="10%"> Department </th>
                                                        <th width="10%" > Job Title </th>
                                                        <th width="10%"> Name </th>
                                                        <th width="10%"> Email ID </th>
                                                        <th width="10%"> Cont No </th>
                                                        <th width="10%"> Skype ID </th>
                                                        <th width="10%" > Reg Date </th>
                                                        <th width="8%"> Status </th>
                                                        <th width="10%"> Actions </th>                                                
                                                         
            </tr>
            <tr role="row" class="filter">
                                                        
                                                       
                                                           
                                                        <td>
                                                               <input type="text" class="form-control form-filter input-sm" name="emp_code"> </td>
                                                        </td>
                                                        <td>
                                                               <input type="text" class="form-control form-filter input-sm" name="agent_id"> </td>
                                                        </td>
                                                        <td>
                                                            <input type="text" class="form-control form-filter input-sm" id="department" name="department"> </td>
                                                        <td>
                                                            <input type="text" class="form-control form-filter input-sm" name="job_title"> </td>
                                                            <td>
                                                            <input type="text" class="form-control form-filter input-sm" name="username"> </td>
                                                        <td>
                                                            <input type="text" class="form-control form-filter input-sm" name="emailid"> </td>
                                                          <td>
                                                            <input type="text" class="form-control form-filter input-sm" name="contacts"> </td>
                                                            <td>
                                                            <input type="text" class="form-control form-filter input-sm" name="skype"> </td>
                                                        <td></td>  <td>
                                                            <select name="status" class="form-control form-filter input-sm">
                                                                <option value="">Select</option>
                                                                <option value="ACTIVE">ACTIVE</option>
                                                                <option value="INACTIVE">INACTIVE</option> 
                                                            </select>
                                                        </td>
                                                        <td>
                                                            <div class="margin-bottom-5">
                                                                <button class="btn btn-sm green btn-outline filter-submit margin-bottom">
                                                                    <i class="fa fa-search"></i> Search</button>
                                                            </div>
                                                            <button class="btn btn-sm red btn-outline filter-cancel">
                                                                <i class="fa fa-times"></i> Reset</button>
                                                        </td>
                                                    </tr>
   </thead>
       
</table>
 
                                         
                                            
                                        <div id="responsive" class="modal fade" tabindex="-1" data-width="950" data-backdrop="static" data-keyboard="false"  data-height="400">
                                            <div class="modal-header">
                                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                                                <h4 class="modal-title">Label Actions</h4>
                                            </div>
                                            <div class="modal-body">
                                                <div class="row">
                                               sdsds
                                                      
                                                </div>
                                                   
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" id="label_cancel" data-dismiss="modal" class="btn btn-outline dark">Close</button>
                                                <button type="button" id="label_apply"  data-dismiss="modal"  class="btn green">Apply</button>
                                            </div>
                                        </div>
                                       
                                    </div>
                                </div>
                                <!-- END EXAMPLE TABLE PORTLET-->
                            </div>
                        </div>
                         
                         
                         
                    </div>
                    <!-- END CONTENT BODY -->
                </div>
                <!-- END CONTENT -->
                <!-- BEGIN QUICK SIDEBAR -->
                <a href="javascript:;" class="page-quick-sidebar-toggler">
                    <i class="icon-login"></i>
                </a>
                 <?php   $this->load->view('common/right_bar',''); ?>
                <!-- END QUICK SIDEBAR -->
            </div>
            <!-- END CONTAINER -->
            <!-- BEGIN FOOTER -->
                        <?php   $this->load->view('common/footer',''); ?>

            <!-- END FOOTER -->
        </div>
        <!-- BEGIN QUICK NAV -->
         
         <?php   $this->load->view('common/overlay',''); ?>
        
        <!-- END QUICK NAV -->
        <!--[if lt IE 9]>
<script src="<?php echo ASSETS; ?>/global/plugins/respond.min.js"></script>
<script src="<?php echo ASSETS; ?>/global/plugins/excanvas.min.js"></script> 
<script src="<?php echo ASSETS; ?>/global/plugins/ie8.fix.min.js"></script> 
<![endif]-->
        <!-- BEGIN CORE PLUGINS -->
        <script src="<?php echo ASSETS; ?>/global/plugins/jquery.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/js.cookie.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/jquery-slimscroll/jquery.slimscroll.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/jquery.blockui.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/bootstrap-switch/js/bootstrap-switch.min.js" type="text/javascript"></script>
        <!-- END CORE PLUGINS -->
        <!-- BEGIN PAGE LEVEL PLUGINS -->
      
        <!-- END PAGE LEVEL PLUGINS -->
          <script src="<?php echo ASSETS; ?>/global/plugins/bootstrap-confirmation/bootstrap-confirmation.min.js" type="text/javascript"></script>
        <!-- BEGIN THEME GLOBAL SCRIPTS -->
          <!-- BEGIN PAGE LEVEL PLUGINS -->
        <script src="<?php echo ASSETS; ?>/global/plugins/bootstrap-modal/js/bootstrap-modalmanager.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/bootstrap-modal/js/bootstrap-modal.js" type="text/javascript"></script>
           <script src="<?php echo ASSETS; ?>/global/scripts/datatable.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/datatables/datatables.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap.js" type="text/javascript"></script>
        <!-- END PAGE LEVEL PLUGINS -->        
		<script src="<?php echo ASSETS; ?>/global/plugins/bootstrap-tagsinput/bootstrap-tagsinput.min.js" type="text/javascript"></script>

        <!-- BEGIN THEME GLOBAL SCRIPTS -->
        <script src="<?php echo ASSETS; ?>/global/scripts/app.min.js" type="text/javascript"></script>
        <!-- END THEME GLOBAL SCRIPTS -->
 
        <!-- BEGIN PAGE LEVEL SCRIPTS -->
         <!-- END PAGE LEVEL SCRIPTS -->
        
         <script src="<?php echo ASSETS; ?>/global/plugins/jquery-validation/js/jquery.validate.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/jquery-validation/js/additional-methods.min.js" type="text/javascript"></script>
         <!-- END THEME GLOBAL SCRIPTS -->
        <!-- BEGIN PAGE LEVEL SCRIPTS -->
   <script src="<?php echo ASSETS; ?>/global/plugins/jquery-notific8/jquery.notific8.js" type="text/javascript"></script>
      
    
       <script>
	   var UINotific8 = function () {
     
 }();

 
</script>
                <!-- BEGIN THEME LAYOUT SCRIPTS -->
        <script src="<?php echo ASSETS; ?>/layouts/layout/scripts/layout.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/layouts/layout/scripts/demo.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/layouts/global/scripts/quick-sidebar.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/layouts/global/scripts/quick-nav.min.js" type="text/javascript"></script>
         <script src="<?php echo ASSETS; ?>/global/plugins/bootstrap-toastr/toastr.min.js" type="text/javascript"></script>
        <!-- END THEME LAYOUT SCRIPTS -->
        <script>
	
	 
		$(document).ready(function(){
		toastr.options = {
		    "closeButton": false,
  "debug": false,
  "newestOnTop": false,
  "progressBar": false,
  "positionClass": "toast-bottom-right",
  "preventDuplicates": false,
  "onclick": null,
  "showDuration": "300",
  "hideDuration": "1000",
  "timeOut": "5000",
  "extendedTimeOut": "1000",
  "showEasing": "swing",
  "hideEasing": "linear",
  "showMethod": "fadeIn",
  "hideMethod": "fadeOut",
  "body-output-type": "trustedHtml"
		};
		 <?php   if(isset($page_data->msg_type)) { ?>
		toastr.<?php  echo $page_data->msg_type;  ?>("<?php echo $page_data->msg;  ?>");
		<?php }  ?>
		 $set_valc=0;
		  <?php  
		   if($this->session->flashdata('notification') == "active") { ?>
		   $set_valc = 1;
  			Connectnotification.pushn('<?php echo $this->session->flashdata('ntfy_count'); ?>','<?php echo $this->session->flashdata('ntfy_url'); ?>','<?php echo $this->session->flashdata('ntfy_pic'); ?>','<?php echo $this->session->flashdata('ntfy_title'); ?>','<?php echo $this->session->flashdata('ntfy_time'); ?>','<?php echo $this->session->flashdata('ntfy_msg'); ?>'); 
			<?php } ?>

		});
</script>
 
 
<script>
  jQuery(document).ready(function() {
	  	
  var grid = new Datatable();

        grid.init({
            src: $("#example"),
            onSuccess: function (grid, response) {
                // grid:        grid object
                // response:    json object of server side ajax response
                // execute some code after table records loaded
            },
            onError: function (grid) {
                // execute some code on network or other general error  
            },
            onDataLoad: function(grid) {
                // execute some code on ajax data load
            },
            loadingMessage: 'Loading...',
            dataTable: { // here you can define a typical datatable settings from http://datatables.net/usage/options 

                // Uncomment below line("dom" parameter) to fix the dropdown overflow issue in the datatable cells. The default datatable layout
                // setup uses scrollable div(table-scrollable) with overflow:auto to enable vertical scroll(see: assets/global/scripts/datatable.js). 
                // So when dropdowns used the scrollable div should be removed. 
                //"dom": "<'row'<'col-md-8 col-sm-12'pli><'col-md-4 col-sm-12'<'table-group-actions pull-right'>>r>t<'row'<'col-md-8 col-sm-12'pli><'col-md-4 col-sm-12'>>",
                
                // save datatable state(pagination, sort, etc) in cookie.
                "bStateSave": true, 

                 // save custom filters to the state
                "fnStateSaveParams":    function ( oSettings, sValue ) {
                    $("#datatable_ajax tr.filter .form-control").each(function() {
                        sValue[$(this).attr('name')] = $(this).val();
                    });
                   
                    return sValue;
                },

                // read the custom filters from saved state and populate the filter inputs
                "fnStateLoadParams" : function ( oSettings, oData ) {
                    //Load custom filters
                    $("#datatable_ajax tr.filter .form-control").each(function() {
                        var element = $(this);
                        if (oData[element.attr('name')]) {
                            element.val( oData[element.attr('name')] );
                        }
                    });
                    
                    return true;
                },

                
                "pageLength": 10, // default record count per page
                "ajax": {
                    "url": "<?php echo WEB_URL; ?>/b2c_do/list_all_b2c_ajax", // ajax source
 							 "beforeSend" : function() {
								 App.blockUI({
									target: '#tablebox' 
								});
							 },
							 
							  "complete": function(xhr, status){
									App.unblockUI('#tablebox');
									
								  $t_r = xhr.responseText;
								  var jsonResponse = JSON.parse($t_r);
									$('.tooltips').tooltip()
							 }
                },
				 'columnDefs': [ { "name": "iata_airline",   "targets": 0,  'orderable': true },
    { "name": "icao_airline",  "targets": 1,  'orderable': true},
    { "name": "airline_name", "targets": 2 ,  'orderable': true},
    { "name": "call_sign",  "targets": 3, 'orderable': true },
    { "name": "country",    "targets": 4 , 'orderable': true},
	 { "name": "email_id",    "targets": 5 , 'orderable': true},
	  { "name": "contact_no",    "targets": 6 , 'orderable': true},
	   { "name": "eligibility",    "targets": 7 , 'orderable': true},
	   { "name": "eligibility",    "targets": 8 , 'orderable': true},
	     { "name": "eligibility",    "targets": 9 , 'orderable': true},
		   { "name": "eligibility",    "targets": 10 , 'orderable': false}
   ],
                "order": [
                    [0, "asc"]
                ]// set first column as a default sort by asc
            }
        });

        // handle group actionsubmit button click
        grid.getTableWrapper().on('click', '.table-group-action-submit', function (e) {
            e.preventDefault();
            var action = $(".table-group-action-input", grid.getTableWrapper());
            if (action.val() != "" && grid.getSelectedRowsCount() > 0) {
                grid.setAjaxParam("customActionType", "group_action");
                grid.setAjaxParam("customActionName", action.val());
                grid.setAjaxParam("id", grid.getSelectedRows());
                grid.getDataTable().ajax.reload();
                grid.clearAjaxParams();
            } else if (action.val() == "") {
                App.alert({
                    type: 'danger',
                    icon: 'warning',
                    message: 'Please select an action',
                    container: grid.getTableWrapper(),
                    place: 'prepend'
                });
            } else if (grid.getSelectedRowsCount() === 0) {
                App.alert({
                    type: 'danger',
                    icon: 'warning',
                    message: 'No record selected',
                    container: grid.getTableWrapper(),
                    place: 'prepend'
                });
            }
        });
	 
   
        
          
			});  
			
			 
 
	


</script>  
<script src="<?php echo ASSETS; ?>/global/plugins/select2/js/select2.full.min.js" type="text/javascript"></script>
<script src="<?php echo ASSETS; ?>/pages/scripts/components-select2.min.js" type="text/javascript"></script>
<script src="<?php echo ASSETS; ?>/global/plugins/bootstrap-fileinput/bootstrap-fileinput.js" type="text/javascript"></script>
<script src="<?php echo ASSETS; ?>/pages/scripts/overlaymessage.js" type="text/javascript"></script>


<script src="<?php echo ASSETS.'/pages/scripts/appconnect.js'; ?>"></script>
  
    </body>

</html>