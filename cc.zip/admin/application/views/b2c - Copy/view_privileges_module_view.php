<div class="portlet box green">
                                    <div class="portlet-title">
                                        <div class="caption">
                                            <i class="icon-key"></i>Privileges </div>
                                       
                                    </div>
                                    <div class="portlet-body">
                                        <div class="table-scrollable">
                                            <table class="table table-striped table-hover">
                                                <thead>
                                                    <tr>
                                                        <th> # </th>
                                                        <th> Privilege Name </th>
                                                        <th> Path </th>
                                                        <th> Status </th>
                                                        <th> Visibility </th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
													if($result) {
														for($i=0;$i<count($result);$i++) { ?>
                                                    <tr>
                                                        <td> <?php echo $i+1; ?> </td>
                                                        <td> <i class="<?php echo $result[$i]->privileges_icon; ?>"></i> <?php echo $result[$i]->privileges_name; ?> </td>
                                                        <td> 
                                                         <?php echo $result[$i]->controller_name; ?> / <?php echo $result[$i]->method_name; ?>
                                                        </td>
                                                        <td>
                                                        <?php if($result[$i]->status== 'INACTIVE') { ?>
                                                         <span class="label label-sm label-danger"> INACTIVE </span> 
                                                         <?php
														}
														else
														{
															?>
                                                        <span class="label label-sm label-success"> ACTIVE </span> 
                                                            <?php
														}
														?>
                                                         </td>
                                                        <td>   <?php if($result[$i]->status== 'HIDE') { ?>
                                                         <span class="label label-sm label-danger"> HIDE </span> 
                                                         <?php
														}
														else
														{
															?>
                                                        <span class="label label-sm label-success"> SHOW </span> 
                                                            <?php
														}
														?> 
                                                        </td>
                                                    </tr>
                                                    <?php
														}
													}
														?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>