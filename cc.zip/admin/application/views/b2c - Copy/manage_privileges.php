<!DOCTYPE html>
<html lang="en">
    <!--<![endif]-->
    <!-- BEGIN HEAD -->
    <head>
        <meta charset="utf-8" />
        <title><?php echo PROJECT_TITLE; ?></title>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta content="width=device-width, initial-scale=1" name="viewport" />
        <meta content="Flight is canceled, delayed or missed connecting flight ? Up to 600 € compensation received ✓ 98% success rate ✓ More than 120 countries ✓ Check your claim!" name="description" />
        <meta content="" name="author" />
        <!-- BEGIN GLOBAL MANDATORY STYLES -->
        <link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700&subset=all" rel="stylesheet" type="text/css" />
        <link href="<?php echo ASSETS; ?>/global/plugins/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo ASSETS; ?>/global/plugins/simple-line-icons/simple-line-icons.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo ASSETS; ?>/global/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo ASSETS; ?>/global/plugins/bootstrap-switch/css/bootstrap-switch.min.css" rel="stylesheet" type="text/css" />
        <!-- END GLOBAL MANDATORY STYLES -->
        <!-- BEGIN PAGE LEVEL PLUGINS -->
        <link href="<?php echo ASSETS; ?>/global/plugins/datatables/datatables.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo ASSETS; ?>/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap.css" rel="stylesheet" type="text/css" />
          <link href="<?php echo ASSETS; ?>/global/plugins/bootstrap-modal/css/bootstrap-modal-bs3patch.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo ASSETS; ?>/global/plugins/bootstrap-modal/css/bootstrap-modal.css" rel="stylesheet" type="text/css" />
        <!-- END PAGE LEVEL PLUGINS -->
        <!-- BEGIN THEME GLOBAL STYLES -->
        <link href="<?php echo ASSETS; ?>/global/css/components-md.min.css" rel="stylesheet" id="style_components" type="text/css" />
        <link href="<?php echo ASSETS; ?>/global/css/plugins-md.min.css" rel="stylesheet" type="text/css" />
        <!-- END THEME GLOBAL STYLES -->
          <link href="<?php echo ASSETS; ?>/global/plugins/bootstrap-toastr/toastr.min.css" rel="stylesheet" type="text/css" />
        <!-- BEGIN THEME LAYOUT STYLES -->
        <link href="<?php echo ASSETS; ?>/layouts/layout/css/layout.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo ASSETS; ?>/layouts/layout/css/themes/darkblue.min.css" rel="stylesheet" type="text/css" id="style_color" />
        <link href="<?php echo ASSETS; ?>/layouts/layout/css/custom.min.css" rel="stylesheet" type="text/css" />
        <!-- END THEME LAYOUT STYLES -->
              <link rel="shortcut icon" href="<?php echo ASSETS; ?>/pages/img/refundmeico.png" /> 
 </head>
    <!-- END HEAD -->

    <body class="page-header-fixed page-sidebar-closed-hide-logo page-content-white page-md">
        <div class="page-wrapper">
            <!-- BEGIN HEADER -->
            <div class="page-header navbar navbar-fixed-top">
                <!-- BEGIN HEADER INNER -->
                  <?php $this->load->view('common/header',''); ?>
                <!-- END HEADER INNER -->
            </div>
            <!-- END HEADER -->
            <!-- BEGIN HEADER & CONTENT DIVIDER -->
            <div class="clearfix"> </div>
            <!-- END HEADER & CONTENT DIVIDER -->
            <!-- BEGIN CONTAINER -->
            <div class="page-container">
                <!-- BEGIN SIDEBAR -->
                 <?php $this->load->view('common/side_bar',''); ?>
                <!-- END SIDEBAR -->
                <!-- BEGIN CONTENT -->
                <div class="page-content-wrapper">
                    <!-- BEGIN CONTENT BODY -->
                    <div class="page-content">
                        <!-- BEGIN PAGE HEADER-->
                        <!-- BEGIN THEME PANEL -->
                         
                        <!-- END THEME PANEL -->
                        <!-- BEGIN PAGE BAR -->
                        <div class="page-bar">
                            <ul class="page-breadcrumb">
                                <li>
                                    <a href="<?php echo WEB_URL; ?>">Home</a>
                                    <i class="fa fa-circle"></i>
                                </li>
                                <li>
                                    <a href="#">Manage Privileges</a>
                                    <i class="fa fa-circle"></i>
                                </li>
                                <li>
                                    <span>List All</span>
                                </li>
                            </ul>
                             
                        </div>
                        <!-- END PAGE BAR -->
                        <!-- BEGIN PAGE TITLE-->
                        <h1 class="page-title"> Privileges<br/>
                            <small>List all the privileges functions.</small>
                        </h1>
                        <!-- END PAGE TITLE-->
                        <!-- END PAGE HEADER-->
                         
                        <div class="row">
                            <div class="col-md-12">
                                <!-- BEGIN EXAMPLE TABLE PORTLET-->
                                <div class="portlet light bordered">
                                     
                                    <div class="portlet-body">
                                     
                                        <table class="table table-striped table-bordered table-hover table-checkable order-column" id="sample_1s">
                                            <thead>
                                                <tr>
                                                     <th> Sl No </th>
                                                    <th> Module </th>
                                                    <th> Privileges </th>
                                                    <th> Path </th>
                                                     <th> Status </th>
                                                    
                                                </tr>
                                            </thead>
                                            <tbody>
                                              <?php 
											  if($result) {
											  for($i=0;$i<count($result);$i++)
											  {
												  ?>
                                                 
                                                 
                                                <tr class="odd gradeX">
                                                     <td> <?php echo $i+1; ?> </td>
                                                       <td> <?php echo $result[$i]->module_name; ?> </td>
                                                    <td>  <i class="fa <?php echo $result[$i]->privileges_icon; ?>"></i> <?php echo $result[$i]->privileges_name; ?> </td>
                                                    <td> <?php echo $result[$i]->controller_name.'/'.$result[$i]->method_name; ?> </td>
                                                     <td>
                                                   
                                                  <button data-id="<?php echo (base64_encode(($result[$i]->privileges_id))); ?>"  class="demo btn btn-xs <?php if($result[$i]->status=='ACTIVE') { echo 'green-jungle'; } else { echo 'red-mint'; } ?> " data-toggle="confirmation" data-placement="top" data-btn-ok-label="ACTIVE" data-btn-ok-icon="icon-like" data-btn-ok-class="btn-success" data-btn-cancel-label="INACTIVE"   data-btn-cancel-icon="icon-close" data-btn-cancel-class="btn-danger"><?php echo $result[$i]->status; ?></button>
                                                    </td>
                                                    
                                                   
                                                </tr>
                                                 
                                            <?php
											  }
											  }
											  ?>
                                             
                                            </tbody>
                                        </table>
                                         <div id="ajax-modal" class="modal container fade"  tabindex="-1"> </div>
                                       
                                    </div>
                                </div>
                                <!-- END EXAMPLE TABLE PORTLET-->
                            </div>
                        </div>
                         
                         
                         
                    </div>
                    <!-- END CONTENT BODY -->
                </div>
                <!-- END CONTENT -->
                <!-- BEGIN QUICK SIDEBAR -->
                <a href="javascript:;" class="page-quick-sidebar-toggler">
                    <i class="icon-login"></i>
                </a>
                 <?php   $this->load->view('common/right_bar',''); ?>
                <!-- END QUICK SIDEBAR -->
            </div>
            <!-- END CONTAINER -->
            <!-- BEGIN FOOTER -->
                        <?php   $this->load->view('common/footer',''); ?>

            <!-- END FOOTER -->
        </div>
        <!-- BEGIN QUICK NAV -->
         
         <?php   $this->load->view('common/overlay',''); ?>
        
        <!-- END QUICK NAV -->
        <!--[if lt IE 9]>
<script src="<?php echo ASSETS; ?>/global/plugins/respond.min.js"></script>
<script src="<?php echo ASSETS; ?>/global/plugins/excanvas.min.js"></script> 
<script src="<?php echo ASSETS; ?>/global/plugins/ie8.fix.min.js"></script> 
<![endif]-->
        <!-- BEGIN CORE PLUGINS -->
        <script src="<?php echo ASSETS; ?>/global/plugins/jquery.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/js.cookie.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/jquery-slimscroll/jquery.slimscroll.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/jquery.blockui.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/bootstrap-switch/js/bootstrap-switch.min.js" type="text/javascript"></script>
        <!-- END CORE PLUGINS -->
        <!-- BEGIN PAGE LEVEL PLUGINS -->
      
        <!-- END PAGE LEVEL PLUGINS -->
          <script src="<?php echo ASSETS; ?>/global/plugins/bootstrap-confirmation/bootstrap-confirmation.min.js" type="text/javascript"></script>
        <!-- BEGIN THEME GLOBAL SCRIPTS -->
          <!-- BEGIN PAGE LEVEL PLUGINS -->
        <script src="<?php echo ASSETS; ?>/global/plugins/bootstrap-modal/js/bootstrap-modalmanager.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/bootstrap-modal/js/bootstrap-modal.js" type="text/javascript"></script>
           <script src="<?php echo ASSETS; ?>/global/scripts/datatable.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/datatables/datatables.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap.js" type="text/javascript"></script>
        <!-- END PAGE LEVEL PLUGINS -->
        <!-- BEGIN THEME GLOBAL SCRIPTS -->
        <script src="<?php echo ASSETS; ?>/global/scripts/app.min.js" type="text/javascript"></script>
        <!-- END THEME GLOBAL SCRIPTS -->
        <!-- BEGIN PAGE LEVEL SCRIPTS -->
        <script src="<?php echo ASSETS; ?>/pages/scripts/ui-extended-modals.min.js" type="text/javascript"></script>
        <!-- END PAGE LEVEL SCRIPTS -->
         <!-- END THEME GLOBAL SCRIPTS -->
        <!-- BEGIN PAGE LEVEL SCRIPTS -->
          <script src="<?php echo ASSETS; ?>/pages/scripts/ui-confirmations.min.js" type="text/javascript"></script>
         <script src="<?php echo ASSETS; ?>/pages/scripts/table-datatables-managed.min.js" type="text/javascript"></script>
        <!-- END PAGE LEVEL SCRIPTS -->
        <!-- BEGIN THEME LAYOUT SCRIPTS -->
        <script src="<?php echo ASSETS; ?>/layouts/layout/scripts/layout.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/layouts/layout/scripts/demo.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/layouts/global/scripts/quick-sidebar.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/layouts/global/scripts/quick-nav.min.js" type="text/javascript"></script>
         <script src="<?php echo ASSETS; ?>/global/plugins/bootstrap-toastr/toastr.min.js" type="text/javascript"></script>
        <!-- END THEME LAYOUT SCRIPTS -->
        <script>
		var WEB_URL = "<?php echo WEB_URL; ?>";
		$('.demo').confirmation({
			  onConfirm: function() {
				$id = $(this).attr("data-id");
 				$.ajax({
					url: WEB_URL+"/role/change_privileges_status_active/"+$id,  
					success:function(data) {
					   
					}
				  });
				  $(this).html('ACTIVE');
				  $(this).removeClass( "red-mint" ).addClass( "green-jungle" );
 			  },
  			 onCancel: function() {
				 $id = $(this).attr("data-id");
				 $.ajax({
					url: WEB_URL+"/role/change_privileges_status_inactive/"+$id,  
					success:function(data) {
					 
					}
				  });
				  $(this).html('INACTIVE');
				  $(this).removeClass( "green-jungle" ).addClass( "red-mint" );
 			  }
 		});
	$(document).ready(function(){
		toastr.options = {
		  "closeButton": true,
		  "debug": false,
		  "positionClass": "toast-bottom-right",
		  "onclick": null,
		  "showDuration": "1000",
		  "hideDuration": "1000",
		  "timeOut": "5000",
		  "extendedTimeOut": "1000",
		  "showEasing": "swing",
		  "hideEasing": "linear",
		  "showMethod": "fadeIn",
		  "hideMethod": "fadeOut"
		};
		 <?php if(isset($page_data->msg_type)) { ?>
		toastr.<?php  echo $page_data->msg_type;  ?>('<?php echo $page_data->msg;  ?>');
		<?php } ?>
		
		});
		jQuery(document).ready(function() {
 
        // begin first table
 
   var table = $('#sample_1s').DataTable({
      'columnDefs': [ { "name": "slno",   "targets": 4,  'orderable': false },
    
	],
      'order': [0, 'asc']
   });
 $("#sample_1s_filter").hide();
	 
    });
</script>
<script src="<?php echo ASSETS.'/pages/scripts/appconnect.js'; ?>"></script>
    </body>

</html>