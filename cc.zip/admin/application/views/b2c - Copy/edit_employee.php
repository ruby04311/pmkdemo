<!DOCTYPE html>
<html lang="en">
    <!--<![endif]-->
    <!-- BEGIN HEAD -->
    <head>
        <meta charset="utf-8" />
        <title><?php echo PROJECT_TITLE; ?></title>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta content="width=device-width, initial-scale=1" name="viewport" />
        <meta content="Flight is canceled, delayed or missed connecting flight ? Up to 600 € compensation received ✓ 98% success rate ✓ More than 120 countries ✓ Check your claim!" name="description" />
        <meta content="" name="author" />
        <!-- BEGIN GLOBAL MANDATORY STYLES -->
        <link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700&subset=all" rel="stylesheet" type="text/css" />
        <link href="<?php echo ASSETS; ?>/global/plugins/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo ASSETS; ?>/global/plugins/simple-line-icons/simple-line-icons.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo ASSETS; ?>/global/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo ASSETS; ?>/global/plugins/bootstrap-switch/css/bootstrap-switch.min.css" rel="stylesheet" type="text/css" />
        <!-- END GLOBAL MANDATORY STYLES -->
        <!-- BEGIN PAGE LEVEL PLUGINS -->
        <link href="<?php echo ASSETS; ?>/global/plugins/bootstrap-wysihtml5/bootstrap-wysihtml5.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo ASSETS; ?>/global/plugins/bootstrap-markdown/css/bootstrap-markdown.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo ASSETS; ?>/global/plugins/bootstrap-summernote/summernote.css" rel="stylesheet" type="text/css" />
        <!-- END PAGE LEVEL PLUGINS -->
        <link href="<?php echo ASSETS; ?>/global/plugins/select2/css/select2.min.css" rel="stylesheet" type="text/css" />
<link href="<?php echo ASSETS; ?>/global/plugins/select2/css/select2-bootstrap.min.css" rel="stylesheet" type="text/css" />
 <link href="<?php echo ASSETS; ?>/global/plugins/bootstrap-sweetalert/sweetalert.css" rel="stylesheet" type="text/css" />



           <link href="<?php echo ASSETS; ?>/global/plugins/bootstrap-fileinput/bootstrap-fileinput.css" rel="stylesheet" type="text/css" />
        <!-- BEGIN THEME GLOBAL STYLES -->
        <link href="<?php echo ASSETS; ?>/global/css/components-md.min.css" rel="stylesheet" id="style_components" type="text/css" />
        <link href="<?php echo ASSETS; ?>/global/css/plugins-md.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo ASSETS; ?>/global/plugins/bootstrap-toastr/toastr.min.css" rel="stylesheet" type="text/css" />
        <!-- END THEME GLOBAL STYLES -->
        <!-- BEGIN THEME LAYOUT STYLES -->
        <link href="<?php echo ASSETS; ?>/layouts/layout/css/layout.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo ASSETS; ?>/layouts/layout/css/themes/darkblue.min.css" rel="stylesheet" type="text/css" id="style_color" />
        <link href="<?php echo ASSETS; ?>/layouts/layout/css/custom.min.css" rel="stylesheet" type="text/css" />
        <!-- END THEME LAYOUT STYLES -->
 <link rel="shortcut icon" href="<?php echo ASSETS; ?>/pages/img/refundmeico.png" /> </head>
    <!-- END HEAD -->

    <body class="page-header-fixed page-sidebar-closed-hide-logo page-content-white page-md">
        <div class="page-wrapper">
            <!-- BEGIN HEADER -->
             <div class="page-header navbar navbar-fixed-top">
                <!-- BEGIN HEADER INNER -->
                  <?php $this->load->view('common/header',''); ?>
                <!-- END HEADER INNER -->
            </div>
            <!-- END HEADER -->
            <!-- BEGIN HEADER & CONTENT DIVIDER -->
            <div class="clearfix"> </div>
            <!-- END HEADER & CONTENT DIVIDER -->
            <!-- BEGIN CONTAINER -->
            <div class="page-container">
                <!-- BEGIN SIDEBAR -->
                                 <?php $this->load->view('common/side_bar',''); ?>

                <!-- END SIDEBAR -->
                <!-- BEGIN CONTENT -->
                <div class="page-content-wrapper">
                    <!-- BEGIN CONTENT BODY -->
                    <div class="page-content">
                        <!-- BEGIN PAGE HEADER-->
                        <!-- BEGIN THEME PANEL -->
                         
                        <!-- END THEME PANEL -->
                        <!-- BEGIN PAGE BAR -->
                        <div class="page-bar">
                            <ul class="page-breadcrumb">
                              <li>
                                    <a href="<?php echo WEB_URL; ?>">Home</a>
                                    <i class="fa fa-circle"></i>
                                </li>
                                <li>
                                    <a href="#">Employee</a>
                                    <i class="fa fa-circle"></i>
                                </li> 
                                  <li>
                                    <a href="<?php echo WEB_URL; ?>/employee/list_all">List All</a>
                                    <i class="fa fa-circle"></i>
                                </li>
                                <li>
                                    <a href="">Edit Employee</a>
                                    <i class="fa fa-circle"></i>
                                </li>
                                
                            
                        </div>
                        <!-- END PAGE BAR -->
                        <!-- BEGIN PAGE TITLE-->
                        <h1 class="page-title"> Edit Employee
                         </h1>
                        <!-- END PAGE TITLE-->
                        <!-- END PAGE HEADER-->
                          <form class="form-horizontal "  action="<?php echo WEB_URL; ?>/employee_do/update_employee/<?php echo $emp_id; ?>" method="post"  id="form_sample_1" enctype="multipart/form-data">
                        <div class="row">
                            <div class="col-md-12">
                                <!-- BEGIN EXTRAS PORTLET-->
                                 <div class="col-md-6">
                                <div class="portlet light bordered">
                                     <div class="portlet-title">
                                        <div class="caption font-blue-soft">
                                            <i class="fa fa-user font-blue-soft"></i>
                                            <span class="caption-subject bold uppercase"> Employee Details</span>
                                        </div>
                                     </div>
                                    <div class="portlet-body form">
                                      
                                            <div class="form-body">
                                                <div class="form-group last">
                                                 <div class="col-md-12">
                                                      <div class="form-group form-md-line-input">
                                                    <label class="col-md-3 control-label" for="form_control_1">First Name                                                        <span class="required">*</span>
                                                    </label>
                                                    <div class="col-md-9">
                                                        <input type="text" class="form-control" placeholder="" name="first_name" value="<?php echo $result->first_name; ?>">
                                                        <div class="form-control-focus"> </div>
                                                    </div>
                                                </div>
                                                <div class="form-group form-md-line-input">
                                                    <label class="col-md-3 control-label" for="form_control_1">Last Name                                                        <span class="required">*</span>
                                                    </label>
                                                    <div class="col-md-9">
                                                        <input type="text" class="form-control" placeholder="" name="last_name" value="<?php echo $result->last_name; ?>">
                                                        <div class="form-control-focus"> </div>
                                                    </div>
                                                </div>
                                                 <div class="form-group form-md-line-input">
                                                    <label class="col-md-3 control-label" for="form_control_1">Department                                                       <span class="required">*</span>
                                                    </label>
                                                    <div class="col-md-9">
                                                        <select   class="form-control" name="department_id">
                                                            <option value="">Select</option>
                                                            <?php 
															if($department) {
																for($i=0;$i<count($department);$i++) { ?>
                                                            <option <?php if($department[$i]->department_id == $result->department_id) { echo 'selected'; }  ?> value="<?php echo $department[$i]->department_id; ?>"><?php echo $department[$i]->department_name; ?></option>
                                                            <?php
																}
															}
															?>
                                                        </select>
                                                        <div class="form-control-focus"> </div>
                                                    </div>
                                                </div>
                                                <div class="form-group form-md-line-input">
                                                    <label class="col-md-3 control-label" for="form_control_1">Legacy system Agent ID                                                        
                                                    </label>
                                                    <div class="col-md-9">
                                                        <input type="text"  class="form-control" name="agent_id" value="<?php echo $result->agent_id; ?>">
                                                             
                                                        <div class="form-control-focus"> </div>
                                                    </div>
                                                </div>
                                                 <div class="form-group form-md-line-input">
                                                    <label class="col-md-3 control-label" for="form_control_1">Job Title
                                                         
                                                    </label>
                                                    <div class="col-md-9">
                                                        <input type="text" class="form-control" placeholder="" name="job_title" value="<?php echo $result->job_title; ?>">
                                                        <div class="form-control-focus"> </div>
                                                    </div>
                                                </div>
                                                   <div class="form-group  form-md-line-input" style=" padding-left:20px">
                                                               <label class="col-md-3 control-label" for="form_control_1">Profile Piture
                                                        <span class="required">*</span>
                                                    </label>
                                                             <div class="col-md-9">  
                                                                <div class="fileinput fileinput-new" data-provides="fileinput">
                                                                    <div class="fileinput-new thumbnail" style="width: 150px; height: 150px;">
                                                                        <img src="<?php echo FILE_PATH.$result->profile_pic; ?>" alt="" /></div>
                                                                    <div class="fileinput-preview fileinput-exists thumbnail" style="max-width: 200px; max-height: 150px;"> </div>
                                                                    <div>
                                                                        <span class="btn default btn-file">
                                                                            <span class="fileinput-new"> Edit image </span>
                                                                            <span class="fileinput-exists"> Change </span>
                                                                            <input type="file"  name="avatar_file"> </span>
                                                                        <a href="javascript:;" class="btn default fileinput-exists" data-dismiss="fileinput"> Remove </a>
                                                                    </div>
                                                                </div>
													   </div>
                                                            </div>
                                                    </div>
                                                     
                                                </div>
                                                
                                            </div>
                                           
                                             
                                        
                                    </div>
                                </div>
								</div>
                                <div class="col-md-6">
                                <div class="portlet light bordered">
                                     <div class="portlet-title">
                                        <div class="caption font-blue-soft">
                                            <i class="fa fa-phone  font-blue-soft"></i>
                                            <span class="caption-subject bold uppercase"> Contact Details</span>
                                        </div>
                                         
                                    </div>
                                    <div class="portlet-body form">
                                         
                                            <div class="form-body">
                                                <div class="form-group last">
                                                 <div class="col-md-12">
                                                      <div class="form-group form-md-line-input">
                                                    <label class="col-md-3 control-label" for="form_control_1">Email Address
                                                        <span class="required">*</span>
                                                    </label>
                                                    <div class="col-md-9">
                                                        <input type="text" class="form-control" placeholder="" name="email_address" disabled value="<?php echo $result->email_address; ?>">
                                                        <div class="form-control-focus"> </div>
                                                    </div>
                                                </div>
                                                
                                                
                                                <div class="form-group form-md-line-input">
                                                    <label class="col-md-3 control-label" for="form_control_1">Contact Number
                                                        <span class="required">*</span>
                                                    </label>
                                                    <div class="col-md-9">
                                                        <input type="text" class="form-control" placeholder="" name="phone_number" value="<?php echo $result->phone_number; ?>">
                                                        <div class="form-control-focus"> </div>
                                                    </div>
                                                </div>
                                                <div class="form-group form-md-line-input">
                                                    <label class="col-md-3 control-label" for="form_control_1">Skype ID
                                                        <span class="required">*</span>
                                                    </label>
                                                    <div class="col-md-9">
                                                        <input type="text" class="form-control" placeholder="" name="skype_id" value="<?php echo $result->skype_id; ?>">
                                                        <div class="form-control-focus"> </div>
                                                    </div>
                                                </div>
                                               <div class="form-group form-md-line-input">
                                                    <label class="col-md-3 control-label" for="form_control_1">Note
                                                        <span class="required">*</span>
                                                    </label>
                                                    <div class="col-md-9">
														<textarea class="form-control" placeholder="" name="note_info"><?php echo $result->note_info; ?></textarea>  
                                                        <div class="form-control-focus"> </div>
                                                    </div>
                                                </div>
                                                    </div>
                                                     
                                                </div>
                                            </div>
                                           
                                             
                                       
                                    </div>
                                </div>

								</div>
                                     
                            </div>
                            <div class="col-md-12">
                                <!-- BEGIN EXTRAS PORTLET-->
                                 
                                
                               <div class="form-actions">
                                                <div class="row">
                                                    <div class="col-md-offset-2 col-md-10">
                                                    <input type="submit" class="btn green" value="Save Changes"> 
                                                    </div>
                                                </div>
                                            </div>
                            </div>
                             
                            	
                        </div>
                         </form>
                         
                    </div>
                    <!-- END CONTENT BODY -->
                </div>
                <!-- END CONTENT -->
                <!-- BEGIN QUICK SIDEBAR -->
                
                   <?php   $this->load->view('common/right_bar',''); ?>
                <!-- END QUICK SIDEBAR -->
            </div>
            <!-- END CONTAINER -->
            <!-- BEGIN FOOTER -->
                        <?php   $this->load->view('common/footer',''); ?>

            <!-- END FOOTER -->
        </div>
        <!-- BEGIN QUICK NAV -->
         <?php   $this->load->view('common/overlay',''); ?>
        <!-- END QUICK NAV -->
        <!--[if lt IE 9]>
<script src="<?php echo ASSETS; ?>/global/plugins/respond.min.js"></script>
<script src="<?php echo ASSETS; ?>/global/plugins/excanvas.min.js"></script> 
<script src="<?php echo ASSETS; ?>/global/plugins/ie8.fix.min.js"></script> 
<![endif]-->
        <!-- BEGIN CORE PLUGINS -->
        <script src="<?php echo ASSETS; ?>/global/plugins/jquery.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/js.cookie.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/jquery-slimscroll/jquery.slimscroll.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/jquery.blockui.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/bootstrap-switch/js/bootstrap-switch.min.js" type="text/javascript"></script>
         <script src="<?php echo ASSETS; ?>/global/plugins/bootstrap-fileinput/bootstrap-fileinput.js" type="text/javascript"></script>
      
        <!-- END CORE PLUGINS -->
        <!-- BEGIN PAGE LEVEL PLUGINS -->
        <script src="<?php echo ASSETS; ?>/global/plugins/bootstrap-wysihtml5/wysihtml5-0.3.0.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/bootstrap-wysihtml5/bootstrap-wysihtml5.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/bootstrap-markdown/lib/markdown.js" type="text/javascript"></script>
        <script src="./<?php echo ASSETS; ?>/global/plugins/bootstrap-markdown/js/bootstrap-markdown.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/bootstrap-summernote/summernote.min.js" type="text/javascript"></script>
        <!-- END PAGE LEVEL PLUGINS -->
        <!-- BEGIN THEME GLOBAL SCRIPTS -->
        <script src="<?php echo ASSETS; ?>/global/scripts/app.min.js" type="text/javascript"></script>
        <script>
	 var FormValidationMd = function() {

    var handleValidation1 = function() {
        // for more info visit the official plugin documentation: 
        // http://docs.jquery.com/Plugins/Validation
        var form1 = $('#form_sample_1');
        var error1 = $('.alert-danger', form1);
        var success1 = $('.alert-success', form1);
		

        form1.validate({
            errorElement: 'span', //default input error message container
            errorClass: 'help-block help-block-error', // default input error message class
            focusInvalid: false, // do not focus the last invalid input
            ignore: "", // validate all fields including form hidden input
            messages: { },
            rules: {
                first_name	: {
                    minlength: 4,
                    required: true
                },
				last_name	: {
                    minlength: 3,
                    required: true
                },
				department_id	: {
                   
                    required: true
                },
				 
				 email_address: {
					  
					required:true 
				 },
				  
                phone_number: {
                  
					number:  true
                } 
				  
				 
            },
        errorPlacement: function(error, element) {
                if (element.is(':checkbox')) {
                    error.insertAfter(element.closest(".md-checkbox-list, .md-checkbox-inline, .checkbox-list, .checkbox-inline"));
                } else if (element.is(':radio')) {
                    error.insertAfter(element.closest(".md-radio-list, .md-radio-inline, .radio-list,.radio-inline"));
                } else {
                    error.insertAfter(element); // for other inputs, just perform default behavior
                }
            },

            highlight: function(element) { // hightlight error inputs
                $(element)
                    .closest('.form-group').addClass('has-error'); // set error class to the control group
            },

            unhighlight: function(element) { // revert the change done by hightlight
                $(element)
                    .closest('.form-group').removeClass('has-error'); // set error class to the control group
            },

            success: function(label) {
				 
                label
                    .closest('.form-group').removeClass('has-error'); // set success class to the control group
            }
        });
		$('#form_sample_2').validate({ });
    }
 

    return {
        //main function to initiate the module
        init: function() {
            handleValidation1(); 
        }
    };
}();

jQuery(document).ready(function() {
    FormValidationMd.init();
});
	 
		$(document).ready(function(){
			
			$("#checkbox_all").on("click", function()
								  {
			 
			 $('input:checkbox').not(this).prop('checked', this.checked);
				 
			});
			
		toastr.options = {
		    "closeButton": false,
  "debug": false,
  "newestOnTop": false,
  "progressBar": false,
  "positionClass": "toast-bottom-right",
  "preventDuplicates": false,
  "onclick": null,
  "showDuration": "300",
  "hideDuration": "1000",
  "timeOut": "5000",
  "extendedTimeOut": "1000",
  "showEasing": "swing",
  "hideEasing": "linear",
  "showMethod": "fadeIn",
  "hideMethod": "fadeOut",
  "body-output-type": "trustedHtml"
		};
		 <?php   if(isset($page_data->msg_type)) { ?>
		toastr.<?php  echo $page_data->msg_type;  ?>("<?php echo $page_data->msg;  ?>");
		<?php }  ?>
		 

		});
</script>

         <script src="<?php echo ASSETS; ?>/global/plugins/jquery-validation/js/jquery.validate.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/jquery-validation/js/additional-methods.min.js" type="text/javascript"></script>
        <!-- END THEME GLOBAL SCRIPTS -->
        <!-- BEGIN PAGE LEVEL SCRIPTS -->
        <script src="<?php echo ASSETS; ?>/pages/scripts/components-editors.min.js" type="text/javascript"></script>
        <!-- END PAGE LEVEL SCRIPTS -->
        <!-- BEGIN THEME LAYOUT SCRIPTS --><script src="<?php echo ASSETS; ?>/global/plugins/select2/js/select2.full.min.js" type="text/javascript"></script>
<script src="<?php echo ASSETS; ?>/pages/scripts/components-select2.min.js" type="text/javascript"></script>
 <script src="<?php echo ASSETS; ?>/pages/scripts/overlaymessage.js" type="text/javascript"></script>


         
        <script src="<?php echo ASSETS; ?>/layouts/layout/scripts/layout.min.js" type="text/javascript"></script>
         <script src="<?php echo ASSETS; ?>/global/plugins/bootstrap-toastr/toastr.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/layouts/layout/scripts/demo.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/layouts/global/scripts/quick-sidebar.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/layouts/global/scripts/quick-nav.min.js" type="text/javascript"></script>
        <!-- END THEME LAYOUT SCRIPTS -->
        
<script src="<?php echo ASSETS.'/pages/scripts/appconnect.js'; ?>"></script>
    </body>

</html>