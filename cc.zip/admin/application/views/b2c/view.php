<!DOCTYPE html>
<!-- 
Template Name: Metronic - Responsive Admin Dashboard Template build with Twitter Bootstrap 3.3.7
Version: 4.7.1
Author: KeenThemes
Website: http://www.keenthemes.com/
Contact: support@keenthemes.com
Follow: www.twitter.com/keenthemes
Dribbble: www.dribbble.com/keenthemes
Like: www.facebook.com/keenthemes
Purchase: http://themeforest.net/item/metronic-responsive-admin-dashboard-template/4021469?ref=keenthemes
Renew Support: http://themeforest.net/item/metronic-responsive-admin-dashboard-template/4021469?ref=keenthemes
License: You must have a valid license purchased only from themeforest(the above link) in order to legally use the theme for your project.
-->
<!--[if IE 8]> <html lang="en" class="ie8 no-js"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9 no-js"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en">
    <!--<![endif]-->
    <!-- BEGIN HEAD -->

    <head>
        <meta charset="utf-8" />
       <title><?php echo PROJECT_TITLE; ?></title>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta content="width=device-width, initial-scale=1" name="viewport" />
          <meta content="Flight is canceled, delayed or missed connecting flight ? Up to 600 € compensation received ✓ 98% success rate ✓ More than 120 countries ✓ Check your claim!" name="description" />
        <meta content="" name="author" />
        <!-- BEGIN GLOBAL MANDATORY STYLES -->
        <link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700&subset=all" rel="stylesheet" type="text/css" />
        <link href="<?php echo ASSETS; ?>/global/plugins/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo ASSETS; ?>/global/plugins/simple-line-icons/simple-line-icons.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo ASSETS; ?>/global/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo ASSETS; ?>/global/plugins/bootstrap-switch/css/bootstrap-switch.min.css" rel="stylesheet" type="text/css" />
        <!-- END GLOBAL MANDATORY STYLES -->
		
		<link href="<?php echo ASSETS; ?>/global/plugins/datatables/datatables.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo ASSETS; ?>/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap.css" rel="stylesheet" type="text/css" />
		
        <!-- BEGIN PAGE LEVEL PLUGINS -->
               <link href="<?php echo ASSETS; ?>/global/plugins/select2/css/select2.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo ASSETS; ?>/global/plugins/select2/css/select2-bootstrap.min.css" rel="stylesheet" type="text/css" />
               <link href="<?php echo ASSETS; ?>/global/plugins/bootstrap-fileinput/bootstrap-fileinput.css" rel="stylesheet" type="text/css" />
 <link href="<?php echo ASSETS; ?>/global/plugins/bootstrap-sweetalert/sweetalert.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo ASSETS; ?>/global/plugins/bootstrap-fileinput/bootstrap-fileinput.css" rel="stylesheet" type="text/css" />
        <!-- END PAGE LEVEL PLUGINS -->
        <!-- BEGIN THEME GLOBAL STYLES -->
        <link href="<?php echo ASSETS; ?>/global/css/components-md.min.css" rel="stylesheet" id="style_components" type="text/css" />
        <link href="<?php echo ASSETS; ?>/global/css/plugins-md.min.css" rel="stylesheet" type="text/css" />
        <!-- END THEME GLOBAL STYLES -->
        <!-- BEGIN PAGE LEVEL STYLES -->
        <link href="<?php echo ASSETS; ?>/pages/css/profile.min.css" rel="stylesheet" type="text/css" />
        <!-- END PAGE LEVEL STYLES -->
        <!-- BEGIN THEME LAYOUT STYLES -->
        <link href="<?php echo ASSETS; ?>/layouts/layout/css/layout.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo ASSETS; ?>/layouts/layout/css/themes/darkblue.min.css" rel="stylesheet" type="text/css" id="style_color" />
        <link href="<?php echo ASSETS; ?>/layouts/layout/css/custom.min.css" rel="stylesheet" type="text/css" />
        <!-- END THEME LAYOUT STYLES -->
		<link rel="shortcut icon" href="<?php echo ASSETS; ?>/pages/img/refundmeico.png" /></head>
    <!-- END HEAD -->

    <body class="page-header-fixed page-sidebar-closed-hide-logo page-content-white page-md">
        <div class="page-wrapper">
            <!-- BEGIN HEADER -->
            <div class="page-header navbar navbar-fixed-top">
                <!-- BEGIN HEADER INNER -->
                  <?php $this->load->view('common/header',''); ?>
                <!-- END HEADER INNER -->
            </div>
            <!-- END HEADER -->
            <!-- BEGIN HEADER & CONTENT DIVIDER -->
            <div class="clearfix"> </div>
            <!-- END HEADER & CONTENT DIVIDER -->
            <!-- BEGIN CONTAINER -->
            <div class="page-container">
                <!-- BEGIN SIDEBAR -->
                 <?php $this->load->view('common/side_bar',''); ?> 
                <!-- END SIDEBAR -->
                <!-- BEGIN CONTENT -->
                <div class="page-content-wrapper">
                    <!-- BEGIN CONTENT BODY -->
                    <div class="page-content">
                        <!-- BEGIN PAGE HEADER-->
                        <!-- BEGIN THEME PANEL -->
                         
                        <!-- END THEME PANEL -->
                        <!-- BEGIN PAGE BAR -->
                        <div class="page-bar">
                              <ul class="page-breadcrumb">
                              <li>
                                    <a href="<?php echo WEB_URL; ?>">Home</a>
                                    <i class="fa fa-circle"></i>
                                </li>
                                <li>
                                    <a href="#">Users</a>
                                    <i class="fa fa-circle"></i>
                                </li> 
                                  <li>
                                    <a href="<?php echo WEB_URL; ?>/employee/list_all">List All</a>
                                    <i class="fa fa-circle"></i>
                                </li>
                                <li>
                                    <a href="">Edit Users</a>
                                    <i class="fa fa-circle"></i>
                                </li>
                                
							</ul>
                         
                        </div>
                        <!-- END PAGE BAR -->
                        <!-- BEGIN PAGE TITLE-->
                        <h1 class="page-title"> <?php echo $result->user_code; ?>
                            <small></small>
                        </h1>
                        <!-- END PAGE TITLE-->
                        <!-- END PAGE HEADER-->
                        <div class="row">
                            <div class="col-md-12">
                                <!-- BEGIN PROFILE SIDEBAR -->
                                <div class="profile-sidebar">
                                    <!-- PORTLET MAIN -->
                                    <div class="portlet light profile-sidebar-portlet ">
                                        <!-- SIDEBAR USERPIC -->
                                        <div class="profile-userpic">
                                            <img src="<?php echo FILE_PATH.$result->profile_pic; ?>" class="img-responsive" alt=""> </div>
                                        <!-- END SIDEBAR USERPIC -->
                                        <!-- SIDEBAR USER TITLE -->
                                        <div class="profile-usertitle">
                                            <div class="profile-usertitle-name">  <?php echo $result->first_name; ?> <?php echo $result->last_name; ?> </div>
                                            <div class="profile-usertitle-job"> <?php echo $result->user_code; ?> </div>
                                        </div>
                                        <!-- END SIDEBAR USER TITLE -->
                                        <!-- SIDEBAR BUTTONS -->
                                        <div class="profile-userbuttons">
                                            <button type="button" class="btn btn-circle green-jungle btn-sm"><?php echo $result->email_address; ?></button>
                                            <button type="button" class="btn btn-circle red btn-sm"><?php echo $result->phone_number; ?></button>
                                        </div>
                                        <!-- END SIDEBAR BUTTONS -->
                                        <!-- SIDEBAR MENU -->
                                        <div class="profile-usermenu">
                                            <ul class="nav">
                                                <li class="active left_nav" onclick="switchView('overview', this)">
                                                    <a href="javascript:;">
                                                        <i class="icon-home"></i> Overview </a>
                                                </li>
                                                <li class="left_nav" onclick="switchView('credit_points', this)">
                                                    <a href="javascript:;">
                                                        <i class="icon-settings"></i> Credit Points </a>
                                                </li>
                                                <li class="left_nav" onclick="switchView('flights_under_observation', this)">
                                                    <a href="javascript:;">
                                                        <i class="icon-info"></i> Flights Under Observation  </a>
                                                </li>
                                                <li class="left_nav" onclick="switchView('flights_history', this)">
                                                    <a href="javascript:;">
                                                        <i class="icon-info"></i> Flights History  </a>
                                                </li>
                                            </ul>
                                        </div>
                                        <!-- END MENU -->
                                    </div>
                                    <!-- END PORTLET MAIN -->
                                    <!-- PORTLET MAIN -->
                                    <div class="portlet light ">
                                        <!-- STAT -->
                                        <div class="row list-separated profile-stat">
                                            <div class="col-md-4 col-sm-4 col-xs-6">
                                                <div class="uppercase profile-stat-title"> <?php echo !empty($total_generic_hits) ? $total_generic_hits : 0 ?> </div>
                                                <div class="uppercase profile-stat-text"> Generic Preview </div>
                                            </div>
                                            <div class="col-md-4 col-sm-4 col-xs-6">
                                                <div class="uppercase profile-stat-title"> <?php echo !empty($total_paid_hits) ? $total_paid_hits : 0 ?> </div>
                                                <div class="uppercase profile-stat-text"> One Time Preview </div>
                                            </div>
                                            <div class="col-md-4 col-sm-4 col-xs-6">
                                                <div class="uppercase profile-stat-title"> 61 </div>
                                                <div class="uppercase profile-stat-text">Registered Flight </div>
                                            </div>
                                        </div>
                                        <!-- END STAT -->
                                        <div>
                                            <h4 class="profile-desc-title">About <?php echo $result->first_name; ?></h4>
                                            <span class="profile-desc-text"> <?php echo $result->street; ?>
                                            <br/><?php echo $result->state; ?><br/><?php echo $result->city; ?> </span>
                                            <div class="margin-top-20 profile-desc-link">
                                                <i class="fa fa-globe"></i>
                                                <a href=""><?php echo $result->country; ?></a>
                                            </div>
                                            <div class="margin-top-20 profile-desc-link">
                                                <i class="fa fa-location-arrow"></i>
                                                <a href=""><?php echo $result->postal_code; ?></a>
                                            </div>
                                            <div class="margin-top-20 profile-desc-link">
                                                <i class="fa fa-clock-o"></i>
                                                <a href=""><?php echo $result->created_timestamp; ?></a>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- END PORTLET MAIN -->
                                </div>
                                <!-- END BEGIN PROFILE SIDEBAR -->
                                <!-- BEGIN PROFILE CONTENT -->
                                <div class="profile-content" id="overview_view">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <!-- BEGIN PORTLET -->
                                            <div class="portlet light ">
                                                <div class="portlet-title">
                                                    <div class="caption caption-md">
                                                        <i class="icon-bar-chart theme-font hide"></i>
                                                        <span class="caption-subject font-blue-madison bold uppercase">Credit Points</span>
                                                        <span class="caption-helper hide">weekly stats...</span>
                                                    </div>
                                                    <div class="actions">
                                                        <div class="btn-group btn-group-devided" data-toggle="buttons">
                                                             View All
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="portlet-body">
                                                    <div class="row number-stats margin-bottom-30">
                                                        <div class="col-md-6 col-sm-6 col-xs-6">
                                                            <div class="stat-left">
                                                                <div class="stat-chart">
                                                                    <!-- do not line break "sparkline_bar" div. sparkline chart has an issue when the container div has line break -->
                                                                    <div id="generic_bar"></div>
                                                                </div>
                                                                <div class="stat-number">
                                                                    <div class="title"> Generic Hits </div>
                                                                    <div class="number"> <?php echo !empty($generic_hits) ? $generic_hits : 0 ; ?> </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6 col-sm-6 col-xs-6">
                                                            <div class="stat-right">
                                                                <div class="stat-chart">
                                                                    <!-- do not line break "sparkline_bar" div. sparkline chart has an issue when the container div has line break -->
                                                                    <div id="paid_bar"></div>
                                                                </div>
                                                                <div class="stat-number">
                                                                    <div class="title"> Paid Hits </div>
                                                                    <div class="number"> <?php echo !empty($paid_hits) ? $paid_hits : 0 ; ?> </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="table-scrollable table-scrollable-borderless">
                                                        <table class="table table-hover table-light">
                                                            <thead>
                                                                <tr class="uppercase">
                                                                    <th> Mode </th>
                                                                    <th> Type </th>
                                                                    <th> Credit Points </th>
                                                                    <th> At </th>
                                                                </tr>
                                                            </thead>
															<?php foreach( $credit_points_info as $credit_points_table ) { ?>
																<tr>
																	<td>
																		<?php echo $credit_points_table->transaction_mode; ?>
																	</td>
																	<td>
																		<?php echo $credit_points_table->credit_points_charge_type; ?>
																	</td>
																	 
																	<td> 
																		<?php echo $credit_points_table->user_credit_points_value; ?>
																	</td>
																	<td>
																		<span class="bold theme-font"> <?php echo $this->general_model->get_date_time_diff('', $credit_points_table->created_timestamp); ?> </span>
																	</td>
																</tr>
															<?php } ?>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- END PORTLET -->
                                        </div>
                                        <div class="col-md-6">
                                            <!-- BEGIN PORTLET -->
                                            <div class="portlet light bordered">
												<div class="portlet-title">
																<div class="caption caption-md">
																	<i class="icon-bar-chart theme-font hide"></i>
																	<span class="caption-subject font-blue-madison bold uppercase">Recent Hits</span>
																	<span class="caption-helper hide">weekly stats...</span>
																</div>
																<div class="actions">
																	<div class="btn-group btn-group-devided" data-toggle="buttons">
																		 View All
																	</div>
																</div>
															</div>
												<div class="portlet-body">
													<div id="site_statistics_loading">
														<img src="<?php echo ASSETS; ?>/global/img/loading.gif" alt="loading" /> </div>
													<div id="site_statistics_content" class="display-none">
														<div id="site_statistics" class="chart"> </div>
													</div>
												</div>
											</div>
                                            
                                            <!-- END PORTLET -->
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <!-- BEGIN PORTLET -->
                                            <div class="portlet light ">
                                                <div class="portlet-title">
                                                    <div class="caption caption-md">
                                                        <i class="icon-bar-chart theme-font hide"></i>
                                                        <span class="caption-subject font-blue-madison bold uppercase">Customer Support</span>
                                                        <span class="caption-helper">45 pending</span>
                                                    </div>
                                                    <div class="inputs">
                                                        <div class="portlet-input input-inline input-small ">
                                                            <div class="input-icon right">
                                                                <i class="icon-magnifier"></i>
                                                                <input type="text" class="form-control form-control-solid" placeholder="search..."> </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="portlet-body">
                                                    <div class="scroller" style="height: 305px;" data-always-visible="1" data-rail-visible1="0" data-handle-color="#D7DCE2">
                                                        <div class="general-item-list">
                                                            <div class="item">
                                                                <div class="item-head">
                                                                    <div class="item-details">
                                                                        <img class="item-pic" src="<?php echo ASSETS; ?>/pages/media/users/avatar4.jpg">
                                                                        <a href="" class="item-name primary-link">Nick Larson</a>
                                                                        <span class="item-label">3 hrs ago</span>
                                                                    </div>
                                                                    <span class="item-status">
                                                                        <span class="badge badge-empty badge-success"></span> Open</span>
                                                                </div>
                                                                <div class="item-body"> Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. </div>
                                                            </div>
                                                            <div class="item">
                                                                <div class="item-head">
                                                                    <div class="item-details">
                                                                        <img class="item-pic" src="<?php echo ASSETS; ?>/pages/media/users/avatar3.jpg">
                                                                        <a href="" class="item-name primary-link">Mark</a>
                                                                        <span class="item-label">5 hrs ago</span>
                                                                    </div>
                                                                    <span class="item-status">
                                                                        <span class="badge badge-empty badge-warning"></span> Pending</span>
                                                                </div>
                                                                <div class="item-body"> Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat tincidunt ut laoreet. </div>
                                                            </div>
                                                            <div class="item">
                                                                <div class="item-head">
                                                                    <div class="item-details">
                                                                        <img class="item-pic" src="<?php echo ASSETS; ?>/pages/media/users/avatar6.jpg">
                                                                        <a href="" class="item-name primary-link">Nick Larson</a>
                                                                        <span class="item-label">8 hrs ago</span>
                                                                    </div>
                                                                    <span class="item-status">
                                                                        <span class="badge badge-empty badge-primary"></span> Closed</span>
                                                                </div>
                                                                <div class="item-body"> Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh. </div>
                                                            </div>
                                                            <div class="item">
                                                                <div class="item-head">
                                                                    <div class="item-details">
                                                                        <img class="item-pic" src="<?php echo ASSETS; ?>/pages/media/users/avatar7.jpg">
                                                                        <a href="" class="item-name primary-link">Nick Larson</a>
                                                                        <span class="item-label">12 hrs ago</span>
                                                                    </div>
                                                                    <span class="item-status">
                                                                        <span class="badge badge-empty badge-danger"></span> Pending</span>
                                                                </div>
                                                                <div class="item-body"> Consectetuer adipiscing elit Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. </div>
                                                            </div>
                                                            <div class="item">
                                                                <div class="item-head">
                                                                    <div class="item-details">
                                                                        <img class="item-pic" src="<?php echo ASSETS; ?>/pages/media/users/avatar9.jpg">
                                                                        <a href="" class="item-name primary-link">Richard Stone</a>
                                                                        <span class="item-label">2 days ago</span>
                                                                    </div>
                                                                    <span class="item-status">
                                                                        <span class="badge badge-empty badge-danger"></span> Open</span>
                                                                </div>
                                                                <div class="item-body"> Lorem ipsum dolor sit amet, consectetuer adipiscing elit, ut laoreet dolore magna aliquam erat volutpat. </div>
                                                            </div>
                                                            <div class="item">
                                                                <div class="item-head">
                                                                    <div class="item-details">
                                                                        <img class="item-pic" src="<?php echo ASSETS; ?>/pages/media/users/avatar8.jpg">
                                                                        <a href="" class="item-name primary-link">Dan</a>
                                                                        <span class="item-label">3 days ago</span>
                                                                    </div>
                                                                    <span class="item-status">
                                                                        <span class="badge badge-empty badge-warning"></span> Pending</span>
                                                                </div>
                                                                <div class="item-body"> Lorem ipsum dolor sit amet, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. </div>
                                                            </div>
                                                            <div class="item">
                                                                <div class="item-head">
                                                                    <div class="item-details">
                                                                        <img class="item-pic" src="<?php echo ASSETS; ?>/pages/media/users/avatar2.jpg">
                                                                        <a href="" class="item-name primary-link">Larry</a>
                                                                        <span class="item-label">4 hrs ago</span>
                                                                    </div>
                                                                    <span class="item-status">
                                                                        <span class="badge badge-empty badge-success"></span> Open</span>
                                                                </div>
                                                                <div class="item-body"> Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- END PORTLET -->
                                        </div>
                                        <div class="col-md-6">
                                         <div class="portlet light ">
                                                <div class="portlet-title tabbable-line">
                                                    <div class="caption caption-md">
                                                        <i class="icon-globe theme-font hide"></i>
                                                        <span class="caption-subject font-blue-madison bold uppercase">Feeds</span>
                                                    </div>
                                                    <ul class="nav nav-tabs">
                                                        <li class="active">
                                                            <a href="#tab_1_1" data-toggle="tab"> System </a>
                                                        </li>
                                                        <li>
                                                            <a href="#tab_1_2" data-toggle="tab"> Activities </a>
                                                        </li>
                                                    </ul>
                                                </div>
                                                <div class="portlet-body">
                                                    <!--BEGIN TABS-->
                                                    <div class="tab-content">
                                                        <div class="tab-pane active" id="tab_1_1">
                                                            <div class="scroller" style="height: 320px;" data-always-visible="1" data-rail-visible1="0" data-handle-color="#D7DCE2">
                                                                <ul class="feeds">
                                                                    <li>
                                                                        <div class="col1">
                                                                            <div class="cont">
                                                                                <div class="cont-col1">
                                                                                    <div class="label label-sm label-success">
                                                                                        <i class="fa fa-bell-o"></i>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="cont-col2">
                                                                                    <div class="desc"> You have 4 pending tasks.
                                                                                        <span class="label label-sm label-info"> Take action
                                                                                            <i class="fa fa-share"></i>
                                                                                        </span>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="col2">
                                                                            <div class="date"> Just now </div>
                                                                        </div>
                                                                    </li>
                                                                    <li>
                                                                        <a href="javascript:;">
                                                                            <div class="col1">
                                                                                <div class="cont">
                                                                                    <div class="cont-col1">
                                                                                        <div class="label label-sm label-success">
                                                                                            <i class="fa fa-bell-o"></i>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="cont-col2">
                                                                                        <div class="desc"> New version v1.4 just lunched! </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="col2">
                                                                                <div class="date"> 20 mins </div>
                                                                            </div>
                                                                        </a>
                                                                    </li>
                                                                    <li>
                                                                        <div class="col1">
                                                                            <div class="cont">
                                                                                <div class="cont-col1">
                                                                                    <div class="label label-sm label-danger">
                                                                                        <i class="fa fa-bolt"></i>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="cont-col2">
                                                                                    <div class="desc"> Database server #12 overloaded. Please fix the issue. </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="col2">
                                                                            <div class="date"> 24 mins </div>
                                                                        </div>
                                                                    </li>
                                                                    <li>
                                                                        <div class="col1">
                                                                            <div class="cont">
                                                                                <div class="cont-col1">
                                                                                    <div class="label label-sm label-info">
                                                                                        <i class="fa fa-bullhorn"></i>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="cont-col2">
                                                                                    <div class="desc"> New order received and pending for process. </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="col2">
                                                                            <div class="date"> 30 mins </div>
                                                                        </div>
                                                                    </li>
                                                                    <li>
                                                                        <div class="col1">
                                                                            <div class="cont">
                                                                                <div class="cont-col1">
                                                                                    <div class="label label-sm label-success">
                                                                                        <i class="fa fa-bullhorn"></i>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="cont-col2">
                                                                                    <div class="desc"> New payment refund and pending approval. </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="col2">
                                                                            <div class="date"> 40 mins </div>
                                                                        </div>
                                                                    </li>
                                                                    <li>
                                                                        <div class="col1">
                                                                            <div class="cont">
                                                                                <div class="cont-col1">
                                                                                    <div class="label label-sm label-warning">
                                                                                        <i class="fa fa-plus"></i>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="cont-col2">
                                                                                    <div class="desc"> New member registered. Pending approval. </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="col2">
                                                                            <div class="date"> 1.5 hours </div>
                                                                        </div>
                                                                    </li>
                                                                    <li>
                                                                        <div class="col1">
                                                                            <div class="cont">
                                                                                <div class="cont-col1">
                                                                                    <div class="label label-sm label-success">
                                                                                        <i class="fa fa-bell-o"></i>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="cont-col2">
                                                                                    <div class="desc"> Web server hardware needs to be upgraded.
                                                                                        <span class="label label-sm label-default "> Overdue </span>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="col2">
                                                                            <div class="date"> 2 hours </div>
                                                                        </div>
                                                                    </li>
                                                                    <li>
                                                                        <div class="col1">
                                                                            <div class="cont">
                                                                                <div class="cont-col1">
                                                                                    <div class="label label-sm label-default">
                                                                                        <i class="fa fa-bullhorn"></i>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="cont-col2">
                                                                                    <div class="desc"> Prod01 database server is overloaded 90%. </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="col2">
                                                                            <div class="date"> 3 hours </div>
                                                                        </div>
                                                                    </li>
                                                                    <li>
                                                                        <div class="col1">
                                                                            <div class="cont">
                                                                                <div class="cont-col1">
                                                                                    <div class="label label-sm label-warning">
                                                                                        <i class="fa fa-bullhorn"></i>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="cont-col2">
                                                                                    <div class="desc"> New group created. Pending manager review. </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="col2">
                                                                            <div class="date"> 5 hours </div>
                                                                        </div>
                                                                    </li>
                                                                    <li>
                                                                        <div class="col1">
                                                                            <div class="cont">
                                                                                <div class="cont-col1">
                                                                                    <div class="label label-sm label-info">
                                                                                        <i class="fa fa-bullhorn"></i>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="cont-col2">
                                                                                    <div class="desc"> Order payment failed. </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="col2">
                                                                            <div class="date"> 18 hours </div>
                                                                        </div>
                                                                    </li>
                                                                    <li>
                                                                        <div class="col1">
                                                                            <div class="cont">
                                                                                <div class="cont-col1">
                                                                                    <div class="label label-sm label-default">
                                                                                        <i class="fa fa-bullhorn"></i>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="cont-col2">
                                                                                    <div class="desc"> New application received. </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="col2">
                                                                            <div class="date"> 21 hours </div>
                                                                        </div>
                                                                    </li>
                                                                    <li>
                                                                        <div class="col1">
                                                                            <div class="cont">
                                                                                <div class="cont-col1">
                                                                                    <div class="label label-sm label-info">
                                                                                        <i class="fa fa-bullhorn"></i>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="cont-col2">
                                                                                    <div class="desc"> Dev90 web server restarted. Pending overall system check. </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="col2">
                                                                            <div class="date"> 22 hours </div>
                                                                        </div>
                                                                    </li>
                                                                    <li>
                                                                        <div class="col1">
                                                                            <div class="cont">
                                                                                <div class="cont-col1">
                                                                                    <div class="label label-sm label-default">
                                                                                        <i class="fa fa-bullhorn"></i>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="cont-col2">
                                                                                    <div class="desc"> New member registered. Pending approval </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="col2">
                                                                            <div class="date"> 21 hours </div>
                                                                        </div>
                                                                    </li>
                                                                    <li>
                                                                        <div class="col1">
                                                                            <div class="cont">
                                                                                <div class="cont-col1">
                                                                                    <div class="label label-sm label-info">
                                                                                        <i class="fa fa-bullhorn"></i>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="cont-col2">
                                                                                    <div class="desc"> L45 Network failure. Schedule maintenance. </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="col2">
                                                                            <div class="date"> 22 hours </div>
                                                                        </div>
                                                                    </li>
                                                                    <li>
                                                                        <div class="col1">
                                                                            <div class="cont">
                                                                                <div class="cont-col1">
                                                                                    <div class="label label-sm label-default">
                                                                                        <i class="fa fa-bullhorn"></i>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="cont-col2">
                                                                                    <div class="desc"> Order canceled with failed payment. </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="col2">
                                                                            <div class="date"> 21 hours </div>
                                                                        </div>
                                                                    </li>
                                                                    <li>
                                                                        <div class="col1">
                                                                            <div class="cont">
                                                                                <div class="cont-col1">
                                                                                    <div class="label label-sm label-info">
                                                                                        <i class="fa fa-bullhorn"></i>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="cont-col2">
                                                                                    <div class="desc"> Web-A2 clound instance created. Schedule full scan. </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="col2">
                                                                            <div class="date"> 22 hours </div>
                                                                        </div>
                                                                    </li>
                                                                    <li>
                                                                        <div class="col1">
                                                                            <div class="cont">
                                                                                <div class="cont-col1">
                                                                                    <div class="label label-sm label-default">
                                                                                        <i class="fa fa-bullhorn"></i>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="cont-col2">
                                                                                    <div class="desc"> Member canceled. Schedule account review. </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="col2">
                                                                            <div class="date"> 21 hours </div>
                                                                        </div>
                                                                    </li>
                                                                    <li>
                                                                        <div class="col1">
                                                                            <div class="cont">
                                                                                <div class="cont-col1">
                                                                                    <div class="label label-sm label-info">
                                                                                        <i class="fa fa-bullhorn"></i>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="cont-col2">
                                                                                    <div class="desc"> New order received. Please take care of it. </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="col2">
                                                                            <div class="date"> 22 hours </div>
                                                                        </div>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                        <div class="tab-pane" id="tab_1_2">
                                                            <div class="scroller" style="height: 337px;" data-always-visible="1" data-rail-visible1="0" data-handle-color="#D7DCE2">
                                                                <ul class="feeds">
                                                                    <li>
                                                                        <a href="javascript:;">
                                                                            <div class="col1">
                                                                                <div class="cont">
                                                                                    <div class="cont-col1">
                                                                                        <div class="label label-sm label-success">
                                                                                            <i class="fa fa-bell-o"></i>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="cont-col2">
                                                                                        <div class="desc"> New user registered </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="col2">
                                                                                <div class="date"> Just now </div>
                                                                            </div>
                                                                        </a>
                                                                    </li>
                                                                    <li>
                                                                        <a href="javascript:;">
                                                                            <div class="col1">
                                                                                <div class="cont">
                                                                                    <div class="cont-col1">
                                                                                        <div class="label label-sm label-success">
                                                                                            <i class="fa fa-bell-o"></i>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="cont-col2">
                                                                                        <div class="desc"> New order received </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="col2">
                                                                                <div class="date"> 10 mins </div>
                                                                            </div>
                                                                        </a>
                                                                    </li>
                                                                    <li>
                                                                        <div class="col1">
                                                                            <div class="cont">
                                                                                <div class="cont-col1">
                                                                                    <div class="label label-sm label-danger">
                                                                                        <i class="fa fa-bolt"></i>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="cont-col2">
                                                                                    <div class="desc"> Order #24DOP4 has been rejected.
                                                                                        <span class="label label-sm label-danger "> Take action
                                                                                            <i class="fa fa-share"></i>
                                                                                        </span>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="col2">
                                                                            <div class="date"> 24 mins </div>
                                                                        </div>
                                                                    </li>
                                                                    <li>
                                                                        <a href="javascript:;">
                                                                            <div class="col1">
                                                                                <div class="cont">
                                                                                    <div class="cont-col1">
                                                                                        <div class="label label-sm label-success">
                                                                                            <i class="fa fa-bell-o"></i>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="cont-col2">
                                                                                        <div class="desc"> New user registered </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="col2">
                                                                                <div class="date"> Just now </div>
                                                                            </div>
                                                                        </a>
                                                                    </li>
                                                                    <li>
                                                                        <a href="javascript:;">
                                                                            <div class="col1">
                                                                                <div class="cont">
                                                                                    <div class="cont-col1">
                                                                                        <div class="label label-sm label-success">
                                                                                            <i class="fa fa-bell-o"></i>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="cont-col2">
                                                                                        <div class="desc"> New user registered </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="col2">
                                                                                <div class="date"> Just now </div>
                                                                            </div>
                                                                        </a>
                                                                    </li>
                                                                    <li>
                                                                        <a href="javascript:;">
                                                                            <div class="col1">
                                                                                <div class="cont">
                                                                                    <div class="cont-col1">
                                                                                        <div class="label label-sm label-success">
                                                                                            <i class="fa fa-bell-o"></i>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="cont-col2">
                                                                                        <div class="desc"> New user registered </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="col2">
                                                                                <div class="date"> Just now </div>
                                                                            </div>
                                                                        </a>
                                                                    </li>
                                                                    <li>
                                                                        <a href="javascript:;">
                                                                            <div class="col1">
                                                                                <div class="cont">
                                                                                    <div class="cont-col1">
                                                                                        <div class="label label-sm label-success">
                                                                                            <i class="fa fa-bell-o"></i>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="cont-col2">
                                                                                        <div class="desc"> New user registered </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="col2">
                                                                                <div class="date"> Just now </div>
                                                                            </div>
                                                                        </a>
                                                                    </li>
                                                                    <li>
                                                                        <a href="javascript:;">
                                                                            <div class="col1">
                                                                                <div class="cont">
                                                                                    <div class="cont-col1">
                                                                                        <div class="label label-sm label-success">
                                                                                            <i class="fa fa-bell-o"></i>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="cont-col2">
                                                                                        <div class="desc"> New user registered </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="col2">
                                                                                <div class="date"> Just now </div>
                                                                            </div>
                                                                        </a>
                                                                    </li>
                                                                    <li>
                                                                        <a href="javascript:;">
                                                                            <div class="col1">
                                                                                <div class="cont">
                                                                                    <div class="cont-col1">
                                                                                        <div class="label label-sm label-success">
                                                                                            <i class="fa fa-bell-o"></i>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="cont-col2">
                                                                                        <div class="desc"> New user registered </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="col2">
                                                                                <div class="date"> Just now </div>
                                                                            </div>
                                                                        </a>
                                                                    </li>
                                                                    <li>
                                                                        <a href="javascript:;">
                                                                            <div class="col1">
                                                                                <div class="cont">
                                                                                    <div class="cont-col1">
                                                                                        <div class="label label-sm label-success">
                                                                                            <i class="fa fa-bell-o"></i>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="cont-col2">
                                                                                        <div class="desc"> New user registered </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="col2">
                                                                                <div class="date"> Just now </div>
                                                                            </div>
                                                                        </a>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!--END TABS-->
                                                </div>
                                            </div>
										</div>
                                    </div>
                                    <div class="row">
                                         
                                    </div>
                                </div>
                                <!-- END PROFILE CONTENT -->
								
								<!-- BEGIN PROFILE CONTENT 2 -->
								<div class="profile-content" id="credit_points_view" style="display:none">
								
									<div class="row">
										<div class="col-md-12" >
											<!-- BEGIN EXAMPLE TABLE PORTLET-->
											<div class="portlet light bordered" id="tablebox">
												<div class="portlet-body">
													<table id="example" class="display select table table-striped table-bordered table-hover   order-column" cellspacing="0" width="100%">
														<thead>
															<tr>
																<th> Id </th>
																<th> Charge Type </th>
																<th> Credit </th>
																<th> Debit </th>
																<th> Balance </th>
																<th> Actions </th>
															</tr>
															<tr role="row" class="filter">

																<td></td>       

																<td>
																	<input type="text" class="form-control form-filter input-sm" name="charge_type"> </td>

																<td>
																	<input type="text" class="form-control form-filter input-sm" name="credit_points"> </td>

																<td>
																	<input type="text" class="form-control form-filter input-sm" name="debit_points"> </td>
																	
																<td>
																	<input type="text" class="form-control form-filter input-sm" name="balance_points"> </td>
																
																<td>
																	<div class="margin-bottom-5">
																		<button class="btn btn-sm green btn-outline filter-submit margin-bottom">
																		<i class="fa fa-search"></i></button>
																	</div>
																	<button class="btn btn-sm red btn-outline filter-cancel">
																	<i class="fa fa-times"></i></button>
																</td>
															</tr>
														</thead>
													</table>
												</div>											
											</div>
										</div>
									</div>
									<!-- END CONTENT BODY -->
								</div>
								<!-- END PROFILE CONTENT 2-->
								<!-- BEGIN PROFILE CONTENT 3 -->
								<div class="profile-content" id="flights_under_observation_view" style="display:none">
								
									<div class="row">
										<div class="col-md-12" >
											<!-- BEGIN EXAMPLE TABLE PORTLET-->
											<div class="portlet light bordered" id="tablebox1">
												<div class="portlet-body">
													<table id="example1" class="display select table table-striped table-bordered table-hover   order-column" cellspacing="0" width="100%">
														<thead>
															<tr>
																<th> Id </th>
																<th width="32%"> Itinerary ID </th>
																<th> Depature Airport Code </th>
																<th> Arrival Airport Code </th>
																<th> Airlines Number </th>
																<th> Date Of Journey </th>
																<th> Actions </th>
															</tr>
															<tr role="row" class="filter">

																<td></td>       

																<td>
																	<input type="text" class="form-control form-filter input-sm" name="flight_id"> </td>

																<td>
																	<input type="text" class="form-control form-filter input-sm" name="depature_airport_code"> </td>

																<td>
																	<input type="text" class="form-control form-filter input-sm" name="arrival_airport_code"> </td>
																	
																<td>
																	<input type="text" class="form-control form-filter input-sm" name="airline_no"> </td>
																	
																<td> </td>
																
																<td>
																	<div class="margin-bottom-5">
																		<button class="btn btn-sm green btn-outline filter-submit margin-bottom">
																		<i class="fa fa-search"></i></button>
																	</div>
																	<button class="btn btn-sm red btn-outline filter-cancel">
																	<i class="fa fa-times"></i></button>
																</td>
															</tr>
														</thead>
													</table>
												</div>											
											</div>
											<div class="portlet box red" id="history_table_observation" style="display:none">
												<div class="portlet-title">
													<div class="caption" id="history_table_title_observation">
													</div>
												</div>
												<div class="portlet-body">
													<div class="table-responsive">
														<table class="display select table" cellspacing="0" width="100%">
															<thead>
																<tr>
																	<th> Delay Index </th>
																	<th> Delay Risk </th>
																	<th> Delay Cause </th>
																	<th> Status </th>
																	<th> Departure Scheduled </th>
																	<th> Departure Updated </th>
																	<th> Arrival Scheduled </th>
																	<th> Arrival Updated </th>
																</tr>
															</thead>
															<tbody id="history_detail_table_observation">
															</tbody>
														</table>
													</div>
												</div>
											</div>
										</div>
									</div>
									<!-- END CONTENT BODY -->
								</div>
								<!-- END PROFILE CONTENT 3-->
								<!-- BEGIN PROFILE CONTENT 4 -->
								<div class="profile-content" id="flights_history_view" style="display:none">
								
									<div class="row">
										<div class="col-md-12" >
											<!-- BEGIN EXAMPLE TABLE PORTLET-->
											<div class="portlet light bordered" id="tablebox2">
												<div class="portlet-body">
													<table id="example2" class="display select table table-striped table-bordered table-hover   order-column" cellspacing="0" width="100%">
														<thead>
															<tr>
																<th> Id </th>
																<th width="32%"> Itinerary ID </th>
																<th> Depature Airport Code </th>
																<th> Arrival Airport Code </th>
																<th> Airlines Number </th>
																<th> Date Of Journey </th>
																<th> Actions </th>
															</tr>
															<tr role="row" class="filter">

																<td></td>       

																<td>
																	<input type="text" class="form-control form-filter input-sm" name="flight_id_history"> </td>

																<td>
																	<input type="text" class="form-control form-filter input-sm" name="depature_airport_code_history"> </td>

																<td>
																	<input type="text" class="form-control form-filter input-sm" name="arrival_airport_code_history"> </td>
																	
																<td>
																	<input type="text" class="form-control form-filter input-sm" name="airline_no_history"> </td>
																	
																<td> </td>
																
																<td>
																	<div class="margin-bottom-5">
																		<button class="btn btn-sm green btn-outline filter-submit margin-bottom">
																		<i class="fa fa-search"></i></button>
																	</div>
																	<button class="btn btn-sm red btn-outline filter-cancel">
																	<i class="fa fa-times"></i></button>
																</td>
															</tr>
														</thead>
													</table>
												</div>											
											</div>
											<div class="portlet box red" id="history_table" style="display:none">
												<div class="portlet-title">
													<div class="caption" id="history_table_title">
													</div>
												</div>
												<div class="portlet-body">
													<div class="table-responsive">
														<table class="display select table" cellspacing="0" width="100%">
															<thead>
																<tr>
																	<th> Delay Index </th>
																	<th> Delay Risk </th>
																	<th> Delay Cause </th>
																	<th> Status </th>
																	<th> Departure Scheduled </th>
																	<th> Departure Updated </th>
																	<th> Arrival Scheduled </th>
																	<th> Arrival Updated </th>
																</tr>
															</thead>
															<tbody id="history_detail_table">
															</tbody>
														</table>
													</div>
												</div>
											</div>
										</div>
									</div>
									<!-- END CONTENT BODY -->
								</div>
								<!-- END PROFILE CONTENT 4-->
                <!-- END CONTENT -->
                <!-- BEGIN QUICK SIDEBAR -->
                <?php   $this->load->view('common/right_bar',''); ?>
                <!-- END QUICK SIDEBAR -->
            </div>
            <!-- END CONTAINER -->
            <!-- BEGIN FOOTER -->
             <?php   $this->load->view('common/footer',''); ?>
            <!-- END FOOTER -->
        </div>
        <!-- BEGIN QUICK NAV -->
         <?php   $this->load->view('common/overlay',''); ?>
        <!-- END QUICK NAV -->
        <!--[if lt IE 9]>
<script src="<?php echo ASSETS; ?>/global/plugins/respond.min.js"></script>
<script src="<?php echo ASSETS; ?>/global/plugins/excanvas.min.js"></script> 
<script src="<?php echo ASSETS; ?>/global/plugins/ie8.fix.min.js"></script> 
<![endif]-->
        <!-- BEGIN CORE PLUGINS -->
        <script src="<?php echo ASSETS; ?>/global/plugins/jquery.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/js.cookie.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/jquery-slimscroll/jquery.slimscroll.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/jquery.blockui.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/bootstrap-switch/js/bootstrap-switch.min.js" type="text/javascript"></script>
        <!-- END CORE PLUGINS -->
        <!-- BEGIN PAGE LEVEL PLUGINS -->
        <script src="<?php echo ASSETS; ?>/global/plugins/jquery-validation/js/jquery.validate.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/jquery-validation/js/additional-methods.min.js" type="text/javascript"></script>
        
        <script src="<?php echo ASSETS; ?>/global/plugins/bootstrap-fileinput/bootstrap-fileinput.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/jquery.sparkline.min.js" type="text/javascript"></script>
         
        <!-- END PAGE LEVEL PLUGINS -->
           <script src="<?php echo ASSETS; ?>/global/plugins/moment.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/bootstrap-daterangepicker/daterangepicker.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/morris/morris.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/morris/raphael-min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/counterup/jquery.waypoints.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/counterup/jquery.counterup.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/amcharts/amcharts/amcharts.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/amcharts/amcharts/serial.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/amcharts/amcharts/pie.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/amcharts/amcharts/radar.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/amcharts/amcharts/themes/light.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/amcharts/amcharts/themes/patterns.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/amcharts/amcharts/themes/chalk.js" type="text/javascript"></script> 
        <script src="<?php echo ASSETS; ?>/global/plugins/amcharts/amstockcharts/amstock.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/fullcalendar/fullcalendar.min.js" type="text/javascript"></script>
         <script src="<?php echo ASSETS; ?>/global/plugins/flot/jquery.flot.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/flot/jquery.flot.resize.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/flot/jquery.flot.categories.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/jquery-easypiechart/jquery.easypiechart.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/jquery.sparkline.min.js" type="text/javascript"></script>
         
        <!-- BEGIN THEME GLOBAL SCRIPTS -->
        <script src="<?php echo ASSETS; ?>/global/scripts/app.min.js" type="text/javascript"></script>
        <!-- END THEME GLOBAL SCRIPTS -->
        <script src="<?php echo ASSETS; ?>/global/plugins/select2/js/select2.full.min.js" type="text/javascript"></script>
<script src="<?php echo ASSETS; ?>/pages/scripts/components-select2.min.js" type="text/javascript"></script>
 <script src="<?php echo ASSETS; ?>/pages/scripts/overlaymessage.js" type="text/javascript"></script>
       <script src="<?php echo ASSETS; ?>/global/plugins/bootstrap-fileinput/bootstrap-fileinput.js" type="text/javascript"></script>

        
        <!-- BEGIN PAGE LEVEL SCRIPTS -->
        <script src="<?php echo ASSETS; ?>/pages/scripts/profile.min.js" type="text/javascript"></script> 
        <!-- END PAGE LEVEL SCRIPTS -->
        <!-- BEGIN THEME LAYOUT SCRIPTS -->
        <script src="<?php echo ASSETS; ?>/layouts/layout/scripts/layout.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/layouts/layout/scripts/demo.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/layouts/global/scripts/quick-sidebar.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/layouts/global/scripts/quick-nav.min.js" type="text/javascript"></script>
        <!-- END THEME LAYOUT SCRIPTS -->
		
		<script src="<?php echo ASSETS; ?>/global/scripts/datatable.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/datatables/datatables.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap.js" type="text/javascript"></script>
 <script src="<?php echo ASSETS.'/pages/scripts/appconnect.js'; ?>"></script> 
 <script >
$(document).on('click', '.history_detail', function(){
	var flight_id		=	$(this).data('flightid');
	var itinerary_id	=	$(this).data('itineraryid');
	var tableHtml		=	'';
	
	$.ajax({
		url		:	'<?php echo WEB_URL; ?>/b2c_do/flight_notification_history',
		data	:	{'flight_id':flight_id, 'itinerary_id':itinerary_id},
		type	:	'post',
		dataType:	'json',
		success	:	function(result){
			if( result.length > 0 ){
				$.each(result, function( key, value ){
					tableHtml	+=	'<tr>\
										<td>'+value.delay_index+'</td>\
										<td>'+value.delay_risk+'</td>\
										<td>'+value.delay_causes+'</td>\
										<td>'+value.flight_status+'</td>\
										<td>'+value.departure_scheduled+'</td>\
										<td>'+value.departure_latest+'</td>\
										<td>'+value.arrival_scheduled+'</td>\
										<td>'+value.arrival_latest+'</td>\
									</tr>';
				});
			}else{
				tableHtml += '<tr><td>No data to show.</td></tr>';
			}

			$('#history_detail_table').html( tableHtml );
			$('#history_table_title').html( "Notification History: "+flight_id );
			$('#history_table').show();
		}
	});
});
$(document).on('click', '.history_detail_observation', function(){
	var flight_id		=	$(this).data('flightid');
	var itinerary_id	=	$(this).data('itineraryid');
	var current_status	=	$(this).data('currentstatus');
	var tableHtml		=	'';
	var table_title		=	'Current Status';
	if( current_status == 'undefined' ){
		current_status 	= '';
		table_title		=	'Notification History';
	}
	
	$.ajax({
		url		:	'<?php echo WEB_URL; ?>/b2c_do/flight_notification_history',
		data	:	{'flight_id':flight_id, 'itinerary_id':itinerary_id, 'current_status':current_status},
		type	:	'post',
		dataType:	'json',
		success	:	function(result){
			if( result.length > 0 ){
				$.each(result, function( key, value ){
					tableHtml	+=	'<tr>\
										<td>'+value.delay_index+'</td>\
										<td>'+value.delay_risk+'</td>\
										<td>'+value.delay_causes+'</td>\
										<td>'+value.flight_status+'</td>\
										<td>'+value.departure_scheduled+'</td>\
										<td>'+value.departure_latest+'</td>\
										<td>'+value.arrival_scheduled+'</td>\
										<td>'+value.arrival_latest+'</td>\
									</tr>';
				});
			}else{
				tableHtml += '<tr><td>No data to show.</td></tr>';
			}

			$('#history_detail_table_observation').html( tableHtml );
			$('#history_table_title_observation').html( table_title+": "+flight_id );
			$('#history_table_observation').show();
		}
	});
});
  function switchView( tab, currentObj )
 {
	if( tab == 'overview' )
	{
		$('#credit_points_view').hide();
		$('#flights_under_observation_view').hide();
		$('#flights_history_view').hide();
		$('#overview_view').show();
	}
	else if( tab == 'credit_points' )
	{
		$('#overview_view').hide();
		$('#flights_under_observation_view').hide();
		$('#flights_history_view').hide();
		$('#credit_points_view').show();		
	}
	else if( tab == 'flights_under_observation' )
	{
		$('#overview_view').hide();
		$('#credit_points_view').hide();		
		$('#flights_history_view').hide();		
		$('#flights_under_observation_view').show();		
	}
	else if( tab == 'flights_history' )
	{
		$('#overview_view').hide();
		$('#credit_points_view').hide();		
		$('#flights_under_observation_view').hide();		
		$('#flights_history_view').show();		
	}
	
	$('.left_nav').removeClass('active');
	$(currentObj).addClass('active');
 }
 
 $(document).ready(function(){
	 
	
	 
	$('#generic_bar').sparkline([ <?php echo implode( ',', array_values($generic_hits_10_days) ); ?> ], {
		type: 'bar',
		width: '100',
		barWidth: 6,
		height: '45',
		barColor: '#F36A5B',
		negBarColor: '#e02222'
	}); 
	
	$("#paid_bar").sparkline([ <?php echo implode( ',', array_values($paid_hits_10_days) ); ?> ], {
		type: 'bar',
		width: '100',
		barWidth: 6,
		height: '45',
		barColor: '#5C9BD1',
		negBarColor: '#e02222'
	});
	
	var grid = new Datatable();
	var grid1 = new Datatable();
	var grid2 = new Datatable();

	grid.init({
		src: $("#example"),
		onSuccess: function(grid, response) {
			// grid:        grid object
			// response:    json object of server side ajax response
			// execute some code after table records loaded
		},
		onError: function(grid) {
			// execute some code on network or other general error  
		},
		onDataLoad: function(grid) {
			// execute some code on ajax data load
		},
		loadingMessage: 'Loading...',
		dataTable: { // here you can define a typical datatable settings from http://datatables.net/usage/options 

			// Uncomment below line("dom" parameter) to fix the dropdown overflow issue in the datatable cells. The default datatable layout
			// setup uses scrollable div(table-scrollable) with overflow:auto to enable vertical scroll(see: assets/global/scripts/datatable.js). 
			// So when dropdowns used the scrollable div should be removed. 
			//"dom": "<'row'<'col-md-8 col-sm-12'pli><'col-md-4 col-sm-12'<'table-group-actions pull-right'>>r>t<'row'<'col-md-8 col-sm-12'pli><'col-md-4 col-sm-12'>>",

			// save datatable state(pagination, sort, etc) in cookie.
			"bStateSave": true,

			// save custom filters to the state
			"fnStateSaveParams": function(oSettings, sValue) {
				$("#datatable_ajax tr.filter .form-control").each(function() {
					sValue[$(this).attr('name')] = $(this).val();
				});

				return sValue;
			},

			// read the custom filters from saved state and populate the filter inputs
			"fnStateLoadParams": function(oSettings, oData) {
				//Load custom filters
				$("#datatable_ajax tr.filter .form-control").each(function() {
					var element = $(this);
					if (oData[element.attr('name')]) {
						element.val(oData[element.attr('name')]);
					}
				});

				return true;
			},


			"pageLength": 10, // default record count per page
			"ajax": {
				"url": "<?php echo WEB_URL; ?>/b2c_do/list_all_credit_point_transaction_ajax/<?php echo $result->user_code; ?>", // ajax source
				"beforeSend": function() {
					App.blockUI({
						target: '#tablebox'
					});
				},

				"complete": function(xhr, status) {
					App.unblockUI('#tablebox');

					$t_r = xhr.responseText;
					var jsonResponse = JSON.parse($t_r);
					$('.tooltips').tooltip()
				}
			},
			'columnDefs': [{
					"name": "iata_airline",
					"targets": 0,
					'orderable': true
				},
				{
					"name": "icao_airline",
					"targets": 1,
					'orderable': true
				},
				{
					"name": "airline_name",
					"targets": 2,
					'orderable': true
				},
				{
					"name": "call_sign",
					"targets": 3,
					'orderable': true
				},
				{
					"name": "country",
					"targets": 4,
					'orderable': true
				},
				{
					"name": "email_id",
					"targets": 5,
					'orderable': true
				}
			],
			"order": [
				[0, "desc"]
			] // set first column as a default sort by asc
		}
	});
	
	grid1.init({
		src: $("#example1"),
		onSuccess: function(grid, response) {
			// grid:        grid object
			// response:    json object of server side ajax response
			// execute some code after table records loaded
		},
		onError: function(grid) {
			// execute some code on network or other general error  
		},
		onDataLoad: function(grid) {
			// execute some code on ajax data load
		},
		loadingMessage: 'Loading...',
		dataTable: { // here you can define a typical datatable settings from http://datatables.net/usage/options 

			// Uncomment below line("dom" parameter) to fix the dropdown overflow issue in the datatable cells. The default datatable layout
			// setup uses scrollable div(table-scrollable) with overflow:auto to enable vertical scroll(see: assets/global/scripts/datatable.js). 
			// So when dropdowns used the scrollable div should be removed. 
			//"dom": "<'row'<'col-md-8 col-sm-12'pli><'col-md-4 col-sm-12'<'table-group-actions pull-right'>>r>t<'row'<'col-md-8 col-sm-12'pli><'col-md-4 col-sm-12'>>",

			// save datatable state(pagination, sort, etc) in cookie.
			"bStateSave": true,

			// save custom filters to the state
			"fnStateSaveParams": function(oSettings, sValue) {
				$("#datatable_ajax tr.filter .form-control").each(function() {
					sValue[$(this).attr('name')] = $(this).val();
				});

				return sValue;
			},

			// read the custom filters from saved state and populate the filter inputs
			"fnStateLoadParams": function(oSettings, oData) {
				//Load custom filters
				$("#datatable_ajax tr.filter .form-control").each(function() {
					var element = $(this);
					if (oData[element.attr('name')]) {
						element.val(oData[element.attr('name')]);
					}
				});

				return true;
			},


			"pageLength": 10, // default record count per page
			"ajax": {
				"url": "<?php echo WEB_URL; ?>/b2c_do/list_flights_under_observation/<?php echo $result->user_code; ?>", // ajax source
				"beforeSend": function() {
					App.blockUI({
						target: '#tablebox1'
					});
				},

				"complete": function(xhr, status) {
					App.unblockUI('#tablebox1');

					$t_r = xhr.responseText;
					var jsonResponse = JSON.parse($t_r);
					$('.tooltips').tooltip()
				}
			},
			'columnDefs': [{
					"name": "iata_airline",
					"targets": 0,
					'orderable': true
				},
				{
					"name": "icao_airline",
					"targets": 1,
					'orderable': true
				},
				{
					"name": "airline_name",
					"targets": 2,
					'orderable': true
				},
				{
					"name": "call_sign",
					"targets": 3,
					'orderable': true
				},
				{
					"name": "country",
					"targets": 4,
					'orderable': true
				},
				{
					"name": "email_id",
					"targets": 5,
					'orderable': true
				}
			],
			"order": [
				[0, "desc"]
			] // set first column as a default sort by asc
		}
	});
	
	grid2.init({
		src: $("#example2"),
		onSuccess: function(grid, response) {
			// grid:        grid object
			// response:    json object of server side ajax response
			// execute some code after table records loaded
		},
		onError: function(grid) {
			// execute some code on network or other general error  
		},
		onDataLoad: function(grid) {
			// execute some code on ajax data load
		},
		loadingMessage: 'Loading...',
		dataTable: { // here you can define a typical datatable settings from http://datatables.net/usage/options 

			// Uncomment below line("dom" parameter) to fix the dropdown overflow issue in the datatable cells. The default datatable layout
			// setup uses scrollable div(table-scrollable) with overflow:auto to enable vertical scroll(see: assets/global/scripts/datatable.js). 
			// So when dropdowns used the scrollable div should be removed. 
			//"dom": "<'row'<'col-md-8 col-sm-12'pli><'col-md-4 col-sm-12'<'table-group-actions pull-right'>>r>t<'row'<'col-md-8 col-sm-12'pli><'col-md-4 col-sm-12'>>",

			// save datatable state(pagination, sort, etc) in cookie.
			"bStateSave": true,

			// save custom filters to the state
			"fnStateSaveParams": function(oSettings, sValue) {
				$("#datatable_ajax tr.filter .form-control").each(function() {
					sValue[$(this).attr('name')] = $(this).val();
				});

				return sValue;
			},

			// read the custom filters from saved state and populate the filter inputs
			"fnStateLoadParams": function(oSettings, oData) {
				//Load custom filters
				$("#datatable_ajax tr.filter .form-control").each(function() {
					var element = $(this);
					if (oData[element.attr('name')]) {
						element.val(oData[element.attr('name')]);
					}
				});

				return true;
			},


			"pageLength": 10, // default record count per page
			"ajax": {
				"url": "<?php echo WEB_URL; ?>/b2c_do/list_flights_history/<?php echo $result->user_code; ?>", // ajax source
				"beforeSend": function() {
					App.blockUI({
						target: '#tablebox2'
					});
				},

				"complete": function(xhr, status) {
					App.unblockUI('#tablebox2');

					$t_r = xhr.responseText;
					var jsonResponse = JSON.parse($t_r);
					$('.tooltips').tooltip()
				}
			},
			'columnDefs': [{
					"name": "iata_airline",
					"targets": 0,
					'orderable': true
				},
				{
					"name": "icao_airline",
					"targets": 1,
					'orderable': true
				},
				{
					"name": "airline_name",
					"targets": 2,
					'orderable': true
				},
				{
					"name": "call_sign",
					"targets": 3,
					'orderable': true
				},
				{
					"name": "country",
					"targets": 4,
					'orderable': true
				},
				{
					"name": "email_id",
					"targets": 5,
					'orderable': true
				}
			],
			"order": [
				[0, "desc"]
			] // set first column as a default sort by asc
		}
	});

	// handle group actionsubmit button click
	grid.getTableWrapper().on('click', '.table-group-action-submit', function(e) {
	e.preventDefault();
	var action = $(".table-group-action-input", grid.getTableWrapper());
	if (action.val() != "" && grid.getSelectedRowsCount() > 0) {
		grid.setAjaxParam("customActionType", "group_action");
		grid.setAjaxParam("customActionName", action.val());
		grid.setAjaxParam("id", grid.getSelectedRows());
		grid.getDataTable().ajax.reload();
		grid.clearAjaxParams();
	} else if (action.val() == "") {
		App.alert({
			type: 'danger',
			icon: 'warning',
			message: 'Please select an action',
			container: grid.getTableWrapper(),
			place: 'prepend'
		});
	} else if (grid.getSelectedRowsCount() === 0) {
		App.alert({
			type: 'danger',
			icon: 'warning',
			message: 'No record selected',
			container: grid.getTableWrapper(),
			place: 'prepend'
		});
	}
	});
	// handle group actionsubmit button click
	grid1.getTableWrapper().on('click', '.table-group-action-submit', function(e) {
	e.preventDefault();
	var action = $(".table-group-action-input", grid1.getTableWrapper());
	if (action.val() != "" && grid1.getSelectedRowsCount() > 0) {
		grid1.setAjaxParam("customActionType", "group_action");
		grid1.setAjaxParam("customActionName", action.val());
		grid1.setAjaxParam("id", grid1.getSelectedRows());
		grid1.getDataTable().ajax.reload();
		grid1.clearAjaxParams();
	} else if (action.val() == "") {
		App.alert({
			type: 'danger',
			icon: 'warning',
			message: 'Please select an action',
			container: grid1.getTableWrapper(),
			place: 'prepend'
		});
	} else if (grid1.getSelectedRowsCount() === 0) {
		App.alert({
			type: 'danger',
			icon: 'warning',
			message: 'No record selected',
			container: grid1.getTableWrapper(),
			place: 'prepend'
		});
	}
	});
	// handle group actionsubmit button click
	grid2.getTableWrapper().on('click', '.table-group-action-submit', function(e) {
	e.preventDefault();
	var action = $(".table-group-action-input", grid2.getTableWrapper());
	if (action.val() != "" && grid2.getSelectedRowsCount() > 0) {
		grid2.setAjaxParam("customActionType", "group_action");
		grid2.setAjaxParam("customActionName", action.val());
		grid2.setAjaxParam("id", grid2.getSelectedRows());
		grid2.getDataTable().ajax.reload();
		grid2.clearAjaxParams();
	} else if (action.val() == "") {
		App.alert({
			type: 'danger',
			icon: 'warning',
			message: 'Please select an action',
			container: grid2.getTableWrapper(),
			place: 'prepend'
		});
	} else if (grid2.getSelectedRowsCount() === 0) {
		App.alert({
			type: 'danger',
			icon: 'warning',
			message: 'No record selected',
			container: grid2.getTableWrapper(),
			place: 'prepend'
		});
	}
	});




});
	
 var Dashboard = function() {

    return {
 

        initCharts: function() {
            if (!jQuery.plot) {
                return;
            }

            function showChartTooltip(x, y, xValue, yValue) {
                $('<div id="tooltip" class="chart-tooltip">' + yValue + '<\/div>').css({
                    position: 'absolute',
                    display: 'none',
                    top: y - 40,
                    left: x - 40,
                    border: '0px solid #ccc',
                    padding: '2px 6px',
                    'background-color': '#fff'
                }).appendTo("body").fadeIn(200);
            }

            var data = [];
            var totalPoints = 250;

            // random data generator for plot charts

            function getRandomData() {
                if (data.length > 0) data = data.slice(1);
                // do a random walk
                while (data.length < totalPoints) {
                    var prev = data.length > 0 ? data[data.length - 1] : 50;
                    var y = prev + Math.random() * 10 - 5;
                    if (y < 0) y = 0;
                    if (y > 100) y = 100;
                    data.push(y);
                }
                // zip the generated y values with the x values
                var res = [];
                for (var i = 0; i < data.length; ++i) res.push([i, data[i]])
                return res;
            }

            function randValue() {
                return (Math.floor(Math.random() * (1 + 50 - 20))) + 10;
            }

            var visitors = [
				<?php
					foreach( $generic_hits_10_days as $key=>$value )
					{
						echo "['$key', $value],";
					}
				?>
            ];


            if ($('#site_statistics').size() != 0) {

                $('#site_statistics_loading').hide();
                $('#site_statistics_content').show();

                var plot_statistics = $.plot($("#site_statistics"), [{
                        data: visitors,
                        lines: {
                            fill: 0.6,
                            lineWidth: 0
                        },
                        color: ['#f89f9f']
                    }, {
                        data: visitors,
                        points: {
                            show: true,
                            fill: true,
                            radius: 5,
                            fillColor: "#f89f9f",
                            lineWidth: 3
                        },
                        color: '#fff',
                        shadowSize: 0
                    }],

                    {
                        xaxis: {
                            tickLength: 0,
                            tickDecimals: 0,
                            mode: "categories",
                            min: 0,
                            font: {
                                lineHeight: 14,
                                style: "normal",
                                variant: "small-caps",
                                color: "#6F7B8A"
                            }
                        },
                        yaxis: {
                            ticks: 5,
                            tickDecimals: 0,
                            tickColor: "#eee",
                            font: {
                                lineHeight: 14,
                                style: "normal",
                                variant: "small-caps",
                                color: "#6F7B8A"
                            }
                        },
                        grid: {
                            hoverable: true,
                            clickable: true,
                            tickColor: "#eee",
                            borderColor: "#eee",
                            borderWidth: 1
                        }
                    });

                var previousPoint = null;
                $("#site_statistics").bind("plothover", function(event, pos, item) {
                    $("#x").text(pos.x.toFixed(2));
                    $("#y").text(pos.y.toFixed(2));
                    if (item) {
                        if (previousPoint != item.dataIndex) {
                            previousPoint = item.dataIndex;

                            $("#tooltip").remove();
                            var x = item.datapoint[0].toFixed(2),
                                y = item.datapoint[1].toFixed(2);

                            showChartTooltip(item.pageX, item.pageY, item.datapoint[0], item.datapoint[1] + ' visits');
                        }
                    } else {
                        $("#tooltip").remove();
                        previousPoint = null;
                    }
                });
            }


            if ($('#site_activities').size() != 0) {
                //site activities
                var previousPoint2 = null;
                $('#site_activities_loading').hide();
                $('#site_activities_content').show();

                var data1 = [
                    ['DEC', 300],
                    ['JAN', 600],
                    ['FEB', 1100],
                    ['MAR', 1200],
                    ['APR', 860],
                    ['MAY', 1200],
                    ['JUN', 1450],
                    ['JUL', 1800],
                    ['AUG', 1200],
                    ['SEP', 600]
                ];


                var plot_statistics = $.plot($("#site_activities"),

                    [{
                        data: data1,
                        lines: {
                            fill: 0.2,
                            lineWidth: 0,
                        },
                        color: ['#BAD9F5']
                    }, {
                        data: data1,
                        points: {
                            show: true,
                            fill: true,
                            radius: 4,
                            fillColor: "#9ACAE6",
                            lineWidth: 2
                        },
                        color: '#9ACAE6',
                        shadowSize: 1
                    }, {
                        data: data1,
                        lines: {
                            show: true,
                            fill: false,
                            lineWidth: 3
                        },
                        color: '#9ACAE6',
                        shadowSize: 0
                    }],

                    {

                        xaxis: {
                            tickLength: 0,
                            tickDecimals: 0,
                            mode: "categories",
                            min: 0,
                            font: {
                                lineHeight: 18,
                                style: "normal",
                                variant: "small-caps",
                                color: "#6F7B8A"
                            }
                        },
                        yaxis: {
                            ticks: 5,
                            tickDecimals: 0,
                            tickColor: "#eee",
                            font: {
                                lineHeight: 14,
                                style: "normal",
                                variant: "small-caps",
                                color: "#6F7B8A"
                            }
                        },
                        grid: {
                            hoverable: true,
                            clickable: true,
                            tickColor: "#eee",
                            borderColor: "#eee",
                            borderWidth: 1
                        }
                    });

                $("#site_activities").bind("plothover", function(event, pos, item) {
                    $("#x").text(pos.x.toFixed(2));
                    $("#y").text(pos.y.toFixed(2));
                    if (item) {
                        if (previousPoint2 != item.dataIndex) {
                            previousPoint2 = item.dataIndex;
                            $("#tooltip").remove();
                            var x = item.datapoint[0].toFixed(2),
                                y = item.datapoint[1].toFixed(2);
                            showChartTooltip(item.pageX, item.pageY, item.datapoint[0], item.datapoint[1] + 'M$');
                        }
                    }
                });

                $('#site_activities').bind("mouseleave", function() {
                    $("#tooltip").remove();
                });
            }
        },

         

        init: function() {

            
            this.initCharts();
            
        }
    };

}();

 
    jQuery(document).ready(function() {
        Dashboard.init(); // init metronic core componets
    });
</script>  </body>

</html>