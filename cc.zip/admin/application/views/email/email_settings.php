<!DOCTYPE html>
<html lang="en">
    <!--<![endif]-->
    <!-- BEGIN HEAD -->
    <head>
        <meta charset="utf-8" />
        <title><?php echo PROJECT_TITLE; ?></title>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta content="width=device-width, initial-scale=1" name="viewport" />
        <meta content="Flight is canceled, delayed or missed connecting flight ? Up to 600 € compensation received ✓ 98% success rate ✓ More than 120 countries ✓ Check your claim!" name="description" />
        <meta content="" name="author" />
        <!-- BEGIN GLOBAL MANDATORY STYLES -->
           
<link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700&subset=all" rel="stylesheet" type="text/css" />
        <link href="<?php echo ASSETS; ?>/global/plugins/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo ASSETS; ?>/global/plugins/simple-line-icons/simple-line-icons.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo ASSETS; ?>/global/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo ASSETS; ?>/global/plugins/bootstrap-switch/css/bootstrap-switch.min.css" rel="stylesheet" type="text/css" />
        <!-- END GLOBAL MANDATORY STYLES -->
        <!-- BEGIN PAGE LEVEL PLUGINS -->
        <link href="<?php echo ASSETS; ?>/global/plugins/select2/css/select2.min.css" rel="stylesheet" type="text/css" />
<link href="<?php echo ASSETS; ?>/global/plugins/select2/css/select2-bootstrap.min.css" rel="stylesheet" type="text/css" />
<link href="<?php echo ASSETS; ?>/global/plugins/bootstrap-fileinput/bootstrap-fileinput.css" rel="stylesheet" type="text/css" />
<link href="<?php echo ASSETS; ?>/global/plugins/bootstrap-sweetalert/sweetalert.css" rel="stylesheet" type="text/css" />

<link href="<?php echo ASSETS; ?>/global/plugins/bootstrap-modal/css/bootstrap-modal-bs3patch.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo ASSETS; ?>/global/plugins/bootstrap-modal/css/bootstrap-modal.css" rel="stylesheet" type="text/css" />
        <!-- END PAGE LEVEL PLUGINS -->
        <!-- BEGIN THEME GLOBAL STYLES -->
        <link href="<?php echo ASSETS; ?>/global/css/components-md.min.css" rel="stylesheet" id="style_components" type="text/css" />
        <link href="<?php echo ASSETS; ?>/global/css/plugins-md.min.css" rel="stylesheet" type="text/css" />
        <!-- END THEME GLOBAL STYLES -->
        <!-- BEGIN PAGE LEVEL STYLES -->
        <link href="<?php echo ASSETS; ?>/pages/css/contact.min.css" rel="stylesheet" type="text/css" />
         <link href="<?php echo ASSETS; ?>/global/plugins/bootstrap-toastr/toastr.min.css" rel="stylesheet" type="text/css" />
        <!-- END PAGE LEVEL STYLES -->
        <!-- BEGIN THEME LAYOUT STYLES -->
        <link href="<?php echo ASSETS; ?>/layouts/layout/css/layout.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo ASSETS; ?>/layouts/layout/css/themes/darkblue.min.css" rel="stylesheet" type="text/css" id="style_color" />
        <link href="<?php echo ASSETS; ?>/layouts/layout/css/custom.min.css" rel="stylesheet" type="text/css" />
        <link rel="shortcut icon" href="<?php echo ASSETS; ?>/pages/img/refundmeico.png" /> 
        </head>
    <!-- END HEAD -->

    <body class="page-header-fixed page-sidebar-closed-hide-logo page-content-white page-md">
        <div class="page-wrapper">
            <!-- BEGIN HEADER -->
            <div class="page-header navbar navbar-fixed-top">
                <!-- BEGIN HEADER INNER -->
                 <?php $this->load->view('common/header',''); ?>
                <!-- END HEADER INNER -->
            </div>
            <!-- END HEADER -->
            <!-- BEGIN HEADER & CONTENT DIVIDER -->
            <div class="clearfix"> </div>
            <!-- END HEADER & CONTENT DIVIDER -->
            <!-- BEGIN CONTAINER -->
            <div class="page-container">
                <!-- BEGIN SIDEBAR -->
                 <?php $this->load->view('common/side_bar',''); ?>
                <!-- END SIDEBAR -->
                <!-- BEGIN CONTENT -->
                <div class="page-content-wrapper">
                    <!-- BEGIN CONTENT BODY -->
                    <div class="page-content">
                        <!-- BEGIN PAGE HEADER--> 
                        <!-- BEGIN PAGE BAR -->
                        <div class="page-bar">
                            <ul class="page-breadcrumb">
                                <li>
                                    <a href="<?php echo WEB_URL; ?>">Home</a>
                                    <i class="fa fa-circle"></i>
                                </li>
                                <li>
                                    <span>Manage Emails</span>
                                      <i class="fa fa-circle"></i>
                                </li>
                                 <li>
                                    <span>Email Settings</span>
                                </li>
                            </ul>
                            
                        </div>
                        <!-- END PAGE BAR -->
                        <!-- BEGIN PAGE TITLE-->
                        <h1 class="page-title">Email Settings<br/>
                            <small>To change email smtp details</small>
                        </h1>
                        <!-- END PAGE TITLE-->
                        <!-- END PAGE HEADER-->
                       <div class="row">
                            <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                                <a class="dashboard-stat dashboard-stat-v2 blue" href="<?php echo WEB_URL; ?>/email/all">
                                    <div class="visual">
                                        <i class="fa fa-envelope"></i>
                                    </div>
                                    <div class="details">
                                        <div class="number">
                                            <span data-counter="counterup" data-value="<?php echo $get_email_counts->overall; ?>"><?php echo $get_email_counts->overall; ?></span>
                                        </div>
                                        <div class="desc"> Total Emails </div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                                <a class="dashboard-stat dashboard-stat-v2 green-jungle" href="<?php echo WEB_URL; ?>/email/success">
                                    <div class="visual">
                                        <i class="fa fa-thumbs-o-up"></i>
                                    </div>
                                    <div class="details">
                                        <div class="number">
                                            <span data-counter="counterup" data-value="<?php echo $get_email_counts->success; ?>"><?php echo $get_email_counts->success; ?></span> </div>
                                        <div class="desc"> Success  </div>
                                    </div>
                                </a>
                            </div>
                              <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                                <a class="dashboard-stat dashboard-stat-v2 red" href="<?php echo WEB_URL; ?>/email/failure">
                                    <div class="visual">
                                        <i class="fa fa-warning"></i>
                                    </div>
                                    <div class="details">
                                        <div class="number">  
                                            <span data-counter="counterup" data-value="<?php echo $get_email_counts->failure; ?>"><?php echo $get_email_counts->failure; ?></span>  </div>
                                        <div class="desc">Failure</div>
                                    </div>
                                </a>
                            </div>
                             
                          
                        </div>
                        <div class="clearfix"></div>  <div id="ajax-modal" class="modal container fade"  tabindex="-1"> </div>
                                       
                         <div class="c-content-feedback-1 c-option-1">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="c-container bg-green">
                                        <div class="c-content-title-1 c-inverse">
                                            <h3 class="uppercase">Need to manage emails?</h3>
                                            <div class="c-line-left"></div>
                                            <p class="c-font-lowercase">Try manage and update the email theme for all email templates.</p>
                                          <a href="<?php echo WEB_URL; ?>/email/manage_emails">  <button class="btn grey-cararra font-dark">Manage Emails</button></a>
                                         <!-- <a class="ajax-demo"   data-url="<?php echo WEB_URL; ?>/email/email_variables" data-toggle="modal">
                                             <button class="btn blue-dark  ">Email Variables</button></a>
                                              -->
                                             <a href="<?php echo WEB_URL; ?>/email/cron_email" >  <button class="btn blue">Email CRON</button></a>
                                             
                                        </div>
                                    </div>
                                    <div class="c-container bg-grey-steel">
                                        <div class="c-content-title-1">
                                            <h3 class="uppercase">Have a test?</h3>
                                            <div class="c-line-left bg-dark"></div>
                                            <form action="<?php echo WEB_URL; ?>/email_do/test_email" method="post" class="form-horizontal" id="form_sample_2">
                                            <div class="form-body">
                                            
                                                <div class="form-group form-md-line-input has-info form-md-floating-label">
                                                    <div class="input-group input-group-sm">
                                                         <div class="input-group-control">
                                                            <input  required type="email" name="email_address" class="form-control ">
                                                            <label for="form_control_1">Email Address</label>
                                                        </div>
                                                        <span class="input-group-btn btn-right">
                                                          <input type="submit" class="btn green-haze" value="SEND">
                                                        </span>
                                                    </div>
                                                </div>
                                                 </div>
                                            </form>
                                            <p>check your email access whether working correctly or going to spam folder.</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="c-contact">
                                        <div class="c-content-title-1">
                                            <h3 class="uppercase">Email Access</h3>
                                            <div class="c-line-left bg-dark"></div>
                                            <p class="c-font-lowercase">Our helpline is always open to receive any inquiry or feedback. Please feel free to drop us an email from the form below and we will get back to you as soon as we can.</p>
                                        </div>
                                        <form action="<?php echo WEB_URL; ?>/email_do/update_email_settings" method="post" class="form-horizontal" id="form_sample_1">
                                            <div class="form-body">
                                                <div class="form-group form-md-line-input">
                                                    <label class="col-md-3 control-label" for="form_control_1">SMTP                                                        <span class="required">*</span>
                                                    </label>
                                                    <div class="col-md-9">
                                                        <input type="text" class="form-control" placeholder="" name="smtp" value="<?php echo $result->smtp; ?>">
                                                        <div class="form-control-focus"> </div>
                                                    </div>
                                                </div>
                                                <div class="form-group form-md-line-input">
                                                    <label class="col-md-3 control-label" for="form_control_1">Host Name
                                                        <span class="required">*</span>
                                                    </label>
                                                    <div class="col-md-9">
                                                        <input type="text" class="form-control" placeholder="" name="host_name" value="<?php echo $result->host; ?>">
                                                        <div class="form-control-focus"> </div>
                                                    </div>
                                                </div>
                                                 
                                                <div class="form-group form-md-line-input">
                                                    <label class="col-md-3 control-label" for="form_control_1">Port
                                                        <span class="required">*</span>
                                                    </label>
                                                    <div class="col-md-9">
                                                        <input type="text" class="form-control" placeholder="" name="port" value="<?php echo $result->port; ?>">
                                                        <div class="form-control-focus"> </div>
                                                    </div>
                                                </div>
                                                <div class="form-group form-md-line-input">
                                                    <label class="col-md-3 control-label" for="form_control_1">Username / Email address
                                                        <span class="required">*</span>
                                                    </label>
                                                    <div class="col-md-9">
                                                        <input type="text" class="form-control" placeholder="" name="email_address" value="<?php echo $result->username; ?>">
                                                        <div class="form-control-focus"> </div>
                                                    </div>
                                                </div>
                                                <div class="form-group form-md-line-input">
                                                    <label class="col-md-3 control-label" for="form_control_1">Password
                                                        <span class="required">*</span>
                                                    </label>
                                                    <div class="col-md-9">
                                                        <input type="password" class="form-control" placeholder="" name="password" value="">
                                                        <div class="form-control-focus"> </div>
                                                    </div>
                                                </div>
                                                     </div>
                                            <div class="form-actions">
                                                <div class="row">
                                                    <div class="col-md-offset-3 col-md-9">
                                                        <button type="submit" class="btn green">Save Changes</button>
                                                     </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- END CONTENT BODY -->
                </div>
                <!-- END CONTENT -->
                <!-- BEGIN QUICK SIDEBAR -->
                <a href="javascript:;" class="page-quick-sidebar-toggler">
                    <i class="icon-login"></i>
                </a>
                  <?php   $this->load->view('common/right_bar',''); ?>
                <!-- END QUICK SIDEBAR -->
            </div>
            <!-- END CONTAINER -->
            <!-- BEGIN FOOTER -->
            <?php   $this->load->view('common/footer',''); ?>
            <!-- END FOOTER -->
        </div>
        <!-- BEGIN QUICK NAV -->
         <?php   $this->load->view('common/overlay',''); ?>
        
        <!-- END QUICK NAV -->
        <!--[if lt IE 9]>
<script src="<?php echo ASSETS; ?>/global/plugins/respond.min.js"></script>
<script src="<?php echo ASSETS; ?>/global/plugins/excanvas.min.js"></script> 
<script src="<?php echo ASSETS; ?>/global/plugins/ie8.fix.min.js"></script> 
<![endif]-->
        <!-- BEGIN CORE PLUGINS -->
         <script src="<?php echo ASSETS; ?>/global/plugins/jquery.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/js.cookie.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/jquery-slimscroll/jquery.slimscroll.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/jquery.blockui.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/bootstrap-switch/js/bootstrap-switch.min.js" type="text/javascript"></script>
        <!-- END CORE PLUGINS -->
        <!-- BEGIN PAGE LEVEL PLUGINS -->
    
      
         <script src="<?php echo ASSETS; ?>/global/plugins/counterup/jquery.waypoints.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/counterup/jquery.counterup.min.js" type="text/javascript"></script>
        
         <script src="<?php echo ASSETS; ?>/global/plugins/jquery-validation/js/jquery.validate.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/jquery-validation/js/additional-methods.min.js" type="text/javascript"></script>
        <!-- END PAGE LEVEL PLUGINS -->
        <!-- BEGIN THEME GLOBAL SCRIPTS -->
        <script src="<?php echo ASSETS; ?>/global/scripts/app.min.js" type="text/javascript"></script>
        <!-- END THEME GLOBAL SCRIPTS -->
        <script>
	 var FormValidationMd = function() {

    var handleValidation1 = function() {
        // for more info visit the official plugin documentation: 
        // http://docs.jquery.com/Plugins/Validation
        var form1 = $('#form_sample_1');
        var error1 = $('.alert-danger', form1);
        var success1 = $('.alert-success', form1);

        form1.validate({
            errorElement: 'span', //default input error message container
            errorClass: 'help-block help-block-error', // default input error message class
            focusInvalid: false, // do not focus the last invalid input
            ignore: "", // validate all fields including form hidden input
            messages: { },
            rules: {
                smtp: {
                    minlength: 4,
                    required: true
                },
                host_name: {
                    required: true 
                },
                port: {
                    required: true,
                    number: true
                },
                email_address: {
                    required: true,
                    email: true
                },
                password: {
                    required: true 
                } 
            },
        errorPlacement: function(error, element) {
                if (element.is(':checkbox')) {
                    error.insertAfter(element.closest(".md-checkbox-list, .md-checkbox-inline, .checkbox-list, .checkbox-inline"));
                } else if (element.is(':radio')) {
                    error.insertAfter(element.closest(".md-radio-list, .md-radio-inline, .radio-list,.radio-inline"));
                } else {
                    error.insertAfter(element); // for other inputs, just perform default behavior
                }
            },

            highlight: function(element) { // hightlight error inputs
                $(element)
                    .closest('.form-group').addClass('has-error'); // set error class to the control group
            },

            unhighlight: function(element) { // revert the change done by hightlight
                $(element)
                    .closest('.form-group').removeClass('has-error'); // set error class to the control group
            },

            success: function(label) {
                label
                    .closest('.form-group').removeClass('has-error'); // set success class to the control group
            }
        });
		$('#form_sample_2').validate({
            errorElement: 'span', //default input error message container
            errorClass: 'help-block help-block-error', // default input error message class
            focusInvalid: false, // do not focus the last invalid input
            ignore: "", // validate all fields including form hidden input
            messages: { },
            rules: {
                 
              email_address: {
                    required: true,
                    email: true
                }
            },

              errorPlacement: function(error, element) {
                if (element.is(':checkbox')) {
                    error.insertAfter(element.closest(".md-checkbox-list, .md-checkbox-inline, .checkbox-list, .checkbox-inline"));
                } else if (element.is(':radio')) {
                    error.insertAfter(element.closest(".md-radio-list, .md-radio-inline, .radio-list,.radio-inline"));
                } else {
                    error.insertAfter(element); // for other inputs, just perform default behavior
                }
            },

            highlight: function(element) { // hightlight error inputs
                $(element)
                    .closest('.form-group').addClass('has-error'); // set error class to the control group
            },

            unhighlight: function(element) { // revert the change done by hightlight
                $(element)
                    .closest('.form-group').removeClass('has-error'); // set error class to the control group
            },

            success: function(label) {
                label
                    .closest('.form-group').removeClass('has-error'); // set success class to the control group
            } 
        });
    }
 

    return {
        //main function to initiate the module
        init: function() {
            handleValidation1(); 
        }
    };
}();

jQuery(document).ready(function() {
    FormValidationMd.init();
});
	 
		$(document).ready(function(){
		toastr.options = {
		  "closeButton": true,
		  "debug": false,
		  "positionClass": "toast-bottom-right",
		  "onclick": null,
		  "showDuration": "1000",
		  "hideDuration": "1000",
		  "timeOut": "5000",
		  "extendedTimeOut": "1000",
		  "showEasing": "swing",
		  "hideEasing": "linear",
		  "showMethod": "fadeIn",
		  "hideMethod": "fadeOut"
		};
		 <?php if(isset($page_data->msg_type)) { ?>
		toastr.<?php  echo $page_data->msg_type;  ?>('<?php echo $page_data->msg;  ?>');
		<?php } ?>
		
		});
</script>
 

<script src="<?php echo ASSETS; ?>/global/plugins/select2/js/select2.full.min.js" type="text/javascript"></script>
<script src="<?php echo ASSETS; ?>/pages/scripts/components-select2.min.js" type="text/javascript"></script>
<script src="<?php echo ASSETS; ?>/global/plugins/bootstrap-fileinput/bootstrap-fileinput.js" type="text/javascript"></script>
<script src="<?php echo ASSETS; ?>/pages/scripts/overlaymessage.js" type="text/javascript"></script>



          <script src="<?php echo ASSETS; ?>/global/plugins/bootstrap-modal/js/bootstrap-modalmanager.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/bootstrap-modal/js/bootstrap-modal.js" type="text/javascript"></script>
         <script src="<?php echo ASSETS; ?>/pages/scripts/ui-extended-modals.min.js" type="text/javascript"></script>

        <!-- BEGIN THEME LAYOUT SCRIPTS -->
        <script src="<?php echo ASSETS; ?>/layouts/layout/scripts/layout.min.js" type="text/javascript"></script>
 
         <script src="<?php echo ASSETS; ?>/global/plugins/bootstrap-toastr/toastr.min.js" type="text/javascript"></script>
         
        <script src="<?php echo ASSETS; ?>/layouts/layout/scripts/demo.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/layouts/global/scripts/quick-sidebar.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/layouts/global/scripts/quick-nav.min.js" type="text/javascript"></script>
       <script src="<?php echo ASSETS.'/pages/scripts/appconnect.js'; ?>"></script>
        <!-- END THEME LAYOUT SCRIPTS -->
    </body>

</html>