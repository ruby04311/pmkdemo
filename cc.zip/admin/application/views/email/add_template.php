<!DOCTYPE html>
<html lang="en">
    <!--<![endif]-->
    <!-- BEGIN HEAD -->
    <head>
        <meta charset="utf-8" />
        <title><?php echo PROJECT_TITLE; ?></title>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta content="width=device-width, initial-scale=1" name="viewport" />
        <meta content="Flight is canceled, delayed or missed connecting flight ? Up to 600 € compensation received ✓ 98% success rate ✓ More than 120 countries ✓ Check your claim!" name="description" />
        <meta content="" name="author" />
        <!-- BEGIN GLOBAL MANDATORY STYLES -->
        <link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700&subset=all" rel="stylesheet" type="text/css" />
        <link href="<?php echo ASSETS; ?>/global/plugins/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo ASSETS; ?>/global/plugins/simple-line-icons/simple-line-icons.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo ASSETS; ?>/global/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo ASSETS; ?>/global/plugins/bootstrap-switch/css/bootstrap-switch.min.css" rel="stylesheet" type="text/css" />
        <!-- END GLOBAL MANDATORY STYLES -->
        <!-- BEGIN PAGE LEVEL PLUGINS -->
        <link href="<?php echo ASSETS; ?>/global/plugins/bootstrap-wysihtml5/bootstrap-wysihtml5.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo ASSETS; ?>/global/plugins/bootstrap-markdown/css/bootstrap-markdown.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo ASSETS; ?>/global/plugins/bootstrap-summernote/summernote.css" rel="stylesheet" type="text/css" />
        <!-- END PAGE LEVEL PLUGINS -->
        <link href="<?php echo ASSETS; ?>/global/plugins/select2/css/select2.min.css" rel="stylesheet" type="text/css" />
<link href="<?php echo ASSETS; ?>/global/plugins/select2/css/select2-bootstrap.min.css" rel="stylesheet" type="text/css" />
<link href="<?php echo ASSETS; ?>/global/plugins/bootstrap-fileinput/bootstrap-fileinput.css" rel="stylesheet" type="text/css" />
<link href="<?php echo ASSETS; ?>/global/plugins/bootstrap-sweetalert/sweetalert.css" rel="stylesheet" type="text/css" />

          <link href="<?php echo ASSETS; ?>/global/plugins/bootstrap-multiselect/css/bootstrap-multiselect.css" rel="stylesheet" type="text/css" />


        <!-- BEGIN THEME GLOBAL STYLES -->
        <link href="<?php echo ASSETS; ?>/global/css/components-md.min.css" rel="stylesheet" id="style_components" type="text/css" />
        <link href="<?php echo ASSETS; ?>/global/css/plugins-md.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo ASSETS; ?>/global/plugins/bootstrap-toastr/toastr.min.css" rel="stylesheet" type="text/css" />
        <!-- END THEME GLOBAL STYLES -->
        <!-- BEGIN THEME LAYOUT STYLES -->
        <link href="<?php echo ASSETS; ?>/layouts/layout/css/layout.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo ASSETS; ?>/layouts/layout/css/themes/darkblue.min.css" rel="stylesheet" type="text/css" id="style_color" />
        <link href="<?php echo ASSETS; ?>/layouts/layout/css/custom.min.css" rel="stylesheet" type="text/css" />
        <!-- END THEME LAYOUT STYLES -->
         <link rel="shortcut icon" href="<?php echo ASSETS; ?>/pages/img/refundmeico.png" /> 
         
            <style>
 
 		.checkbox, .form-horizontal .checkbox { padding: 3px 20px 3px 40px; }
		</style>
        
        </head>
    <!-- END HEAD -->

    <body class="page-header-fixed page-sidebar-closed-hide-logo page-content-white page-md">
        <div class="page-wrapper">
            <!-- BEGIN HEADER -->
             <div class="page-header navbar navbar-fixed-top">
                <!-- BEGIN HEADER INNER -->
                  <?php $this->load->view('common/header',''); ?>
                <!-- END HEADER INNER -->
            </div>
            <!-- END HEADER -->
            <!-- BEGIN HEADER & CONTENT DIVIDER -->
            <div class="clearfix"> </div>
            <!-- END HEADER & CONTENT DIVIDER -->
            <!-- BEGIN CONTAINER -->
            <div class="page-container">
                <!-- BEGIN SIDEBAR -->
                                 <?php $this->load->view('common/side_bar',''); ?>

                <!-- END SIDEBAR -->
                <!-- BEGIN CONTENT -->
                <div class="page-content-wrapper">
                    <!-- BEGIN CONTENT BODY -->
                    <div class="page-content">
                        <!-- BEGIN PAGE HEADER-->
                        <!-- BEGIN THEME PANEL -->
                         
                        <!-- END THEME PANEL -->
                        <!-- BEGIN PAGE BAR -->
                        <div class="page-bar">
                            <ul class="page-breadcrumb">
                              <li>
                                    <a href="<?php echo WEB_URL; ?>">Home</a>
                                    <i class="fa fa-circle"></i>
                                </li>
                                <li>
                                    <a href="#">Manage Emails</a>
                                    <i class="fa fa-circle"></i>
                                </li> 
                                <li>
                                    <a href="<?php echo WEB_URL; ?>/email/manage_emails">Manage Theme</a>
                                    <i class="fa fa-circle"></i>
                                </li>
                                <li>
                                    <span>Add Template</span>
                                </li>
                            </ul>
                            
                        </div>
                        <!-- END PAGE BAR -->
                        <!-- BEGIN PAGE TITLE-->
                        <h1 class="page-title"> Add Email Template
                         </h1>
                        <!-- END PAGE TITLE-->
                        <!-- END PAGE HEADER-->
                        <div class="row">
                            <div class="col-md-12">
                                <!-- BEGIN EXTRAS PORTLET-->
                                <div class="portlet light ">
                                     
                                    <div class="portlet-body form">
                                        <form class="form-horizontal "  action="<?php echo WEB_URL; ?>/email_do/add_email_template" method="post"  enctype="multipart/form-data" id="form_sample_1">
                                            <div class="form-body">
                                                <div class="form-group last">
                                                 <div class="col-md-5">
                                                <div class="form-group form-md-line-input">
                                                    <label class="col-md-3 control-label" for="form_control_1">  
                                                    </label>
                                                    <div class="col-md-9">
                                                    <select class="form-control" id="template_type" name="template_type" onChange="change_template(this.value);">
                                                    <option value="">New Template</option>
                                                    <?php 
													for($i=0;$i<count($template);$i++)
													{
														?>
                                                        <option value="<?php echo $template[$i]->email_type; ?>"><?php echo $template[$i]->email_type; ?></option>
                                                        <?php
													}
													?>
                                                    </select>
                                                    
                                                        <div class="form-control-focus"> </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="form-group form-md-line-input" id="template_name">
                                                    <label class="col-md-3 control-label" for="form_control_1">Name of Template <span class="required">*</span>
                                                    </label>
                                                    <div class="col-md-9">
                                                        <input type="text" class="form-control" placeholder="" id="template_name1" name="template_name" value="">
                                                        <div class="form-control-focus"> </div>
                                                    </div>
                                                </div>
                                                <div class="form-group form-md-line-input">
                                                    <label class="col-md-3 control-label" for="form_control_1">Category                                                        <span class="required">*</span>
                                                    </label>
                                                    <div class="col-md-9">
                                                        <select class="form-control" name="category" >
                                                        <option value="">Select</option>
                                                        <?php
														for($l=0;$l<count($cat);$l++)
														{
														?>
															<option value="<?php echo $cat[$l]->email_categories_id; ?>"><?php echo $cat[$l]->category_name; ?></option>
														<?php
														}
														?>
                                                        </select>
                                                        <div class="form-control-focus"> </div>
                                                    </div>
                                                </div>
                                                      <div class="form-group form-md-line-input">
                                                    <label class="col-md-3 control-label" for="form_control_1">Subject                                                        <span class="required">*</span>
                                                    </label>
                                                    <div class="col-md-9">
                                                        <input type="text" class="form-control" placeholder="" name="subject" value="">
                                                        <div class="form-control-focus"> </div>
                                                    </div>
                                                </div>
                                                <div class="form-group form-md-line-input">
                                                    <label class="col-md-3 control-label" for="form_control_1">From Name
                                                        <span class="required">*</span>
                                                    </label>
                                                    <div class="col-md-9">
                                                        <input type="text" class="form-control" placeholder="" name="from_name" value="">
                                                        <div class="form-control-focus"> </div>
                                                    </div>
                                                </div>
                                                 
                                                <div class="form-group form-md-line-input">
                                                    <label class="col-md-3 control-label" for="form_control_1">From Address
                                                        <span class="required">*</span>
                                                    </label>
                                                    <div class="col-md-9">
                                                        <input type="text" class="form-control" placeholder="" name="from_address" value="">
                                                        <div class="form-control-focus"> </div>
                                                    </div>
                                                </div>
                                                 <div class="form-group form-md-line-input">
                                                    <label class="col-md-3 control-label" for="form_control_1">CC address
                                                        
                                                    </label>
                                                    <div class="col-md-9">
                                                        <input type="text" class="form-control" placeholder="" name="email_cc" value="">
                                                        <div class="form-control-focus"> </div>
                                                    </div>
                                                </div>
                                                <div class="form-group form-md-line-input">
                                                    <label class="col-md-3 control-label" for="form_control_1">BCC address
                                                        
                                                    </label>
                                                    <div class="col-md-9">
                                                        <input type="text" class="form-control" placeholder="" name="email_bcc" value="">
                                                        <div class="form-control-focus"> </div>
                                                    </div>
                                                </div>
                                                  <div class="form-group form-md-line-input">
                                                    <label class="col-md-3 control-label" for="form_control_1">Language <span class="required">*</span>
                                                    </label>
                                                    <div class="col-md-9">
                                                    <select class="form-control" name="language" id="language1">
                                                   
                                                    <?php 
													for($i=0;$i<count($language);$i++)
													{
														?>
                                                        <option <?php if($language[$i]->lang_code=='en') { echo 'selected'; } ?> value="<?php echo $language[$i]->lang_code; ?>"><?php echo $language[$i]->lang_name; ?></option>
                                                        <?php
													}
													?>
                                                    </select>
                                                    
                                                        <div class="form-control-focus"> </div>
                                                    </div>
                                                </div>
                                                
                                                  <div class="form-group form-md-line-input">
                                                  <div id="language2">
                                                   
                                                  </div>
                                                   </div>
                                                   
                                                
                                                <div class="form-group form-md-line-input">
                                                    <label class="col-md-3 control-label" for="form_control_1">Add Attachment                                                  
                                                    </label>
                                                    <div class="col-md-9">
                                                       <input type="file" class="form-control" placeholder="" multiple name="file_attach[]" value="">
                                                       
                                                        <div class="form-control-focus"> </div>
                                                    </div>
                                                </div>
                                                 
                                                
                                                    </div>
                                                    <div class="col-md-7">
                                                        <div name="summernote" id="summernote_1">  
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<style type="text/css">
    /* CLIENT-SPECIFIC STYLES */
    body, table, td, a{-webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%;} /* Prevent WebKit and Windows mobile changing default text sizes */
    table, td{mso-table-lspace: 0pt; mso-table-rspace: 0pt;} /* Remove spacing between tables in Outlook 2007 and up */
    img{-ms-interpolation-mode: bicubic;} /* Allow smoother rendering of resized image in Internet Explorer */

    /* RESET STYLES */
    img{border: 0; height: auto; line-height: 100%; outline: none; text-decoration: none;}
    table{border-collapse: collapse !important;}
    body{height: 100% !important; margin: 0 !important; padding: 0 !important; width: 100% !important;}

    /* iOS BLUE LINKS */
    a[x-apple-data-detectors] {
        color: inherit !important;
        text-decoration: none !important;
        font-size: inherit !important;
        font-family: inherit !important;
        font-weight: inherit !important;
        line-height: inherit !important;
    }

    /* MOBILE STYLES */
    @media screen and (max-width: 525px) {

        /* ALLOWS FOR FLUID TABLES */
        .wrapper {
          width: 100% !important;
            max-width: 100% !important;
        }

        /* ADJUSTS LAYOUT OF LOGO IMAGE */
        .logo img {
          margin: 0 auto !important;
        }

        /* USE THESE CLASSES TO HIDE CONTENT ON MOBILE */
        .mobile-hide {
          display: none !important;
        }

        .img-max {
          max-width: 100% !important;
          width: 100% !important;
          height: auto !important;
        }

        /* FULL-WIDTH TABLES */
        .responsive-table {
          width: 100% !important;
        }

        /* UTILITY CLASSES FOR ADJUSTING PADDING ON MOBILE */
        .padding {
          padding: 10px 5% 15px 5% !important;
        }

        .padding-meta {
          padding: 30px 5% 0px 5% !important;
          text-align: center;
        }

        .padding-copy {
             padding: 10px 5% 10px 5% !important;
          text-align: center;
        }

        .no-padding {
          padding: 0 !important;
        }

        .section-padding {
          padding: 50px 15px 50px 15px !important;
        }

        /* ADJUST BUTTONS ON MOBILE */
        .mobile-button-container {
            margin: 0 auto;
            width: 100% !important;
        }

        .mobile-button {
            padding: 15px !important;
            border: 0 !important;
            font-size: 16px !important;
            display: block !important;
        }

    }

    /* ANDROID CENTER FIX */
    div[style*="margin: 16px 0;"] { margin: 0 !important; }
</style>



<!-- HIDDEN PREHEADER TEXT -->
 

<!-- HEADER -->
<table border="0" cellpadding="0" cellspacing="0" width="100%">
    <tbody><tr>
        <td bgcolor="#ffffff" align="center">
            <!--[if (gte mso 9)|(IE)]>
            <table align="center" border="0" cellspacing="0" cellpadding="0" width="500">
            <tr>
            <td align="center" valign="top" width="500">
            <![endif]-->
            <table border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width: 500px;" class="wrapper">
                <tbody><tr>
                    <td align="center" valign="top" style="padding: 15px 0;" class="logo">
                        <a href="refund.me" target="_blank">
                            <img alt="Logo" src="https://www.refund.me/wp-content/uploads/2015/08/refundme-Logo-2015R-02_313x67.png" style="display: block; font-family: Helvetica, Arial, sans-serif; color: #ffffff; font-size: 16px;" border="0">
                        </a>
                    </td>
                </tr>
            </tbody></table>
            <!--[if (gte mso 9)|(IE)]>
            </td>
            </tr>
            </table>
            <![endif]-->
        </td>
    </tr>
     
     
    
    <tr>
        <td bgcolor="#ffffff" align="center" style="text-align: left; padding: 15px;"><p>Dear,</p><p><span style="margin: 0px; padding: 0px; font-family: &quot;Open Sans&quot;, Arial, sans-serif; font-size: 14px; text-align: justify;">Lorem Ipsum</span><span style="font-family: &quot;Open Sans&quot;, Arial, sans-serif; font-size: 14px; text-align: justify;">&nbsp;is simply dummy text of the printing and typesetting industry.</span><br></p><p>
            <!--[if (gte mso 9)|(IE)]>
            </td>
            </tr>
            </table>
            <![endif]-->
        </p></td>
    </tr>
    <tr>
        <td bgcolor="#ffffff" align="center" style="padding: 20px 0px;"><br><table width="100%" border="0" cellspacing="0" cellpadding="0" align="center" style="max-width: 500px;" class="responsive-table">
                <tbody><tr>
                    <td align="center" style="font-size: 12px; line-height: 18px; font-family: Helvetica, Arial, sans-serif; color:#666666;">
                        Copyright © 2016 by refund.me GmbH
                        <br>
                        <a href=" " target="_blank" style="color: #666666; text-decoration: none;">Unsubscribe</a>
                        <span style="font-family: Arial, sans-serif; font-size: 12px; color: #444444;">&nbsp;&nbsp;|&nbsp;&nbsp;</span>
                        <a href=" " target="_blank" style="color: #666666; text-decoration: none;">View this email in your browser</a>
                    </td>
                </tr>
            </tbody></table>
            <!--[if (gte mso 9)|(IE)]>
            </td>
            </tr>
            </table>
            <![endif]-->
        </td>
    </tr>
</tbody></table></div>
                                                    </div>
                                                      
                                                </div>
                                            </div>
                                            <input type="hidden" name="message" value="" id="message">
                                            <div class="form-actions">
                                                <div class="row">
                                                    <div class="col-md-offset-2 col-md-10">
                                                    <input type="submit" class="btn green" value="Save Changes"> 
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                         
                         
                    </div>
                    <!-- END CONTENT BODY -->
                </div>
                <!-- END CONTENT -->
                <!-- BEGIN QUICK SIDEBAR -->
                
                   <?php   $this->load->view('common/right_bar',''); ?>
                <!-- END QUICK SIDEBAR -->
            </div>
            <!-- END CONTAINER -->
            <!-- BEGIN FOOTER -->
                        <?php   $this->load->view('common/footer',''); ?>

            <!-- END FOOTER -->
        </div>
        <!-- BEGIN QUICK NAV -->
         <?php   $this->load->view('common/overlay',''); ?>
        <!-- END QUICK NAV -->
        <!--[if lt IE 9]>
<script src="<?php echo ASSETS; ?>/global/plugins/respond.min.js"></script>
<script src="<?php echo ASSETS; ?>/global/plugins/excanvas.min.js"></script> 
<script src="<?php echo ASSETS; ?>/global/plugins/ie8.fix.min.js"></script> 
<![endif]-->
        <!-- BEGIN CORE PLUGINS -->
        <script src="<?php echo ASSETS; ?>/global/plugins/jquery.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/js.cookie.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/jquery-slimscroll/jquery.slimscroll.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/jquery.blockui.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/bootstrap-switch/js/bootstrap-switch.min.js" type="text/javascript"></script>
        <!-- END CORE PLUGINS -->
        <!-- BEGIN PAGE LEVEL PLUGINS -->
        <script src="<?php echo ASSETS; ?>/global/plugins/bootstrap-wysihtml5/wysihtml5-0.3.0.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/bootstrap-wysihtml5/bootstrap-wysihtml5.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/bootstrap-markdown/lib/markdown.js" type="text/javascript"></script>
        <script src="./<?php echo ASSETS; ?>/global/plugins/bootstrap-markdown/js/bootstrap-markdown.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/bootstrap-summernote/summernote.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/bootstrap-summernote/summernote1.js" type="text/javascript"></script>
         <!-- END PAGE LEVEL PLUGINS -->
        <!-- BEGIN THEME GLOBAL SCRIPTS -->
        <script src="<?php echo ASSETS; ?>/global/scripts/app.min.js" type="text/javascript"></script>
        <script>
	 var FormValidationMd = function() {

    var handleValidation1 = function() {
        // for more info visit the official plugin documentation: 
        // http://docs.jquery.com/Plugins/Validation
        var form1 = $('#form_sample_1');
        var error1 = $('.alert-danger', form1);
        var success1 = $('.alert-success', form1);
		

        form1.validate({
            errorElement: 'span', //default input error message container
            errorClass: 'help-block help-block-error', // default input error message class
            focusInvalid: false, // do not focus the last invalid input
            ignore: "", // validate all fields including form hidden input
            messages: { },
            rules: {
			 
                subject	: {
                    minlength: 4,
                    required: true
                },
				 category	: {
                   required: true
                },
                from_name: {
                    required: true 
                },
                from_address: {
                    required: true,
                    email: true
                 
                } 
            },
			 submitHandler: function(form) { 
	  var template_name1 = $("#template_name1").val();
	   var template_type = $("#template_type").val();
	  if(template_type=='' && template_name1=='')
	  {
		  alert('Enter');
		   return false; 
	  }
	  else
	  {
		   return true; 
	  }
			 },
        errorPlacement: function(error, element) {
                if (element.is(':checkbox')) {
                    error.insertAfter(element.closest(".md-checkbox-list, .md-checkbox-inline, .checkbox-list, .checkbox-inline"));
                } else if (element.is(':radio')) {
                    error.insertAfter(element.closest(".md-radio-list, .md-radio-inline, .radio-list,.radio-inline"));
                } else {
                    error.insertAfter(element); // for other inputs, just perform default behavior
                }
            },

            highlight: function(element) { // hightlight error inputs
                $(element)
                    .closest('.form-group').addClass('has-error'); // set error class to the control group
            },

            unhighlight: function(element) { // revert the change done by hightlight
                $(element)
                    .closest('.form-group').removeClass('has-error'); // set error class to the control group
            },

            success: function(label) {
				$aaa = $('#summernote_1').summernote('code'); 
		$("#message").val($aaa);
                label
                    .closest('.form-group').removeClass('has-error'); // set success class to the control group
            }
        });
		$('#form_sample_2').validate({ });
    }
 

    return {
        //main function to initiate the module
        init: function() {
            handleValidation1(); 
        }
    };
}();

jQuery(document).ready(function() {
    FormValidationMd.init();
});
	 function change_template($val)
			{
				 
				if($val!='')
				{
					 $.ajax({
					"dataType": 'json',
					"type": "POST",
					"url": "<?php echo WEB_URL; ?>/email_do/get_language_data_v1/"+$val,
					"data": "",
 						  success: function(resultData) {
							 $("#language1").html(resultData.result);
							  $("#language2").html(resultData.lang);
 						  }
					
					} );

					$("#template_name").hide();
				}
				else
				{
					 $.ajax({
					"dataType": 'json',
					"type": "POST",
					"url": "<?php echo WEB_URL; ?>/email_do/get_language_data_v1",
					"data": "",
 						  success: function(resultData) {
							 $("#language1").html(resultData.result);
							  $("#language2").html(resultData.lang);
 						  }
					
					} );
					$("#template_name").show();
				}
			}
		$(document).ready(function(){
			 $('.example-getting-started_v1').multiselect({
    includeSelectAllOption: true,
 	preventInputChangeEvent: false,
			 enableCaseInsensitiveFiltering: true,
    maxHeight: 200,
	buttonWidth: 378,
	  maxWidth: 600
		});
		toastr.options = {
		  "closeButton": true,
		  "debug": false,
		  "positionClass": "toast-bottom-right",
		  "onclick": null,
		  "showDuration": "1000",
		  "hideDuration": "1000",
		  "timeOut": "5000",
		  "extendedTimeOut": "1000",
		  "showEasing": "swing",
		  "hideEasing": "linear",
		  "showMethod": "fadeIn",
		  "hideMethod": "fadeOut"
		};
		 <?php if(isset($page_data->msg_type)) { ?>
		toastr.<?php  echo $page_data->msg_type;  ?>('<?php echo $page_data->msg;  ?>');
		<?php } ?>
		
		});
		 $('#summernote_1').summernote({
        height: 400,
        
       toolbar: [
  		    ['style', ['bold', 'italic', 'underline', 'clear']],
    ['font', ['strikethrough', 'superscript', 'subscript']],
    ['fontsize', ['fontsize']],
    ['color', ['color']],
			['para', ['ul', 'ol', 'paragraph']],
  		    ['insert', ['template','link','picture','video','fullscreen','codeview','table','help']]
  		  ],
        template: {
          path: '<?php echo ASSETS; ?>/global/plugins/bootstrap-summernote/tpls',
          list: {
			<?php
			echo $res; ?> 
          }
        }
      });
</script>

         <script src="<?php echo ASSETS; ?>/global/plugins/jquery-validation/js/jquery.validate.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/jquery-validation/js/additional-methods.min.js" type="text/javascript"></script>
        <!-- END THEME GLOBAL SCRIPTS -->
        <!-- BEGIN PAGE LEVEL SCRIPTS -->
        <script src="<?php echo ASSETS; ?>/pages/scripts/components-editors.min.js" type="text/javascript"></script>
        <!-- END PAGE LEVEL SCRIPTS -->
        <!-- BEGIN THEME LAYOUT SCRIPTS -->
        

<script src="<?php echo ASSETS; ?>/global/plugins/select2/js/select2.full.min.js" type="text/javascript"></script>
<script src="<?php echo ASSETS; ?>/pages/scripts/components-select2.min.js" type="text/javascript"></script>
<script src="<?php echo ASSETS; ?>/global/plugins/bootstrap-fileinput/bootstrap-fileinput.js" type="text/javascript"></script>
<script src="<?php echo ASSETS; ?>/pages/scripts/overlaymessage.js" type="text/javascript"></script>

   <script src="<?php echo ASSETS; ?>/global/plugins/bootstrap-multiselect/js/bootstrap-multiselect.js" type="text/javascript"></script>

         
        <script src="<?php echo ASSETS; ?>/layouts/layout/scripts/layout.min.js" type="text/javascript"></script>
         <script src="<?php echo ASSETS; ?>/global/plugins/bootstrap-toastr/toastr.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/layouts/layout/scripts/demo.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/layouts/global/scripts/quick-sidebar.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/layouts/global/scripts/quick-nav.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS.'/pages/scripts/appconnect.js'; ?>"></script>
        <!-- END THEME LAYOUT SCRIPTS -->
    </body>
<style>
.note-popover .popover-content .dropdown-menu, .panel-heading.note-toolbar .dropdown-menu {
	    overflow-y: scroll !important;
    height: 200px !important;
}
</style>
</html>