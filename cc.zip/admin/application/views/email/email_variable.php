<div class="portlet light bordered">
                                     
                                    <div class="portlet-body">
                                        
                                        <table class="table table-striped table-bordered table-hover table-checkable order-column" id="sample_1">
                                            <thead>
                                                <tr>
                                                     <th> Sl No </th>
                                                    <th> Variable </th>
                                                    <th> Description </th>
                                                    
                                                </tr>
                                            </thead>
                                            <tbody>
                                              <?php 
											  for($i=0;$i<count($result);$i++)
											  {
												  ?>
                                                 
                                                 
                                                <tr class="odd gradeX"
                                                <?php
												if($result[$i]->status=='ACTIVE')
												{
													echo ' style="background:#bdffbd"';
												}
													?>
                                                >
                                                     <td> <?php echo $i+1; ?> </td>
                                                    <td> <?php echo $result[$i]->email_variables_code; ?> </td>
                                                     <td> <?php echo $result[$i]->email_variables_des; ?> </td>
                                                  
                                                    
                                                </tr>
                                                 
                                            <?php
											  }
											  ?>
                                             
                                            </tbody>
                                        </table>
                                       
                                    </div>
                                </div>