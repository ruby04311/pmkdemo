<div class="portlet box green">
                                    <div class="portlet-title">
                                        <div class="caption">
                                            <i class="icon-key"></i>Email List </div>
                                       
                                    </div>
                                    <div class="portlet-body">
                                        <div class="table-scrollable">
                                        <?php
										if($result_cron->case_cnt==0)
										{
											 
										}
										else
										{
										if($result_cron->case_cnt != count($result))
										{
											?>
                                        <span class="caption-subject bold uppercase"> <?php echo $result_cron->case_cnt-count($result); ?> Cases are not a (3,2)</span>
                                        <?php
										}
										}
										?>
                                            <table class="table table-striped table-hover">
                                                <thead>
                                                    <tr>
                                                        <th> # </th>
                                                        <th> Subject </th>
                                                        <th> From Address</th>
                                                        <th> To Address </th>
                                                        <th> Status </th>
                                                        <th> Timestamp </th>
                                                       <th> Action </th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
													if($result) {
														for($i=0;$i<count($result);$i++) { ?>
                                                    <tr>
                                                        <td> <?php echo $i+1; ?> </td>
                                                        <td> <?php echo $result[$i]->subject; ?> </td>
                                                        <td> 
                                                         <?php echo $result[$i]->from_address; ?> </td>
                                                         <td> <?php echo $result[$i]->to_address; ?>
                                                        </td>
                                                        <td>
                                                        <?php if($result[$i]->status== 'FAILURE') { ?>
                                                         <span   class="caption-subject font-red-thunderbird bold SCE<?php echo $result[$i]->email_tracking_id; ?>"> FAILURE </span>
                                                         <a class="CE<?php echo $result[$i]->email_tracking_id; ?>"  onClick="run_email(<?php echo $result[$i]->email_tracking_id; ?>);"> <span class="label label-sm label-success bg-purple  bg-font-purple "> Resend </span> </a>
                                                        <span  id="CEE<?php echo $result[$i]->email_tracking_id; ?>"></span>
                                                         <?php
														}
														else
														{
															?>
                                                       <span class="caption-subject font-green-jungle bold"> SENT</span>&nbsp;
                                                         
                                                            <?php
														}
														?>
                                                         </td>
                                                        <td>   
                                                         <?php echo $result[$i]->created_timestamp; ?>
                                                        </td>
                                                         <td>   
                                                        <div class="btn-group btn-group-sm btn-group-solid">   
 																		<a class="btn btn-xs green " target="_blank" href="<?php echo WEB_URL.'/email/view_email/all/'.base64_encode($result[$i]->email_tracking_id); ?>">
                                                                        <i class="fa fa-eye"></i>   </a></div>
                                                        </td>
                                                    </tr>
                                                    <?php
														}
													}
													else
													{
														?>
                                                         <tr><td colspan="7">
                                                        
                                                         <?php
														 
														 	if($result_cron->case_cnt==0)
										{
											 echo '   All the cases not a (3,2).';
										}
										?>
                                                   
                                                         </td></tr>
                                                        <?php
													}
													?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                                
                                <script>
								function run_email($id)
								{
									 $.ajax({
									dataType:"json",
											url: "<?php echo WEB_URL; ?>/email_do/resend_email/"+$id,  
											beforeSend: function(a)
											{
												$idd = "CE"+$id;
												$idde = "CEE"+$id;
												$("."+$idd).html('');
												$("#"+$idde).html('<img src="<?php echo ASSETS; ?>/global/img/loading-spinner-blue.gif">');
											},
											success:function(data) {
												$idd = "CE"+$id;
												$idde = "CEE"+$id;
												$idds = "SCE"+$id;
												 $("."+$idds).html("");
											 $("#"+$idde).html(data.result);
											 
											 /*  $("#summernote_1").summernote('code', data.message); */
											}
										  }); 
									return false;
								}
								</script>