<?php
if($this->uri->segment(1) == true)
{
	$uri_1 = $this->uri->segment(1);
}
if($this->uri->segment(2) == true)
{
	$uri_2 = $this->uri->segment(2);
}
else
{
	$uri_2='';
}
?>
<div class="page-sidebar-wrapper">
                    <!-- BEGIN SIDEBAR -->
                    <!-- DOC: Set data-auto-scroll="false" to disable the sidebar from auto scrolling/focusing -->
                    <!-- DOC: Change data-auto-speed="200" to adjust the sub menu slide up/down speedstyle="width:1000px" -->
                    <div class="page-sidebar navbar-collapse collapse"   >
                        <!-- BEGIN SIDEBAR MENU -->
                        <!-- DOC: Apply "page-sidebar-menu-light" class right after "page-sidebar-menu" to enable light sidebar menu style(without borders) -->
                        <!-- DOC: Apply "page-sidebar-menu-hover-submenu" class right after "page-sidebar-menu" to enable hoverable(hover vs accordion) sub menu mode -->
                        <!-- DOC: Apply "page-sidebar-menu-closed" class right after "page-sidebar-menu" to collapse("page-sidebar-closed" class must be applied to the body element) the sidebar sub menu mode -->
                        <!-- DOC: Set data-auto-scroll="false" to disable the sidebar from auto scrolling/focusing -->
                        <!-- DOC: Set data-keep-expand="true" to keep the submenues expanded -->
                        <!-- DOC: Set data-auto-speed="200" to adjust the sub menu slide up/down speed -->
                        <ul class="page-sidebar-menu  page-header-fixed " data-keep-expanded="false" data-auto-scroll="true" data-slide-speed="200" style="padding-top: 20px">
                            <!-- DOC: To remove the sidebar toggler from the sidebar you just need to completely remove the below "sidebar-toggler-wrapper" LI element -->
                            <!-- BEGIN SIDEBAR TOGGLER BUTTON -->
                            <li class="sidebar-toggler-wrapper hide">
                                <div class="sidebar-toggler">
                                    <span></span>
                                </div>
                            </li>
                            <!-- END SIDEBAR TOGGLER BUTTON -->
                            <!-- DOC: To remove the search box from the sidebar you just need to completely remove the below "sidebar-search-wrapper" LI element -->
                             <?php
$menu_title_v = $this->general_model->get_side_bar_menu_v1($this->user_type,$this->user_id,'privilege_group');
 
if(!empty($menu_title_v))
{
	
	
			$tmp = array();
			
			foreach($menu_title_v as $arg)
			{
 				$menu_title_v2 = array('privileges_name'=>$arg->privileges_name
				,'privileges_icon'=>$arg->privileges_icon,'controller_name'=>$arg->controller_name
				,'method_name'=>$arg->method_name);
				
 				$tempa = array('privilege'=>$menu_title_v2,'module_name'=>$arg->module_name,'module_icon'=>$arg->module_icon);
				 
				$tmp[$arg->group_name][] = $tempa;
 			}
			
			$output = array();
			
			foreach($tmp as $type => $labels)
			{
				$tmpq = array();

				foreach($labels as $argq)
				{
					 
					$tmpq[$argq['module_name']][] =  array($argq['module_icon'],$argq['privilege']);
				
				}
				
				$outputq = array();
				 
				foreach($tmpq as $typeq => $labelsq)
				{
					 
					$outputq[] = array(
						'privilege_name' => $typeq,
						 'privilege_icon' => $labelsq[0][0],
						'actions' => $labelsq
					);
				}

				$output[] = array(
					'group_name' => $type,  
					'privileges' => $outputq
				);
			}
			

} 
 
if(!empty($output))
{
	
	for($jd=0;$jd<count($output);$jd++)
	{
?>
							<li class="heading">
                                <h3 class="uppercase"><?php echo $output[$jd]['group_name']; ?></h3>
                            </li>
                            <?php
	 
							for($j=0;$j<count($output[$jd]['privileges']);$j++)
							{
							
							?>
                            <li class="nav-item   <?php if($uri_1==$output[$jd]['privileges'][$j]['actions'][0][1]['controller_name']) { ?>active open <?php } ?>">
                                <a href="javascript:;" class="nav-link nav-toggle">
                                    <i class="<?php echo $output[$jd]['privileges'][$j]['privilege_icon']; ?>"></i>
                                    <span class="title"><?php echo $output[$jd]['privileges'][$j]['privilege_name']; ?></span>
                                    <span class="arrow <?php if($uri_1==$output[$jd]['privileges'][$j]['actions'][0][1]['controller_name']) { ?>open <?php } ?>"></span>
                                </a>
                                
                                
                                <ul class="sub-menu">
                                  <?php
	 
							for($jj=0;$jj<count($output[$jd]['privileges'][$j]['actions']);$jj++)
							{
								
							?>
                                    <li class="nav-item <?php    if($uri_2==$output[$jd]['privileges'][$j]['actions'][$jj][1]['method_name']) { ?>active  <?php } ?> ">
                                        <a href="<?php echo WEB_URL; ?>/<?php echo $output[$jd]['privileges'][$j]['actions'][$jj][1]['controller_name']; ?>/<?php echo $output[$jd]['privileges'][$j]['actions'][$jj][1]['method_name']; ?><?php echo $this->emp_sign; ?>" class="nav-link ">
                                           <i class="<?php echo $output[$jd]['privileges'][$j]['actions'][$jj][1]['privileges_icon']; ?>"></i>
                                            <span class="title"><?php echo $output[$jd]['privileges'][$j]['actions'][$jj][1]['privileges_name']; ?></span>
                                        </a>
                                    </li>
                                   <?php
							}
							?>
                           
                                     
                                </ul>
                            </li>
                               
                            <?php
							}
							?>
                   
                    <!-- /sidebar menu -->
<?php
	}
}
?>
                        <!--     <li class="heading">
                                <h3 class="uppercase">Admin Console</h3>
                            </li>
                            <li class="nav-item start <?php if($uri_1=='home') { ?>active open <?php } ?>">
                                <a href="<?php echo WEB_URL; ?>" class="nav-link nav-toggle">
                                    <i class="icon-home"></i>
                                    <span class="title">Dashboard </span>
                                    <span class="selected"></span>
                                   
                                </a>
                            
                            </li>
                            
                            <li class="nav-item  ">
                                <a href="javascript:;" class="nav-link nav-toggle">
                                    <i class="fa fa-folder-open-o"></i>
                                    <span class="title">Departments </span>
                                   <span class="arrow"></span>
                                </a>
                                <ul class="sub-menu">
                                    <li class="nav-item start  ">
                                        <a href="<?php echo WEB_URL; ?>/department/list_all" class="nav-link ">
                                            <i class="fa fa-folder-open-o"></i>
                                            <span class="title">All Department</span>
                                            <span class="selected"></span>
                                        </a>
                                    </li>
                                    <li class="nav-item start ">
                                        <a href="<?php echo WEB_URL; ?>/department/add_new" class="nav-link ">
                                            <i class="fa fa-folder-open-o"></i>
                                            <span class="title">Add New Depatrment</span>
                                             
                                        </a>
                                    </li>
                                    
                                    
                                </ul>
                            </li>
                            <li class="nav-item">
                                <a href="javascript:;" class="nav-link nav-toggle">
                                    <i class="icon-key"></i>
                                    <span class="title">Role / Privileges</span>
                                     <span class="arrow"></span>
                                </a>
                                <ul class="sub-menu">
                                    <li class="nav-item start ">
                                        <a href="<?php echo WEB_URL; ?>/role/list_all" class="nav-link ">
                                            <i class="fa fa-asterisk"></i>
                                            <span class="title">All Role</span>
                                            
                                        </a>
                                    </li>
                                    <li class="nav-item start ">
                                        <a href="<?php echo WEB_URL; ?>/role/add_new" class="nav-link ">
                                            <i class="fa fa-asterisk"></i>
                                            <span class="title">Add New Role</span>
                                         </a>
                                    </li>
                                    <li class="nav-item start ">
                                        <a href="<?php echo WEB_URL; ?>/role/manage_privileges" class="nav-link ">
                                            <i class="icon-key"></i>
                                            <span class="title">Privileges</span>
                                           
                                        </a>
                                    </li>
                                    
                                      <li class="nav-item start ">
                                        <a href="<?php echo WEB_URL; ?>/role/allot_privileges" class="nav-link ">
                                            <i class="icon-key"></i>
                                            <span class="title">Allot Privileges</span>
                                           
                                        </a>
                                    </li>
                                    
                                </ul>
                            </li>
                            <li class="nav-item  ">
                                <a href="javascript:;" class="nav-link nav-toggle">
                                    <i class="icon-user"></i>
                                    <span class="title">Employee</span>
                                    <span class="arrow"></span>
                                </a>
                                <ul class="sub-menu">
                                    <li class="nav-item  ">
                                        <a href="<?php echo WEB_URL; ?>/employee/list_all" class="nav-link ">
                                          <i class="fa fa-navicon"></i>
                                            <span class="title">All List</span>
                                        </a>
                                    </li>
                                    <li class="nav-item  ">
                                        <a href="<?php echo WEB_URL; ?>/employee/add_new" class="nav-link ">
                                          <i class="fa fa-user-plus"></i>
                                            <span class="title">Add New</span>
                                        </a>
                                    </li>
                                    <li class="nav-item  ">
                                        <a href="<?php echo WEB_URL; ?>/employee/active" class="nav-link ">
                                          <i class="fa fa-check-circle-o"></i>
                                            <span class="title">Active Employee</span>
                                        </a>
                                    </li>
                                    <li class="nav-item  ">
                                        <a href="<?php echo WEB_URL; ?>/employee/inactive" class="nav-link ">
                                          <i class="fa fa-remove"></i>
                                            <span class="title">Inactive Employee</span>
                                        </a>
                                    </li>
                                     
                                </ul>
                            </li>
                            <li class="heading">
                                <h3 class="uppercase">Support</h3>
                            </li>
                            <li class="nav-item  ">
                                <a href="javascript:;" class="nav-link nav-toggle">
                                    <i class="fa fa-support"></i>
                                    <span class="title">Support Ticket</span>
                                    <span class="arrow"></span>
                                </a>
                                <ul class="sub-menu">
                                    <li class="nav-item  ">
                                        <a href="ui_colors.html" class="nav-link ">
                                          <i class="fa fa-inbox"></i>
                                            <span class="title">Inbox</span>
                                        </a>
                                    </li>
                                    <li class="nav-item  ">
                                        <a href="ui_metronic_grid.html" class="nav-link ">
                                          <i class="fa fa-send-o"></i>
                                            <span class="title">Sent</span>
                                        </a>
                                    </li>
                                    <li class="nav-item  ">
                                        <a href="ui_general.html" class="nav-link ">
                                          <i class="fa fa-sign-out"></i>
                                            <span class="title">Closed</span>
                                        </a>
                                    </li>
                                    <li class="nav-item  ">
                                        <a href="ui_buttons.html" class="nav-link ">
                                          <i class="fa fa-cube"></i>
                                            <span class="title">Subject Line</span>
                                        </a>
                                    </li>
                                     
                                </ul>
                            </li>
                            
                            <li class="nav-item  ">
                                <a href="javascript:;" class="nav-link nav-toggle">
                                    <i class="fa fa-info"></i>
                                    <span class="title">Help</span>
                                    <span class="arrow"></span>
                                </a>
                                <ul class="sub-menu">
                                    <li class="nav-item  ">
                                        <a href="ui_colors.html" class="nav-link ">
                                          <i class="fa fa-navicon"></i>
                                            <span class="title">List All</span>
                                        </a>
                                    </li>
                                    <li class="nav-item  ">
                                        <a href="ui_metronic_grid.html" class="nav-link ">
                                          <i class="fa fa-plus-circle"></i>
                                            <span class="title">Add New</span>
                                        </a>
                                    </li>
                           
                                     
                                </ul>
                            </li>
                             <li class="nav-item   <?php if($uri_1=='email') { ?>active open <?php } ?>">
                                <a href="javascript:;" class="nav-link nav-toggle">
                                    <i class="fa fa-envelope-o"></i>
                                    <span class="title">Manage Emails</span>
                                    <span class="arrow <?php if($uri_1=='email') { ?>open <?php } ?>"></span>
                                </a>
                                <ul class="sub-menu">
                                    <li class="nav-item <?php if($uri_2=='manage_theme') { ?>active  <?php } ?> ">
                                        <a href="<?php echo WEB_URL; ?>/email/manage_emails" class="nav-link ">
                                          <i class="fa fa-navicon"></i>
                                            <span class="title">Manage Theme</span>
                                        </a>
                                    </li>
                                    <li class="nav-item  <?php if($uri_2=='email_settings') { ?>active <?php } ?>">
                                        <a href="<?php echo WEB_URL; ?>/email/email_settings" class="nav-link ">
                                          <i class="fa fa-gear"></i>
                                            <span class="title">Email Settings</span>
                                        </a>
                                    </li>
                           
                                     
                                </ul>
                            </li>-->
                            
                       
                        </ul>
                        <!-- END SIDEBAR MENU -->
                        <!-- END SIDEBAR MENU -->
                    </div>
                    <!-- END SIDEBAR -->
                </div>