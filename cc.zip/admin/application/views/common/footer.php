<div class="page-footer">
                <div class="page-footer-inner"> Copyright © <?php echo date("Y"); ?>  by <a href="refund.me">refund.me</a> GmbH
                </div>
                <div class="scroll-to-top">
                    <i class="icon-arrow-up"></i>
                </div>
            </div>
 
 
      <script src="<?php echo ASSETS.'/node_modules/socket.io/node_modules/socket.io-client/socket.io.js'; ?>"></script>
      <script>
	  $set_valc=0;
	  var WEB_URL = "<?php echo WEB_URL; ?>";
	   $ntfy_current_user = "<?php echo $this->user_id; ?>";
	  </script>