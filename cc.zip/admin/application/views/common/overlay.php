  <nav class="quick-nav" style="width:500px; top:37%">
            <a class="quick-nav-trigger" href="#0">
                <span aria-hidden="true"></span>
            </a>
            <ul>
                <li>
                    <div class="row">
                            <div class="col-md-12">
                                <!-- BEGIN EXTRAS PORTLET-->
                                <div class="">
                                     
                                    <div class="portlet-body form">
                                    <div class="mt-timeline-2">
                                    
                                    <ul class="mt-container" style="margin:0px !important">
                                        
                                        
                                        
                                        
                                        <li class="mt-item">
                                            
                                            <div class="mt-timeline-content"  style="width:100%">
                                                <div class="mt-content-container" id="overlaymessage_body" style="background-color:#FFFFFF; border:0px">
                                                    <div class="mt-title" style="position:absolute">
                                                        <h3 class="mt-content-title" style="margin-top:20px">Message</h3>
                                                    </div>
                                                    <div class="mt-author" style="width:100%">
                                                        <div class="mt-avatar">
                                                            <img src="<?php echo  $this->user_pic; ?>">
                                                        </div>
                                                        <div class="mt-author-name">
                                                            <a href="javascript:;" class="font-blue-madison"><?php echo $this->user_name;  ?></a>
                                                        </div>
                                                        <div class="mt-author-notes font-grey-mint">
                                                        <?php echo date("d M Y : h:i A"); ?> </div>
                                                    </div>
                                                    <div class="mt-content border-grey-salt" style="padding-top:0px; border:0px;"> 
  <div id="layoutmessage_success" style="background-color:#fff; position:absolute; width:80%; height:78%; display:none; z-index:10000000; text-align:center; animation:showSweetAlert 0.3s">
  <div class="sa-icon sa-success animate" style="    border-color: #4cae4c;    border-radius: 50%!important;width: 80px;
    height: 80px;
    border: 4px solid gray;
    border-radius: 50%;
    margin: 20px auto;
    position: relative;
    box-sizing: content-box;
">
      <span class="sa-line sa-tip animateSuccessTip" style="    width: 25px;
    left: 14px;
    top: 46px;
    transform: rotate(45deg);height: 5px;
    background-color: #5cb85c;
    display: block;
    border-radius: 2px;
    position: absolute;
    z-index: 2;"></span>
      <span class="sa-line sa-long animateSuccessLong" style="width: 47px;
    right: 8px;
    top: 38px;
    transform: rotate(-45deg);    height: 5px;
    background-color: #5cb85c;
    display: block;
    border-radius: 2px;
    position: absolute;
    z-index: 2;"></span>

      <div class="sa-placeholder" style="width: 80px;
    height: 80px;
    border: 4px solid rgba(92, 184, 92, 0.2);
    border-radius: 50%;
    box-sizing: content-box;
    position: absolute;
    left: -4px;
    top: -4px;
    z-index: 2;"></div>
      <div class="sa-fix" style="width: 5px;
    height: 90px;
     position: absolute;
    left: 28px;
    top: 8px;
    z-index: 1;
    transform: rotate(-45deg);"></div>
    </div> <h2 style="    font-size: 20px;
    padding-top: 5px;">Message Sent...</h2>
    <p style=" font-size:14px ">Your message has beed sent successfully, For mor details check your inbox.</p>
    </div>
    
    
                                                    <form role="form" class="form-horizontal " id="form_overlaymessage"  >
                                            <div class="form-body">
                                            <?php /*?><div class="form-group form-md-radios">
                                                <label>To</label>
                                                <div class="md-radio-inline">
                                                    <div class="md-radio">
                                                        <input type="radio" id="radio6" name="radio2" class="md-radiobtn">
                                                        <label for="radio6">
                                                            <span></span>
                                                            <span class="check"></span>
                                                            <span class="box"></span> All </label>
                                                    </div>
                                                    
                                                </div>
                                            </div><?php */?>
                                            <div class="form-group">
                                            <select required id="overlay_employee" name="overlay_employee" class="form-control select2-multiple" multiple>
                                                    <?php
													if($this->overlay_employee_details)
													{
													for($oed=0;$oed<count($this->overlay_employee_details);$oed++)
													{
                                                    echo '<option value="'.$this->overlay_employee_details[$oed]["user_id"].'|'.$this->overlay_employee_details[$oed]["user_type"].'">'.$this->overlay_employee_details[$oed]["user_name"].'</option>';
												 
													}
													}
													?>
                                                 
                                            </select>
                                        </div>
                                         <div class="form-group ">
                                                    <input type="text" required class="form-control" id="overlay_subject" name="overlay_subject" placeholder="Subject" />
                                                   
                                                </div>
                                                 <div class="form-group ">
                                                    <textarea required class="form-control" id="overlay_message" name="overlay_message" placeholder="Message type here..." rows="5"></textarea>
                                                   
                                                </div>
                                                 <div class="form-group">
                                                          <div class="fileinput fileinput-new" data-provides="fileinput">
                                                            <span class="btn btn-xs blue-dark  btn-file">
                                                                <span class="fileinput-new"> Attachment </span>
                                                                <span class="fileinput-exists"> Change </span>
                                                                <input type="file"  id="overlay_attachment" name="overlay_attachment"> </span>
                                                            <span class="fileinput-filename" style="display:-webkit-inline-box !important; color:#999 !important;"> </span> &nbsp;
                                                           <?php /*?> <a href="javascript:;" style="display:-webkit-inline-box !important; color:#999 !important;" class="close fileinput-exists" data-dismiss="fileinput"> </a><?php */?>
                                                        </div>
                                                 </div>
                                              <?php /*?><div class="form-group"> 
                                                  <div class="fileinput fileinput-new" data-provides="fileinput">
                                                            <span class="label label-primary  btn-file" style="">
                                                                <span class="fileinput-new"> <i class="fa fa-paperclip"></i> Attachment</span>
                                                                <span class="fileinput-exists"> Change </span>
                                                                <input type="file" id="overlay_attachment" name="overlay_attachment"> </span>
                                                            <span class="fileinput-filename" style="display:-webkit-inline-box !important; color:#999 !important;"> </span> &nbsp;
                                                            <a href="javascript:;" class="close fileinput-exists"  style="display:-webkit-inline-box !important; color:#999 !important;" data-dismiss="fileinput"> </a>
                                                        </div>
                                                </div><?php */?>
                                             </div>
                                            <div class="form-actions noborder" id="overlaymessage_footer">
                                                <input type="submit" class="btn blue" value="send">
                                            </div>
                                        </form>
                                        
                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                        
                                        
                                    </ul>
                                </div>
                                        <?php /*?><?php */?>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                </li>
            </ul>
            <span aria-hidden="true" class="quick-nav-bg"></span>
        </nav>
        <div class="quick-nav-overlay"></div> 