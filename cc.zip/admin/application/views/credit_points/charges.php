<!DOCTYPE html>
<html lang="en">
    <!--<![endif]-->
    <!-- BEGIN HEAD -->
    <head>
        <meta charset="utf-8" />
        <title><?php echo PROJECT_TITLE; ?></title>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta content="width=device-width, initial-scale=1" name="viewport" />
        <meta content="Flight is canceled, delayed or missed connecting flight ? Up to 600 € compensation received ✓ 98% success rate ✓ More than 120 countries ✓ Check your claim!" name="description" />
        <meta content="" name="author" />
        <!-- BEGIN GLOBAL MANDATORY STYLES -->
        <link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700&subset=all" rel="stylesheet" type="text/css" />
        <link href="<?php echo ASSETS; ?>/global/plugins/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo ASSETS; ?>/global/plugins/simple-line-icons/simple-line-icons.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo ASSETS; ?>/global/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo ASSETS; ?>/global/plugins/bootstrap-switch/css/bootstrap-switch.min.css" rel="stylesheet" type="text/css" />
        <!-- END GLOBAL MANDATORY STYLES -->
        <!-- BEGIN PAGE LEVEL PLUGINS -->
        <link href="<?php echo ASSETS; ?>/global/plugins/bootstrap-wysihtml5/bootstrap-wysihtml5.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo ASSETS; ?>/global/plugins/bootstrap-markdown/css/bootstrap-markdown.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo ASSETS; ?>/global/plugins/bootstrap-summernote/summernote.css" rel="stylesheet" type="text/css" />
        <!-- END PAGE LEVEL PLUGINS -->
        <link href="<?php echo ASSETS; ?>/global/plugins/select2/css/select2.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo ASSETS; ?>/global/plugins/select2/css/select2-bootstrap.min.css" rel="stylesheet" type="text/css" />
       <link href="<?php echo ASSETS; ?>/global/plugins/bootstrap-fileinput/bootstrap-fileinput.css" rel="stylesheet" type="text/css" />
 <link href="<?php echo ASSETS; ?>/global/plugins/datatables/datatables.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo ASSETS; ?>/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo ASSETS; ?>/global/plugins/bootstrap-sweetalert/sweetalert.css" rel="stylesheet" type="text/css" />
        <!-- BEGIN THEME GLOBAL STYLES -->
        <link href="<?php echo ASSETS; ?>/global/css/components-md.min.css" rel="stylesheet" id="style_components" type="text/css" />
        <link href="<?php echo ASSETS; ?>/global/css/plugins-md.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo ASSETS; ?>/global/plugins/bootstrap-toastr/toastr.min.css" rel="stylesheet" type="text/css" />
        <!-- END THEME GLOBAL STYLES -->
        <!-- BEGIN THEME LAYOUT STYLES -->
        <link href="<?php echo ASSETS; ?>/layouts/layout/css/layout.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo ASSETS; ?>/layouts/layout/css/themes/darkblue.min.css" rel="stylesheet" type="text/css" id="style_color" />
        <link href="<?php echo ASSETS; ?>/layouts/layout/css/custom.min.css" rel="stylesheet" type="text/css" />
        <!-- END THEME LAYOUT STYLES -->
 <link rel="shortcut icon" href="<?php echo ASSETS; ?>/pages/img/refundmeico.png" /> </head>
    <!-- END HEAD -->

    <body class="page-header-fixed page-sidebar-closed-hide-logo page-content-white page-md">
        <div class="page-wrapper">
            <!-- BEGIN HEADER -->
             <div class="page-header navbar navbar-fixed-top">
                <!-- BEGIN HEADER INNER -->
                  <?php $this->load->view('common/header',''); ?>
                <!-- END HEADER INNER -->
            </div>
            <!-- END HEADER -->
            <!-- BEGIN HEADER & CONTENT DIVIDER -->
            <div class="clearfix"> </div>
            <!-- END HEADER & CONTENT DIVIDER -->
            <!-- BEGIN CONTAINER -->
            <div class="page-container">
                <!-- BEGIN SIDEBAR -->
                                 <?php $this->load->view('common/side_bar',''); ?>

                <!-- END SIDEBAR -->
                <!-- BEGIN CONTENT -->
                <div class="page-content-wrapper">
                    <!-- BEGIN CONTENT BODY -->
                    <div class="page-content">
                        <!-- BEGIN PAGE HEADER-->
                        <!-- BEGIN THEME PANEL -->
                         
                        <!-- END THEME PANEL -->
                        <!-- BEGIN PAGE BAR -->
                        <div class="page-bar">
                            <ul class="page-breadcrumb">
                              <li>
                                    <a href="<?php echo WEB_URL; ?>">Home</a>
                                    <i class="fa fa-circle"></i>
                                </li>
                                <li>
                                    <a href="#">Credit Points</a>
                                    <i class="fa fa-circle"></i>
                                </li> 
                                <li>
                                    <a href="">Credit Points Charges</a>
                                   
                                </li> 
                            </ul>
                            
                        </div>
                        <!-- END PAGE BAR -->
                        <!-- BEGIN PAGE TITLE-->
                        <h1 class="page-title"> Credit Points Charges
                         </h1>
                        <!-- END PAGE TITLE-->
                        <!-- END PAGE HEADER-->
                        <div class="row">
                           <?php
							for($i=0;$i<count($result);$i++)
							{
								if($result[$i]->charge_type=='SINGLE')
								{
								?>
								<div class="col-md-6">
                                <!-- BEGIN EXTRAS PORTLET-->
                                <div class="portlet box green-jungle ">
                                     <div class="portlet-title">
                                        <div class="caption">
                                            <i class="fa fa-gift"></i>SINGLE </div>
                                        <div class="tools">
                                            <div class="actions">
												<div class="btn-group">
													<a class="btn btn-sm red" href="javascript:;" data-toggle="dropdown" id="single_status">
														<i class="fa <?php echo $single=='ACTIVE'?'fa-eye':'fa-eye-slash';?>"></i> <?php echo $single; ?>
														<i class="fa fa-angle-down "></i>
													</a>
													<ul class="dropdown-menu pull-right">
														<li>
															<a href="javascript:;" id="single_active">
																<i class="fa fa-eye"></i> ACTIVE </a>
														</li>
														<li>
															<a href="javascript:;" id="single_inactive">
																<i class="fa fa-eye-slash"></i> INACTIVE </a>
														</li>
													</ul>
												</div>
											</div>
                                        </div>
                                    </div>
                                    <div class="portlet-body form">
                                        <form class="form-horizontal "  method="post"  id="form_sample_1">
                                            <div class="form-body">
                                                <div class="form-group last">
                                                 <div class="col-md-12">
                                                      <div class="form-group form-md-line-input">
                                                    <label class="col-md-4 control-label" for="form_control_1">Credit Point Value                                                 <span class="required">*</span>
                                                    </label>
                                                    <div class="col-md-8">
                                                        <input type="number" class="form-control" value="<?php echo $result[$i]->charge_value; ?>" id="single_val" name="single_val">
                                                        <div class="form-control-focus"> </div>
                                                    </div>
                                                </div>
                                              
                                                 
                                                 
                                                    </div>
                                                     
                                                </div>
                                            </div>
                                           
                                            <div class="form-actions">
                                                <div class="row">
                                                    <div class="col-md-offset-2 col-md-10">
                                                    <input type="submit" class="btn green" value="Save"> 
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <!-- BEGIN EXTRAS PORTLET-->
                                <div class="portlet box green-jungle ">
                                     <div class="portlet-title">
                                        <div class="caption">
                                            <i class="fa fa-gift"></i>HISTORY </div>
                                        <div class="tools">
                                            
                                        </div>
                                    </div>
                                    <div class="portlet-body">
                                        
                                         <table class="table table-striped table-bordered table-hover order-column" id="sample_1s">
                                                <thead>
                                                    <tr>
                                                        <th> # </th>
                                                        <th> Credit Point Value</th>
                                                        <th> Updated On  </th>
                                                        
                                                    </tr>
                                                </thead>
                                                <tbody >
                                                    <?php 
										$result_history = $this->credit_points_model->get_charges_history('SINGLE');
													if(isset($result_history) && $result_history!='') { for($j=0;$j<count($result_history);$j++)
													{
														?>
                                                    <tr>
                                                        <td> CPH<?php echo $result_history[$j]->user_credit_points_charges_history_id; ?> </td>
                                                        <td> <?php echo $result_history[$j]->charge_value; ?></td>
                                                       <td> <?php echo $result_history[$j]->created_timestamp; ?></td>
                                                    </tr>
                                                    <?php
													}
													}
													else
													{
														echo '<tr> <td colspan="3">No Record Found. </td></tr>';
													}
													?>
                                                </tbody>
                                            </table>
                                      
                                    </div>
                                </div>
                            </div>
								<?php
								}
								if($result[$i]->charge_type=='JOURNEY')
								{
								?>
								<div class="col-md-6">
                                <!-- BEGIN EXTRAS PORTLET-->
                                <div class="portlet box purple-wisteria ">
                                     <div class="portlet-title">
                                        <div class="caption">
                                            <i class="fa fa-gift"></i>JOURNEY </div>
                                        <div class="tools">
                                            <div class="actions">
												<div class="btn-group">
													<a class="btn btn-sm red" href="javascript:;" data-toggle="dropdown" id="journey_status">
														<i class="fa <?php echo $journey=='ACTIVE'?'fa-eye':'fa-eye-slash';?>"></i> <?php echo $journey; ?>
														<i class="fa fa-angle-down "></i>
													</a>
													<ul class="dropdown-menu pull-right">
														<li>
															<a href="javascript:;" id="journey_active">
																<i class="fa fa-eye"></i> ACTIVE </a>
														</li>
														<li>
															<a href="javascript:;" id="journey_inactive">
																<i class="fa fa-eye-slash"></i> INACTIVE </a>
														</li>
													</ul>
												</div>
											</div>
                                        </div>
                                    </div>
                                    <div class="portlet-body form">
                                        <form class="form-horizontal "  method="post"  id="form_sample_2">
                                            <div class="form-body">
                                                <div class="form-group last">
                                                 <div class="col-md-12">
                                                      <div class="form-group form-md-line-input">
                                                    <label class="col-md-4 control-label" for="form_control_1">Credit Point Value                                                 <span class="required">*</span>
                                                    </label>
                                                    <div class="col-md-8">
                                                        <input type="number" value="<?php echo $result[$i]->charge_value; ?>" class="form-control" id="journey_val" name="journey_val">
                                                        <div class="form-control-focus"> </div>
                                                    </div>
                                                </div>
                                              
                                                 
                                                 
                                                    </div>
                                                     
                                                </div>
                                            </div>
                                           
                                            <div class="form-actions">
                                                <div class="row">
                                                    <div class="col-md-offset-2 col-md-10">
                                                    <input type="submit" class="btn green" value="Save"> 
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <!-- BEGIN EXTRAS PORTLET-->
                                <div class="portlet box purple-wisteria ">
                                     <div class="portlet-title">
                                        <div class="caption">
                                            <i class="fa fa-gift"></i>HISTORY </div>
                                        <div class="tools">
                                            
                                        </div>
                                    </div>
                                    <div class="portlet-body">
                                        
                                         <table class="table table-striped table-bordered table-hover order-column" id="sample_2s">
                                                <thead>
                                                    <tr>
                                                        <th> # </th>
                                                        <th> Credit Point Value</th>
                                                        <th> Updated On  </th>
                                                        
                                                    </tr>
                                                </thead>
                                                <tbody >
                                                    <?php 
										$result_history = $this->credit_points_model->get_charges_history('JOURNEY');
													if(isset($result_history) && $result_history!='') { for($j=0;$j<count($result_history);$j++)
													{
														?>
                                                    <tr>
                                                        <td> CPH<?php echo $result_history[$j]->user_credit_points_charges_history_id; ?> </td>
                                                        <td> <?php echo $result_history[$j]->charge_value; ?></td>
                                                       <td> <?php echo $result_history[$j]->created_timestamp; ?></td>
                                                    </tr>
                                                    <?php
													}
													}
													else
													{
														echo '<tr> <td colspan="3">No Record Found. </td></tr>';
													}
													?>
                                                </tbody>
                                            </table>
                                      
                                    </div>
                                </div>
                            </div>
								<?php
								}
								if($result[$i]->charge_type=='PREVIEW')
								{
								?>
								<div class="col-md-6">
                                <!-- BEGIN EXTRAS PORTLET-->
                                <div class="portlet box blue ">
                                     <div class="portlet-title">
                                        <div class="caption">
                                            <i class="fa fa-gift"></i>PREVIEW </div>
                                        <div class="tools">
                                            <div class="actions">
												<div class="btn-group">
													<a class="btn btn-sm red" href="javascript:;" data-toggle="dropdown" id="preview_status">
														<i class="fa <?php echo $preview=='ACTIVE'?'fa-eye':'fa-eye-slash';?>"></i> <?php echo $preview; ?>
														<i class="fa fa-angle-down "></i>
													</a>
													<ul class="dropdown-menu pull-right">
														<li>
															<a href="javascript:;" id="preview_active">
																<i class="fa fa-eye"></i> ACTIVE </a>
														</li>
														<li>
															<a href="javascript:;" id="preview_inactive">
																<i class="fa fa-eye-slash"></i> INACTIVE </a>
														</li>
													</ul>
												</div>
											</div>
                                        </div>
                                    </div>
                                    <div class="portlet-body form">
                                        <form class="form-horizontal "  method="post"  id="form_sample_3">
                                            <div class="form-body">
                                                <div class="form-group last">
                                                 <div class="col-md-12">
                                                      <div class="form-group form-md-line-input">
                                                    <label class="col-md-4 control-label" for="form_control_3">Credit Point Value                                                 <span class="required">*</span>
                                                    </label>
                                                    <div class="col-md-8">
                                                        <input type="number" value="<?php echo $result[$i]->charge_value; ?>" class="form-control" id="preview_val" name="preview_val">
                                                        <div class="form-control-focus"> </div>
                                                    </div>
                                                </div>
                                              
                                                 
                                                 
                                                    </div>
                                                     
                                                </div>
                                            </div>
                                           
                                            <div class="form-actions">
                                                <div class="row">
                                                    <div class="col-md-offset-2 col-md-10">
                                                    <input type="submit" class="btn green" value="Save"> 
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div><div class="col-md-6">
                                <!-- BEGIN EXTRAS PORTLET-->
                                <div class="portlet box blue ">
                                     <div class="portlet-title">
                                        <div class="caption">
                                            <i class="fa fa-gift"></i>HISTORY </div>
                                        <div class="tools">
                                            
                                        </div>
                                    </div>
                                    <div class="portlet-body">
                                        
                                         <table class="table table-striped table-bordered table-hover order-column" id="sample_3s">
                                                <thead>
                                                    <tr>
                                                        <th> # </th>
                                                        <th> Credit Point Value</th>
                                                        <th> Updated On  </th>
                                                        
                                                    </tr>
                                                </thead>
                                                <tbody >
                                                    <?php 
										$result_history = $this->credit_points_model->get_charges_history('PREVIEW');
													if(isset($result_history) && $result_history!='') { for($j=0;$j<count($result_history);$j++)
													{
														?>
                                                    <tr>
                                                        <td> CPH<?php echo $result_history[$j]->user_credit_points_charges_history_id; ?> </td>
                                                        <td> <?php echo $result_history[$j]->charge_value; ?></td>
                                                       <td> <?php echo $result_history[$j]->created_timestamp; ?></td>
                                                    </tr>
                                                    <?php
													}
													}
													else
													{
														echo '<tr> <td colspan="3">No Record Found. </td></tr>';
													}
													?>
                                                </tbody>
                                            </table>
                                      
                                    </div>
                                </div>
                            </div>
								<?php
								}
							}
                          ?>  
                        </div>
                         
                         
                    </div>
                    <!-- END CONTENT BODY -->
                </div>
                <!-- END CONTENT -->
                <!-- BEGIN QUICK SIDEBAR -->
                
                   <?php   $this->load->view('common/right_bar',''); ?>
                <!-- END QUICK SIDEBAR -->
            </div>
            <!-- END CONTAINER -->
            <!-- BEGIN FOOTER -->
                        <?php   $this->load->view('common/footer',''); ?>

            <!-- END FOOTER -->
        </div>
        <!-- BEGIN QUICK NAV -->
         <?php   $this->load->view('common/overlay',''); ?>
        <!-- END QUICK NAV -->
        <!--[if lt IE 9]>
<script src="<?php echo ASSETS; ?>/global/plugins/respond.min.js"></script>
<script src="<?php echo ASSETS; ?>/global/plugins/excanvas.min.js"></script> 
<script src="<?php echo ASSETS; ?>/global/plugins/ie8.fix.min.js"></script> 
<![endif]-->
        <!-- BEGIN CORE PLUGINS -->
        <script src="<?php echo ASSETS; ?>/global/plugins/jquery.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/js.cookie.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/jquery-slimscroll/jquery.slimscroll.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/jquery.blockui.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/bootstrap-switch/js/bootstrap-switch.min.js" type="text/javascript"></script>
        <!-- END CORE PLUGINS -->
        <!-- BEGIN PAGE LEVEL PLUGINS -->
        <script src="<?php echo ASSETS; ?>/global/plugins/bootstrap-wysihtml5/wysihtml5-0.3.0.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/bootstrap-wysihtml5/bootstrap-wysihtml5.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/bootstrap-markdown/lib/markdown.js" type="text/javascript"></script>
        <script src="./<?php echo ASSETS; ?>/global/plugins/bootstrap-markdown/js/bootstrap-markdown.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/bootstrap-summernote/summernote.min.js" type="text/javascript"></script>
        <!-- END PAGE LEVEL PLUGINS -->
          <script src="<?php echo ASSETS; ?>/global/scripts/datatable.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/datatables/datatables.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap.js" type="text/javascript"></script>
        <!-- BEGIN THEME GLOBAL SCRIPTS -->
        <script src="<?php echo ASSETS; ?>/global/scripts/app.min.js" type="text/javascript"></script>
        <script>
		
		$('#preview_active, #preview_inactive, #journey_active, #journey_inactive, #single_active, #single_inactive').on('click', function(){
			var elId = $(this).attr('id');
			
			$.ajax({
				url		:	'<?php echo WEB_URL; ?>/credit_points_do/update_charges_status',
				data	:	{'action':elId},
				dataType:	'json',
				type	:	'post',
				success	:	function(result){
					if(result.status == 'ACTIVE'){
						innerHtml = '<i class="fa fa-eye"></i> ACTIVE<i class="fa fa-angle-down "></i>';
					}else{
						innerHtml = '<i class="fa fa-eye-slash"></i> INACTIVE<i class="fa fa-angle-down "></i>';
					}
					
					$('#'+result.charge_type+'_status').html(innerHtml);
				}
			});
		});
		
	 var FormValidationMd = function() {

    var handleValidation1 = function() {
        // for more info visit the official plugin documentation: 
        // http://docs.jquery.com/Plugins/Validation
        var form1 = $('#form_sample_1');
        var error1 = $('.alert-danger', form1);
        var success1 = $('.alert-success', form1);
		

        form1.validate({
            errorElement: 'span', //default input error message container
            errorClass: 'help-block help-block-error', // default input error message class
            focusInvalid: false, // do not focus the last invalid input
            ignore: "", // validate all fields including form hidden input
            messages: { },
            rules: {
                single_val	: {
                     required: true 
					 
                } 
            }, submitHandler: function(form) { 
				$val =  $("#single_val").val();
				 $type =  "SINGLE";
				 
				 
			 var myKeyVals = { val : $val, type : $type   }
            //Submit the form manually
       	$.ajax({
      type: 'POST',
      url: "<?php echo WEB_URL; ?>/credit_points_do/update_charges",
      data: myKeyVals,
      dataType: "json",
			beforeSend: function()
			{
				 App.blockUI({
									target: '#form_sample_1' 
								});
			},
      success: function(resultData) {
		   App.unblockUI('#form_sample_1');
		  toastr.options = {
		    "closeButton": false,
  "debug": false,
  "newestOnTop": false,
  "progressBar": false,
  "positionClass": "toast-bottom-right",
  "preventDuplicates": false,
  "onclick": null,
  "showDuration": "300",
  "hideDuration": "1000",
  "timeOut": "5000",
  "extendedTimeOut": "1000",
  "showEasing": "swing",
  "hideEasing": "linear",
  "showMethod": "fadeIn",
  "hideMethod": "fadeOut",
  "body-output-type": "trustedHtml"
		};
		  var table = $('#sample_1s').DataTable();
  
		   table.ajax.url("<?php echo WEB_URL; ?>/credit_points_do/get_charges_history/SINGLE").load();  
  
 	   if(resultData.result == 'true')
		   {
			   toastr.success("Updated Successfully");
			   
		   }
		  else
			  {
				   toastr.error("Failure.");
			  }
	  
	  }
			});
				 
			 },
        errorPlacement: function(error, element) {
                if (element.is(':checkbox')) {
                    error.insertAfter(element.closest(".md-checkbox-list, .md-checkbox-inline, .checkbox-list, .checkbox-inline"));
                } else if (element.is(':radio')) {
                    error.insertAfter(element.closest(".md-radio-list, .md-radio-inline, .radio-list,.radio-inline"));
                } else {
                    error.insertAfter(element); // for other inputs, just perform default behavior
                }
            },

            highlight: function(element) { // hightlight error inputs
                $(element)
                    .closest('.form-group').addClass('has-error'); // set error class to the control group
            },

            unhighlight: function(element) { // revert the change done by hightlight
                $(element)
                    .closest('.form-group').removeClass('has-error'); // set error class to the control group
            },

            success: function(label) {
				 
                label
                    .closest('.form-group').removeClass('has-error'); // set success class to the control group
            }
        });
		$('#form_sample_2').validate({
            errorElement: 'span', //default input error message container
            errorClass: 'help-block help-block-error', // default input error message class
            focusInvalid: false, // do not focus the last invalid input
            ignore: "", // validate all fields including form hidden input
            messages: { },
            rules: {
                single_val	: {
                     required: true 
					 
                } 
            }, submitHandler: function(form) { 
				$val =  $("#journey_val").val();
				 $type =  "JOURNEY";
				 
				 
			 var myKeyVals = { val : $val, type : $type   }
            //Submit the form manually
       	$.ajax({
      type: 'POST',
      url: "<?php echo WEB_URL; ?>/credit_points_do/update_charges",
      data: myKeyVals,
      dataType: "json",
			beforeSend: function()
			{
				 App.blockUI({
									target: '#form_sample_2' 
								});
			},
      success: function(resultData) {
		   App.unblockUI('#form_sample_2');
		  toastr.options = {
		    "closeButton": false,
  "debug": false,
  "newestOnTop": false,
  "progressBar": false,
  "positionClass": "toast-bottom-right",
  "preventDuplicates": false,
  "onclick": null,
  "showDuration": "300",
  "hideDuration": "1000",
  "timeOut": "5000",
  "extendedTimeOut": "1000",
  "showEasing": "swing",
  "hideEasing": "linear",
  "showMethod": "fadeIn",
  "hideMethod": "fadeOut",
  "body-output-type": "trustedHtml"
		};
		 
   var table = $('#sample_2s').DataTable();
  
		   table.ajax.url("<?php echo WEB_URL; ?>/credit_points_do/get_charges_history/JOURNEY").load();  
 	   if(resultData.result == 'true')
		   {
			   toastr.success("Updated Successfully");
			   
		   }
		  else
			  {
				   toastr.error("Failure.");
			  }
	  
	  }
			});
				 
			 },
        errorPlacement: function(error, element) {
                if (element.is(':checkbox')) {
                    error.insertAfter(element.closest(".md-checkbox-list, .md-checkbox-inline, .checkbox-list, .checkbox-inline"));
                } else if (element.is(':radio')) {
                    error.insertAfter(element.closest(".md-radio-list, .md-radio-inline, .radio-list,.radio-inline"));
                } else {
                    error.insertAfter(element); // for other inputs, just perform default behavior
                }
            },

            highlight: function(element) { // hightlight error inputs
                $(element)
                    .closest('.form-group').addClass('has-error'); // set error class to the control group
            },

            unhighlight: function(element) { // revert the change done by hightlight
                $(element)
                    .closest('.form-group').removeClass('has-error'); // set error class to the control group
            },

            success: function(label) {
				 
                label
                    .closest('.form-group').removeClass('has-error'); // set success class to the control group
            }
         });
		$('#form_sample_3').validate({
            errorElement: 'span', //default input error message container
            errorClass: 'help-block help-block-error', // default input error message class
            focusInvalid: false, // do not focus the last invalid input
            ignore: "", // validate all fields including form hidden input
            messages: { },
            rules: {
                single_val	: {
                     required: true 
					 
                } 
            }, submitHandler: function(form) { 
				$val =  $("#preview_val").val();
				 $type =  "PREVIEW";
				 
				 
			 var myKeyVals = { val : $val, type : $type   }
            //Submit the form manually
       	$.ajax({
      type: 'POST',
      url: "<?php echo WEB_URL; ?>/credit_points_do/update_charges",
      data: myKeyVals,
      dataType: "json",
			beforeSend: function()
			{
				 App.blockUI({
									target: '#form_sample_3' 
								});
			},
      success: function(resultData) {
		   App.unblockUI('#form_sample_3');
		  toastr.options = {
		    "closeButton": false,
  "debug": false,
  "newestOnTop": false,
  "progressBar": false,
  "positionClass": "toast-bottom-right",
  "preventDuplicates": false,
  "onclick": null,
  "showDuration": "300",
  "hideDuration": "1000",
  "timeOut": "5000",
  "extendedTimeOut": "1000",
  "showEasing": "swing",
  "hideEasing": "linear",
  "showMethod": "fadeIn",
  "hideMethod": "fadeOut",
  "body-output-type": "trustedHtml"
		};
		 var table = $('#sample_3s').DataTable();
  
		   table.ajax.url("<?php echo WEB_URL; ?>/credit_points_do/get_charges_history/PREVIEW").load();   
  	   if(resultData.result == 'true')
		   {
			   toastr.success("Updated Successfully");
			   
		   }
		  else
			  {
				   toastr.error("Failure.");
			  }
	  
	  }
			});
				 
			 },
        errorPlacement: function(error, element) {
                if (element.is(':checkbox')) {
                    error.insertAfter(element.closest(".md-checkbox-list, .md-checkbox-inline, .checkbox-list, .checkbox-inline"));
                } else if (element.is(':radio')) {
                    error.insertAfter(element.closest(".md-radio-list, .md-radio-inline, .radio-list,.radio-inline"));
                } else {
                    error.insertAfter(element); // for other inputs, just perform default behavior
                }
            },

            highlight: function(element) { // hightlight error inputs
                $(element)
                    .closest('.form-group').addClass('has-error'); // set error class to the control group
            },

            unhighlight: function(element) { // revert the change done by hightlight
                $(element)
                    .closest('.form-group').removeClass('has-error'); // set error class to the control group
            },

            success: function(label) {
				 
                label
                    .closest('.form-group').removeClass('has-error'); // set success class to the control group
            }
         });
    }
 

    return {
        //main function to initiate the module
        init: function() {
            handleValidation1();  
        }
    };
}();

jQuery(document).ready(function() {
    FormValidationMd.init();
});
	 
		$(document).ready(function(){
		toastr.options = {
		    "closeButton": false,
  "debug": false,
  "newestOnTop": false,
  "progressBar": false,
  "positionClass": "toast-bottom-right",
  "preventDuplicates": false,
  "onclick": null,
  "showDuration": "300",
  "hideDuration": "1000",
  "timeOut": "5000",
  "extendedTimeOut": "1000",
  "showEasing": "swing",
  "hideEasing": "linear",
  "showMethod": "fadeIn",
  "hideMethod": "fadeOut",
  "body-output-type": "trustedHtml"
		};
		 <?php   if(isset($page_data->msg_type)) { ?>
		toastr.<?php  echo $page_data->msg_type;  ?>("<?php echo $page_data->msg;  ?>");
		<?php }  ?>
  <?php   if($this->session->flashdata('notification') == 'active') { ?>
  alert('dsf');
  //Connectnotification.pushn('<?php echo $page_data->ntf_count; ?>','<?php echo $page_data->ntf_url; ?>','<?php echo $page_data->ntf_pic; ?>','<?php echo $page_data->ntf_title; ?>','<?php echo $page_data->ntf_time; ?>','<?php echo $page_data->ntf_msg; ?>'); 
	<?php } ?>
		});
</script>

         <script src="<?php echo ASSETS; ?>/global/plugins/jquery-validation/js/jquery.validate.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/jquery-validation/js/additional-methods.min.js" type="text/javascript"></script>
        <!-- END THEME GLOBAL SCRIPTS -->
        <!-- BEGIN PAGE LEVEL SCRIPTS -->
        <script src="<?php echo ASSETS; ?>/pages/scripts/components-editors.min.js" type="text/javascript"></script>
        <!-- END PAGE LEVEL SCRIPTS -->
        
        <!-- BEGIN THEME LAYOUT SCRIPTS -->
           <!-- BEGIN PAGE LEVEL SCRIPTS -->
          <script src="<?php echo ASSETS; ?>/global/plugins/select2/js/select2.full.min.js" type="text/javascript"></script>
 	    <script src="<?php echo ASSETS; ?>/pages/scripts/components-select2.min.js" type="text/javascript"></script>
         <script src="<?php echo ASSETS; ?>/pages/scripts/overlaymessage.js" type="text/javascript"></script>
                <script src="<?php echo ASSETS; ?>/global/plugins/bootstrap-fileinput/bootstrap-fileinput.js" type="text/javascript"></script>
                                 <script src="<?php echo ASSETS; ?>/pages/scripts/table-datatables-managed.min.js" type="text/javascript"></script>

        <!-- END PAGE LEVEL SCRIPTS -->
        <script src="<?php echo ASSETS; ?>/layouts/layout/scripts/layout.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/global/plugins/bootstrap-toastr/toastr.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/layouts/layout/scripts/demo.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/layouts/global/scripts/quick-sidebar.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS; ?>/layouts/global/scripts/quick-nav.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS.'/pages/scripts/appconnect.js'; ?>"></script>
      <script>
		 	jQuery(document).ready(function() {
 
        // begin first table
 
   var table = $('#sample_1s').DataTable({
      'columnDefs': [ { "name": "slno",   "targets": 0,  'orderable': true },
    
	],
      'order': [2, 'desc']
   });
 $("#sample_1s_filter").hide();
				 var table = $('#sample_2s').DataTable({
      'columnDefs': [ { "name": "slno",   "targets": 0,  'orderable': true },
    
	],
      'order': [2, 'desc']
   });
 $("#sample_2s_filter").hide();
				 var table = $('#sample_3s').DataTable({
      'columnDefs': [ { "name": "slno",   "targets": 0,  'orderable': true },
    
	],
      'order': [2, 'desc']
   });
 $("#sample_3s_filter").hide();
	 
    });
		</script>
        <!-- END THEME LAYOUT SCRIPTS -->
    </body>

</html>