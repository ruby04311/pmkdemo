var TableDatatablesButtons = function () {

    var initTable1 = function () {
        var table = $('#invoice_reports');

        var oTable = table.dataTable({

            // Internationalisation. For more info refer to http://datatables.net/manual/i18n
            "language": {
                "aria": {
                    "sortAscending": ": activate to sort column ascending",
                    "sortDescending": ": activate to sort column descending"
                },
                "emptyTable": "No data available in table",
                "info": "Showing _START_ to _END_ of _TOTAL_ entries",
                "infoEmpty": "No entries found",
                "infoFiltered": "(filtered1 from _MAX_ total entries)",
                "lengthMenu": "_MENU_ entries",
                "search": "Search:",
                "zeroRecords": "No matching records found"
            },

            // Or you can use remote translation file
            //"language": {
            //   url: '//cdn.datatables.net/plug-ins/3cfcc339e89/i18n/Portuguese.json'
            //},
 
            buttons: [
                { extend: 'print', className: 'btn dark btn-outline',	   title: 'Snapshot of Invoice Range ' ,
				//message: 'This print was produced using the Print button for DataTables',
				  exportOptions: {
                    columns: ':visible'
               		 } },
                
                { 
				
				 className: 'btn green btn-outline',
				  extend: 'pdfHtml5',
				   title: 'Snapshot of invoice_range Table',
                customize: function ( doc ) {
					 
                     doc.content.splice( 1, 0, {
                        margin: [ 0, 0, 0, 12 ],
                        alignment: 'center',
                        image: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJ0AAAAiCAYAAABFutt2AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAZdEVYdFNvZnR3YXJlAEFkb2JlIEltYWdlUmVhZHlxyWU8AAASnUlEQVR4Xu2bCVxU1R7HBxQFVBQzKzPfq6xemhsqrrnWc2Fnhn1HUEIwUJFNpadpKZqalZlYVsYTGGaGRRapUDHLpafAzDAzgBsimYgGuKTAef//4dzbMAyoWS/5vPl9Pv/PzPz//3PunXu+92x3RqCtPZW11pYyZUzqZdKbuQwy6M/V3jOX/tZbUtrSF0yQUnzT9ci5cEKIEQsbZNCfo4TTNQN7psub+0nlpC+YeXppUx9J6fkt5VfnsBSDDHo4zS7Q2Jqll9w2TiluPEmIOfq+qGnpZSQupeBxhgCapZfeHpShLPr+2q2/08JMqur6AfvO19mlnrsW9FJO2Zpns5Rr98H7jJqG4SzFIIN0lFrcgmBhryZITe2GrumFZ017SMuatMHj4LMA6ykubjAVlzb2Tpffwc+cYZzLsZQqyLB81W56DIMM0tasgxUJHFQ90opv/ae+/vEPyn/xGZip2KMNXEdmiSZTEFOJgphlqIhAqiKWEvmN1w5WrE+FKtlhDDLoN9HFQnpZS08Aph/AYyFTkj7QS+F7CpQWWD0BLFMES6YGQEtuDM9THfQ4fm616OjZudaFVYOnZpdYtrS09GRVG2RQxwLwuk0vVA2YXFA+ySq/YtOTGYorRinFDeMLystGFWiS/Y+fj3M8fM7WOl/17PgC5WOQb8qKGvQnC25ii4z8/GfZxy6lDcpqq/WK2gns4/+fNm/c6ORsZ3fayda2Gl4vieztK5eEhkay8CMhfze3Zxzmzz8qtLfXONvb/wyvt0UODsTV2TmXpXQJ2R05Fy4QK8iYPNXOkbmq7SbiEmIhke9i4XsLezW4215JSkryf3fdug8jliwJuXbt2hjw9WEpj7Tg/I2h8ZQAGXF1cqLm4uhIX33c3UNY2iMhOCcr7tzwlTMPkSiLpTzy8jt2cbbRvtO1cN0HACMjwV5C/xMZyqKxB8rjaRI4e/4KUL2/dav3zh0fbomJjs55a9Xq0tUrV158a3XCzVVx8SQhfiVZGRtH/Ly8yaxpM8jEcePJBLCpkyb/Osl6Qs2rkyYrxrwyssDPx+cjdxeXQIDSCg5Kt2D+atnNnXuZNh70GAsDAj4JCw0NWxgYeBJA/JWlPDLKycnp6TRnjpW7UDgczq+hq0EHbW5knFJ8J7+mpteLeeqtQzKU+/+eWVZgnlKsoAmpJUSQsHJ1KsK0GqBKWLmKrEbA4FWfrYqNJwE+vuS1GbPIlImT2tnUSZPIxPHWBCAkE8aOI9ZgHkLXffRgf5FgaMrGRsOeY4Gv7xbmpoIL1J29fSQFw+v1rgbd9MLC7oLkU834fnieevOeyjrvnxoanhCkyFvQZ5pWck2wOj4+XR9g+myVVk8HPZxe8HTNRSgU48H+KsHcrQUbDeZxZEVk5ETm7hIC6H7petDBjZx8ugnfD89XbeonlVcbS1XkYG3ty+gzSy+9cl/QRUUuIxvXv0Mk4nSSk5VNvvhsD4mLjgbwppDRI0bqhY2zvxK68+fPj3OysaGNJrSzI1FRUXRu0VUEw+uFrgYdDq+CNCXB90NzVNs2lF1ZGPXjxdlmaSUqmpACw2tn0MVDz/bR9g9ITU0N1KVfJ44fJ69OnqIXOLS/ErqopUsdceWHjQbzOnLjxo2nWahLCBY+57oadKhp35T79pUqjnmfrhn4gfzyk+h7IqtsxsBMZdILOeovOoQuPiaW5O3PIbDIYHh1Lg9XNzJ5woNBB8V6S1JTp4rs7N4I9PJKCl+48HMWEoicnOZ6u7sf9vf2PuFoYyOGXP7JxnsbN/7T38PjMy83t0OY4+fu/vm2zZv5obMgO/u5T3bs8AoPCdnBQecwfz75cs+eRUk7d7qjRS9f7u1sY7MQepNgN6Fwuaera2yAt/cCVoVg8+bN/R3nzQsT2tgEQ4PHY9zf0zOWham+++67gR9v2zYXFijRzra22VVVVYNZSPBmeHgglMnF8/Nxc/u0sLBwAAu1k0QieQxW0evcRaKvIf+Qh4uLDM5lscjRsYaDzk0kkrD0DgXXyCi1+uYQ7+NVwiczVQkDZPJMFhJk1d54+oks+Y5BmcrDA2XyvMnfnPknC1EVXm588nGJYlN/KDNkvzJl8tfqV1lIr842Nj5pKSldA8fIfzpTfugxqTz7+Rz1QhYWPJdb9mEfcWn1AKlylaVUHv2UTFE6CBYVNNgRdF/u+RxZaqerV66Q+vp69qmtZkybRqbogNcRdEcOHpyJQ54jwEAvLMBhN39+FcZiIiPnw1yMuLILbj9vHlZvcuTHHwdBnhogJAALb5gDjU6gkbdi+dhlyzbbzpnDx9BwIYHgcUbrBx93DLQFfn75WB61bt266XSLRSsOkN9mYZwr1mEcz8UF6kG4Q4OCRMsiIvwAlmt4bO1tD5hT3lqzZs0LrDgvXw+PaLwGdC8O8p3gvPBacOW0rNM9Lrg+vQXZZ4hpVgUxlZWRvuzJ0tGr9VMGyBTpPcBvKfvt6ZKpTE1G5avfGZqj6Qmg7euxH+OtT6Dw0aZZhpoM3a96m1XPKyGBGD8hk+8yya4k/TOUxDQbjgfWH8r0zigjFtLSSyxVkHH5+lAzaWkE1BsVdOziaOZuDx2uYiPDl5Dm5mZsaF75uXl0bmczZy4Z9sI/iM3ceUSjUrNoq86dPUu3Ue4Huh+Kiib6eXoqoCH5IcTBxqYBY9CgN7kGw9clixd/UldX1xfAuok+bOjIxYvd4ZCW0MizoMGoHxt6eUSEw5qVK309hMJsqPsIVzfW4+XikgO+TM48RaI08F/j4kuXLEmjJwdKTEx8Vujk9Bb4T3B1QJlaFhb4e3mdDAoI0MCxm7k4nHczAoOLlgAvLyUAVQmLAf74AOcFVpwqNCRkGQKLcQAVb5o98VFRHtDLveHn4ZGPPq5uKN/pDydgROo1OENe9fz+sjP4YwvuubhZlpoCBKBcHJQpl/WVyhu5GLxvMZfIiXmGijwuU1wfkqU81Fda2sKB1wdiedX1/2CHoD3p41Llt/0BTvxRx7NZis9u3GgZVFRdN+SZTOUxDmgzcYmSFdEvXei2vbeF3Llzh0KkrcbGRnL71m1y8+ZN0tzUTCZbTyDDXnyJXL16lWW0Snd+d685XW5W1qtcjyQEeKAxs7AXcnNySgYofaDhPgkPD7eA3klDGwcadXlkpJAVpwoLDV2Gfto4jo7nmBsXElNpTwR+7PmgYQaxEK9AH5/vsTfThY4TlH+XAgM5AN1V5uYF53sWY2j4PTxcXXcfUyofY2HBoqCgj7g4wniksJDe8TExMUO5c8NzXxgQEEALaAlGAnpDoN0LOk7QBCZGMg0PXT+ZvMr16LkpLCxwKDzbr5tMxcctJfI6h6JKOxaG1ae8twn0lBhDsAZI5SdYSDD720ovrpxJWnEFc1ONPXnSxCRdQWMWkhKYk1V3vEerDR32csWni1vpuYdwDw6hClkQTA4fPMSbi7MQ5nYT7xs6sVj8GgcdXPwWbICQBQuSWJgqSyKxxqGMNhwMRaA2v1zBzxx0OGRrNBoL9CtLSqZzq9eOFhKBvr4/sEbVCx3Ut7Ez6Hw9PekKE3MCvb3bTfa3JSYOw6Efc9CgBxShH75jCtfLwZyykibrSHvL5AGgMzXKKG9tfKmCzPq24k0W4jU0p6yOg8r6G80e5uY1Ild9koPLOKX4CvoScP+NgwrsvZJL42iylszFJde5eoNOVPkyd3vp9nTr175Njhw6jA3L61+rE8j6NWvJ2rfWkJCgYDLv9Tk8VLgZPHb0GN5wY5iLPSh0aNCjNRG5vA1U0DhSLg4QNCwKCFgXEhS0YdGCBe+Gh4buWBwSks5Bh/OjT95/nz4cf1DooC5+IcPpQaDzcndPZW5e0Ls+5QBzUszBc4SeTwSX1BimEtSH5uni0u64qIeGDuZ00wsrPFiI19D96jIOjrEHyvcyN6/huWUSjKNx0AX859LjvZgPyrWMyddsGpan3oA2IlezaUJB+ce98ZdJrXESfOxim434NtKF7qsvvyRKhZLCxkmckkqk4nSSniYmu3buJMvejOThwteZ06bz9qDDqzZ02HDvvP22EwvxggZScxcfGw6H3zYGPQkOXfgKDfU1K3Z/0Pn48NCFLVrUbrL+INB5u7m16ylxSMeFC3fucMOIssXi5zgQsRycYxxLb6M/AroZMCSyEK8X9pdpODis8su/Ym5eI/LVUoyjGe8r/hl9G0qvzOR8aOaZKjpX1Db8yRt9n1ZyB753x8/ltaGLi4kld+/ebSWtE331xZetQyjYro93Mm+rvNw8fvfwivOupKSkdvMuaJQz3MWHRj5bX1s7DIbQMdpWXl5uBfPNv7EiVPcDHTSmgjUqCX1I6CDe7rtqQ4evJXBOaWlpw3FFzpWDm6X1IbiO/nzoFGRMQcUHzM1LGzqjlNa5m8OhM26cD1aozacafx19/FrjGF27cKtlKJxD53/magNddAw5XHiQHDlcRAHiBBeOFOQfIN8WfE1kEinx9/Klc7pZ0LPpQsrN9X4PdHj379q1qz8L8YKLX8xdfMi5y9z3lDZ0bNvFkoV4QWMqWaOSNxcv/oK5eT0IdG7Ozp8yNy9t6HDhcOLEiZk5OTmDOR+t18Xl3yy9jf4X0FkVqN9lbl5toNtXfAZ9H52/MpbzYQ9ZWVc3hCb/HukOr7iYiFkeRVer2roBnz/dtZuEhbwBE18R2bplS7ttlU93JT3UnA7B2L59O7/y4xQRGrqKn7NBw62KiRnPQp1KFzoAoB3QMJ/6kWtYD6Gw9ZcQWoIV9db7hQ5eP2ZuXvqgQz/k80DBMeposo4A+HouRxc6z6LzllO/rUiZWVh5xLHo/Fjm/tOgsz1Zbd5NqqQ+tOdzygpo8u+RLnTapgtVZ6q9coUuJLSBuxd0UMwoOTn5db6ng8aRSqX90I/G0qgAHv5nPvYwVEZFRLwKPYYF5JluX7/+seDg4BHxK1ZsXL506SrMB7+x/PTpWTo93QCw7mB83R4uLhu4enGPDXqrpYmJiQNDQ0OHBnl7f8XBjuYuElE4ACQzWhjk6+FRhTEKnbNzG+jwOJD7DDd/Q+h+PHZsGsaC/f3DuLqxLMxJCzcnJPSHMqZxcXFPhQcHb9I+tptItAfq6vlBQgL9I/xTmWWXuH0xc4n8FvqgrDHk9OK2TFqh03iBn/7ZCoXnBNCVYxyhG3dAvQF8JuhnKYJXctVZHFwmaSUqLI/xwVll2ZyfzgcPlL8T8l3NQLwe4T9oLGYXqJ+zLzrvayYuPcuq0q/OoHv7X2tIQ0MDHK9zVWjKO3zw3xl0dnPm3HKaP5/+CoS/+AAezL/uQiMcZmlUh/PzJ0CjNXG52CC4AsTVKsLKNVCgt3cN5s+fPbsJY9wTBayb5gIAEKOTY07g/4mrFw0BxYUJ1gkLlUvaMQTHx83tusjRcTXWpQ0Gmu3rr5MlCxfSPTd/L69T9Bxae0H+HOAmu4NxN6HwqHZ5/B4Yx2OgH45BN73R8MbE48FQfAguebfuma29GRr+nwXU4/lczWmTTA3pLy3lY71hYt8to4JOSV7OLR9unHOOPq34La4k3bIqcBToYwO9p0CqobByccw1hmNNKFCF4rZJ97Tiavr/GYgh8N1lUD+UN8kqJz2wJ4T83jIlVNfJ/2Q6gw5tecRSciA3l9T/8gudv0FlpLmpiW4SV124QBYvCiFWo0brBQ6tM+jgIv4EF/iqPoMLncfSeOGFhYtfBCDUi+ztKazQOC3guwm9X82S0NDECxcu0F4IwK3VVy8awN5mXwzqNYLyJVAPfboAdd51mDv3DPTCdC8KACzHXhDiTRC74e3qemqBn9+7HdTdEBEWZoPlFvj6HtWXAzcCD/3ikJAPnezsGih8rcf4FXLK9u7dOyUkMPAVXJFTAB0c7oD/updIROedQ/cr11pISlsAgJb+UvlR9L28v+x78/SSq7oGq0m67TH168qRuJemJ06ftNgWVg/oua+4XdxcXFo3r6jCE3NQMwvPrOqRVvKzRbr8LgKK1kciv2OaVlzbVyw/cOCnqyNYqn7FRccm64NN16JhnoePwQJ9/clr02eQl194kVjpGU61DZ9awGQ4mR3qDxUCCNYPu3bmemixOi3BjJmLV0f+P0pQtzlYP/aRF34/sF7sYxtBfreOYv8r4TmD9WUf719yudx6xfKoi9yvhzuye/1ymLOJ4yeQV4YNq9u9e7ctO4RBBukX3m0r4+IOr4yNvfug0OHe3MRx45usRoxSnDp1qkv9bs2gR0RbEjcnxq6Ivn0v6BC2MSNG3nG0tdtbiM/nDDLoYZWSnOy0Ytnym/hvMG3oELYRw4Y3hb0RFspSDTLoj1V1dfWQuBXRFf7ePi2TrSf+nJeXN4qFDDLoASQQ/BcEavPJPQc1CgAAAABJRU5ErkJggg=='
                    } );
                },
				//message: 'This print was produced using the Print button for DataTables',
				  exportOptions: {
                    columns: ':visible'
               		 }
				},
                { extend: 'excel', className: 'btn yellow btn-outline ',	   title: 'Snapshot of Invoice Range ',  
				//message: 'This print was produced using the Print button for DataTables',
				  exportOptions: {
                    columns: ':visible'
               		 } },
              /*  { extend: 'csv', className: 'btn purple btn-outline ' ,	   title: 'Snapshot of Invoice Range ',  
				//message: 'This print was produced using the Print button for DataTables',
				  exportOptions: {
                    columns: ':visible'
               		 } },*/
                { extend: 'colvis', className: 'btn dark btn-outline', text: 'Columns'}
            ],

            // setup responsive extension: http://datatables.net/extensions/responsive/
            responsive: true,

            //"ordering": false, disable column ordering 
            //"paging": false, disable pagination

            "order": [
                [0, 'asc']
            ],
            
            "lengthMenu": [
                [5, 10, 15, 20, -1],
                [5, 10, 15, 20, "All"] // change per page values here
            ],
            // set the initial value
            "pageLength": 10,

            "dom": "<'row' <'col-md-12'B>><'row'<'col-md-6 col-sm-12'l><'col-md-6 col-sm-12'f>r><'table-scrollable't><'row'<'col-md-5 col-sm-12'i><'col-md-7 col-sm-12'p>>", // horizobtal scrollable datatable

            // Uncomment below line("dom" parameter) to fix the dropdown overflow issue in the datatable cells. The default datatable layout
            // setup uses scrollable div(table-scrollable) with overflow:auto to enable vertical scroll(see: assets/global/plugins/datatables/plugins/bootstrap/dataTables.bootstrap.js). 
            // So when dropdowns used the scrollable div should be removed. 
            //"dom": "<'row' <'col-md-12'T>><'row'<'col-md-6 col-sm-12'l><'col-md-6 col-sm-12'f>r>t<'row'<'col-md-5 col-sm-12'i><'col-md-7 col-sm-12'p>>",
        });
    }

    var initTable2 = function () {
        var table = $('#sample_2');

        var oTable = table.dataTable({

            // Internationalisation. For more info refer to http://datatables.net/manual/i18n
            "language": {
                "aria": {
                    "sortAscending": ": activate to sort column ascending",
                    "sortDescending": ": activate to sort column descending"
                },
                "emptyTable": "No data available in table",
                "info": "Showing _START_ to _END_ of _TOTAL_ entries",
                "infoEmpty": "No entries found",
                "infoFiltered": "(filtered1 from _MAX_ total entries)",
                "lengthMenu": "_MENU_ entries",
                "search": "Search:",
                "zeroRecords": "No matching records found"
            },

            // Or you can use remote translation file
            //"language": {
            //   url: '//cdn.datatables.net/plug-ins/3cfcc339e89/i18n/Portuguese.json'
            //},

            buttons: [
                { extend: 'print', className: 'btn default' },
                { extend: 'copy', className: 'btn default' },
                { extend: 'pdf', className: 'btn default' },
                { extend: 'excel', className: 'btn default' },
                { extend: 'csv', className: 'btn default' },
                {
                    text: 'Reload',
                    className: 'btn default',
                    action: function ( e, dt, node, config ) {
                        //dt.ajax.reload();
                        alert('Custom Button');
                    }
                }
            ],

            "order": [
                [0, 'asc']
            ],
            
            "lengthMenu": [
                [5, 10, 15, 20, -1],
                [5, 10, 15, 20, "All"] // change per page values here
            ],
            // set the initial value
            "pageLength": 10,

            "dom": "<'row' <'col-md-12'B>><'row'<'col-md-6 col-sm-12'l><'col-md-6 col-sm-12'f>r><'table-scrollable't><'row'<'col-md-5 col-sm-12'i><'col-md-7 col-sm-12'p>>", // horizobtal scrollable datatable

            // Uncomment below line("dom" parameter) to fix the dropdown overflow issue in the datatable cells. The default datatable layout
            // setup uses scrollable div(table-scrollable) with overflow:auto to enable vertical scroll(see: assets/global/plugins/datatables/plugins/bootstrap/dataTables.bootstrap.js). 
            // So when dropdowns used the scrollable div should be removed. 
            //"dom": "<'row' <'col-md-12'T>><'row'<'col-md-6 col-sm-12'l><'col-md-6 col-sm-12'f>r>t<'row'<'col-md-5 col-sm-12'i><'col-md-7 col-sm-12'p>>",
        });
    }

    var initTable3 = function () {
        var table = $('#sample_3');

        var oTable = table.dataTable({

            // Internationalisation. For more info refer to http://datatables.net/manual/i18n
            "language": {
                "aria": {
                    "sortAscending": ": activate to sort column ascending",
                    "sortDescending": ": activate to sort column descending"
                },
                "emptyTable": "No data available in table",
                "info": "Showing _START_ to _END_ of _TOTAL_ entries",
                "infoEmpty": "No entries found",
                "infoFiltered": "(filtered1 from _MAX_ total entries)",
                "lengthMenu": "_MENU_ entries",
                "search": "Search:",
                "zeroRecords": "No matching records found"
            },

            // Or you can use remote translation file
            //"language": {
            //   url: '//cdn.datatables.net/plug-ins/3cfcc339e89/i18n/Portuguese.json'
            //},

            buttons: [
                { extend: 'print', className: 'btn dark btn-outline' },
                { extend: 'copy', className: 'btn red btn-outline' },
                { extend: 'pdf', className: 'btn green btn-outline' },
                { extend: 'excel', className: 'btn yellow btn-outline ' },
                { extend: 'csv', className: 'btn purple btn-outline ' },
                { extend: 'colvis', className: 'btn dark btn-outline', text: 'Columns'}
            ],

            // setup responsive extension: http://datatables.net/extensions/responsive/
            responsive: true,

            //"ordering": false, disable column ordering 
            //"paging": false, disable pagination

            "order": [
                [0, 'asc']
            ],
            
            "lengthMenu": [
                [5, 10, 15, 20, -1],
                [5, 10, 15, 20, "All"] // change per page values here
            ],
            // set the initial value
            "pageLength": 10,

            //"dom": "<'row' <'col-md-12'>><'row'<'col-md-6 col-sm-12'l><'col-md-6 col-sm-12'f>r><'table-scrollable't><'row'<'col-md-5 col-sm-12'i><'col-md-7 col-sm-12'p>>", // horizobtal scrollable datatable

            // Uncomment below line("dom" parameter) to fix the dropdown overflow issue in the datatable cells. The default datatable layout
            // setup uses scrollable div(table-scrollable) with overflow:auto to enable vertical scroll(see: assets/global/plugins/datatables/plugins/bootstrap/dataTables.bootstrap.js). 
            // So when dropdowns used the scrollable div should be removed. 
            //"dom": "<'row' <'col-md-12'T>><'row'<'col-md-6 col-sm-12'l><'col-md-6 col-sm-12'f>r>t<'row'<'col-md-5 col-sm-12'i><'col-md-7 col-sm-12'p>>",
        });

        // handle datatable custom tools
        $('#sample_3_tools > li > a.tool-action').on('click', function() {
            var action = $(this).attr('data-action');
            oTable.DataTable().button(action).trigger();
        });
    }

    var initAjaxDatatables = function () {

        //init date pickers
        $('.date-picker').datepicker({
            rtl: App.isRTL(),
            autoclose: true
        });

        var grid = new Datatable();

        grid.init({
            src: $("#datatable_ajax"),
            onSuccess: function (grid, response) {
                // grid:        grid object
                // response:    json object of server side ajax response
                // execute some code after table records loaded
            },
            onError: function (grid) {
                // execute some code on network or other general error  
            },
            onDataLoad: function(grid) {
                // execute some code on ajax data load
            },
            loadingMessage: 'Loading...',
            dataTable: { // here you can define a typical datatable settings from http://datatables.net/usage/options 

                // Uncomment below line("dom" parameter) to fix the dropdown overflow issue in the datatable cells. The default datatable layout
                // setup uses scrollable div(table-scrollable) with overflow:auto to enable vertical scroll(see: assets/global/scripts/datatable.js). 
                // So when dropdowns used the scrollable div should be removed. 
                
                //"dom": "<'row'<'col-md-8 col-sm-12'pli><'col-md-4 col-sm-12'<'table-group-actions pull-right'>>r>t<'row'<'col-md-8 col-sm-12'pli><'col-md-4 col-sm-12'>>",
                
                "bStateSave": true, // save datatable state(pagination, sort, etc) in cookie.

                "lengthMenu": [
                    [10, 20, 50, 100, 150, -1],
                    [10, 20, 50, 100, 150, "All"] // change per page values here
                ],
                "pageLength": 10, // default record count per page
                "ajax": {
                    "url": "../demo/table_ajax.php", // ajax source
                },
                "order": [
                    [1, "asc"]
                ],// set first column as a default sort by asc
            
                // Or you can use remote translation file
                //"language": {
                //   url: '//cdn.datatables.net/plug-ins/3cfcc339e89/i18n/Portuguese.json'
                //},

                buttons: [
                    { extend: 'print', className: 'btn default' },
                    { extend: 'copy', className: 'btn default' },
                    { extend: 'pdf', className: 'btn default' },
                    { extend: 'excel', className: 'btn default' },
                    { extend: 'csv', className: 'btn default' },
                    {
                        text: 'Reload',
                        className: 'btn default',
                        action: function ( e, dt, node, config ) {
                            dt.ajax.reload();
                            alert('Datatable reloaded!');
                        }
                    }
                ],

            }
        });

        // handle group actionsubmit button click
        grid.getTableWrapper().on('click', '.table-group-action-submit', function (e) {
            e.preventDefault();
            var action = $(".table-group-action-input", grid.getTableWrapper());
            if (action.val() != "" && grid.getSelectedRowsCount() > 0) {
                grid.setAjaxParam("customActionType", "group_action");
                grid.setAjaxParam("customActionName", action.val());
                grid.setAjaxParam("id", grid.getSelectedRows());
                grid.getDataTable().ajax.reload();
                grid.clearAjaxParams();
            } else if (action.val() == "") {
                App.alert({
                    type: 'danger',
                    icon: 'warning',
                    message: 'Please select an action',
                    container: grid.getTableWrapper(),
                    place: 'prepend'
                });
            } else if (grid.getSelectedRowsCount() === 0) {
                App.alert({
                    type: 'danger',
                    icon: 'warning',
                    message: 'No record selected',
                    container: grid.getTableWrapper(),
                    place: 'prepend'
                });
            }
        });

        //grid.setAjaxParam("customActionType", "group_action");
        //grid.getDataTable().ajax.reload();
        //grid.clearAjaxParams();

        // handle datatable custom tools
        $('#datatable_ajax_tools > li > a.tool-action').on('click', function() {
            var action = $(this).attr('data-action');
            grid.getDataTable().button(action).trigger();
        });
    }

    return {

        //main function to initiate the module
        init: function () {

            if (!jQuery().dataTable) {
                return;
            }

            initTable1();
        //    initTable2();
            initTable3();

         //   initAjaxDatatables();
        }

    };

}();

jQuery(document).ready(function() {
    TableDatatablesButtons.init();
});