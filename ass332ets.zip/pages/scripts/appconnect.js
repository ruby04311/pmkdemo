var Connectnotification = function () {
  var initv = function() {
	  
	  $("#notification_id").click(function(){
    		  $.ajax({
"dataType": 'json',
"type": "POST",
"url": WEB_URL+'/notification/change_status_none',
"data": "",
      success: function(resultData) { }

});
		});
  var socket = io.connect( 'http://'+window.location.hostname+':3000' );

  socket.on( 'new_count_message', function( data ) {
 // console.log(data.user);
 
 if(data.notification_type == 'message')
	{
		if(data.user==$ntfy_current_user)
		{
		 $acount = 	 parseInt($( ".msg_new_count_message" ).html());
		 $( ".msg_new_count_message" ).html($acount+1);
		}
	}
	if(data.notification_type == 'notify')
	{
		if(data.ntfy_from_user!=$ntfy_current_user)
		{
		 $acount = 	 parseInt($( ".new_count_message" ).html());
		 $( ".new_count_message" ).html($acount+1);
		}
	}
		
		
		
/*if(data.user=='')
{	

if(data.notification_type == 'message')
						{
$acount = 	 parseInt($( ".msg_new_count_message" ).html());
 $( ".msg_new_count_message" ).html($acount+1);
						}
						else
						{
						$acount = 	 parseInt($( ".new_count_message" ).html());
 $( ".new_count_message" ).html($acount+1);	
						}
}
else
{
	if(data.user==$ntfy_current_user)
						{
							if(data.notification_type == 'message')
						{
$acount = 	 parseInt($( ".msg_new_count_message" ).html());
 $( ".msg_new_count_message" ).html($acount+1);
						}
						else
						{
						$acount = 	 parseInt($( ".new_count_message" ).html());
 $( ".new_count_message" ).html($acount+1);	
						}
						
							}
}*/
					 

  });

  socket.on( 'update_count_message', function( data ) {
 
      $( ".new_count_message" ).html( data.update_count_message );
    
  });

  socket.on( 'new_message', function( data ) {
	console.log(data.ntfy_from_user);
	console.log(data.notification_type);
	console.log($ntfy_current_user);
	if(data.notification_type == 'message')
	{
		if(data.user==$ntfy_current_user)
		{
		 $( "#msg_message-tbody" ).prepend('<li><a href="'+data.url+'"><span class="photo"><img src="'+data.pic+'" class="img-circle" alt=""></span><span class="subject"><span class="from">'+data.title+'</span><span class="time">'+data.created_at+'</span></span><span class="message">'+data.message+'</span></a></li>');
		  $('#notif_audio')[0].play();
	   	if(window.Notification && Notification.permission !== "denied") {
	Notification.requestPermission(function(status) {  // status is "granted", if accepted by user
	 
		var n = new Notification(data.title, { 
			body: data.message,
			icon: data.pic// optional
				}); 
 
	        	});
			}	
		}
	}
	if(data.notification_type == 'notify')
	{
		if(data.ntfy_from_user!=$ntfy_current_user)
		{
		$( "#message-tbody" ).prepend('<li><a href="'+data.url+'"><span class="photo"><img src="'+data.pic+'" class="img-circle" alt=""></span><span class="subject"><span class="from">'+data.title+'</span><span class="time">'+data.created_at+'</span></span><span class="message">'+data.message+'</span></a></li>');	
		 $('#notif_audio')[0].play();
	   	if(window.Notification && Notification.permission !== "denied") {
	Notification.requestPermission(function(status) {  // status is "granted", if accepted by user
	 
		var n = new Notification(data.title, { 
			body: data.message,
			icon: data.pic// optional
				}); 
 
	        	});
			}	
		}
	}
						/*
  			  			if(data.user=='')
						{		
						if(data.notification_type == 'message')
						{ 
      $( "#msg_message-tbody" ).prepend('<li><a href="'+data.url+'"><span class="photo"><img src="'+data.pic+'" class="img-circle" alt=""></span><span class="subject"><span class="from">'+data.title+'</span><span class="time">'+data.created_at+'</span></span><span class="message">'+data.message+'</span></a></li>');
						}
						else
						{
			$( "#message-tbody" ).prepend('<li><a href="'+data.url+'"><span class="photo"><img src="'+data.pic+'" class="img-circle" alt=""></span><span class="subject"><span class="from">'+data.title+'</span><span class="time">'+data.created_at+'</span></span><span class="message">'+data.message+'</span></a></li>');
						}
		    if(document.hasFocus()) {
				 $('#notif_audio')[0].play();
	   	if(window.Notification && Notification.permission !== "denied") {
	Notification.requestPermission(function(status) {  // status is "granted", if accepted by user
	 
		var n = new Notification(data.title, { 
			body: data.message,
			icon: data.pic// optional
				}); 
 
	        	});
			}	
			
	    }	
						}
						else
						{
						 	
						if(data.user==$ntfy_current_user)
						{		
						 	
    if(data.notification_type == 'message')
						{ 
      $( "#msg_message-tbody" ).prepend('<li><a href="'+data.url+'"><span class="photo"><img src="'+data.pic+'" class="img-circle" alt=""></span><span class="subject"><span class="from">'+data.title+'</span><span class="time">'+data.created_at+'</span></span><span class="message">'+data.message+'</span></a></li>');
						}
						else
						{
		$( "#message-tbody" ).prepend('<li><a href="'+data.url+'"><span class="photo"><img src="'+data.pic+'" class="img-circle" alt=""></span><span class="subject"><span class="from">'+data.title+'</span><span class="time">'+data.created_at+'</span></span><span class="message">'+data.message+'</span></a></li>');
						} 
		   // if(document.hasFocus()) {
				 $('#notif_audio')[0].play();
	   	if(window.Notification && Notification.permission !== "denied") {
	Notification.requestPermission(function(status) {  // status is "granted", if accepted by user
	 
		var n = new Notification(data.title, { 
			body: data.message,
			icon: data.pic// optional
				}); 
 
	        	});
			}	
			
	    //}	
						}
						}*/
	  //$( "#no-message-notif" ).html('');
      //$( "#new-message-notif" ).html('<div class="alert alert-success" role="alert"> <i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>New message ...</div>');
  });
  }
    return {
		  init: function() {
             initv();
		  },
        //main function to initiate the module
        pushn: function ($new_count_message,$url,$pic,$title,$created_at,$message,$user,$notification_type,$ntfy_from_user) {
			  
			 var socket = io.connect( 'http://'+window.location.hostname+':3000' );
 
                socket.emit('new_count_message', { 
                  new_count_message: $new_count_message,
				  user: $user,
				  notification_type: $notification_type,
				  ntfy_from_user: $ntfy_from_user
                });

                socket.emit('new_message', { 
                  url: $url,
                  pic: $pic,
                  title: $title,
                  created_at: $created_at,
                  message: $message,
				  user: $user,
				  notification_type: $notification_type,
				  ntfy_from_user: $ntfy_from_user
                });
			
			}

    };

}();

jQuery(document).ready(function() {    
   Connectnotification.init(); 
});

 