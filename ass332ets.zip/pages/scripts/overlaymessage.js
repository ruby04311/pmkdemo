	 var overlaymessage = function() {

    var overlaymessage1 = function() {
        // for more info visit the official plugin documentation: 
        // http://docs.jquery.com/Plugins/Validation
        var form1 = $('#form_overlaymessage');
        var error1 = $('.alert-danger', form1);
        var success1 = $('.alert-success', form1);
		

        form1.validate({
            errorElement: 'span', //default input error message container
            errorClass: 'help-block help-block-error', // default input error message class
            focusInvalid: false, // do not focus the last invalid input
            ignore: "", // validate all fields including form hidden input
            messages: { },
            rules: {
                overlay_employee	: {
                    
                    required: true
                },
                overlay_message: {
                    required: true 
                },
				overlay_subject: {
					required: true
				}
				
            },
			 submitHandler: function(form) { 
			  var file_data = $('#overlay_attachment').prop('files')[0];  
			  
			  var overlay_employee = $('#overlay_employee').val(); 
				var overlay_message = $('#overlay_message').val();
				var overlay_subject = $('#overlay_subject').val();
				
			     var form_data = new FormData();                  
    			form_data.append("file", file_data);
				form_data.append("overlay_employee", overlay_employee);
				form_data.append("overlay_subject", overlay_subject);
				form_data.append("overlay_message", overlay_message);
					 $.ajax({
			"dataType": 'json',
			"type": "POST",
			 "cache": false,
                "contentType": false,
                "processData": false,
                "data": form_data,   
			"url": WEB_URL+"/notification/send_message",
		 
			beforeSend: function()
						{
							
							 App.blockUI({
												target: '#overlaymessage_footer',
								  animate: true
											});
						},
				  success: function(resultData) {
					  $notification_totla = resultData.notification;
				 
					  for (var iqq = 0; iqq < $notification_totla.length; iqq++) {
    // Iterate over numeric indexes from 0 to 5, as everyone expects.
	$set_valc=1;
	   $notification_type = 'message';
    Connectnotification.pushn($notification_totla[iqq]['ntfy_count'],$notification_totla[iqq]['ntfy_url'],$notification_totla[iqq]['ntfy_pic'],$notification_totla[iqq]['ntfy_title'],$notification_totla[iqq]['ntfy_time'],$notification_totla[iqq]['ntfy_msg'],$notification_totla[iqq]['ntfy_user'],$notification_type,$notification_totla[iqq]['ntfy_from_user']); 
					  
}

					   App.unblockUI('#overlaymessage_footer');
					 $("#layoutmessage_success").show();
					    setTimeout(function(){
							 $("#layoutmessage_success").hide();
						 var stretchyNavs = $('.quick-nav');
							stretchyNavs.removeClass('nav-is-visible');
					var $exampleMulti23 = 	 $(".select2-multiple").select2();	
				 $exampleMulti23.val(null).trigger("change"); 
				 
				 
				  $('#overlay_message').val('');
			  $('#overlay_subject').val('');
				
							
							}, 4000); 
				  }
			
			});
			
			   return false;
			 },
       		errorPlacement: function(error, element) {
                if (element.is(':checkbox')) {
                    error.insertAfter(element.closest(".md-checkbox-list, .md-checkbox-inline, .checkbox-list, .checkbox-inline"));
                } else if (element.is(':radio')) {
                    error.insertAfter(element.closest(".md-radio-list, .md-radio-inline, .radio-list,.radio-inline"));
                } else {
                    error.insertAfter(element); // for other inputs, just perform default behavior
                }
            },

            highlight: function(element) { // hightlight error inputs
                $(element)
                    .closest('.form-group').addClass('has-error'); // set error class to the control group
            },

            unhighlight: function(element) { // revert the change done by hightlight
                $(element)
                    .closest('.form-group').removeClass('has-error'); // set error class to the control group
            },

            success: function(label) {
				 
                label
                    .closest('.form-group').removeClass('has-error'); // set success class to the control group
            }
        });
		 
    }
 

    return {
        //main function to initiate the module
        init: function() {
            overlaymessage1(); 
        }
    };
}();

jQuery(document).ready(function() {
	 
    overlaymessage.init();
});
	 