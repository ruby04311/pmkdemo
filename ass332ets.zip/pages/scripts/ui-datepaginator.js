var UIDatepaginator = function () {

    return {

        //main function to initiate the module
        init: function () {
var options = {
	endDate: '2016-10-29', 
    endDateFormat:  'YYYY-MM-DD',
	  onSelectedDateChanged: function(event, date) {
	var d = new Date(date);
						$.ajax({
					url: WEB_URL+"/department_do/change_department_status_active/"+$id,  
					success:function(data) {
					   
					}
				  });
	  }
}
$('#datepaginator_sample_4').datepaginator(options);
            //sample #1
            $('#datepaginator_sample_1').datepaginator(options);

            //sample #2
            $('#datepaginator_sample_2').datepaginator({
                size: "large"
            });

            //sample #3
            $('#datepaginator_sample_3').datepaginator({
                size: "small"
            });

            //sample #3
            $('#datepaginator_sample_4s').datepaginator({
                onSelectedDateChanged: function(event, date) {
                  alert("Selected date: " + moment(date).format("Do, MMM YYYY"));
                }
            });
            
        } // end init

    };

}();

jQuery(document).ready(function() {    
   UIDatepaginator.init();
});