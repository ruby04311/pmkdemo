var UINotific8 = function () {

    return {
        //main function to initiate the module
        init: function () {

            
                    $('.notific8_show1, .notific8_show').click(function(event) {
						 
						 setTimeout(function(){
 
					 var table = $('#example').DataTable();
   				      $total_rows = table.rows().count();
	  			//alert($total_rows);
						var val_v1 = [];
						table.$('input[type="checkbox"]').each(function(i){
						  if(this.checked){
							 val_v1[i] = $(this).val();
						  }
						});
						$("#asd").val(val_v1);
}, 250);
						if($(this).is(':checked'))
             			{ 
 						 
						/*if ($('.notific8_show:checked').length == $total_rows) {
							//alert('all');
						}*/
							notificationClass = "" + notific8Defaults.namespace + "-notification";
							notifications = document.getElementsByClassName(notificationClass);
							  			 
							if(notifications.length<=0)
							{
								 $.getJSON("/select.php",{id: $(this).val(), ajax: 'true'}, function(j){
								  var options = '';
								  for (var i = 0; i < j.length; i++) {
									options += '<option value="' + j[i].optionValue + '">' + j[i].optionDisplay + '</option>';
								  }
								  $("select#statusvalue").html(options);
								})
	
								
								notific8('configure', { queue: false,zindex: 11500, 
							  onClose: function(notification, data) {
								notific8('remove');
							  } });
							 	notific8('<input type="hidden" class="form-control" id="asd" name="" value=""><div class="input-group"><span class="input-group-addon bg-green border-green font-green "><i class="fa fa-arrows font-white"></i> </span><select id="statusvalue" class="form-control " style="width:164px!important;"><option>Option 1</option><option>Option 2</option><option>Option 3</option><option>Option 4</option><option>Option 5</option></select><span class="input-group-btn"><button id="genpassword" class="btn btn-success" type="button"><i class="fa fa-arrow-left fa-fw"></i> Change Status</button></span></div><br/><br/><button type="button" class="btn btn-danger">Send Email</button>&nbsp;&nbsp;<button type="button" class="btn btn-info"><i class="fa fa-download"></i> PDF</button>&nbsp;&nbsp;<button type="button" class="btn btn-info"><i class="fa fa-download"></i>  Excel</button>', { sticky: true });
							}
							
  
						}
						else
						{
							 setTimeout(function(){
 
					 var table = $('#example').DataTable();
   				      $total_rows = table.rows().count();
					$total_rows_ =table.$("[type=checkbox]:checked").length;
					if ($total_rows_ == 0) {
 								notific8('remove');
							}
}, 300);
							
					//  alert($total_rows);
						  /* if ($('.notific8_show:checked').length == 0) {
							   $('.notific8_show1').attr('checked', false);
								notific8('remove');
							}*/
							
						}
					 
                    });
					

        }

    };

}();

jQuery(document).ready(function() {    
   //UINotific8.init();
});